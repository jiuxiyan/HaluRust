# CVE held-out semantic tests 扩展方案

版本：v1  
制定日期：2026-07-31  
目标数据集：`cve_safe_func_synth_without_data_race_v2/`  
目标 private evaluator：`heldout_eval_private_cve/`

## 1. 目标与范围

本方案为 CVE function-level benchmark 建立一套独立、不可被 Miragent 修复流程读取的 held-out semantic tests，用于在修复完成后回答两个彼此独立的问题：

1. 最终补丁是否消除了原 CVE 对应的内存安全问题；
2. 最终补丁是否保持了缩减程序中能够由可靠证据确定的功能语义、错误语义和状态不变量。

本轮数据集固定为 `cve_safe_func_synth_without_data_race_v2/` 中的 62 个 PASS case。数据集成员资格与 oracle 覆盖率必须分开记录：manifest 始终包含 62 条；oracle census 另外记录 E/P/N；不得为了提高覆盖率而静默删除困难案例。

本方案不包含以下内容：

- 不修改 CVE 数据集中的 `source.rs`、`test.rs`、`meta.json` 或 `audit.json`；
- 不把 held-out 结果反馈给修复、reflection、RAG 或再次采样流程；
- 不把 Miragent、HaluRust 或任何 baseline 的修复输出当作标准答案；
- 不要求补丁采用某一种具体内部实现，只约束有证据支持的可观察语义。

## 2. 已确认的数据集事实

数据集当前具有以下冻结特征：

- 62 个 `CVE-*` case 目录；
- 每个目录包含 `source.rs`、`test.rs`、`meta.json`、`audit.json`；
- 总文件数为 `62 × 4 + README.md = 249`；
- 62 条均在审计中标记为 PASS；
- 原 65 条中的 3 个 data-race case 已排除：`CVE-2020-13759`、`CVE-2020-35882`、`CVE-2020-35886`；
- 28 条具有 `vulnerable_revision_fetched_and_miri_confirmed` upstream 证据；
- 34 条主要依赖本地重建、审计说明和 Miri evidence；
- 每条具有 1–3 个公开 normal tests 和 1–3 个公开漏洞触发 tests。

以 `audit.json.expected_ub_kinds` 为最终漏洞分类依据，分布如下：

| UB 类型 | case 数 |
|---|---:|
| `uninitialized_memory` | 21 |
| `out_of_bounds` | 18 |
| `use_after_free` | 17 |
| `invalid_alignment` | 2 |
| `invalid_value` | 2 |
| `invalid_deref` | 1 |
| `stacked_borrows` | 1 |
| 合计 | 62 |

个别 `meta.json.initial_ub_kind` 仍为 `unknown`，但对应 `audit.json` 已给出审计后的 `expected_ub_kinds`，因此 manifest 和 oracle 设计不得回退使用旧的 `unknown` 值。

## 3. Private evaluator 目录结构

最终目录结构为：

```text
heldout_eval_private_cve/
├── README.md
├── CVE_HELDOUT_SEMANTIC_TESTS_EXPANSION_PLAN.md
├── manifests/
│   ├── cve_dataset_manifest_v1.json
│   ├── oracle_census_v1.json
│   └── oracle_validation_summary_v1.json
├── cases/
│   └── CVE-YYYY-NNNNN/
│       ├── case.toml
│       ├── semantic_tests.rs
│       ├── reference_fix.rs
│       ├── oracle.md
│       └── mutants/
│           ├── mutant_01.rs
│           ├── mutant_02.rs
│           ├── mutant_03.rs
│           └── mutant_04.rs
└── runner/
    ├── __init__.py
    ├── build_manifest.py
    ├── build_census.py
    ├── evaluate.py
    ├── batch_evaluate.py
    ├── audit_suite.py
    └── generate_batch*.py
```

所有 runner 都必须从自身位置推导路径：

```python
PRIVATE_ROOT = Path(__file__).resolve().parents[1]
PROJECT_ROOT = PRIVATE_ROOT.parent
```

不得再次写死 `heldout_eval_private_cve` 或其他 private 目录名称。

## 4. 隔离与防泄漏要求

目录名中的 `private` 不是安全边界。正式论文实验必须采用实际的访问隔离：

1. 修复阶段不挂载 `heldout_eval_private_cve/`；
2. private tests、reference fixes、mutants 和 oracle 文档放在独立 private repository 或受保护 CI artifact；
3. Miragent 只读取公开数据集文件以及公开测试；
4. 修复过程结束并写出不可变 final patch 后，evaluation job 才挂载 private evaluator；
5. evaluator 不调用修复 pipeline，也不重试或修改补丁；
6. per-case held-out 失败信息不得进入 reflection、prompt、RAG 或后续修复轮次；
7. 面向论文的公开结果只包含聚合统计和必要的错误类别，不公开隐藏断言、输入和 mutants；
8. 本地构造期间允许同处一个 workspace，但不得据此宣称实验已经实现盲测隔离。

## 5. 阶段 A：建立 62 条冻结 manifest

首先实现 `runner/build_manifest.py`，生成 `manifests/cve_dataset_manifest_v1.json`。每条 case 至少记录：

- `cve_id`、project、CWE；
- `source.rs`、`test.rs`、`meta.json`、`audit.json` 的相对路径、大小和 SHA-256；
- `audit.json.disposition`；
- `audit.json.expected_ub_kinds`；
- `target_tests` 和 `normal_tests` 名称；
- upstream verification 状态；
- audit batch、mapping、rationale 摘要；
- oracle level、实现状态和 selection batch；
- 数据集 commit、仓库 freeze commit；
- rustc、cargo、Miri 和 pinned nightly 信息；
- `visible_to_repair=false` 和 `repair_feedback_allowed=false`。

构建器必须执行以下硬性检查：

- case 目录数严格等于 62；
- case ID 与目录名、`meta.json.cve_id`、`audit.json.cve_id` 一致；
- 四个输入文件全部存在；
- 62 条 disposition 均为 PASS；
- `expected_ub_kinds` 非空且属于允许集合；
- manifest 不包含 3 个已排除 data-race case；
- `--check` 在文件变化、hash 漂移、数量变化或元数据不一致时非零退出。

manifest 生成后视为数据集冻结点。后续扩展只能更新 oracle 字段和 private artifacts，不能无记录地改变公开输入。

## 6. 阶段 B：全量 E/P/N oracle census

在写 pilot tests 前先审查全部 62 条，生成 `oracle_census_v1.json`。

### 6.1 Oracle 等级

- `E`：完整覆盖当前缩减 benchmark 的公开安全接口，包括正常返回、错误返回、关键状态转换和资源生命周期；不要求覆盖原 upstream crate 的全部语义。
- `P`：对漏洞相关安全入口、核心功能和关键不变量存在高可信 executable oracle，但部分辅助接口或内部行为没有被完整规定。
- `N`：当前证据不足以独立确定可靠功能语义，不能安全编写 oracle。

所有 62 条保留在 census 中。最终目标为 `E + P = 62`；如果出现 N，必须记录缺失证据并单独升级审查，不得编造断言或从 manifest 删除。

### 6.2 每条 census 的审查字段

每条至少记录：

- 公开或 benchmark-level safe entry；
- 原漏洞触发序列；
- 修复后必须保持的正常行为；
- 错误、拒绝或 panic 合同；
- 长度、容量、顺序、所有权、Drop 等状态不变量；
- 可以合法测试的边界；
- 明确不应规定的行为；
- 证据来源及强度；
- oracle level 与置信度；
- 推荐 Miri profiles；
- 预计测试数量和实现复杂度；
- test module 注入时的接口/可见性限制。

### 6.3 证据优先级

1. 已验证的 upstream vulnerable/fixed revision 与补丁；
2. `audit.json` 中的安全入口、trigger、invariant、rationale 和 mapping；
3. 缩减后的 `source.rs` 公开 API、类型和文档；
4. 公开 normal tests 所表达的行为；
5. Miri evidence 对漏洞类别和触发位置的确认。

公开 `test.rs` 可用于理解合同，但不得直接复制为 held-out tests。Miragent 或 baseline 的输出只能作为后续被评估对象，不能成为 oracle 证据。

## 7. 阶段 C：测试设计规范

### 7.1 每条 case 的测试规模

每条至少 5 个 held-out tests，通常为 6–8 个：

| 维度 | 建议数量 |
|---|---:|
| 正常功能和返回值 | 1–2 |
| 漏洞回归与 Miri 安全性 | 1–2 |
| 边界值和错误路径 | 1–2 |
| 状态、所有权或 Drop 不变量 | 1 |
| 重复操作或操作序列 | 0–1 |

全量预计：

- 硬下限：310 tests；
- 目标：约 372 tests，即平均 6 tests/case；
- 合理范围：310–450；
- 超过 8 tests/case 时应在 `oracle.md` 解释额外覆盖维度；
- 少于 5 tests/case 仅允许用于极小接口，并须解释为何不存在更多独立边界。

### 7.2 通用边界矩阵

按接口相关性选择，不能机械套用：

- 空输入、单元素、多元素；
- `capacity - 1`、`capacity`、`capacity + 1`；
- offset 0、最后一个合法位置、越界一位；
- `checked_add` 溢出和长度乘法溢出；
- 截断输入、精确长度、附加尾部数据；
- 成功、部分成功、失败；
- 操作失败或 panic 后状态保持；
- push/pop/insert/remove/clear 的重复序列；
- clone、move、drop、重新分配后的行为；
- 1/2/8/16/32 字节对齐需求；
- partial read、EOF、I/O error；
- DropCounter 验证资源恰好释放一次；
- 合法 ZST、大对齐类型或带 Drop 类型，仅在接口合同相关时使用。

### 7.3 按 UB 类型的最低覆盖重点

#### `uninitialized_memory`

- 初始化长度与逻辑长度一致；
- 部分读取、EOF、错误返回时不读取未初始化字节；
- 成功路径只暴露已初始化区域；
- 失败后长度、游标或容器状态不虚增；
- 带 Drop 元素时不析构未初始化槽位。

#### `out_of_bounds`

- 空、边界内最后位置、精确边界和越界一位；
- offset/length 加法溢出；
- 错误路径不产生引用或 slice；
- 成功返回的 slice/引用长度准确；
- 原漏洞形状的 safe call 在修复后无 Miri UB。

#### `use_after_free`

- 删除、替换、clear、drop 后不存在悬垂访问；
- iterator/reference 生命周期与容器操作一致；
- clone/move 后所有权关系正确；
- DropCounter 证明无 double-drop、漏析构或重复释放；
- 重复插入删除后状态和顺序保持。

#### `invalid_alignment`

- 多种对齐类型，至少包含漏洞相关的大对齐类型；
- 元素地址满足 `align_of::<T>()`；
- push/deref/drop 的完整序列在 Miri 下通过；
- 普通对齐类型的原有行为不被破坏。

#### `invalid_value` / `invalid_deref`

- 在构造引用或读取值前拒绝非法状态；
- null、无效 sentinel 或非法 bit pattern 不被转换为 Rust reference/value；
- 合法输入仍保留原返回值；
- 错误或 panic 后对象保持可安全销毁的状态。

#### `stacked_borrows`

- clone、drop、lookup 或 mutation 的关键次序；
- 不通过失效 provenance 继续访问；
- 空、单元素和重复操作；
- 在适用的 borrow-model profiles 下均通过。

### 7.4 防止过拟合实现

优先测试公开 safe API。只有公开结果无法观察且 audit 明确规定局部不变量时，才允许 child test module 访问私有项；此时一般只能标为 P，并在 `oracle.md` 说明原因。

禁止把以下内容当作语义要求：

- 与安全合同无关的具体字段布局；
- 某一种分配策略或修复算法；
- 私有辅助函数必须存在；
- 没有 source、audit 或 upstream 证据支持的错误值；
- 对违反 unsafe 前置条件的调用强行定义结果。

每条至少有一个对具体值/状态的断言，不能只用“函数完成且未崩溃”充当全部语义 oracle。

## 8. Held-out 独立性规则

`semantic_tests.rs` 不得逐字复制公开 `test.rs`：

- 不复用公开测试函数名；
- 不复制完整测试体；
- 不复用相同的全部常量和输入组合；
- 不把公开 target test 改名后作为隐藏测试；
- 不依赖公开 test module 中的 helper；
- 应使用新的输入、边界、操作序列或等价关系。

允许测试同一个公开合同，但必须形成独立观察。例如公开测试只检查长度时，held-out 可以检查内容、顺序、错误后状态和重复操作。

`audit_suite.py` 至少检查测试文件与公开 `test.rs` 的 hash 不同、隐藏测试函数名不与公开测试重合；语义独立性仍需在 `oracle.md` 中人工说明。

## 9. 阶段 D：Reference、原漏洞和 mutants 三重校准

### 9.1 Reference positive control

每条建立 evaluator-owned `reference_fix.rs`。reference 必须：

- 保持受保护的公开/benchmark-level API；
- 通过全部 held-out tests；
- 在全部声明 profiles 下无 Miri UB；
- 通过必要的公开 normal behavior；
- 与 `oracle.md` 的合同一致。

对于 upstream-verified case，reference 优先依据 upstream fixed behavior 适配；对于 local-only case，依据 audit、缩减 API 和公开 normal behavior 独立构造。不得直接采用 Miragent 或 baseline 产物作为 reference。

### 9.2 Vulnerable-source negative control

每条原始 `source.rs` 必须被 held-out suite 拒绝，拒绝原因可以是：

- Miri 检出目标 UB；
- 边界/错误行为断言失败；
- 安全入口未正确拒绝非法请求。

这项检查证明 suite 能捕获原漏洞。若原 source 在所有 held-out tests 下通过，该 case 的 oracle 不得验收。

### 9.3 Mutation validation

每条至少 4 个定向 mutants，总计至少 248 个。mutants 应覆盖不同错误族：

1. 移除或放宽关键边界/状态检查；
2. off-by-one 或错误长度；
3. 恢复原 unsafe 操作、释放次序或引用构造；
4. 破坏功能返回值、顺序、状态或错误语义；
5. 复杂 case 可额外增加“永远返回错误/空值”的退化修复。

验收条件为 reference 全通过、原 vulnerable source 被拒绝、全部 expected-fail mutants 被杀死。mutant 若存活，必须增强测试或在 `oracle.md` 明确记录不可观察限制，不能把存活 mutant 默认为通过。

## 10. Miri toolchain 与 profiles

冻结时记录完整 rustc、cargo、Miri 版本，并使用明确日期的 nightly，而不是长期依赖移动的 `nightly` alias。

profiles 原则：

- 所有 case：默认 Miri profile；
- raw pointer/provenance：经当前工具链验证后增加 strict-provenance profile；
- aliasing/stacked-borrows：增加适用 borrow-model profile；
- alignment：增加当前 Miri 支持的 alignment-sensitive profile；
- allocator/drop/UAF：增加资源生命周期相关配置；
- 每个 flag 必须先通过 pilot 验证，未知或已移除 flag 不得写入批量配置。

profile 不是越多越好。仅添加能观察该 case 合同且不会引入无关平台差异的配置。

## 11. 阶段 E：Evaluator 与结果协议

单例接口：

```bash
python3 heldout_eval_private_cve/runner/evaluate.py \
  --case CVE-2020-25794 \
  --fixed /path/to/cve_2020_25794_fixed.rs \
  --output /tmp/CVE-2020-25794.semantic.json
```

执行流程：

1. 加载 case 配置和 manifest；
2. 重新计算四个公开输入文件的 hash；
3. 读取已经完成的 final patch；
4. 创建隔离临时 Cargo library；
5. 将 private tests 作为 child module 注入；
6. 逐一运行声明的 Miri profiles；
7. 分类输出，不修改或重试补丁；
8. 删除临时 crate。

状态协议：

- `pass`：全部 profiles 和断言通过；
- `hidden_ub`：Miri 发现 UB/unsupported operation；
- `semantic_fail`：held-out assertion 或测试失败；
- `compile_fail`：补丁不满足受保护 API 或无法与 oracle 编译；
- `timeout`：超出 case timeout；
- `missing_patch`：没有最终补丁；
- `not_evaluable`：工具链、配置或 evaluator 本身问题。

`compile_fail`、`timeout`、`missing_patch` 和 `not_evaluable` 必须与语义断言失败分开统计，不能算作 pass。

## 12. Batch evaluator 与修复产物解析

批量 evaluator 支持显式 adapter，并兼容当前常见布局：

```text
<result-root>/<CVE-ID>/<cve_slug>_fixed.rs
<result-root>/<CVE-ID>/<cve_slug>_last.rs
<result-root>/<CVE-ID>/result.json
```

解析优先级：

1. 命令行显式映射的 final patch；
2. `result.json` 明确指向的产物；
3. 唯一的 `*_fixed.rs`；
4. 仅在要求评估失败修复时使用唯一的 `*_last.rs`；
5. 多文件歧义直接标记 `not_evaluable`，不得选择目录中“第一个 `.rs`”。

汇总至少报告：

- frozen dataset cases；
- implemented E/P oracles 和 oracle coverage；
- requested/provided/evaluable patches；
- semantic passes；
- consistency rate on all 62；
- consistency rate on evaluable patches；
- 每种状态计数；
- per-case JSON 路径；
- evaluator/toolchain version。

## 13. 扩展批次安排

### 13.1 Pilot：5 条

先实现以下五条，以校准 evaluator、测试模板和 mutation 强度：

| Case | 主要覆盖 |
|---|---|
| `CVE-2020-25794` | invalid alignment、容器长度、push/deref/drop、upstream evidence |
| `CVE-2023-41051` | out-of-bounds、trait 返回长度、边界和溢出拒绝 |
| `CVE-2021-45720` | use-after-free、iterator、删除后的状态和 Drop |
| `CVE-2021-25905` | uninitialized memory、I/O 长度、partial read/EOF |
| `CVE-2020-35923` | invalid value、panic safety、失败后不变量 |

Pilot 结束后才能冻结以下实现细节：

- `case.toml` schema；
- test module 注入方式；
- profile 名称和 flags；
- timeout；
- mutant 表达形式；
- 输出 JSON schema；
- 每条 5–8 tests 的实际成本。

### 13.2 Batch 2：10 条

优先纳入剩余稀有类别：

- `CVE-2019-16882`：stacked borrows；
- `CVE-2020-35860`：invalid dereference；
- `CVE-2021-45709`：第二条 invalid alignment；
- `CVE-2020-35888`：另一条 invalid value；
- 其余 6 条从 uninitialized/OOB/UAF 各选择 2 条。

该批次完成后，所有稀有 UB 类型都应至少有一个正式 oracle 模板。

### 13.3 Batch 3–7

剩余 47 条按 `10 + 10 + 10 + 10 + 7` 扩展。每批同时平衡：

- uninitialized/OOB/UAF 三个主要类别；
- upstream-verified 与 local-only；
- 简单函数、I/O、泛型容器和状态机；
- E 与 P；
- source 规模和预计 Miri 运行成本。

不得单纯按 CVE ID 或目录字母顺序分批，以免前几个批次只验证一种测试模式。

## 14. 每批完成门槛

每个批次只有同时满足以下条件才算完成：

- case 目录和四个 private artifacts 完整；
- `case.toml` 身份、source hashes、profiles、test count 正确；
- hidden test 函数名不与公开 tests 重复；
- 每条至少覆盖正常语义、漏洞回归和一个边界/状态维度；
- reference 在所有 profiles 下通过；
- 原 vulnerable source 被拒绝；
- 每条至少 4 个 expected-fail mutants 且全部被杀死；
- 无随机、网络、时钟、环境变量或未声明平台依赖；
- manifest 和 census 可使用 `--check` 重建；
- suite audit 通过；
- validation summary 更新；
- 批次结果不会反馈给修复 agent。

## 15. Suite audit 要求

`runner/audit_suite.py` 至少检查：

- manifest 和 census 均恰好有 62 个唯一 case；
- case 目录集合等于 E/P 集合；
- manifest、census、validation 的 ID 一致；
- 公开输入当前 hash 等于冻结 hash；
- 每个 case 的 `case.toml`、tests、reference、oracle 文档齐全；
- test count 与 `#[test]` 实际数量一致；
- public/hidden 测试函数名无重合；
- reference 与 semantic tests 不是同一文件；
- vulnerable-source negative control 已记录为失败；
- 每条至少 4 个 mutants；
- validation totals 等于磁盘实际 totals；
- batch counts 相加等于 implemented oracle cases；
- 不存在 manifest 外的额外 case 目录。

## 16. Validation summary

`oracle_validation_summary_v1.json` 至少记录：

- manifest/census ID；
- validation 日期和 pinned toolchain；
- E/P/N 数量；
- reference passes；
- vulnerable sources caught；
- held-out test 总数；
- mutants total/killed/survived；
- 每个 batch 的 case/test/mutant 数；
- profile 运行数；
- timeout 或平台限制；
- 已知 oracle 局限。

最终 paper run 必须重新生成一份独立 validation summary，不能仅复用构造期间的缓存结果。

## 17. 主要风险及控制

| 风险 | 控制措施 |
|---|---|
| 隐藏测试泄漏给 Miragent | 独立 private repo/CI artifact，修复结束后才挂载 |
| 复制公开测试导致不是真正 held-out | 新输入、新操作序列、函数名去重、人工证据说明 |
| 测试过拟合某种修复实现 | 优先公开 API，只断言可观察合同 |
| local-only case 证据不足 | 降为 N 并升级审查，不凭推测写断言 |
| 只检查无 UB、不检查功能 | 每条至少一个具体值/状态断言和 mutation validation |
| 只检查普通行为、抓不到原漏洞 | 原 vulnerable source 必须被 suite 拒绝 |
| moving nightly 导致漂移 | 固定 nightly 日期和 Miri 版本 |
| 合法 API 变化导致假 compile fail | `oracle.md` 明确受保护符号和签名，必要时使用适配层 |
| batch evaluator 选错补丁文件 | 显式 adapter 和严格无歧义解析规则 |
| Miri 运行时间过长 | pilot 测量、case timeout、1–2 workers、按需 profiles |

## 18. 预期最终规模与完成定义

目标最终状态：

```text
frozen dataset cases        = 62
oracle census cases         = 62
implemented E + P oracles   = 62
held-out tests              = 310–450，目标约 372
reference fixes passed      = 62/62
vulnerable sources caught   = 62/62
mutants                     >= 248
expected mutants killed     = 100%
public hidden-name overlap  = 0
suite audit                 = pass
```

只有在 62 条全部具有可辩护的 E/P oracle、原漏洞全部被捕获、reference 全通过且 expected mutants 全部被杀死后，才能宣称 CVE held-out semantic test 扩展完成。

## 19. 执行顺序

1. 创建 CVE evaluator 骨架；
2. 构建并冻结 62 条 dataset manifest；
3. 对 62 条执行完整 E/P/N census；
4. 实现并校准 5 条 pilot；
5. 冻结 schema、profiles 和质量门槛；
6. 完成 batch 2 的 10 条；
7. 依次完成 batch 3–7；
8. 运行全量 reference/vulnerable/mutant validation；
9. 生成 validation summary 和 suite audit；
10. 将 private evaluator 迁移到正式隔离环境；
11. 仅对已经完成的 final patches 运行 post-hoc paper evaluation。
