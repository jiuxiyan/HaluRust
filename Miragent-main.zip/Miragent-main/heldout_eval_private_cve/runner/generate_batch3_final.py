#!/usr/bin/env python3
"""Finish remaining batch_3 cases using surgically fixed references."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from case_writer import mutation, write_case

FIX_ROOT = Path("/tmp/cve_batch3_fix")


def cases() -> list[dict]:
    return [
        {
            "id": "CVE-2019-15554",
            "batch": "batch_3",
            "contract": "SmallVec::grow refuses capacities below len; push/spill keep values.",
            "evidence": "audit OOB; grow shrinks heap below len",
            "dimensions": "inline; spill; grow below len panics; capacity; values",
            "symbols": ["SmallVec::new", "push", "grow", "len", "spilled"],
            "tests": '''
                use std::panic;
                #[test]
                fn heldout_inline_push() {
                    let mut sv: SmallVec<u32, 4> = SmallVec::new();
                    sv.push(1); sv.push(2);
                    assert!(!sv.spilled());
                    assert_eq!(sv.len(), 2);
                }
                #[test]
                fn heldout_spill_via_push() {
                    let mut sv: SmallVec<u32, 2> = SmallVec::new();
                    sv.push(1); sv.push(2); sv.push(3);
                    assert!(sv.spilled());
                    assert_eq!(sv.len(), 3);
                }
                #[test]
                fn heldout_grow_below_len_rejected() {
                    let mut sv: SmallVec<String, 2> = SmallVec::new();
                    sv.push("a".into()); sv.push("b".into()); sv.push("c".into());
                    let panicked = panic::catch_unwind(panic::AssertUnwindSafe(|| sv.grow(1)));
                    assert!(panicked.is_err());
                    assert_eq!(sv.len(), 3);
                }
                #[test]
                fn heldout_grow_up_keeps_len() {
                    let mut sv: SmallVec<u32, 2> = SmallVec::new();
                    sv.push(4); sv.push(5); sv.push(6);
                    let old = sv.capacity();
                    sv.grow(old + 4);
                    assert_eq!(sv.len(), 3);
                    assert!(sv.capacity() >= old + 4);
                }
                #[test]
                fn heldout_empty_len() {
                    let sv: SmallVec<u8, 3> = SmallVec::new();
                    assert_eq!(sv.len(), 0);
                }
            ''',
            "reference": FIX_ROOT.joinpath("CVE-2019-15554.rs").read_text(encoding="utf-8"),
            "mutants": [
                mutation("remove_grow_guard", "assert!(new_capacity >= self.len, \"cannot grow below length\");\n        ", "", "allows shrink below len"),
                mutation("push_skips_len", "self.len += 1;", "self.len += 0;", "skips len increment"),
                mutation("grow_forces_cap_one", "cap: new_capacity,", "cap: 1,", "forces tiny capacity"),
                mutation("spilled_always_false", "SmallVecData::Heap { .. } => true,", "SmallVecData::Heap { .. } => false,", "lies about spilled"),
            ],
        },
        {
            "id": "CVE-2020-25795",
            "batch": "batch_3",
            "contract": "Chunk::insert_from uses a hole-closing guard so panicking iterators cannot leave uninit slots in Drop.",
            "evidence": "audit uninit/double-drop; right bumped before iter finishes",
            "dimensions": "normal insert; panic safety; push; index; len",
            "symbols": ["Chunk::new", "push_back", "insert_from", "len"],
            "tests": '''
                use std::panic;
                #[test]
                fn heldout_push_back_sequence() {
                    let mut chunk: Chunk<i32, 32> = Chunk::new();
                    for i in 0..5 { chunk.push_back(i); }
                    assert_eq!(chunk.len(), 5);
                    assert_eq!(chunk[0], 0);
                    assert_eq!(chunk[4], 4);
                }
                #[test]
                fn heldout_insert_from_middle() {
                    let mut chunk: Chunk<String, 32> = Chunk::new();
                    for i in 0..5 { chunk.push_back(format!("e{i}")); }
                    chunk.insert_from(2, vec!["n0".into(), "n1".into(), "n2".into()].into_iter());
                    assert_eq!(chunk.len(), 8);
                    assert_eq!(chunk[2], "n0");
                    assert_eq!(chunk[5], "e2");
                }
                #[test]
                fn heldout_insert_panic_is_drop_safe() {
                    struct PanicIter { items: Vec<String>, pos: usize, panic_at: usize }
                    impl Iterator for PanicIter {
                        type Item = String;
                        fn next(&mut self) -> Option<String> {
                            if self.pos == self.panic_at { panic!("iterator panic"); }
                            if self.pos >= self.items.len() { return None; }
                            let v = self.items[self.pos].clone();
                            self.pos += 1; Some(v)
                        }
                    }
                    impl ExactSizeIterator for PanicIter {
                        fn len(&self) -> usize { self.items.len() - self.pos }
                    }
                    let mut chunk: Chunk<String, 32> = Chunk::new();
                    for i in 0..4 { chunk.push_back(format!("item_{i}")); }
                    let iter = PanicIter { items: vec!["a".into(), "b".into(), "c".into()], pos: 0, panic_at: 1 };
                    let result = panic::catch_unwind(panic::AssertUnwindSafe(|| chunk.insert_from(2, iter)));
                    assert!(result.is_err());
                }
                #[test]
                fn heldout_insert_at_end() {
                    let mut chunk: Chunk<u32, 16> = Chunk::new();
                    chunk.push_back(1); chunk.push_back(2);
                    chunk.insert_from(2, [3u32, 4].into_iter());
                    assert_eq!(chunk.len(), 4);
                    assert_eq!(chunk[3], 4);
                }
                #[test]
                fn heldout_empty_then_push() {
                    let mut chunk: Chunk<u8, 8> = Chunk::new();
                    assert_eq!(chunk.len(), 0);
                    chunk.push_back(9);
                    assert_eq!(chunk[0], 9);
                }
            ''',
            "reference": FIX_ROOT.joinpath("CVE-2020-25795.rs").read_text(encoding="utf-8"),
            "mutants": [
                mutation(
                    "remove_hole_guard",
                    "let mut guard = HoleGuard {\n            chunk: self,\n            gap_start: real_index,\n            gap_size: insert_size,\n            initialized: 0,\n        };\n        let mut write_idx = real_index;\n        for val in iter {\n            guard.chunk.data[write_idx] = MaybeUninit::new(val);\n            write_idx += 1;\n            guard.initialized += 1;\n        }\n        // Success: leave the claimed length intact.\n        mem::forget(guard);",
                    "let mut write_idx = real_index;\n        for val in iter {\n            self.data[write_idx] = MaybeUninit::new(val);\n            write_idx += 1;\n        }",
                    "restores unguarded insert after right bump",
                ),
                mutation("push_skips_right", "self.right += 1;", "self.right += 0;", "skips push length"),
                mutation(
                    "insert_ignores_values",
                    "guard.chunk.data[write_idx] = MaybeUninit::new(val);",
                    "core::mem::forget(val);",
                    "drops inserted values",
                ),
                mutation("len_always_zero", "self.right - self.left", "0", "lies about len"),
            ],
        },
        {
            "id": "CVE-2020-35861",
            "batch": "batch_3",
            "contract": "Bump realloc never uses the unsound delta-extension fast path; Vec push/resize stay safe.",
            "evidence": "audit OOB; realloc copies new_size from old_size allocation",
            "dimensions": "push within cap; resize grow; values; empty",
            "symbols": ["Bump::new", "Vec::with_capacity_in", "push", "resize"],
            "tests": '''
                #[test]
                fn heldout_push_within_capacity() {
                    let bump = Bump::new();
                    let mut v = Vec::with_capacity_in(8, &bump);
                    v.push(10u32);
                    v.push(20u32);
                    assert_eq!(v.len, 2);
                    unsafe {
                        assert_eq!(*v.buf.ptr.as_ptr(), 10);
                        assert_eq!(*v.buf.ptr.as_ptr().add(1), 20);
                    }
                }
                #[test]
                fn heldout_resize_grow_is_safe() {
                    let bump = Bump::new();
                    let mut v = Vec::with_capacity_in(4, &bump);
                    v.push(1u8); v.push(2); v.push(3); v.push(4);
                    v.resize(64, 0u8);
                    assert_eq!(v.len, 64);
                    unsafe { assert_eq!(*v.buf.ptr.as_ptr(), 1); }
                }
                #[test]
                fn heldout_resize_same_len() {
                    let bump = Bump::new();
                    let mut v = Vec::with_capacity_in(4, &bump);
                    v.push(7u8);
                    v.resize(1, 0);
                    assert_eq!(v.len, 1);
                }
                #[test]
                fn heldout_empty_vec() {
                    let bump = Bump::new();
                    let v: Vec<u8> = Vec::with_capacity_in(4, &bump);
                    assert_eq!(v.len, 0);
                }
                #[test]
                fn heldout_multiple_pushes() {
                    let bump = Bump::new();
                    let mut v = Vec::with_capacity_in(16, &bump);
                    for i in 0..8u32 { v.push(i); }
                    assert_eq!(v.len, 8);
                }
            ''',
            "reference": FIX_ROOT.joinpath("CVE-2020-35861.rs").read_text(encoding="utf-8"),
            "mutants": [
                mutation(
                    "restore_fast_path",
                    "if false {",
                    "if self.is_last_allocation(ptr) {",
                    "restores unsound delta-extension path",
                ),
                mutation(
                    "push_skips_len",
                    "        self.len += 1;\n    }\n\n    pub fn resize",
                    "        self.len += 0;\n    }\n\n    pub fn resize",
                    "skips push len",
                ),
                mutation(
                    "resize_ignores_new_len",
                    "self.len = new_len;",
                    "self.len = 0;",
                    "zeros len on resize",
                ),
                mutation(
                    "realloc_copy_too_much",
                    "ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_ptr(), old_size);",
                    "ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_ptr(), new_size);",
                    "OOB-reads old block during safe realloc",
                ),
            ],
        },
        {
            "id": "CVE-2019-15550",
            "batch": "batch_3",
            "contract": "parse_str refuses short buffers that cannot satisfy a 32-byte load; long quoted strings parse.",
            "evidence": "audit OOB; loadu_32 past short input",
            "dimensions": "short reject; long ok; emptyish; quote early; buffer",
            "symbols": ["parse_str", "SillyWrapper"],
            "tests": '''
                use std::marker::PhantomData;
                #[test]
                fn heldout_short_input_errors() {
                    let mut data = b"\\"short_string_no_quote".to_vec();
                    let mut buffer = vec![0u8; 1024];
                    let wrapper = SillyWrapper { input: data.as_mut_ptr(), _marker: PhantomData };
                    assert!(parse_str(wrapper, &data, &mut buffer, 0).is_err());
                }
                #[test]
                fn heldout_long_quoted_ok() {
                    let mut inner = [b'a'; 32];
                    inner[10] = b'"';
                    let mut data = vec![b'"'];
                    data.extend_from_slice(&inner);
                    let mut buffer = vec![0u8; 1024];
                    let wrapper = SillyWrapper { input: data.as_mut_ptr(), _marker: PhantomData };
                    let parsed = parse_str(wrapper, &data, &mut buffer, 0).unwrap();
                    assert_eq!(parsed, std::str::from_utf8(&inner[..10]).unwrap());
                }
                #[test]
                fn heldout_very_short_errors() {
                    let mut data = b"\\"ab".to_vec();
                    let mut buffer = vec![0u8; 64];
                    let wrapper = SillyWrapper { input: data.as_mut_ptr(), _marker: PhantomData };
                    assert!(parse_str(wrapper, &data, &mut buffer, 0).is_err());
                }
                #[test]
                fn heldout_quote_at_zero_distance() {
                    let mut data = b"\\"\\"".to_vec();
                    // still too short for 32-byte path
                    let mut buffer = vec![0u8; 64];
                    let wrapper = SillyWrapper { input: data.as_mut_ptr(), _marker: PhantomData };
                    assert!(parse_str(wrapper, &data, &mut buffer, 0).is_err());
                }
                #[test]
                fn heldout_long_no_early_quote_errors_or_finishes() {
                    let mut data = vec![b'"'];
                    data.extend(std::iter::repeat(b'x').take(40));
                    // no closing quote in first 32 of content after opening
                    let mut buffer = vec![0u8; 1024];
                    let wrapper = SillyWrapper { input: data.as_mut_ptr(), _marker: PhantomData };
                    let _ = parse_str(wrapper, &data, &mut buffer, 0);
                }
            ''',
            "reference": FIX_ROOT.joinpath("CVE-2019-15550.rs").read_text(encoding="utf-8"),
            "mutants": [
                mutation("remove_short_guard", "if src_i + 32 > src.len() {\n            return Err(ErrorType::Syntax);\n        }\n        ", "", "restores unbounded load"),
                mutation(
                    "always_err_first_quote",
                    "let v = str::from_utf8_unchecked(std::slice::from_raw_parts(\n                    input.add(idx),\n                    len,\n                ));\n                return Ok(v);",
                    "let v = str::from_utf8_unchecked(std::slice::from_raw_parts(\n                    input.add(idx),\n                    len,\n                ));\n                return Err(ErrorType::Syntax);",
                    "never returns Ok on first-path quote",
                ),
                mutation(
                    "wrong_quote_slice",
                    "input.add(idx),\n                    len,",
                    "input.add(idx),\n                    0,",
                    "returns empty string on quote",
                ),
                mutation("skip_idx_increment", "idx += 1;", "idx += 0;", "skips opening quote skip"),
            ],
        },
    ]


def main() -> int:
    for spec in cases():
        # references loaded from files are already final text; wrap for write_case dedent
        if not spec["reference"].startswith("\n"):
            spec["reference"] = "\n" + spec["reference"]
        write_case(spec)
        print(f"wrote cases/{spec['id']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
