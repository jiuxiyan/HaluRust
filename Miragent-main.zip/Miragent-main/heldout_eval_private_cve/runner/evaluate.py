#!/usr/bin/env python3
"""Evaluate final CVE patches against private held-out semantic tests."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

try:
    import tomllib
except ModuleNotFoundError:
    import tomli as tomllib


PRIVATE_ROOT = Path(__file__).resolve().parents[1]
PROJECT_ROOT = PRIVATE_ROOT.parent
DATASET_ROOT = PROJECT_ROOT / "cve_safe_func_synth_without_data_race_v2"
CASES_ROOT = PRIVATE_ROOT / "cases"
MANIFEST_PATH = PRIVATE_ROOT / "manifests" / "cve_dataset_manifest_v1.json"


def _case(case_id: str) -> tuple[Path, dict[str, Any], dict[str, Any]]:
    case_dir = CASES_ROOT / case_id
    with (case_dir / "case.toml").open("rb") as handle:
        config = tomllib.load(handle)
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    item = next((entry for entry in manifest["cases"] if entry["case_id"] == case_id), None)
    if item is None or config.get("case_id") != case_id:
        raise ValueError(f"unknown or mismatched case {case_id}")
    for name, expected in config["dataset_hashes"].items():
        actual = hashlib.sha256((DATASET_ROOT / case_id / name).read_bytes()).hexdigest()
        if actual != expected or item["files"][name]["sha256"] != actual:
            raise ValueError(f"frozen dataset hash mismatch for {case_id}/{name}")
    return case_dir, config, item


def _module(tests: str) -> str:
    return "\n#[cfg(test)]\nmod __cve_heldout_semantics {\nuse super::*;\n" + tests.rstrip() + "\n}\n"


def _classify(stdout: str, stderr: str) -> tuple[str, str]:
    text = (stdout + "\n" + stderr).lower()
    if "undefined behavior" in text or "unsupported operation" in text:
        return "hidden_ub", "Miri reported undefined or unsupported behavior"
    if "panicked at" in text or "test result: failed" in text:
        return "semantic_fail", "a held-out assertion or test failed"
    if "could not compile" in text or "error[e" in text or "error:" in text:
        return "compile_fail", "the patch does not compile with the held-out contract"
    return "not_evaluable", "Miri failed without a recognized outcome"


def run_source(case_id: str, source: str, tests: str, config: dict[str, Any], timeout: int | None = None) -> dict[str, Any]:
    results = []
    for profile in config.get("profiles", [{"name": "default", "flags": []}]):
        started = time.monotonic()
        with tempfile.TemporaryDirectory(prefix=f"cve-heldout-{case_id}-") as tmp:
            root = Path(tmp)
            (root / "src").mkdir()
            package = "heldout_" + re.sub(r"[^A-Za-z0-9_]", "_", case_id).lower()
            (root / "Cargo.toml").write_text(
                f'[package]\nname="{package}"\nversion="0.1.0"\nedition="2021"\npublish=false\n',
                encoding="utf-8",
            )
            (root / "src" / "lib.rs").write_text(source.rstrip() + "\n" + _module(tests), encoding="utf-8")
            env = os.environ.copy()
            env["CARGO_TARGET_DIR"] = str(root / "target")
            flags = profile.get("flags", [])
            if flags:
                env["MIRIFLAGS"] = " ".join(flags)
            else:
                env.pop("MIRIFLAGS", None)
            try:
                proc = subprocess.run(
                    ["cargo", f"+{config.get('toolchain', 'nightly')}", "miri", "test", "--quiet"],
                    cwd=root, env=env, capture_output=True, text=True,
                    timeout=timeout or int(config.get("timeout_seconds", 180)), check=False,
                )
            except subprocess.TimeoutExpired as exc:
                results.append({"profile": profile["name"], "status": "timeout", "passed": False,
                                "stdout_tail": (exc.stdout or "")[-3000:] if isinstance(exc.stdout, str) else "",
                                "stderr_tail": (exc.stderr or "")[-6000:] if isinstance(exc.stderr, str) else ""})
                continue
        if proc.returncode == 0:
            status, reason = "pass", "all held-out tests passed under Miri"
        else:
            status, reason = _classify(proc.stdout, proc.stderr)
        results.append({
            "profile": profile["name"], "flags": flags, "status": status,
            "passed": proc.returncode == 0, "reason": reason, "returncode": proc.returncode,
            "duration_s": round(time.monotonic() - started, 3),
            "stdout_tail": proc.stdout[-3000:], "stderr_tail": proc.stderr[-6000:],
        })
    passed = bool(results) and all(item["passed"] for item in results)
    return {"passed": passed, "status": "pass" if passed else results[0]["status"], "profiles": results}


def evaluate(case_id: str, source_path: Path, timeout: int | None = None) -> dict[str, Any]:
    case_dir, config, _ = _case(case_id)
    tests = (case_dir / "semantic_tests.rs").read_text(encoding="utf-8")
    if tests.count("#[test]") != config["test_count"]:
        raise ValueError(f"held-out test count mismatch for {case_id}")
    result = run_source(case_id, source_path.read_text(encoding="utf-8"), tests, config, timeout)
    return {"schema_version": 1, "case_id": case_id, "source_file": str(source_path), **result}


def validate_oracle(case_id: str, timeout: int | None = None) -> dict[str, Any]:
    case_dir, config, _ = _case(case_id)
    tests = (case_dir / "semantic_tests.rs").read_text(encoding="utf-8")
    reference_path = case_dir / config["oracle_validation"]["reference_fix"]
    reference = reference_path.read_text(encoding="utf-8")
    ref_result = run_source(case_id, reference, tests, config, timeout)
    vulnerable = (DATASET_ROOT / case_id / "source.rs").read_text(encoding="utf-8")
    vulnerable_result = run_source(case_id, vulnerable, tests, config, timeout)
    mutant_results = []
    for mutant in config["oracle_validation"].get("mutants", []):
        mutated = reference
        if "file" in mutant:
            mutated = (case_dir / mutant["file"]).read_text(encoding="utf-8")
        else:
            find, replace = mutant["find"], mutant["replace"]
            if mutated.count(find) != 1:
                raise ValueError(f"{case_id}/{mutant['name']}: mutation anchor must occur once")
            mutated = mutated.replace(find, replace, 1)
        result = run_source(case_id, mutated, tests, config, timeout)
        mutant_results.append({"name": mutant["name"], "expected": mutant["expected"], "killed": not result["passed"], **result})
    passed = ref_result["passed"] and not vulnerable_result["passed"] and all(item["killed"] for item in mutant_results)
    return {
        "schema_version": 1, "case_id": case_id, "passed": passed,
        "reference": ref_result, "vulnerable": {"caught": not vulnerable_result["passed"], **vulnerable_result},
        "mutants": mutant_results,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--case", required=True)
    parser.add_argument("--fixed", type=Path)
    parser.add_argument("--validate-oracle", action="store_true")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--timeout", type=int)
    args = parser.parse_args()
    if args.validate_oracle:
        result = validate_oracle(args.case, args.timeout)
    elif args.fixed:
        result = evaluate(args.case, args.fixed, args.timeout)
    else:
        parser.error("provide --fixed or --validate-oracle")
    content = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(content, encoding="utf-8")
    else:
        sys.stdout.write(content)
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
