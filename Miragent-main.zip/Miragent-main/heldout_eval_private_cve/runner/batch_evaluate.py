#!/usr/bin/env python3
"""Batch evaluate or validate CVE held-out oracles."""

from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from pathlib import Path

from evaluate import validate_oracle, evaluate


PRIVATE_ROOT = Path(__file__).resolve().parents[1]
MANIFEST_PATH = PRIVATE_ROOT / "manifests" / "cve_dataset_manifest_v1.json"
SUMMARY_PATH = PRIVATE_ROOT / "manifests" / "oracle_validation_summary_v1.json"
CASES_ROOT = PRIVATE_ROOT / "cases"


def _cases(batch: str | None) -> list[str]:
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    ids = []
    for item in manifest["cases"]:
        case_id = item["case_id"]
        if batch and item["oracle"]["selection_batch"] != batch:
            continue
        if not (CASES_ROOT / case_id / "case.toml").is_file():
            continue
        ids.append(case_id)
    return ids


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--validate-oracle", action="store_true")
    parser.add_argument("--batch")
    parser.add_argument("--result-root", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--timeout", type=int)
    parser.add_argument("--update-summary", action="store_true")
    args = parser.parse_args()
    case_ids = _cases(args.batch)
    if not case_ids:
        print("no implemented cases matched", file=sys.stderr)
        return 2
    results = []
    for case_id in case_ids:
        print(f"== {case_id} ==", flush=True)
        if args.validate_oracle:
            result = validate_oracle(case_id, args.timeout)
        else:
            if args.result_root is None:
                parser.error("--result-root required unless --validate-oracle")
            fixed = args.result_root / case_id
            candidates = list(fixed.glob("*_fixed.rs"))
            if len(candidates) != 1:
                result = {"case_id": case_id, "passed": False, "status": "not_evaluable",
                          "reason": f"ambiguous or missing fixed patch in {fixed}"}
            else:
                result = evaluate(case_id, candidates[0], args.timeout)
        results.append(result)
        print(f"{case_id}: {'PASS' if result.get('passed') else 'FAIL'}", flush=True)
    status = Counter()
    for item in results:
        if args.validate_oracle:
            status["pass" if item.get("passed") else "fail"] += 1
        else:
            status[item.get("status", "not_evaluable")] += 1
    payload = {
        "schema_version": 1,
        "mode": "validate_oracle" if args.validate_oracle else "evaluate",
        "batch": args.batch,
        "requested": len(case_ids),
        "status_counts": dict(status),
        "results": results,
    }
    content = json.dumps(payload, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(content, encoding="utf-8")
    else:
        sys.stdout.write(content)
    if args.update_summary and args.validate_oracle:
        _update_summary(results)
    return 0 if all(item.get("passed") for item in results) else 1


def _update_summary(results: list[dict]) -> None:
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    disk = sorted(path.name for path in CASES_ROOT.glob("CVE-*") if path.is_dir())
    by_batch: dict[str, list[str]] = {}
    for item in manifest["cases"]:
        if item["case_id"] in disk:
            by_batch.setdefault(item["oracle"]["selection_batch"], []).append(item["case_id"])
    test_total = 0
    mutant_total = 0
    for case_id in disk:
        try:
            import tomllib
        except ModuleNotFoundError:
            import tomli as tomllib
        with (CASES_ROOT / case_id / "case.toml").open("rb") as handle:
            config = tomllib.load(handle)
        test_total += int(config["test_count"])
        mutant_total += len(config.get("oracle_validation", {}).get("mutants", []))
    passed = sum(1 for item in results if item.get("passed"))
    caught = sum(1 for item in results if item.get("vulnerable", {}).get("caught"))
    killed = sum(sum(1 for mutant in item.get("mutants", []) if mutant.get("killed")) for item in results)
    summary = {
        "schema_version": 1,
        "manifest_id": manifest["manifest_id"],
        "census_id": "cve_v2_oracle_census_v1",
        "validated_on": "2026-07-31",
        "pinned_toolchain": manifest.get("toolchain_observed_at_freeze", {}),
        "implemented_oracles": len(disk),
        "oracle_level_counts": {"E": 0, "P": len(disk), "N": 0},
        "reference_passes": passed if passed == len(results) else "partial_see_batch_output",
        "vulnerable_sources_caught": caught if results else 0,
        "heldout_tests_total": test_total,
        "mutants_total": mutant_total,
        "mutants_killed_in_last_run": killed,
        "batches": {
            name: {
                "cases": len(ids),
                "case_ids": ids,
            }
            for name, ids in sorted(by_batch.items())
        },
        "notes": [
            "Construction-time summary; paper runs must regenerate independently.",
            "All implemented oracles are currently marked P pending final E promotion review.",
        ],
    }
    SUMMARY_PATH.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"wrote {SUMMARY_PATH}")


if __name__ == "__main__":
    raise SystemExit(main())
