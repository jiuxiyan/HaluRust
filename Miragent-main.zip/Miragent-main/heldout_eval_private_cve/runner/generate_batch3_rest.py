#!/usr/bin/env python3
"""Generate more batch_3 CVE held-out oracle cases."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from case_writer import mutation, write_case


def cases() -> list[dict]:
    return [
        {
            "id": "CVE-2019-16880",
            "batch": "batch_3",
            "contract": (
                "zip_elements consumes inputs via ManuallyDrop so panic in f does not "
                "double-drop; successful zips preserve computed values."
            ),
            "evidence": "audit UAF/double-free; ptr::read without ManuallyDrop",
            "dimensions": "normal add; panic safety; single cell; order",
            "symbols": ["zip_elements", "Matrix", "GenericArray"],
            "profiles": [{"name": "default_ignore_leaks", "flags": ["-Zmiri-ignore-leaks"]}],
            "tests": '''
                use std::panic;
                #[test]
                fn heldout_zip_adds_cells() {
                    let a = Matrix(GenericArray([GenericArray([1u32, 2])]));
                    let b = Matrix(GenericArray([GenericArray([3u32, 4])]));
                    let c = zip_elements(a, b, |x, y| x + y);
                    assert_eq!(c.0[0][0], 4);
                    assert_eq!(c.0[0][1], 6);
                }
                #[test]
                fn heldout_panic_mid_zip_is_drop_safe() {
                    let a = Matrix(GenericArray([GenericArray([String::from("a1"), String::from("a2")])]));
                    let b = Matrix(GenericArray([GenericArray([String::from("b1"), String::from("b2")])]));
                    let result = panic::catch_unwind(move || {
                        zip_elements(a, b, |_, _| panic!("boom"));
                    });
                    assert!(result.is_err());
                }
                #[test]
                fn heldout_zip_one_by_one_matrix() {
                    let a = Matrix(GenericArray([GenericArray([7u8])]));
                    let b = Matrix(GenericArray([GenericArray([1u8])]));
                    let c = zip_elements(a, b, |x, y| x - y);
                    assert_eq!(c.0[0][0], 6);
                }
                #[test]
                fn heldout_zip_product() {
                    let a = Matrix(GenericArray([GenericArray([2u32, 3])]));
                    let b = Matrix(GenericArray([GenericArray([5u32, 7])]));
                    let c = zip_elements(a, b, |x, y| x * y);
                    assert_eq!(c.0[0][0], 10);
                    assert_eq!(c.0[0][1], 21);
                }
                #[test]
                fn heldout_index_ops_on_generic_array() {
                    let mut g = GenericArray([1, 2, 3]);
                    g[1] = 9;
                    assert_eq!(g[1], 9);
                }
            ''',
            "reference": '''
                use std::mem::{self, ManuallyDrop, MaybeUninit};
                use std::ptr;
                pub struct GenericArray<T, const N: usize>(pub [T; N]);
                impl<T, const N: usize> std::ops::Index<usize> for GenericArray<T, N> {
                    type Output = T;
                    fn index(&self, index: usize) -> &Self::Output { &self.0[index] }
                }
                impl<T, const N: usize> std::ops::IndexMut<usize> for GenericArray<T, N> {
                    fn index_mut(&mut self, index: usize) -> &mut Self::Output { &mut self.0[index] }
                }
                pub struct Matrix<T, const M: usize, const N: usize>(pub GenericArray<GenericArray<T, M>, N>);
                pub fn zip_elements<A, B, C, const M: usize, const N: usize, F>(
                    Matrix(a): Matrix<A, M, N>,
                    Matrix(b): Matrix<B, M, N>,
                    mut f: F,
                ) -> Matrix<C, M, N>
                where
                    F: FnMut(A, B) -> C,
                {
                    let a = ManuallyDrop::new(a);
                    let b = ManuallyDrop::new(b);
                    let mut c: MaybeUninit<GenericArray<GenericArray<C, M>, N>> = MaybeUninit::uninit();
                    let mut initialized = 0usize;
                    let total = M * N;
                    for i in 0..N {
                        for j in 0..M {
                            unsafe {
                                let av = ptr::read(&a[i][j]);
                                let bv = ptr::read(&b[i][j]);
                                ptr::write(&mut (*c.as_mut_ptr()).0[i].0[j], f(av, bv));
                            }
                            initialized += 1;
                        }
                    }
                    debug_assert_eq!(initialized, total);
                    Matrix(unsafe { c.assume_init() })
                }
            ''',
            "mutants": [
                mutation(
                    "restore_forget_without_manualdrop",
                    "let a = ManuallyDrop::new(a);\n    let b = ManuallyDrop::new(b);",
                    "let a = a;\n    let b = b;",
                    "drops inputs again after ptr::read",
                ),
                mutation(
                    "zip_wrong_op_result",
                    "ptr::write(&mut (*c.as_mut_ptr()).0[i].0[j], f(av, bv));",
                    "ptr::write(&mut (*c.as_mut_ptr()).0[i].0[j], f(bv, av));",
                    "swaps zip operand order",
                ),
                mutation(
                    "index_always_zero",
                    "&self.0[index]",
                    "&self.0[0]",
                    "breaks Index",
                ),
                mutation(
                    "skip_write",
                    "ptr::write(&mut (*c.as_mut_ptr()).0[i].0[j], f(av, bv));",
                    "mem::forget((av, bv));",
                    "skips writing outputs",
                ),
            ],
        },
        {
            "id": "CVE-2020-35862",
            "batch": "batch_3",
            "contract": (
                "into_boxed_bitslice uses the live Vec pointer after into_boxed_slice, "
                "not a stale cached pointer from before possible reallocation."
            ),
            "evidence": "audit UAF; cached_ptr stale after capacity shrink in into_boxed_slice",
            "dimensions": "exact cap; oversized cap; values; len; get bounds",
            "symbols": ["BitVec::with_capacity", "push", "into_boxed_bitslice", "BitBox::get"],
            "tests": '''
                #[test]
                fn heldout_exact_capacity_roundtrip() {
                    let mut bv = BitVec::<u8, Lsb0>::with_capacity(4);
                    for i in 0..4u8 { bv.push(i); }
                    let boxed = bv.into_boxed_bitslice();
                    assert_eq!(boxed.len(), 4);
                    assert_eq!(boxed.get(0), 0);
                    assert_eq!(boxed.get(3), 3);
                }
                #[test]
                fn heldout_overcap_push_then_box() {
                    let mut bv = BitVec::<u8, Lsb0>::with_capacity(1024);
                    for i in 0..16u8 { bv.push(i); }
                    let boxed = bv.into_boxed_bitslice();
                    assert_eq!(boxed.len(), 16);
                    for i in 0..16u8 { assert_eq!(boxed.get(i as usize), i); }
                }
                #[test]
                fn heldout_single_element() {
                    let mut bv = BitVec::<u8, Lsb0>::with_capacity(8);
                    bv.push(9);
                    let boxed = bv.into_boxed_bitslice();
                    assert_eq!(boxed.get(0), 9);
                }
                #[test]
                fn heldout_empty_box() {
                    let bv = BitVec::<u8, Lsb0>::with_capacity(4);
                    let boxed = bv.into_boxed_bitslice();
                    assert_eq!(boxed.len(), 0);
                }
                #[test]
                fn heldout_values_are_stable() {
                    let mut bv = BitVec::<u8, Lsb0>::with_capacity(2);
                    bv.push(5); bv.push(6);
                    let boxed = bv.into_boxed_bitslice();
                    assert_eq!(boxed.get(1), 6);
                }
            ''',
            "reference": '''
                use std::marker::PhantomData;
                use std::ptr;
                pub struct Lsb0;
                pub struct BitVec<T, O> {
                    data: Vec<T>,
                    cached_ptr: *mut T,
                    cached_len: usize,
                    _order: PhantomData<O>,
                }
                impl<T, O> BitVec<T, O> {
                    pub fn with_capacity(cap: usize) -> Self {
                        let mut data = Vec::with_capacity(cap);
                        let cached_ptr = data.as_mut_ptr();
                        Self { data, cached_ptr, cached_len: 0, _order: PhantomData }
                    }
                    pub fn push(&mut self, val: T) {
                        self.data.push(val);
                        self.cached_ptr = self.data.as_mut_ptr();
                        self.cached_len = self.data.len();
                    }
                    pub fn into_boxed_bitslice(self) -> BitBox<T, O> {
                        let boxed = self.data.into_boxed_slice();
                        let len = boxed.len();
                        let ptr = Box::into_raw(boxed) as *mut T;
                        unsafe { BitBox::from_raw(ptr, len) }
                    }
                }
                pub struct BitBox<T, O> {
                    ptr: *mut T,
                    len: usize,
                    _order: PhantomData<O>,
                }
                impl<T, O> BitBox<T, O> {
                    pub unsafe fn from_raw(ptr: *mut T, len: usize) -> Self {
                        Self { ptr, len, _order: PhantomData }
                    }
                    pub fn get(&self, index: usize) -> T where T: Copy {
                        unsafe { ptr::read(self.ptr.add(index)) }
                    }
                    pub fn len(&self) -> usize { self.len }
                }
                impl<T, O> Drop for BitBox<T, O> {
                    fn drop(&mut self) {
                        if self.len > 0 || !self.ptr.is_null() {
                            unsafe {
                                let _ = Box::from_raw(std::ptr::slice_from_raw_parts_mut(self.ptr, self.len));
                            }
                        }
                    }
                }
            ''',
            "mutants": [
                mutation(
                    "restore_stale_cached_ptr",
                    "let boxed = self.data.into_boxed_slice();\n        let len = boxed.len();\n        let ptr = Box::into_raw(boxed) as *mut T;\n        unsafe { BitBox::from_raw(ptr, len) }",
                    "let stale_ptr = self.cached_ptr;\n        let stale_len = self.cached_len;\n        let boxed = self.data.into_boxed_slice();\n        std::mem::forget(boxed);\n        unsafe { BitBox::from_raw(stale_ptr, stale_len) }",
                    "restores stale pointer UAF",
                ),
                mutation("get_off_by_one", "unsafe { ptr::read(self.ptr.add(index)) }", "unsafe { ptr::read(self.ptr.add(index.wrapping_add(1))) }", "off-by-one get"),
                mutation("push_does_not_extend", "self.data.push(val);", "core::mem::forget(val);", "drops pushed values"),
                mutation("len_always_zero", "pub fn len(&self) -> usize { self.len }", "pub fn len(&self) -> usize { 0 }", "lies about len"),
            ],
        },
        {
            "id": "CVE-2020-25573",
            "batch": "batch_3",
            "contract": (
                "LinkedHashMap::insert never constructs NonNull via uninitialized memory; "
                "empty maps stay empty until insert; insert updates len."
            ),
            "evidence": "audit uninit; mem::uninitialized NonNull on first insert",
            "dimensions": "empty; first insert; second insert; len; is_empty",
            "symbols": ["LinkedHashMap::new", "insert", "len", "is_empty"],
            "profiles": [{"name": "default_ignore_leaks", "flags": ["-Zmiri-ignore-leaks"]}],
            "tests": '''
                #[test]
                fn heldout_new_is_empty() {
                    let map: LinkedHashMap<i32, i32> = LinkedHashMap::new();
                    assert!(map.is_empty());
                    assert_eq!(map.len(), 0);
                }
                #[test]
                fn heldout_first_insert_sets_len() {
                    let mut map = LinkedHashMap::new();
                    assert_eq!(map.insert(1, 10), None);
                    assert_eq!(map.len(), 1);
                    assert!(!map.is_empty());
                }
                #[test]
                fn heldout_two_inserts() {
                    let mut map = LinkedHashMap::new();
                    map.insert(1, 10);
                    map.insert(2, 20);
                    assert_eq!(map.len(), 2);
                }
                #[test]
                fn heldout_insert_returns_none_for_new_keys() {
                    let mut map = LinkedHashMap::new();
                    assert!(map.insert(3, 30).is_none());
                }
                #[test]
                fn heldout_string_keys() {
                    let mut map = LinkedHashMap::new();
                    map.insert("a".to_string(), 1);
                    map.insert("b".to_string(), 2);
                    assert_eq!(map.len(), 2);
                }
            ''',
            "reference": '''
                use std::ptr::NonNull;
                use std::marker::PhantomData;
                use std::borrow::Borrow;
                use std::hash::Hash;
                pub struct Node<K, V> {
                    pub next: NonNull<Node<K, V>>,
                    pub prev: NonNull<Node<K, V>>,
                    pub key: K,
                    pub value: V,
                }
                pub struct LinkedHashMap<K, V> {
                    pub head: Option<NonNull<Node<K, V>>>,
                    pub len: usize,
                    _marker: PhantomData<(K, V)>,
                }
                impl<K, V> LinkedHashMap<K, V> {
                    pub fn new() -> Self {
                        LinkedHashMap { head: None, len: 0, _marker: PhantomData }
                    }
                    pub fn is_empty(&self) -> bool { self.len == 0 }
                    pub fn len(&self) -> usize { self.len }
                    pub fn insert(&mut self, k: K, v: V) -> Option<V> {
                        unsafe {
                            if self.head.is_none() {
                                let node_ptr = Box::into_raw(Box::new(Node {
                                    next: NonNull::dangling(),
                                    prev: NonNull::dangling(),
                                    key: k,
                                    value: v,
                                }));
                                let nn = NonNull::new_unchecked(node_ptr);
                                (*node_ptr).next = nn;
                                (*node_ptr).prev = nn;
                                self.head = Some(nn);
                                self.len = 1;
                                None
                            } else {
                                let head_nn = self.head.unwrap();
                                let head_ptr = head_nn.as_ptr();
                                let tail_nn = (*head_ptr).prev;
                                let tail_ptr = tail_nn.as_ptr();
                                let node_ptr = Box::into_raw(Box::new(Node {
                                    next: head_nn,
                                    prev: tail_nn,
                                    key: k,
                                    value: v,
                                }));
                                let nn = NonNull::new_unchecked(node_ptr);
                                (*tail_ptr).next = nn;
                                (*head_ptr).prev = nn;
                                self.len += 1;
                                None
                            }
                        }
                    }
                    pub fn get<Q: ?Sized>(&self, _k: &Q) -> Option<&V>
                    where
                        K: Borrow<Q>,
                        Q: Eq + Hash,
                    {
                        None
                    }
                }
            ''',
            "mutants": [
                mutation(
                    "restore_uninitialized_nonnull",
                    "next: NonNull::dangling(),\n                    prev: NonNull::dangling(),",
                    "next: std::mem::uninitialized(),\n                    prev: std::mem::uninitialized(),",
                    "restores uninitialized NonNull",
                ),
                mutation("insert_skips_len", "self.len = 1;", "self.len = 0;", "fails to set len on first insert"),
                mutation("second_insert_skips_len", "self.len += 1;", "self.len += 0;", "skips len on later inserts"),
                mutation("is_empty_inverted", "self.len == 0", "self.len != 0", "inverts emptiness"),
            ],
        },
    ]


def main() -> int:
    for spec in cases():
        write_case(spec)
        print(f"wrote cases/{spec['id']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
