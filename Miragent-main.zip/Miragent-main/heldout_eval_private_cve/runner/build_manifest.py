#!/usr/bin/env python3
"""Build the frozen 62-case CVE v2 manifest."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from collections import Counter
from pathlib import Path


PRIVATE_ROOT = Path(__file__).resolve().parents[1]
PROJECT_ROOT = PRIVATE_ROOT.parent
DATASET_ROOT = PROJECT_ROOT / "cve_safe_func_synth_without_data_race_v2"
MANIFEST_PATH = PRIVATE_ROOT / "manifests" / "cve_dataset_manifest_v1.json"
EXPECTED_CASES = 62
FILES = ("source.rs", "test.rs", "meta.json", "audit.json")
ALLOWED_UB = {
    "uninitialized_memory", "out_of_bounds", "use_after_free",
    "invalid_alignment", "invalid_value", "invalid_deref", "stacked_borrows",
}

PILOT = {
    "CVE-2020-25794", "CVE-2023-41051", "CVE-2021-45720",
    "CVE-2021-25905", "CVE-2020-35923",
}
BATCH2_FIXED = {
    "CVE-2019-16882", "CVE-2020-35860", "CVE-2021-45709", "CVE-2020-35888",
}


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _command(args: list[str]) -> str:
    try:
        return subprocess.run(args, capture_output=True, text=True, check=False).stdout.strip()
    except FileNotFoundError:
        return "unavailable"


def batch_map(case_ids: list[str], ub_by_id: dict[str, str]) -> dict[str, str]:
    result = {case_id: "pilot_1" for case_id in PILOT}
    common = [case_id for case_id in case_ids if case_id not in PILOT | BATCH2_FIXED]
    for kind in ("uninitialized_memory", "out_of_bounds", "use_after_free"):
        chosen = [case_id for case_id in common if ub_by_id[case_id] == kind][:2]
        BATCH2_FIXED.update(chosen)
        common = [case_id for case_id in common if case_id not in chosen]
    result.update({case_id: "batch_2" for case_id in BATCH2_FIXED})
    sizes = [10, 10, 10, 10, 7]
    cursor = 0
    for number, size in enumerate(sizes, 3):
        for case_id in common[cursor:cursor + size]:
            result[case_id] = f"batch_{number}"
        cursor += size
    if set(result) != set(case_ids):
        raise ValueError("batch assignment does not cover the frozen dataset")
    return result


def build_manifest() -> dict:
    case_dirs = sorted(path for path in DATASET_ROOT.glob("CVE-*") if path.is_dir())
    prelim: list[tuple[Path, dict, dict]] = []
    for case_dir in case_dirs:
        missing = [name for name in FILES if not (case_dir / name).is_file()]
        if missing:
            raise ValueError(f"{case_dir.name}: missing {missing}")
        meta = json.loads((case_dir / "meta.json").read_text(encoding="utf-8"))
        audit = json.loads((case_dir / "audit.json").read_text(encoding="utf-8"))
        if meta.get("cve_id") != case_dir.name or audit.get("cve_id") != case_dir.name:
            raise ValueError(f"{case_dir.name}: identity mismatch")
        if audit.get("disposition") != "PASS":
            raise ValueError(f"{case_dir.name}: non-PASS case in v2")
        kinds = audit.get("expected_ub_kinds", [])
        if not kinds or any(kind not in ALLOWED_UB for kind in kinds):
            raise ValueError(f"{case_dir.name}: invalid expected UB kinds {kinds}")
        prelim.append((case_dir, meta, audit))
    ids = [item[0].name for item in prelim]
    ub_by_id = {case_dir.name: audit["expected_ub_kinds"][0] for case_dir, _, audit in prelim}
    batches = batch_map(ids, ub_by_id)
    cases = []
    for case_dir, meta, audit in prelim:
        case_id = case_dir.name
        private_case = PRIVATE_ROOT / "cases" / case_id / "case.toml"
        cases.append({
            "case_id": case_id,
            "project": meta.get("project"),
            "cwe": meta.get("cwe"),
            "rel_dir": case_id,
            "files": {
                name: {"sha256": _sha(case_dir / name), "size_bytes": (case_dir / name).stat().st_size}
                for name in FILES
            },
            "audit": {
                "disposition": audit["disposition"],
                "batch": audit.get("batch"),
                "expected_ub_kinds": audit["expected_ub_kinds"],
                "target_tests": audit.get("target_tests", []),
                "normal_tests": audit.get("normal_tests", []),
                "upstream_verification": audit.get("upstream_verification"),
                "mapping": audit.get("mapping", {}),
                "rationale": audit.get("rationale", ""),
            },
            "oracle": {
                "level": "P",
                "status": "implemented" if private_case.is_file() else "selected",
                "selection_batch": batches[case_id],
                "case_dir": f"cases/{case_id}",
            },
        })
    counts = Counter(case["audit"]["expected_ub_kinds"][0] for case in cases)
    return {
        "schema_version": 1,
        "manifest_id": "cve_v2_dataset_manifest_v1",
        "generated_on": "2026-07-31",
        "dataset": {
            "name": "CVE safe function synthesis without data races v2",
            "root": "cve_safe_func_synth_without_data_race_v2",
            "case_count": len(cases),
            "expected_case_count": EXPECTED_CASES,
            "membership": "all audited PASS cases in v2",
            "ub_kind_counts": dict(sorted(counts.items())),
        },
        "toolchain_observed_at_freeze": {
            "rustc": _command(["rustc", "--version"]),
            "cargo": _command(["cargo", "--version"]),
            "miri": _command(["cargo", "+nightly", "miri", "--version"]),
            "runner_toolchain": "nightly",
        },
        "isolation": {
            "visible_to_repair": False,
            "repair_feedback_allowed": False,
            "evaluation_phase": "post-hoc final patch only",
        },
        "cases": cases,
    }


def serialize(data: dict) -> str:
    return json.dumps(data, ensure_ascii=False, indent=2) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    data = build_manifest()
    if data["dataset"]["case_count"] != EXPECTED_CASES:
        print(f"error: found {data['dataset']['case_count']} cases, expected {EXPECTED_CASES}", file=sys.stderr)
        return 2
    content = serialize(data)
    if args.check:
        if not MANIFEST_PATH.is_file() or MANIFEST_PATH.read_text(encoding="utf-8") != content:
            print("error: checked-in CVE manifest differs from regenerated data", file=sys.stderr)
            return 1
        print(f"CVE manifest OK: {EXPECTED_CASES} cases")
        return 0
    MANIFEST_PATH.parent.mkdir(parents=True, exist_ok=True)
    MANIFEST_PATH.write_text(content, encoding="utf-8")
    print(f"wrote {MANIFEST_PATH} ({EXPECTED_CASES} cases)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
