#!/usr/bin/env python3
"""Generate batch_5 CVE held-out oracle cases (10)."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from case_writer import mutation, write_case

FIX_ROOT = Path("/tmp/cve_batch5_fix")


def ref(cid: str) -> str:
    return FIX_ROOT.joinpath(f"{cid}.rs").read_text(encoding="utf-8")


def cases() -> list[dict]:
    return [
        {
            "id": "CVE-2020-36210",
            "batch": "batch_5",
            "contract": "random_array only drops initialized slots if Random::random panics mid-fill.",
            "evidence": "audit uninit; VulnGuard dropped all N slots including uninit",
            "dimensions": "i32 array; u8 array; nested Random; sizes; values",
            "symbols": ["random_array", "Random"],
            "tests": '''
                use std::panic;
                #[test]
                fn heldout_i32_array_values() {
                    let a: [i32; 4] = random_array();
                    assert_eq!(a, [0, 0, 0, 0]);
                }
                #[test]
                fn heldout_u8_array_values() {
                    let a: [u8; 8] = random_array();
                    assert_eq!(a.iter().copied().sum::<u8>(), 0);
                }
                #[test]
                fn heldout_trait_random_array() {
                    let a: [i32; 2] = <[i32; 2] as Random>::random();
                    assert_eq!(a.len(), 2);
                }
                #[test]
                fn heldout_panic_mid_fill_drop_safe() {
                    use std::sync::atomic::{AtomicUsize, Ordering};
                    struct Boom(String);
                    impl Random for Boom {
                        fn random() -> Self {
                            static N: AtomicUsize = AtomicUsize::new(0);
                            let n = N.fetch_add(1, Ordering::SeqCst);
                            if n == 1 { panic!("random panic"); }
                            Boom(format!("v{n}"))
                        }
                    }
                    let r = panic::catch_unwind(|| {
                        let _a: [Boom; 4] = random_array();
                    });
                    assert!(r.is_err());
                }
                #[test]
                fn heldout_large_ok() {
                    let a: [i32; 32] = random_array();
                    assert_eq!(a[31], 0);
                }
            ''',
            "reference": ref("CVE-2020-36210"),
            "mutants": [
                mutation(
                    "restore_drop_all",
                    "for i in 0..self.initialized {",
                    "for i in 0..N {",
                    "drops uninit slots on panic",
                ),
                mutation(
                    "never_increment_initialized",
                    "guard.initialized = i + 1;",
                    "let _ = i;",
                    "never records initialized slots",
                ),
                mutation("i32_random_nonzero", "impl Random for i32 {\n    fn random() -> Self { 0 }\n}", "impl Random for i32 {\n    fn random() -> Self { 7 }\n}", "changes i32 Random"),
                mutation("forget_skipped", "mem::forget(guard);", "", "double-drops via guard"),
            ],
        },
        {
            "id": "CVE-2021-25907",
            "batch": "batch_5",
            "contract": "mutate/mutate2 use mem::take so panic cannot double-free the original slot.",
            "evidence": "audit UAF; ptr::read then panic drops both copies",
            "dimensions": "success mutate; panic mutate; mutate2; strings; ints",
            "symbols": ["mutate", "mutate2"],
            "tests": '''
                use std::panic;
                #[test]
                fn heldout_mutate_success() {
                    let mut s = String::from("ab");
                    mutate(&mut s, |x| x + "c");
                    assert_eq!(s, "abc");
                }
                #[test]
                fn heldout_mutate_panic_is_drop_safe() {
                    let mut s = String::from("keep");
                    let r = panic::catch_unwind(panic::AssertUnwindSafe(|| {
                        mutate(&mut s, |_| panic!("boom"));
                    }));
                    assert!(r.is_err());
                    assert_eq!(s, "");
                }
                #[test]
                fn heldout_mutate2_success() {
                    let mut a = String::from("x");
                    let mut b = String::from("y");
                    mutate2(&mut a, &mut b, |a, b| (b, a));
                    assert_eq!(a, "y");
                    assert_eq!(b, "x");
                }
                #[test]
                fn heldout_mutate_int() {
                    let mut n = 3i32;
                    mutate(&mut n, |x| x + 1);
                    assert_eq!(n, 4);
                }
                #[test]
                fn heldout_mutate2_panic_safe() {
                    let mut a = String::from("aa");
                    let mut b = String::from("bb");
                    let r = panic::catch_unwind(panic::AssertUnwindSafe(|| {
                        mutate2(&mut a, &mut b, |_, _| panic!("x"));
                    }));
                    assert!(r.is_err());
                    assert_eq!(a, "");
                    assert_eq!(b, "");
                }
            ''',
            "reference": ref("CVE-2021-25907"),
            "mutants": [
                mutation(
                    "restore_ptr_read_mutate",
                    "let x = mem::take(p);\n    *p = f(x);",
                    "unsafe {\n        let x = std::ptr::read(p);\n        let x = f(x);\n        std::ptr::write(p, x);\n    }",
                    "restores ptr::read mutate",
                ),
                mutation(
                    "restore_ptr_read_mutate2",
                    "let x = mem::take(p);\n    let y = mem::take(q);\n    let (x, y) = f(x, y);\n    *p = x;\n    *q = y;",
                    "unsafe {\n        let (x, y) = (std::ptr::read(p), std::ptr::read(q));\n        let (x, y) = f(x, y);\n        std::ptr::write(p, x);\n        std::ptr::write(q, y);\n    }",
                    "restores ptr::read mutate2",
                ),
                mutation("mutate_identity_only", "*p = f(x);", "*p = x;", "ignores f"),
                mutation("mutate2_swaps_wrong", "*p = x;\n    *q = y;", "*p = y;\n    *q = x;", "writes swapped incorrectly vs f result naming"),
            ],
        },
        {
            "id": "CVE-2021-25908",
            "batch": "batch_5",
            "contract": "convert_list moves elements with a drain guard so panic cannot double-drop src.",
            "evidence": "audit UAF; ptr::read without shrinking src len",
            "dimensions": "normal convert; panic convert; empty; identity; order",
            "symbols": ["convert_list_vulnerable"],
            "tests": '''
                use std::panic;
                #[test]
                fn heldout_convert_ok() {
                    let out = convert_list_vulnerable(vec![1i32, 2, 3], |x| x + 1);
                    assert_eq!(out, vec![2, 3, 4]);
                }
                #[test]
                fn heldout_convert_strings() {
                    let out = convert_list_vulnerable(vec!["a".into(), "b".into()], |s: String| s + "!");
                    assert_eq!(out, vec!["a!", "b!"]);
                }
                #[test]
                fn heldout_panic_mid_convert_drop_safe() {
                    let r = panic::catch_unwind(|| {
                        convert_list_vulnerable(vec!["x".into(), "y".into(), "z".into()], |s: String| {
                            if s == "y" { panic!("stop"); }
                            s
                        });
                    });
                    assert!(r.is_err());
                }
                #[test]
                fn heldout_empty_input() {
                    let out: Vec<u8> = convert_list_vulnerable(Vec::<u8>::new(), |x| x);
                    assert!(out.is_empty());
                }
                #[test]
                fn heldout_preserves_order() {
                    let out = convert_list_vulnerable((0..5).collect::<Vec<_>>(), |x| x * 2);
                    assert_eq!(out, vec![0, 2, 4, 6, 8]);
                }
            ''',
            "reference": ref("CVE-2021-25908"),
            "mutants": [
                mutation(
                    "skip_guard_advance",
                    "guard.start = i + 1;",
                    "guard.start = i;",
                    "leaves moved elem in drop range",
                ),
                mutation("convert_ignores_fn", "result.push(convert(item));", "core::mem::forget(item);", "drops converted values"),
                mutation("result_capacity_zero_push", "result.push(convert(item));", "result.insert(0, convert(item));", "reverses via insert"),
                mutation(
                    "free_with_full_len",
                    "let _ = Vec::from_raw_parts(self.base, 0, self.cap);",
                    "let _ = Vec::from_raw_parts(self.base, self.end, self.cap);",
                    "drops remaining as if still owned wrongly",
                ),
            ],
        },
        {
            "id": "CVE-2021-26305",
            "batch": "batch_5",
            "contract": "read_vec allocates zeroed bytes before read_exact; returned buffer matches input.",
            "evidence": "audit uninit; set_len without init before Read",
            "dimensions": "exact read; empty; partial source err; values; reuse",
            "symbols": ["CdrDeserializer::new", "read_vec"],
            "tests": '''
                use std::io::{self, Cursor, Read};
                struct PeekReader;
                impl Read for PeekReader {
                    fn read(&mut self, buf: &mut [u8]) -> io::Result<usize> {
                        if !buf.is_empty() {
                            let x = buf[0];
                            std::hint::black_box(x);
                        }
                        for b in buf.iter_mut() { *b = 0x42; }
                        Ok(buf.len())
                    }
                }
                #[test]
                fn heldout_peek_reader_is_safe() {
                    let mut d = CdrDeserializer::new(PeekReader);
                    let v = d.read_vec(8).unwrap();
                    assert!(v.iter().all(|&b| b == 0x42));
                }
                #[test]
                fn heldout_read_exact_bytes() {
                    let mut d = CdrDeserializer::new(Cursor::new(vec![1u8, 2, 3, 4]));
                    let v = d.read_vec(4).unwrap();
                    assert_eq!(v, vec![1, 2, 3, 4]);
                    assert_eq!(v.iter().fold(0u8, |a, b| a ^ b), 1 ^ 2 ^ 3 ^ 4);
                }
                #[test]
                fn heldout_read_empty() {
                    let mut d = CdrDeserializer::new(Cursor::new(vec![]));
                    assert!(d.read_vec(0).unwrap().is_empty());
                }
                #[test]
                fn heldout_short_reader_errors() {
                    let mut d = CdrDeserializer::new(Cursor::new(vec![9u8]));
                    assert!(d.read_vec(4).is_err());
                }
                #[test]
                fn heldout_two_reads() {
                    let mut d = CdrDeserializer::new(Cursor::new(vec![7u8, 8, 9]));
                    assert_eq!(d.read_vec(2).unwrap(), vec![7, 8]);
                    assert_eq!(d.read_vec(1).unwrap(), vec![9]);
                }
            ''',
            "reference": ref("CVE-2021-26305"),
            "mutants": [
                mutation("restore_set_len", "let mut buf = vec![0u8; len];", "let mut buf = Vec::with_capacity(len); unsafe { buf.set_len(len); }", "restores uninit buf"),
                mutation("read_wrong_len", "self.inner.read_exact(&mut buf)?;", "let _ = self.inner.read(&mut buf)?;", "uses read not read_exact"),
                mutation("always_empty", "Ok(buf)", "Ok(Vec::new())", "returns empty"),
                mutation("capacity_only_no_zero", "vec![0u8; len]", "vec![0u8; 0]", "empty allocation"),
            ],
        },
        {
            "id": "CVE-2021-26951",
            "batch": "batch_5",
            "contract": "Sectors::get extends storage with resize(.,0) so Read never sees uninit bytes.",
            "evidence": "audit uninit; set_len then Read",
            "dimensions": "first sector; second; short eof; values xor; size",
            "symbols": ["Sectors::new", "get"],
            "tests": '''
                use std::io::{self, Cursor, Read};
                struct InspectingReader;
                impl Read for InspectingReader {
                    fn read(&mut self, buf: &mut [u8]) -> io::Result<usize> {
                        let mut acc = 0u8;
                        for &b in buf.iter() { acc ^= b; }
                        std::hint::black_box(acc);
                        for b in buf.iter_mut() { *b = 0xAA; }
                        Ok(buf.len())
                    }
                }
                #[test]
                fn heldout_inspecting_reader_safe() {
                    let mut s = Sectors::new(4);
                    let mut r = InspectingReader;
                    let slice = s.get(0, &mut r).unwrap();
                    assert_eq!(slice, &[0xAA; 4]);
                    let mut acc = 0u8;
                    for b in slice { acc ^= *b; }
                    assert_eq!(acc, 0);
                }
                #[test]
                fn heldout_first_sector() {
                    let mut s = Sectors::new(4);
                    let mut r = Cursor::new(vec![1u8, 2, 3, 4, 5, 6, 7, 8]);
                    let slice = s.get(0, &mut r).unwrap();
                    assert_eq!(slice, &[1, 2, 3, 4]);
                }
                #[test]
                fn heldout_second_sector() {
                    let mut s = Sectors::new(4);
                    let mut r = Cursor::new(vec![10u8, 11, 12, 13, 20, 21, 22, 23]);
                    let _ = s.get(0, &mut r).unwrap();
                    let slice = s.get(1, &mut r).unwrap();
                    assert_eq!(slice, &[20, 21, 22, 23]);
                }
                #[test]
                fn heldout_short_eof() {
                    let mut s = Sectors::new(8);
                    let mut r = Cursor::new(vec![1u8, 2, 3]);
                    let slice = s.get(0, &mut r).unwrap();
                    assert_eq!(slice.len(), 3);
                }
                #[test]
                fn heldout_sector_size_one() {
                    let mut s = Sectors::new(1);
                    let mut r = Cursor::new(vec![42u8]);
                    assert_eq!(s.get(0, &mut r).unwrap(), &[42]);
                }
            ''',
            "reference": ref("CVE-2021-26951"),
            "mutants": [
                mutation("restore_set_len", "self.data.resize(end, 0);", "unsafe { self.data.set_len(end); }", "restores uninit extend"),
                mutation("wrong_start", "let start = id as usize * self.size;", "let start = id as usize;", "wrong offset"),
                mutation("always_empty_slice", "Ok(&self.data[start..end])", "Ok(&self.data[start..start])", "empty slice"),
                mutation("size_lie_new", "size: sector_size,", "size: 1,", "forces size one"),
            ],
        },
        {
            "id": "CVE-2021-26953",
            "batch": "batch_5",
            "contract": "read_bytes zero-initializes before read_exact.",
            "evidence": "audit uninit; set_len before Read",
            "dimensions": "exact; empty; short err; xor use; multi",
            "symbols": ["FontReader::new", "read_bytes"],
            "tests": '''
                use std::io::{self, Cursor, Read};
                struct PeekReader;
                impl Read for PeekReader {
                    fn read(&mut self, buf: &mut [u8]) -> io::Result<usize> {
                        if !buf.is_empty() {
                            let x = buf[0];
                            std::hint::black_box(x);
                        }
                        for b in buf.iter_mut() { *b = 1; }
                        Ok(buf.len())
                    }
                }
                #[test]
                fn heldout_peek_reader_safe() {
                    let mut fr = FontReader::new(PeekReader);
                    let v = fr.read_bytes(4).unwrap();
                    assert_eq!(v.iter().sum::<u8>(), 4);
                }
                #[test]
                fn heldout_read_bytes_ok() {
                    let mut fr = FontReader::new(Cursor::new(b"hello".to_vec()));
                    let v = fr.read_bytes(5).unwrap();
                    assert_eq!(v, b"hello");
                    assert_eq!(v.iter().fold(0u8, |a,b| a.wrapping_add(*b)), b"hello".iter().fold(0u8, |a,b| a.wrapping_add(*b)));
                }
                #[test]
                fn heldout_empty_ok() {
                    let mut fr = FontReader::new(Cursor::new(vec![]));
                    assert!(fr.read_bytes(0).unwrap().is_empty());
                }
                #[test]
                fn heldout_short_errors() {
                    let mut fr = FontReader::new(Cursor::new(vec![1u8,2]));
                    assert!(fr.read_bytes(4).is_err());
                }
                #[test]
                fn heldout_sequential() {
                    let mut fr = FontReader::new(Cursor::new(vec![1u8,2,3]));
                    assert_eq!(fr.read_bytes(2).unwrap(), vec![1,2]);
                    assert_eq!(fr.read_bytes(1).unwrap(), vec![3]);
                }
            ''',
            "reference": ref("CVE-2021-26953"),
            "mutants": [
                mutation("restore_set_len", "let mut buf = vec![0u8; len];", "let mut buf = Vec::with_capacity(len); unsafe { buf.set_len(len); }", "restores uninit"),
                mutation("read_not_exact", "self.inner.read_exact(&mut buf)?;", "let _ = self.inner.read(&mut buf)?;", "partial read ok"),
                mutation("return_empty", "Ok(buf)", "Ok(vec![])", "empty return"),
                mutation("short_alloc", "let mut buf = vec![0u8; len];", "let mut buf = Vec::new();", "empty buf before read"),
            ],
        },
        {
            "id": "CVE-2021-26954",
            "batch": "batch_5",
            "contract": "insert_slice_clone clones into a temp then splices so panic cannot double-drop.",
            "evidence": "audit UAF; ptr::copy then panicking Clone",
            "dimensions": "clone insert; panic clone; copy path; middle; end",
            "symbols": ["VecExt::insert_slice_clone", "insert_slice_copy"],
            "tests": '''
                use std::panic;
                #[test]
                fn heldout_clone_insert_middle() {
                    let mut v: Vec<String> = vec!["a".into(), "c".into()];
                    v.insert_slice_clone(1, &["b".into()]);
                    assert_eq!(v, vec!["a", "b", "c"]);
                }
                #[test]
                fn heldout_clone_panic_drop_safe() {
                    #[derive(Debug)]
                    struct Boom(String);
                    impl Clone for Boom {
                        fn clone(&self) -> Self {
                            if self.0 == "boom" { panic!("clone panic"); }
                            Boom(self.0.clone())
                        }
                    }
                    let mut v = vec![Boom("a".into()), Boom("b".into())];
                    let r = panic::catch_unwind(panic::AssertUnwindSafe(|| {
                        // Insert at 0 so ptr::copy duplicates stay inside old len.
                        v.insert_slice_clone(0, &[Boom("boom".into())]);
                    }));
                    assert!(r.is_err());
                }
                #[test]
                fn heldout_copy_insert() {
                    let mut v = vec![1u32, 4];
                    v.insert_slice_copy(1, &[2, 3]);
                    assert_eq!(v, vec![1, 2, 3, 4]);
                }
                #[test]
                fn heldout_clone_at_end() {
                    let mut v: Vec<String> = vec![String::from("x")];
                    v.insert_slice_clone(1, &["y".into()]);
                    assert_eq!(v.len(), 2);
                    assert_eq!(v[1], "y");
                }
                #[test]
                fn heldout_empty_items() {
                    let mut v = vec![1i32, 2];
                    v.insert_slice_clone(1, &[]);
                    assert_eq!(v, vec![1, 2]);
                }
            ''',
            "reference": ref("CVE-2021-26954"),
            "mutants": [
                mutation(
                    "restore_ptr_copy_clone",
                    "let mut inserted = Vec::with_capacity(items.len());\n        for item in items {\n            inserted.push(item.clone());\n        }\n        let mut tail = self.split_off(index);\n        self.append(&mut inserted);\n        self.append(&mut tail);",
                    "let old_len = self.len();\n        let insert_len = items.len();\n        self.reserve(insert_len);\n        unsafe {\n            let ptr = self.as_mut_ptr();\n            std::ptr::copy(ptr.add(index), ptr.add(index + insert_len), old_len - index);\n            for (i, item) in items.iter().enumerate() {\n                std::ptr::write(ptr.add(index + i), item.clone());\n            }\n            self.set_len(old_len + insert_len);\n        }",
                    "restores vulnerable ptr::copy clone insert",
                ),
                mutation("clone_skips_append_tail", "self.append(&mut tail);", "", "drops tail"),
                mutation("copy_skips_set_len", "self.set_len(old_len + insert_len);", "self.set_len(old_len);", "skips copy len"),
                mutation("assert_always", "assert!(index <= self.len());", "assert!(false);", "always panics"),
            ],
        },
        {
            "id": "CVE-2021-29930",
            "batch": "batch_5",
            "contract": "SliceVec::resize_with advances len only after each successful write.",
            "evidence": "audit uninit; len set before initializing",
            "dimensions": "grow; shrink; panic grow; push; index",
            "symbols": ["SliceVec::new", "push", "resize_with", "len"],
            "tests": '''
                use std::panic;
                #[test]
                fn heldout_push_and_index() {
                    let mut v = SliceVec::new();
                    v.push(1u32); v.push(2);
                    assert_eq!(v.len(), 2);
                    assert_eq!(v[0], 1);
                    assert_eq!(v[1], 2);
                }
                #[test]
                fn heldout_resize_grow() {
                    let mut v = SliceVec::new();
                    v.push(9u8);
                    v.resize_with(4, || 0u8);
                    assert_eq!(v.len(), 4);
                    assert_eq!(v[0], 9);
                }
                #[test]
                fn heldout_resize_shrink() {
                    let mut v = SliceVec::new();
                    v.push(1u8); v.push(2); v.push(3);
                    v.resize_with(1, || 0u8);
                    assert_eq!(v.len(), 1);
                    assert_eq!(v[0], 1);
                }
                #[test]
                fn heldout_resize_panic_drop_safe() {
                    let mut v = SliceVec::new();
                    v.push(String::from("ok"));
                    let r = panic::catch_unwind(panic::AssertUnwindSafe(|| {
                        v.resize_with(3, || panic!("nope"));
                    }));
                    assert!(r.is_err());
                }
                #[test]
                fn heldout_resize_same_len() {
                    let mut v = SliceVec::new();
                    v.push(5u16);
                    v.resize_with(1, || 0);
                    assert_eq!(v.len(), 1);
                }
            ''',
            "reference": ref("CVE-2021-29930"),
            "mutants": [
                mutation(
                    "set_len_upfront",
                    "for i in old_len..new_len {\n                unsafe {\n                    ptr::write(self.ptr.add(i), f());\n                }\n                self.len = i + 1;\n            }",
                    "self.len = new_len;\n            for i in old_len..new_len {\n                unsafe {\n                    ptr::write(self.ptr.add(i), f());\n                }\n            }",
                    "restores upfront len bump",
                ),
                mutation("push_skips_len", "self.len += 1;", "self.len += 0;", "skips push len"),
                mutation("len_fn_zero", "pub fn len(&self) -> usize {\n        self.len\n    }", "pub fn len(&self) -> usize {\n        0\n    }", "lies about len"),
                mutation("shrink_skips_len", "self.len = new_len;", "self.len = old_len;", "skips shrink len"),
            ],
        },
        {
            "id": "CVE-2021-29931",
            "batch": "batch_5",
            "contract": "SliceVec::resize_with does not bump len before initializing new elements.",
            "evidence": "audit uninit; len assigned before fill loop",
            "dimensions": "grow; shrink; panic; push; index",
            "symbols": ["SliceVec::new", "push", "resize_with", "len"],
            "tests": '''
                use std::panic;
                #[test]
                fn heldout_basic_push() {
                    let mut v = SliceVec::new();
                    v.push(3u32);
                    assert_eq!(v[0], 3);
                    assert_eq!(v.len(), 1);
                }
                #[test]
                fn heldout_grow_values() {
                    let mut v = SliceVec::new();
                    v.resize_with(3, || 7u8);
                    assert_eq!(v.len(), 3);
                    assert_eq!(v[2], 7);
                }
                #[test]
                fn heldout_shrink_values() {
                    let mut v = SliceVec::new();
                    v.push(1u8); v.push(2); v.push(3);
                    v.resize_with(2, || 0);
                    assert_eq!(v.len(), 2);
                    assert_eq!(v[1], 2);
                }
                #[test]
                fn heldout_panic_during_grow_safe() {
                    let mut v = SliceVec::new();
                    v.push("a".to_string());
                    let r = panic::catch_unwind(panic::AssertUnwindSafe(|| {
                        v.resize_with(4, || panic!("x"));
                    }));
                    assert!(r.is_err());
                }
                #[test]
                fn heldout_shrink_drops_strings() {
                    let mut v = SliceVec::new();
                    v.push(String::from("keep"));
                    v.push(String::from("dropme"));
                    v.resize_with(1, || String::new());
                    assert_eq!(v.len(), 1);
                    assert_eq!(v[0], "keep");
                }
            ''',
            "reference": ref("CVE-2021-29931"),
            "mutants": [
                mutation(
                    "restore_upfront_len",
                    "if new_len > old_len {\n            for i in old_len..new_len {\n                unsafe {\n                    ptr::write(self.ptr.add(i), f());\n                }\n                self.len = i + 1;\n            }\n        } else if new_len < old_len {\n            for i in new_len..old_len {\n                unsafe {\n                    ptr::drop_in_place(self.ptr.add(i));\n                }\n            }\n            self.len = new_len;\n        }",
                    "self.len = new_len;\n        if new_len > old_len {\n            for i in old_len..new_len {\n                unsafe {\n                    ptr::write(self.ptr.add(i), f());\n                }\n            }\n        } else if new_len < old_len {\n            for i in new_len..old_len {\n                unsafe {\n                    ptr::drop_in_place(self.ptr.add(i));\n                }\n            }\n        }",
                    "restores upfront len assignment",
                ),
                mutation("push_skips_len", "self.len += 1;", "self.len += 0;", "skips push len"),
                mutation("len_fn_zero", "pub fn len(&self) -> usize {\n        self.len\n    }", "pub fn len(&self) -> usize {\n        0\n    }", "lies about len"),
                mutation(
                    "shrink_without_drop",
                    "for i in new_len..old_len {\n                unsafe {\n                    ptr::drop_in_place(self.ptr.add(i));\n                }\n            }",
                    "for i in new_len..old_len {\n                let _ = i;\n            }",
                    "leaks on shrink",
                ),
            ],
        },
        {
            "id": "CVE-2021-29933",
            "batch": "batch_5",
            "contract": "insert_many collects items first then writes with incremental set_len.",
            "evidence": "audit UAF; shift then panicking iterator",
            "dimensions": "normal insert; panic iter; empty; front; back",
            "symbols": ["InsertMany::insert_many"],
            "tests": '''
                use std::panic;
                #[test]
                fn heldout_insert_middle() {
                    let mut v = vec![1u32, 4];
                    v.insert_many(1, vec![2, 3].into_iter());
                    assert_eq!(v, vec![1, 2, 3, 4]);
                }
                #[test]
                fn heldout_insert_strings() {
                    let mut v: Vec<String> = vec!["a".into(), "d".into()];
                    v.insert_many(1, vec!["b".into(), "c".into()].into_iter());
                    assert_eq!(v, vec!["a", "b", "c", "d"]);
                }
                #[test]
                fn heldout_panic_iterator_drop_safe() {
                    struct Boom(usize);
                    impl Iterator for Boom {
                        type Item = String;
                        fn next(&mut self) -> Option<String> {
                            if self.0 == 1 { panic!("iter"); }
                            self.0 += 1;
                            Some(format!("i{}", self.0))
                        }
                    }
                    impl ExactSizeIterator for Boom {
                        fn len(&self) -> usize { 3 }
                    }
                    let mut v: Vec<String> = vec!["x".into(), "y".into()];
                    let r = panic::catch_unwind(panic::AssertUnwindSafe(|| {
                        v.insert_many(1, Boom(0));
                    }));
                    assert!(r.is_err());
                }
                #[test]
                fn heldout_empty_iterable() {
                    let mut v = vec![1i32, 2];
                    v.insert_many(1, std::iter::empty::<i32>());
                    assert_eq!(v, vec![1, 2]);
                }
                #[test]
                fn heldout_oob_index_panics() {
                    use std::panic;
                    let mut v = vec![1u32];
                    assert!(panic::catch_unwind(panic::AssertUnwindSafe(|| {
                        v.insert_many(5, vec![9u32].into_iter());
                    })).is_err());
                }
            ''',
            "reference": ref("CVE-2021-29933"),
            "mutants": [
                mutation(
                    "restore_streaming_write",
                    "let items: Vec<T> = iterable.into_iter().collect();\n        let num_items = items.len();\n        if num_items == 0 {\n            return;\n        }\n        self.reserve(num_items);\n\n        unsafe {\n            let start_ptr = self.as_mut_ptr().add(index);\n            ptr::copy(\n                start_ptr,\n                start_ptr.add(num_items),\n                len - index,\n            );\n            for (i, item) in items.into_iter().enumerate() {\n                ptr::write(start_ptr.add(i), item);\n                self.set_len(len + i + 1);\n            }\n        }",
                    "let mut iter = iterable.into_iter();\n        let num_items = iter.len();\n        if num_items == 0 {\n            return;\n        }\n        self.reserve(num_items);\n        unsafe {\n            let start_ptr = self.as_mut_ptr().add(index);\n            ptr::copy(start_ptr, start_ptr.add(num_items), len - index);\n            for i in 0..num_items {\n                let item = iter.next().expect(\"ExactSizeIterator produced too few items.\");\n                ptr::write(start_ptr.add(i), item);\n            }\n            self.set_len(len + num_items);\n        }",
                    "restores non-panic-safe streaming insert",
                ),
                mutation("skip_incremental_len", "self.set_len(len + i + 1);", "", "skips incremental len"),
                mutation("bad_index_allows", "if index > len {", "if index > len + 100 {", "allows OOB index"),
                mutation("no_reserve", "self.reserve(num_items);", "", "skips reserve"),
            ],
        },
    ]


def main() -> int:
    for spec in cases():
        if not spec["reference"].startswith("\n"):
            spec["reference"] = "\n" + spec["reference"]
        write_case(spec)
        print(f"wrote cases/{spec['id']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
