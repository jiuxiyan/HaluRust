#!/usr/bin/env python3
"""Generate the five pilot CVE held-out oracle cases."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from case_writer import mutation, write_case


def pilot_cases() -> list[dict]:
    return [
        {
            "id": "CVE-2020-25794",
            "batch": "pilot_1",
            "contract": (
                "InlineArray preserves length and element values for ordinary alignments, "
                "aligns element storage for high-alignment types, and remains Miri-safe "
                "across push/deref/drop."
            ),
            "evidence": (
                "audit expected_ub_kinds=invalid_alignment; upstream vulnerable revision "
                "Miri-confirmed; public normal path uses u32; bug is len.add(1) element base."
            ),
            "dimensions": (
                "normal multi-push values; empty length; align-16 push/deref/drop; "
                "mixed repeated push sequence; capacity-like multi-element order."
            ),
            "symbols": ["InlineArray::new", "InlineArray::len", "InlineArray::push", "InlineArray::deref"],
            "tests": '''
                use std::ops::Deref;

                #[repr(align(16))]
                #[derive(Clone, Copy, Debug, PartialEq)]
                struct Align16(u128);

                #[test]
                fn heldout_u32_values_and_order() {
                    let mut array: InlineArray<u32, [u64; 8]> = InlineArray::new();
                    array.push(7);
                    array.push(11);
                    array.push(13);
                    assert_eq!(array.len(), 3);
                    assert_eq!(array.deref(), &[7, 11, 13]);
                }

                #[test]
                fn heldout_empty_len_is_zero() {
                    let array: InlineArray<u32, [u64; 4]> = InlineArray::new();
                    assert_eq!(array.len(), 0);
                    assert!(array.deref().is_empty());
                }

                #[test]
                fn heldout_align16_push_deref_drop_is_safe() {
                    let mut array: InlineArray<Align16, [u64; 8]> = InlineArray::new();
                    array.push(Align16(0x1111_2222_3333_4444));
                    assert_eq!(array.len(), 1);
                    assert_eq!(array.deref()[0], Align16(0x1111_2222_3333_4444));
                    assert_eq!(
                        (array.deref().as_ptr() as usize) % core::mem::align_of::<Align16>(),
                        0
                    );
                    drop(array);
                }

                #[test]
                fn heldout_align16_two_elements_keep_values() {
                    let mut array: InlineArray<Align16, [u64; 12]> = InlineArray::new();
                    array.push(Align16(1));
                    array.push(Align16(2));
                    assert_eq!(array.deref(), &[Align16(1), Align16(2)]);
                }

                #[test]
                fn heldout_repeated_push_preserves_prefix() {
                    let mut array: InlineArray<u8, [u64; 8]> = InlineArray::new();
                    for value in 0u8..5 {
                        array.push(value);
                    }
                    assert_eq!(array.len(), 5);
                    assert_eq!(array.deref(), &[0, 1, 2, 3, 4]);
                }

                #[test]
                fn heldout_single_element_roundtrip() {
                    let mut array: InlineArray<i64, [u64; 4]> = InlineArray::new();
                    array.push(-9);
                    assert_eq!(array.len(), 1);
                    assert_eq!(array.deref()[0], -9);
                }
            ''',
            "reference": '''
                use std::marker::PhantomData;
                use std::mem::{self, MaybeUninit};
                use std::ops::Deref;
                use std::ptr;
                use std::slice::from_raw_parts;

                pub struct InlineArray<A, T> {
                    data: MaybeUninit<T>,
                    phantom: PhantomData<A>,
                }

                impl<A, T> InlineArray<A, T> {
                    #[inline]
                    unsafe fn len_const(&self) -> *const usize {
                        (&self.data as *const MaybeUninit<T>) as *const usize
                    }

                    #[inline]
                    unsafe fn len_mut(&mut self) -> *mut usize {
                        (&mut self.data as *mut MaybeUninit<T>) as *mut usize
                    }

                    #[inline]
                    unsafe fn data_ptr(&self) -> *const A {
                        let base = self.len_const().add(1) as *const u8;
                        base.add(base.align_offset(mem::align_of::<A>())) as *const A
                    }

                    #[inline]
                    unsafe fn data_ptr_mut(&mut self) -> *mut A {
                        let base = self.len_mut().add(1) as *mut u8;
                        base.add(base.align_offset(mem::align_of::<A>())) as *mut A
                    }

                    pub fn new() -> Self {
                        let mut array = InlineArray {
                            data: MaybeUninit::uninit(),
                            phantom: PhantomData,
                        };
                        unsafe {
                            *array.len_mut() = 0;
                        }
                        array
                    }

                    pub fn len(&self) -> usize {
                        unsafe { *self.len_const() }
                    }

                    pub fn push(&mut self, value: A) {
                        let index = self.len();
                        unsafe {
                            ptr::write(self.data_ptr_mut().add(index), value);
                            *self.len_mut() = index + 1;
                        }
                    }
                }

                impl<A, T> Drop for InlineArray<A, T> {
                    fn drop(&mut self) {
                        unsafe {
                            for i in 0..self.len() {
                                ptr::drop_in_place(self.data_ptr_mut().add(i));
                            }
                        }
                    }
                }

                impl<A, T> Deref for InlineArray<A, T> {
                    type Target = [A];

                    fn deref(&self) -> &Self::Target {
                        unsafe { from_raw_parts(self.data_ptr(), self.len()) }
                    }
                }
            ''',
            "mutants": [
                mutation(
                    "restore_unaligned_data_ptr",
                    "base.add(base.align_offset(mem::align_of::<A>())) as *const A",
                    "base as *const A",
                    "removes alignment fixup on const data pointer",
                ),
                mutation(
                    "push_skips_value_write",
                    "ptr::write(self.data_ptr_mut().add(index), value);",
                    "mem::forget(value);",
                    "drops the pushed value on the floor",
                ),
                mutation(
                    "corrupt_reported_len",
                    "*self.len_mut() = index + 1;",
                    "*self.len_mut() = index + 2;",
                    "reports wrong length after push",
                ),
                mutation(
                    "deref_ignores_stored_len",
                    "unsafe { from_raw_parts(self.data_ptr(), self.len()) }",
                    "unsafe { from_raw_parts(self.data_ptr(), 0) }",
                    "always exposes an empty slice",
                ),
            ],
        },
        {
            "id": "CVE-2023-41051",
            "batch": "pilot_1",
            "contract": (
                "VolatileMemory::get_ref only returns a typed reference when get_slice "
                "yields exactly size_of::<T>() bytes; short or overflowing requests err; "
                "SafeMemory normal reads preserve values."
            ),
            "evidence": (
                "audit expected_ub_kinds=out_of_bounds; BadMemory returns 1-byte slices; "
                "default get_ref previously cast without length verification."
            ),
            "dimensions": (
                "SafeMemory u32 value; BadMemory rejection; overflow offset; exact boundary; "
                "array-sized rejection; zero-size ZST acceptance."
            ),
            "symbols": ["VolatileMemory::get_ref", "SafeMemory", "BadMemory"],
            "tests": '''
                #[test]
                fn heldout_safe_memory_reads_written_pattern() {
                    let mut mem = SafeMemory::new(16);
                    mem.data[0..4].copy_from_slice(&[0xD4, 0xC3, 0xB2, 0xA1]);
                    let value = mem.get_ref::<[u8; 4]>(0).expect("in-bounds bytes");
                    assert_eq!(*value, [0xD4, 0xC3, 0xB2, 0xA1]);
                }

                #[test]
                fn heldout_bad_memory_rejects_undersized_slice() {
                    let mem = BadMemory::new(8);
                    assert!(mem.get_ref::<u64>(0).is_err());
                }

                #[test]
                fn heldout_safe_memory_rejects_overflowing_offset() {
                    let mem = SafeMemory::new(8);
                    assert!(mem.get_ref::<[u8; 4]>(usize::MAX - 1).is_err());
                }

                #[test]
                fn heldout_safe_memory_last_exact_fit() {
                    let mem = SafeMemory::new(8);
                    assert!(mem.get_ref::<[u8; 4]>(4).is_ok());
                    assert!(mem.get_ref::<[u8; 4]>(5).is_err());
                }

                #[test]
                fn heldout_bad_memory_rejects_large_array_type() {
                    let mem = BadMemory::new(32);
                    assert!(mem.get_ref::<[u32; 8]>(0).is_err());
                }

                #[test]
                fn heldout_safe_memory_len_matches_capacity() {
                    let mem = SafeMemory::new(24);
                    assert_eq!(mem.len(), 24);
                    assert!(mem.get_ref::<[u8; 2]>(22).is_ok());
                }
            ''',
            "reference": '''
                pub trait VolatileMemory {
                    fn len(&self) -> usize;
                    fn get_slice(&self, offset: usize, count: usize) -> Result<&[u8], ()>;

                    fn get_ref<T: Sized>(&self, offset: usize) -> Result<&T, ()> {
                        let size = std::mem::size_of::<T>();
                        let slice = self.get_slice(offset, size)?;
                        if slice.len() != size {
                            return Err(());
                        }
                        unsafe { Ok(&*(slice.as_ptr() as *const T)) }
                    }
                }

                pub struct SafeMemory {
                    data: Vec<u8>,
                }

                impl SafeMemory {
                    pub fn new(size: usize) -> Self {
                        SafeMemory { data: vec![0u8; size] }
                    }
                }

                impl VolatileMemory for SafeMemory {
                    fn len(&self) -> usize {
                        self.data.len()
                    }

                    fn get_slice(&self, offset: usize, count: usize) -> Result<&[u8], ()> {
                        let end = offset.checked_add(count).ok_or(())?;
                        if end > self.data.len() {
                            return Err(());
                        }
                        Ok(&self.data[offset..end])
                    }
                }

                pub struct BadMemory {
                    data: Vec<u8>,
                }

                impl BadMemory {
                    pub fn new(size: usize) -> Self {
                        BadMemory { data: vec![0u8; size] }
                    }
                }

                impl VolatileMemory for BadMemory {
                    fn len(&self) -> usize {
                        self.data.len()
                    }

                    fn get_slice(&self, offset: usize, _count: usize) -> Result<&[u8], ()> {
                        if offset < self.data.len() {
                            Ok(&self.data[offset..offset + 1])
                        } else {
                            Err(())
                        }
                    }
                }
            ''',
            "mutants": [
                mutation(
                    "skip_returned_len_check",
                    "if slice.len() != size {\n            return Err(());\n        }",
                    "",
                    "restores casting without verifying returned slice length",
                ),
                mutation(
                    "accept_shorter_slices",
                    "if slice.len() != size {",
                    "if slice.len() > size {",
                    "wrong inequality lets short slices through",
                ),
                mutation(
                    "get_ref_ignores_requested_size",
                    "let slice = self.get_slice(offset, size)?;",
                    "let slice = self.get_slice(offset, 1)?;",
                    "requests a one-byte slice regardless of T",
                ),
                mutation(
                    "safe_memory_off_by_one",
                    "if end > self.data.len() {",
                    "if end > self.data.len() + 8 {",
                    "weakens SafeMemory bounds",
                ),
            ],
        },
        {
            "id": "CVE-2021-45720",
            "batch": "pilot_1",
            "contract": (
                "LruCache put/pop_front/iter preserve FIFO order and length; iterator "
                "observation after structural mutation must not read freed nodes; Drop "
                "releases owned entries exactly once."
            ),
            "evidence": (
                "audit expected_ub_kinds=use_after_free; iterator retains node pointers "
                "while pop_front frees; sequential pop-then-iter is the safe baseline."
            ),
            "dimensions": (
                "iteration order/values; pop then iterate; empty pop; DropCounter; "
                "dangling-iter regression; multi pop sequence."
            ),
            "symbols": ["LruCache::new", "LruCache::put", "LruCache::pop_front", "LruCache::iter", "LruCache::len"],
            "profiles": [{"name": "default_no_sb", "flags": ["-Zmiri-disable-stacked-borrows"]}],
            "tests": '''
                #[test]
                fn heldout_iter_preserves_fifo_pairs() {
                    let mut cache = LruCache::new();
                    cache.put(10, 100);
                    cache.put(20, 200);
                    cache.put(30, 300);
                    let items: Vec<_> = cache.iter().map(|(k, v)| (*k, *v)).collect();
                    assert_eq!(items, vec![(10, 100), (20, 200), (30, 300)]);
                    assert_eq!(cache.len(), 3);
                }

                #[test]
                fn heldout_pop_front_then_remaining_iter() {
                    let mut cache = LruCache::new();
                    cache.put(1, 11);
                    cache.put(2, 22);
                    cache.put(3, 33);
                    assert_eq!(cache.pop_front(), Some((1, 11)));
                    let rest: Vec<_> = cache.iter().map(|(k, v)| (*k, *v)).collect();
                    assert_eq!(rest, vec![(2, 22), (3, 33)]);
                    assert_eq!(cache.len(), 2);
                }

                #[test]
                fn heldout_pop_on_empty_returns_none() {
                    let mut cache: LruCache<i32, i32> = LruCache::new();
                    assert_eq!(cache.pop_front(), None);
                    assert_eq!(cache.len(), 0);
                }

                #[test]
                fn heldout_drop_after_mixed_ops_is_safe() {
                    let mut cache = LruCache::new();
                    cache.put(1, 10);
                    cache.put(2, 20);
                    assert_eq!(cache.pop_front(), Some((1, 10)));
                    cache.put(3, 30);
                    assert_eq!(cache.len(), 2);
                    drop(cache);
                }

                #[test]
                #[should_panic(expected = "invalidated")]
                fn heldout_iterator_rejects_use_after_structural_pop() {
                    let mut cache = LruCache::new();
                    cache.put(7, 70);
                    let cache_ptr = &mut cache as *mut LruCache<i32, i32>;
                    unsafe {
                        let mut iter = (*cache_ptr).iter();
                        (*cache_ptr).pop_front();
                        let _ = iter.next();
                    }
                }

                #[test]
                fn heldout_uaf_regression_on_retained_reference() {
                    let mut cache = LruCache::new();
                    cache.put(9, 90);
                    let cache_ptr = &mut cache as *mut LruCache<i32, i32>;
                    unsafe {
                        let mut iter = (*cache_ptr).iter();
                        let (_k, value) = iter.next().expect("one entry");
                        (*cache_ptr).pop_front();
                        let observed = *value;
                        assert_eq!(observed, 90);
                    }
                }

                #[test]
                fn heldout_repeated_pop_drains_in_order() {
                    let mut cache = LruCache::new();
                    cache.put(4, 40);
                    cache.put(5, 50);
                    assert_eq!(cache.pop_front(), Some((4, 40)));
                    assert_eq!(cache.pop_front(), Some((5, 50)));
                    assert_eq!(cache.pop_front(), None);
                    assert!(cache.iter().next().is_none());
                }
            ''',
            "reference": '''
                use std::marker::PhantomData;
                use std::mem::{self, ManuallyDrop};
                use std::ptr;

                struct Node<K, V> {
                    key: ManuallyDrop<K>,
                    value: ManuallyDrop<V>,
                    prev: *mut Node<K, V>,
                    next: *mut Node<K, V>,
                }

                pub struct LruCache<K, V> {
                    head: *mut Node<K, V>,
                    tail: *mut Node<K, V>,
                    len: usize,
                    stamp: usize,
                    quarantine: Vec<*mut Node<K, V>>,
                }

                pub struct Iter<'a, K, V> {
                    ptr: *mut Node<K, V>,
                    remaining: usize,
                    expected_stamp: usize,
                    cache: *const LruCache<K, V>,
                    _phantom: PhantomData<&'a (K, V)>,
                }

                impl<'a, K, V> Iterator for Iter<'a, K, V> {
                    type Item = (&'a K, &'a V);

                    fn next(&mut self) -> Option<Self::Item> {
                        unsafe {
                            if (*self.cache).stamp != self.expected_stamp {
                                panic!("LruCache iterator invalidated by structural modification");
                            }
                        }
                        if self.remaining == 0 {
                            return None;
                        }
                        unsafe {
                            let node = &*self.ptr;
                            self.ptr = node.next;
                            self.remaining -= 1;
                            Some((&*node.key, &*node.value))
                        }
                    }
                }

                impl<K, V> LruCache<K, V> {
                    pub fn new() -> Self {
                        unsafe {
                            let head = Box::into_raw(Box::new(Node {
                                key: ManuallyDrop::new(mem::zeroed()),
                                value: ManuallyDrop::new(mem::zeroed()),
                                prev: ptr::null_mut(),
                                next: ptr::null_mut(),
                            }));
                            let tail = Box::into_raw(Box::new(Node {
                                key: ManuallyDrop::new(mem::zeroed()),
                                value: ManuallyDrop::new(mem::zeroed()),
                                prev: head,
                                next: ptr::null_mut(),
                            }));
                            (*head).next = tail;
                            LruCache {
                                head,
                                tail,
                                len: 0,
                                stamp: 0,
                                quarantine: Vec::new(),
                            }
                        }
                    }

                    pub fn put(&mut self, key: K, value: V) {
                        unsafe {
                            let node = Box::into_raw(Box::new(Node {
                                key: ManuallyDrop::new(key),
                                value: ManuallyDrop::new(value),
                                prev: (*self.tail).prev,
                                next: self.tail,
                            }));
                            (*(*self.tail).prev).next = node;
                            (*self.tail).prev = node;
                            self.len += 1;
                            self.stamp = self.stamp.wrapping_add(1);
                        }
                    }

                    pub fn pop_front(&mut self) -> Option<(K, V)> {
                        if self.len == 0 {
                            return None;
                        }
                        unsafe {
                            let node = (*self.head).next;
                            (*(*node).prev).next = (*node).next;
                            (*(*node).next).prev = (*node).prev;
                            self.len -= 1;
                            self.stamp = self.stamp.wrapping_add(1);
                            let key = ManuallyDrop::take(&mut (*node).key);
                            let value = ManuallyDrop::take(&mut (*node).value);
                            // Keep the allocation alive until cache drop so outstanding
                            // iterator references cannot become use-after-free.
                            self.quarantine.push(node);
                            Some((key, value))
                        }
                    }

                    pub fn iter(&self) -> Iter<'_, K, V> {
                        Iter {
                            ptr: unsafe { (*self.head).next },
                            remaining: self.len,
                            expected_stamp: self.stamp,
                            cache: self,
                            _phantom: PhantomData,
                        }
                    }

                    pub fn len(&self) -> usize {
                        self.len
                    }
                }

                impl<K, V> Drop for LruCache<K, V> {
                    fn drop(&mut self) {
                        while self.pop_front().is_some() {}
                        unsafe {
                            for node in self.quarantine.drain(..) {
                                drop(Box::from_raw(node));
                            }
                            drop(Box::from_raw(self.head));
                            drop(Box::from_raw(self.tail));
                        }
                    }
                }
            ''',
            "mutants": [
                mutation(
                    "ignore_iterator_stamp",
                    "if (*self.cache).stamp != self.expected_stamp {\n                panic!(\"LruCache iterator invalidated by structural modification\");\n            }",
                    "",
                    "allows iteration after structural modification",
                ),
                mutation(
                    "restore_immediate_free_on_pop",
                    "let key = ManuallyDrop::take(&mut (*node).key);\n            let value = ManuallyDrop::take(&mut (*node).value);\n            // Keep the allocation alive until cache drop so outstanding\n            // iterator references cannot become use-after-free.\n            self.quarantine.push(node);\n            Some((key, value))",
                    "let key = ManuallyDrop::take(&mut (*node).key);\n            let value = ManuallyDrop::take(&mut (*node).value);\n            drop(Box::from_raw(node));\n            Some((key, value))",
                    "restores immediate deallocation enabling UAF",
                ),
                mutation(
                    "iter_skips_first",
                    "ptr: unsafe { (*self.head).next },",
                    "ptr: unsafe { (*(*self.head).next).next },",
                    "iterator starts one node too far",
                ),
                mutation(
                    "put_skips_len_increment",
                    "self.len += 1;",
                    "self.len += 0;",
                    "fails to increase length on put",
                ),
            ],
        },
        {
            "id": "CVE-2021-25905",
            "batch": "pilot_1",
            "contract": (
                "GreedyAccessReader::read_chunk only exposes initialized bytes; successful "
                "reads return exact requested contents; short readers and zero-length "
                "requests preserve safe buffer contracts."
            ),
            "evidence": (
                "audit expected_ub_kinds=uninitialized_memory; vulnerable set_len before "
                "Read; Cursor/slice path should remain functionally correct after fix."
            ),
            "dimensions": (
                "exact read contents; malicious reader safety; short-read error; empty "
                "chunk; repeated chunk sequence; partial EOF rejection."
            ),
            "symbols": ["GreedyAccessReader::new", "GreedyAccessReader::read_chunk"],
            "tests": '''
                use std::io::{self, Cursor, Read};

                struct PeekingReader;
                impl Read for PeekingReader {
                    fn read(&mut self, buf: &mut [u8]) -> io::Result<usize> {
                        if let Some(first) = buf.first() {
                            let _observe = *first;
                        }
                        for slot in buf.iter_mut() {
                            *slot = 0x5A;
                        }
                        Ok(buf.len())
                    }
                }

                struct ShortReader;
                impl Read for ShortReader {
                    fn read(&mut self, _buf: &mut [u8]) -> io::Result<usize> {
                        Ok(0)
                    }
                }

                #[test]
                fn heldout_cursor_returns_exact_bytes() {
                    let mut reader = GreedyAccessReader::new(Cursor::new(vec![9, 8, 7, 6]));
                    assert_eq!(reader.read_chunk(4).unwrap(), vec![9, 8, 7, 6]);
                }

                #[test]
                fn heldout_peeking_reader_never_sees_uninit() {
                    let mut reader = GreedyAccessReader::new(PeekingReader);
                    assert_eq!(reader.read_chunk(6).unwrap(), vec![0x5A; 6]);
                }

                #[test]
                fn heldout_short_reader_errors_without_fake_success() {
                    let mut reader = GreedyAccessReader::new(ShortReader);
                    assert!(reader.read_chunk(3).is_err());
                }

                #[test]
                fn heldout_zero_len_chunk_is_empty_ok() {
                    let mut reader = GreedyAccessReader::new(Cursor::new(vec![1, 2, 3]));
                    assert_eq!(reader.read_chunk(0).unwrap(), Vec::<u8>::new());
                }

                #[test]
                fn heldout_repeated_chunks_consume_stream() {
                    let mut reader = GreedyAccessReader::new(Cursor::new(vec![1, 2, 3, 4]));
                    assert_eq!(reader.read_chunk(2).unwrap(), vec![1, 2]);
                    assert_eq!(reader.read_chunk(2).unwrap(), vec![3, 4]);
                }

                #[test]
                fn heldout_eof_before_full_chunk_errors() {
                    let mut reader = GreedyAccessReader::new(Cursor::new(vec![1, 2]));
                    assert!(reader.read_chunk(4).is_err());
                }
            ''',
            "reference": '''
                use std::io::{self, Read};

                pub struct GreedyAccessReader<R> {
                    pub inner: R,
                    pub buf: Vec<u8>,
                    pub pos: usize,
                }

                impl<R: Read> GreedyAccessReader<R> {
                    pub fn new(inner: R) -> Self {
                        GreedyAccessReader {
                            inner,
                            buf: Vec::new(),
                            pos: 0,
                        }
                    }

                    pub fn read_chunk(&mut self, len: usize) -> io::Result<Vec<u8>> {
                        let mut buf = vec![0u8; len];
                        self.inner.read_exact(&mut buf)?;
                        Ok(buf)
                    }
                }
            ''',
            "mutants": [
                mutation(
                    "restore_set_len_uninit",
                    "let mut buf = vec![0u8; len];\n        self.inner.read_exact(&mut buf)?;\n        Ok(buf)",
                    "let mut buf = Vec::with_capacity(len);\n        unsafe { buf.set_len(len); }\n        self.inner.read_exact(&mut buf)?;\n        Ok(buf)",
                    "restores uninitialized buffer exposure",
                ),
                mutation(
                    "truncate_success_length",
                    "Ok(buf)",
                    "Ok(buf[..buf.len().saturating_sub(1)].to_vec())",
                    "returns wrong successful payload length",
                ),
                mutation(
                    "ignore_read_error",
                    "self.inner.read_exact(&mut buf)?;\n        Ok(buf)",
                    "let _ = self.inner.read_exact(&mut buf);\n        Ok(buf)",
                    "reports success after incomplete reads",
                ),
                mutation(
                    "force_empty_on_nonzero",
                    "let mut buf = vec![0u8; len];",
                    "let mut buf = vec![0u8; 0];",
                    "allocates empty buffer for nonzero requests",
                ),
            ],
        },
        {
            "id": "CVE-2020-35923",
            "batch": "pilot_1",
            "contract": (
                "NotNan rejects NaN at construction; successful AddAssign updates only "
                "after a non-NaN sum is computed; panic paths must not leave a NaN "
                "payload that Ord can observe."
            ),
            "evidence": (
                "audit expected_ub_kinds=invalid_value; vulnerable AddAssign mutates then "
                "asserts; post-panic cmp uses unreachable_unchecked."
            ),
            "dimensions": (
                "normal add; NaN constructor rejection; infinity+neg_infinity panic "
                "safety; ordering after success; repeated adds; eq contract."
            ),
            "symbols": ["NotNan::new", "NotNan::into_inner", "AddAssign", "Ord"],
            "tests": '''
                use std::panic;

                #[test]
                fn heldout_add_assign_keeps_finite_sum() {
                    let mut value = NotNan::new(4.0).unwrap();
                    value += NotNan::new(2.5).unwrap();
                    assert_eq!(value.into_inner(), 6.5);
                }

                #[test]
                fn heldout_constructor_rejects_nan() {
                    assert!(NotNan::new(f64::NAN).is_err());
                }

                #[test]
                fn heldout_nan_sum_panics_without_poisoning_value() {
                    let mut value = NotNan::new(f64::INFINITY).unwrap();
                    let other = NotNan::new(f64::NEG_INFINITY).unwrap();
                    let panicked = panic::catch_unwind(panic::AssertUnwindSafe(|| {
                        value += other;
                    }));
                    assert!(panicked.is_err());
                    assert!(!value.into_inner().is_nan());
                    let zero = NotNan::new(0.0).unwrap();
                    let _ = value.cmp(&zero);
                }

                #[test]
                fn heldout_ord_matches_finite_total_order() {
                    let left = NotNan::new(-1.0).unwrap();
                    let right = NotNan::new(2.0).unwrap();
                    assert!(left < right);
                    assert_eq!(left.cmp(&right), std::cmp::Ordering::Less);
                }

                #[test]
                fn heldout_repeated_add_assign_sequence() {
                    let mut value = NotNan::new(1.0).unwrap();
                    value += 1.0;
                    value += NotNan::new(3.0).unwrap();
                    assert_eq!(value.into_inner(), 5.0);
                }

                #[test]
                fn heldout_eq_on_same_payload() {
                    let left = NotNan::new(8.25).unwrap();
                    let right = NotNan::new(8.25).unwrap();
                    assert_eq!(left, right);
                }
            ''',
            "reference": '''
                use std::cmp::Ordering;
                use std::ops::AddAssign;

                #[derive(Debug, Clone, Copy)]
                pub struct NotNan(f64);

                impl NotNan {
                    pub fn new(val: f64) -> Result<Self, &'static str> {
                        if val.is_nan() {
                            Err("NaN is not allowed")
                        } else {
                            Ok(NotNan(val))
                        }
                    }

                    pub fn into_inner(self) -> f64 {
                        self.0
                    }
                }

                impl AddAssign for NotNan {
                    fn add_assign(&mut self, other: Self) {
                        *self += other.0;
                    }
                }

                impl AddAssign<f64> for NotNan {
                    fn add_assign(&mut self, other: f64) {
                        let sum = self.0 + other;
                        assert!(!sum.is_nan(), "Addition resulted in NaN");
                        self.0 = sum;
                    }
                }

                impl PartialEq for NotNan {
                    fn eq(&self, other: &Self) -> bool {
                        self.0 == other.0
                    }
                }

                impl Eq for NotNan {}

                impl PartialOrd for NotNan {
                    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                        self.0.partial_cmp(&other.0)
                    }
                }

                impl Ord for NotNan {
                    fn cmp(&self, other: &Self) -> Ordering {
                        match self.partial_cmp(other) {
                            Some(ord) => ord,
                            None => unsafe { std::hint::unreachable_unchecked() },
                        }
                    }
                }
            ''',
            "mutants": [
                mutation(
                    "mutate_before_nan_check",
                    "let sum = self.0 + other;\n        assert!(!sum.is_nan(), \"Addition resulted in NaN\");\n        self.0 = sum;",
                    "self.0 += other;\n        assert!(!self.0.is_nan(), \"Addition resulted in NaN\");",
                    "restores poisoning AddAssign",
                ),
                mutation(
                    "allow_nan_construction",
                    "if val.is_nan() {\n            Err(\"NaN is not allowed\")\n        } else {\n            Ok(NotNan(val))\n        }",
                    "Ok(NotNan(val))",
                    "accepts NaN into NotNan",
                ),
                mutation(
                    "wrong_sum_result",
                    "self.0 = sum;",
                    "self.0 = sum + 1.0;",
                    "corrupts successful add result",
                ),
                mutation(
                    "break_eq",
                    "self.0 == other.0",
                    "self.0 != other.0",
                    "inverts equality",
                ),
            ],
        },
    ]


def main() -> int:
    for spec in pilot_cases():
        write_case(spec)
        print(f"wrote cases/{spec['id']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
