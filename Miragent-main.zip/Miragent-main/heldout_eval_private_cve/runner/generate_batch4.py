#!/usr/bin/env python3
"""Generate batch_4 CVE held-out oracle cases (10)."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from case_writer import mutation, write_case

FIX_ROOT = Path("/tmp/cve_batch4_fix")


def ref(cid: str) -> str:
    return FIX_ROOT.joinpath(f"{cid}.rs").read_text(encoding="utf-8")


def cases() -> list[dict]:
    return [
        {
            "id": "CVE-2020-35877",
            "batch": "batch_4",
            "contract": "Buffer indexing panics on OOB; in-bounds read/write preserve values.",
            "evidence": "audit OOB; Index/IndexMut use get_unchecked",
            "dimensions": "in-bounds read; write; len; OOB panic; multi",
            "symbols": ["Buffer::new", "len", "Index", "IndexMut"],
            "tests": '''
                use std::panic;
                #[test]
                fn heldout_in_bounds_read() {
                    let b = Buffer::<u32>::new(4);
                    assert_eq!(b[0], 0u32);
                    assert_eq!(b[3], 0u32);
                    assert_eq!(b.len(), 4);
                }
                #[test]
                fn heldout_in_bounds_write() {
                    let mut b = Buffer::new(3);
                    b[1] = 9u8;
                    assert_eq!(b[1], 9);
                }
                #[test]
                fn heldout_oob_read_panics() {
                    let b = Buffer::<u8>::new(2);
                    assert!(panic::catch_unwind(|| { let _ = b[2]; }).is_err());
                }
                #[test]
                fn heldout_oob_write_panics() {
                    let mut b = Buffer::<u8>::new(2);
                    assert!(panic::catch_unwind(panic::AssertUnwindSafe(|| { b[5] = 1; })).is_err());
                }
                #[test]
                fn heldout_empty_buffer_len() {
                    let b = Buffer::<i32>::new(0);
                    assert_eq!(b.len(), 0);
                }
            ''',
            "reference": ref("CVE-2020-35877"),
            "mutants": [
                mutation("restore_unchecked_index", "&self.data[index]", "unsafe { self.data.get_unchecked(index) }", "restores OOB read"),
                mutation("restore_unchecked_index_mut", "&mut self.data[index]", "unsafe { self.data.get_unchecked_mut(index) }", "restores OOB write"),
                mutation("len_always_zero", "self.data.len()", "0", "lies about len"),
                mutation("new_ignores_size", "vec![T::default(); size]", "vec![T::default(); 0]", "allocates empty"),
            ],
        },
        {
            "id": "CVE-2020-35878",
            "batch": "batch_4",
            "contract": "SimpleMap remove_entry_at requires occupied slots; insert/get roundtrip.",
            "evidence": "audit uninit; remove on vacant assumes init",
            "dimensions": "insert get; remove occupied; vacant panic; len; empty",
            "symbols": ["SimpleMap::new", "insert", "get", "remove_entry_at", "len"],
            "tests": '''
                use std::panic;
                #[test]
                fn heldout_insert_get_roundtrip() {
                    let mut m: SimpleMap<&str, i32> = SimpleMap::new(4);
                    m.insert("a", 1);
                    m.insert("b", 2);
                    assert!(!m.is_empty());
                    assert_eq!(m.get(&"a"), Some(&1));
                    assert_eq!(m.get(&"b"), Some(&2));
                    assert_eq!(m.len(), 2);
                }
                #[test]
                fn heldout_remove_occupied() {
                    let mut m: SimpleMap<u32, String> = SimpleMap::new(3);
                    m.insert(7, "x".into());
                    let (k, v) = m.remove_entry_at(0);
                    assert_eq!(k, 7);
                    assert_eq!(v, "x");
                    assert_eq!(m.len(), 0);
                    assert!(m.get(&7).is_none());
                }
                #[test]
                fn heldout_vacant_remove_panics() {
                    let mut m: SimpleMap<u8, u8> = SimpleMap::new(2);
                    m.insert(1, 2);
                    assert!(panic::catch_unwind(panic::AssertUnwindSafe(|| { m.remove_entry_at(1); })).is_err());
                }
                #[test]
                fn heldout_empty_is_empty() {
                    let m: SimpleMap<i32, i32> = SimpleMap::new(2);
                    assert!(m.is_empty());
                    assert_eq!(m.len(), 0);
                }
                #[test]
                fn heldout_missing_get() {
                    let mut m: SimpleMap<&str, u8> = SimpleMap::new(2);
                    m.insert("k", 3);
                    assert!(m.get(&"missing").is_none());
                }
            ''',
            "reference": ref("CVE-2020-35878"),
            "mutants": [
                mutation("remove_occupied_guard", "assert!(entry.occupied, \"entry is not occupied\");\n        ", "", "allows vacant remove"),
                mutation("insert_skips_len", "self.len += 1;", "self.len += 0;", "skips insert len"),
                mutation("get_always_none", "return Some(unsafe { entry.value.assume_init_ref() });", "return None;", "never finds"),
                mutation("is_empty_always_true", "self.len == 0", "true", "lies empty"),
            ],
        },
        {
            "id": "CVE-2020-35885",
            "batch": "batch_4",
            "contract": "StrcCtx::new owns and frees; from_ptr does not free borrowed C strings.",
            "evidence": "audit UAF/double-free; from_ptr Drop frees non-owned",
            "dimensions": "owned new; borrowed reclaim; nullish; as_ptr; drop owned",
            "symbols": ["StrcCtx::new", "from_ptr", "Drop"],
            "tests": '''
                use std::ffi::CString;
                #[test]
                fn heldout_owned_new_drops_clean() {
                    let ctx = StrcCtx::new("owned");
                    assert!(!ctx.as_ptr().is_null());
                    drop(ctx);
                }
                #[test]
                fn heldout_borrowed_from_ptr_does_not_free() {
                    let c = CString::new("borrowed").unwrap();
                    let raw = c.into_raw();
                    {
                        let ctx = StrcCtx::from_ptr(raw);
                        assert_eq!(ctx.as_ptr(), raw);
                        drop(ctx);
                    }
                    // Reclaim still valid because from_ptr must not free.
                    let reclaimed = unsafe { CString::from_raw(raw) };
                    assert_eq!(reclaimed.to_str().unwrap(), "borrowed");
                }
                #[test]
                fn heldout_two_owned_independent() {
                    let a = StrcCtx::new("a");
                    let b = StrcCtx::new("b");
                    assert_ne!(a.as_ptr(), b.as_ptr());
                }
                #[test]
                fn heldout_empty_owned() {
                    let ctx = StrcCtx::new("");
                    assert!(!ctx.as_ptr().is_null());
                }
                #[test]
                fn heldout_borrowed_null_is_noop_drop() {
                    let ctx = StrcCtx::from_ptr(std::ptr::null_mut());
                    drop(ctx);
                }
            ''',
            "reference": ref("CVE-2020-35885"),
            "mutants": [
                mutation("from_ptr_marks_owned", "StrcCtx { ptr, owned: false }", "StrcCtx { ptr, owned: true }", "frees borrowed"),
                mutation("drop_ignores_owned", "if self.owned && !self.ptr.is_null()", "if !self.ptr.is_null()", "always frees"),
                mutation("new_not_owned", "StrcCtx { ptr: c.into_raw(), owned: true }", "StrcCtx { ptr: c.into_raw(), owned: false }", "leaks owned / breaks drop"),
                mutation("as_ptr_null", "pub fn as_ptr(&self) -> *mut c_char {\n        self.ptr\n    }", "pub fn as_ptr(&self) -> *mut c_char {\n        std::ptr::null_mut()\n    }", "lies about pointer"),
            ],
        },
        {
            "id": "CVE-2020-35887",
            "batch": "batch_4",
            "contract": "Array indexing and ranges panic when out of bounds; in-bounds access works.",
            "evidence": "audit OOB; Index without bounds checks",
            "dimensions": "in-bounds; OOB panic; range; mut write; len",
            "symbols": ["Array::new", "len", "Index", "IndexMut"],
            "tests": '''
                use std::panic;
                #[test]
                fn heldout_in_bounds_access() {
                    let a = Array::<u32>::new(4);
                    assert_eq!(a[0], 0);
                    assert_eq!(a[3], 0);
                    assert_eq!(a.len(), 4);
                }
                #[test]
                fn heldout_mut_write() {
                    let mut a = Array::<u8>::new(3);
                    a[1] = 7;
                    assert_eq!(a[1], 7);
                }
                #[test]
                fn heldout_oob_index_panics() {
                    let a = Array::<u8>::new(2);
                    assert!(panic::catch_unwind(|| { let _ = a[2]; }).is_err());
                }
                #[test]
                fn heldout_oob_index_mut_panics() {
                    let mut a = Array::<u8>::new(2);
                    assert!(panic::catch_unwind(panic::AssertUnwindSafe(|| { a[2] = 9; })).is_err());
                }
                #[test]
                fn heldout_range_in_bounds() {
                    let a = Array::<u8>::new(5);
                    let s: &[u8] = &a[1..4];
                    assert_eq!(s.len(), 3);
                }
                #[test]
                fn heldout_range_oob_panics() {
                    let a = Array::<u8>::new(3);
                    assert!(panic::catch_unwind(|| { let _ = &a[0..4]; }).is_err());
                }
            ''',
            "reference": ref("CVE-2020-35887"),
            "mutants": [
                mutation(
                    "remove_index_bound",
                    "fn index(&self, idx: usize) -> &T {\n        assert!(idx < self.len, \"index out of bounds\");\n        unsafe { &*self.ptr.add(idx) }",
                    "fn index(&self, idx: usize) -> &T {\n        unsafe { &*self.ptr.add(idx) }",
                    "removes index bound",
                ),
                mutation(
                    "remove_index_mut_bound",
                    "fn index_mut(&mut self, idx: usize) -> &mut T {\n        assert!(idx < self.len, \"index out of bounds\");\n        unsafe { &mut *self.ptr.add(idx) }",
                    "fn index_mut(&mut self, idx: usize) -> &mut T {\n        unsafe { &mut *self.ptr.add(idx) }",
                    "removes mut bound",
                ),
                mutation("remove_range_bound", "assert!(range.start <= range.end && range.end <= self.len, \"range out of bounds\");\n        ", "", "removes range bound"),
                mutation(
                    "len_lie",
                    "pub fn len(&self) -> usize {\n        self.len\n    }",
                    "pub fn len(&self) -> usize {\n        0\n    }",
                    "lies about len()",
                ),
            ],
        },
        {
            "id": "CVE-2020-35890",
            "batch": "batch_4",
            "contract": "compact::Vec::with relinquishes ownership before the closure so panic cannot double-free.",
            "evidence": "audit UAF; with not panic-safe",
            "dimensions": "push remove; panic remove; len; with success; empty",
            "symbols": ["compact::Vec::new", "push", "remove", "with", "len"],
            "profiles": [{"name": "default", "flags": []}],
            "tests": '''
                use std::panic;
                use compact::Vec as CVec;
                #[test]
                fn heldout_push_remove_ok() {
                    let mut v = CVec::new();
                    v.push(1u32); v.push(2); v.push(3);
                    assert_eq!(v.remove(1), 2);
                    assert_eq!(v.len(), 2);
                }
                #[test]
                fn heldout_oob_remove_panic_is_drop_safe() {
                    let mut v = CVec::new();
                    v.push("a".to_string());
                    v.push("b".to_string());
                    let r = panic::catch_unwind(panic::AssertUnwindSafe(|| { v.remove(9); }));
                    assert!(r.is_err());
                }
                #[test]
                fn heldout_with_extends() {
                    let mut v = CVec::new();
                    v.push(10u8);
                    v.with(|stdv| { stdv.push(20); stdv.push(30); });
                    assert_eq!(v.len(), 3);
                }
                #[test]
                fn heldout_empty_len() {
                    let v: CVec<u8> = CVec::new();
                    assert_eq!(v.len(), 0);
                }
                #[test]
                fn heldout_remove_first() {
                    let mut v = CVec::new();
                    v.push(7u16); v.push(8);
                    assert_eq!(v.remove(0), 7);
                    assert_eq!(v.len(), 1);
                }
            ''',
            "reference": ref("CVE-2020-35890"),
            "mutants": [
                mutation(
                    "skip_relinquish",
                    "self.ptr = NonNull::dangling().as_ptr();\n            self.len = 0;\n            self.cap = 0;\n            ",
                    "",
                    "keeps ownership during with",
                ),
                mutation("push_skips_len", "self.set_len(len + 1);", "self.set_len(len);", "skips push len"),
                mutation(
                    "len_always_zero",
                    "pub fn len(&self) -> usize {\n            self.len\n        }",
                    "pub fn len(&self) -> usize {\n            0\n        }",
                    "lies about len",
                ),
                mutation("remove_always_first", "v.remove(index)", "v.remove(0)", "ignores remove index"),
            ],
        },
        {
            "id": "CVE-2020-35891",
            "batch": "batch_4",
            "contract": "Vec::with relinquishes ownership before the closure so panic cannot double-free.",
            "evidence": "audit UAF; with not panic-safe",
            "dimensions": "valid remove; panic remove; push; with; empty",
            "symbols": ["Vec::new", "push", "remove", "with", "len"],
            "tests": '''
                use std::panic;
                #[test]
                fn heldout_valid_remove() {
                    let mut v = Vec::new();
                    v.push(1u32); v.push(2); v.push(3);
                    assert_eq!(v.remove(1), 2);
                    assert_eq!(v.len(), 2);
                }
                #[test]
                fn heldout_oob_remove_panic_is_drop_safe() {
                    let mut v = Vec::new();
                    v.push("x".to_string());
                    let r = panic::catch_unwind(panic::AssertUnwindSafe(|| { v.remove(3); }));
                    assert!(r.is_err());
                }
                #[test]
                fn heldout_with_push_via_std() {
                    let mut v = Vec::new();
                    v.with(|stdv| stdv.extend_from_slice(&[1u8, 2, 3]));
                    assert_eq!(v.len(), 3);
                }
                #[test]
                fn heldout_empty() {
                    let v: Vec<u8> = Vec::new();
                    assert_eq!(v.len(), 0);
                }
                #[test]
                fn heldout_remove_last() {
                    let mut v = Vec::new();
                    v.push(9u8); v.push(8);
                    assert_eq!(v.remove(1), 8);
                }
            ''',
            "reference": ref("CVE-2020-35891"),
            "mutants": [
                mutation(
                    "skip_relinquish",
                    "self.ptr = NonNull::dangling();\n        self.len = 0;\n        self.cap = 0;\n\n        ",
                    "",
                    "keeps ownership during with",
                ),
                mutation("push_skips_len", "self.len = len + 1;", "self.len = len;", "skips push len"),
                mutation(
                    "len_always_zero",
                    "pub fn len(&self) -> usize {\n        self.len\n    }",
                    "pub fn len(&self) -> usize {\n        0\n    }",
                    "lies about len",
                ),
                mutation("remove_always_zero", "v.remove(index)", "v.remove(0)", "ignores remove index"),
            ],
        },
        {
            "id": "CVE-2020-35892",
            "batch": "batch_4",
            "contract": "Slab remove handles last-element specially; Index is bounds-checked against len.",
            "evidence": "audit OOB/double-free; remove duplicates last; Index unchecked",
            "dimensions": "insert index; remove mid; remove last; OOB index; len",
            "symbols": ["Slab::with_capacity", "insert", "remove", "Index", "len"],
            "tests": '''
                use std::panic;
                #[test]
                fn heldout_insert_index_roundtrip() {
                    let mut s = Slab::with_capacity(4);
                    s.insert(10u32); s.insert(20); s.insert(30);
                    assert_eq!(s[0], 10);
                    assert_eq!(s[2], 30);
                    assert_eq!(s.len(), 3);
                }
                #[test]
                fn heldout_remove_middle() {
                    let mut s = Slab::with_capacity(4);
                    s.insert("a".to_string()); s.insert("b".into()); s.insert("c".into());
                    assert_eq!(s.remove(1), "b");
                    assert_eq!(s.len(), 2);
                }
                #[test]
                fn heldout_remove_last_no_double_free() {
                    let mut s = Slab::with_capacity(2);
                    s.insert("only".to_string());
                    assert_eq!(s.remove(0), "only");
                    assert_eq!(s.len(), 0);
                }
                #[test]
                fn heldout_oob_index_panics() {
                    let mut s = Slab::with_capacity(2);
                    s.insert(1u8);
                    assert!(panic::catch_unwind(|| { let _ = s[3]; }).is_err());
                }
                #[test]
                fn heldout_empty_len() {
                    let s: Slab<u8> = Slab::with_capacity(2);
                    assert_eq!(s.len(), 0);
                }
            ''',
            "reference": ref("CVE-2020-35892"),
            "mutants": [
                mutation(
                    "forget_swapped_last",
                    "ptr::write(elem_ptr, last_elem);",
                    "core::mem::forget(last_elem);",
                    "drops last elem twice on mid-remove",
                ),
                mutation("remove_index_bound", "assert!(index < self.len, \"index out of bounds\");\n        ", "", "removes index bound"),
                mutation("insert_skips_len", "self.len += 1;", "self.len += 0;", "skips insert len"),
                mutation(
                    "len_always_zero",
                    "pub fn len(&self) -> usize {\n        self.len\n    }",
                    "pub fn len(&self) -> usize {\n        0\n    }",
                    "lies about len",
                ),
            ],
        },
        {
            "id": "CVE-2020-35893",
            "batch": "batch_4",
            "contract": "Slab remove handles last-element specially; Index is bounds-checked against len.",
            "evidence": "audit OOB; remove last double-read; Index unchecked",
            "dimensions": "insert index; remove mid; remove last; OOB; len",
            "symbols": ["Slab::with_capacity", "insert", "remove", "Index", "len"],
            "tests": '''
                use std::panic;
                #[test]
                fn heldout_basic_insert_get() {
                    let mut s = Slab::with_capacity(3);
                    s.insert(5u16); s.insert(6);
                    assert_eq!(s[0], 5);
                    assert_eq!(s[1], 6);
                }
                #[test]
                fn heldout_remove_middle_keeps_other() {
                    let mut s = Slab::with_capacity(4);
                    s.insert("a".to_string()); s.insert("b".into()); s.insert("c".into());
                    assert_eq!(s.remove(0), "a");
                    assert_eq!(s.len(), 2);
                    assert_eq!(s[0], "c");
                }
                #[test]
                fn heldout_remove_last_drop_safe() {
                    let mut s = Slab::with_capacity(2);
                    s.insert("z".to_string());
                    assert_eq!(s.remove(0), "z");
                }
                #[test]
                fn heldout_index_oob_panics() {
                    let mut s = Slab::with_capacity(2);
                    s.insert(9u8);
                    assert!(panic::catch_unwind(|| { let _ = s[8]; }).is_err());
                }
                #[test]
                fn heldout_len_tracks_inserts() {
                    let mut s = Slab::with_capacity(8);
                    for i in 0..5u8 { s.insert(i); }
                    assert_eq!(s.len(), 5);
                }
            ''',
            "reference": ref("CVE-2020-35893"),
            "mutants": [
                mutation(
                    "forget_swapped_last",
                    "ptr::write(elem_ptr, last_elem);",
                    "core::mem::forget(last_elem);",
                    "drops last elem twice on mid-remove",
                ),
                mutation("remove_index_bound", "assert!(index < self.len, \"index out of bounds\");\n        ", "", "removes index bound"),
                mutation("insert_skips_len", "self.len += 1;", "self.len += 0;", "skips insert len"),
                mutation("capacity_start_zero", "capacity: cap,", "capacity: 0,", "lies initial capacity"),
            ],
        },
        {
            "id": "CVE-2020-35895",
            "batch": "batch_4",
            "contract": "ArrayVec::insert requires index <= len; push/pop/insert within bounds keep values.",
            "evidence": "audit OOB; insert without index<=len check",
            "dimensions": "push pop; valid insert; OOB insert panic; len; drop types",
            "symbols": ["ArrayVec::new", "push", "pop", "insert", "len"],
            "tests": '''
                use std::panic;
                #[test]
                fn heldout_push_pop_values() {
                    let mut v: ArrayVec<u32, 4> = ArrayVec::new();
                    v.push(1); v.push(2);
                    assert_eq!(v.pop(), Some(2));
                    assert_eq!(v[0], 1);
                }
                #[test]
                fn heldout_insert_middle() {
                    let mut v: ArrayVec<u8, 8> = ArrayVec::new();
                    v.push(1); v.push(3);
                    v.insert(1, 2);
                    assert_eq!(v.len(), 3);
                    assert_eq!(v[0], 1);
                    assert_eq!(v[1], 2);
                    assert_eq!(v[2], 3);
                }
                #[test]
                fn heldout_insert_oob_panics() {
                    let mut v: ArrayVec<u8, 4> = ArrayVec::new();
                    v.push(1);
                    assert!(panic::catch_unwind(panic::AssertUnwindSafe(|| v.insert(3, 9))).is_err());
                }
                #[test]
                fn heldout_insert_at_len() {
                    let mut v: ArrayVec<String, 4> = ArrayVec::new();
                    v.push("a".into());
                    v.insert(1, "b".into());
                    assert_eq!(v[1], "b");
                }
                #[test]
                fn heldout_empty_pop_none() {
                    let mut v: ArrayVec<u8, 2> = ArrayVec::new();
                    assert!(v.pop().is_none());
                    assert_eq!(v.len(), 0);
                }
            ''',
            "reference": ref("CVE-2020-35895"),
            "mutants": [
                mutation("remove_insert_bound", "assert!(index <= self.len, \"insert index out of bounds\");\n        ", "", "allows OOB insert"),
                mutation(
                    "push_skips_len",
                    "self.data[self.len] = MaybeUninit::new(val);\n        self.len += 1;",
                    "self.data[self.len] = MaybeUninit::new(val);\n        self.len += 0;",
                    "skips push len",
                ),
                mutation("pop_skips_len", "self.len -= 1;", "self.len -= 0;", "skips pop len"),
                mutation(
                    "len_always_zero",
                    "pub fn len(&self) -> usize {\n        self.len\n    }",
                    "pub fn len(&self) -> usize {\n        0\n    }",
                    "lies about len",
                ),
            ],
        },
        {
            "id": "CVE-2020-35900",
            "batch": "batch_4",
            "contract": "ArrayQueue::pop_back uses ring index(); mix of pop_front/pop_back stays initialized.",
            "evidence": "audit uninit; pop_back uses length-1 not index()",
            "dimensions": "push pop_back; after pop_front; first last; empty; wrap",
            "symbols": ["ArrayQueue::new", "push_back", "pop_front", "pop_back", "first", "last"],
            "tests": '''
                #[test]
                fn heldout_pop_back_basic() {
                    let mut q: ArrayQueue<u32, 4> = ArrayQueue::new();
                    q.push_back(1).unwrap();
                    q.push_back(2).unwrap();
                    assert_eq!(q.pop_back(), Some(2));
                    assert_eq!(q.last(), Some(&1));
                }
                #[test]
                fn heldout_pop_back_after_pop_front() {
                    let mut q: ArrayQueue<u8, 4> = ArrayQueue::new();
                    q.push_back(10).unwrap();
                    q.push_back(20).unwrap();
                    q.push_back(30).unwrap();
                    assert_eq!(q.pop_front(), Some(10));
                    assert_eq!(q.pop_back(), Some(30));
                    assert_eq!(q.first(), Some(&20));
                    assert_eq!(q.last(), Some(&20));
                }
                #[test]
                fn heldout_empty_pops_none() {
                    let mut q: ArrayQueue<u8, 2> = ArrayQueue::new();
                    assert!(q.pop_front().is_none());
                    assert!(q.pop_back().is_none());
                }
                #[test]
                fn heldout_full_push_err() {
                    let mut q: ArrayQueue<u8, 2> = ArrayQueue::new();
                    q.push_back(1).unwrap();
                    q.push_back(2).unwrap();
                    assert!(q.push_back(3).is_err());
                }
                #[test]
                fn heldout_wrap_indices() {
                    let mut q: ArrayQueue<i32, 3> = ArrayQueue::new();
                    q.push_back(1).unwrap();
                    q.push_back(2).unwrap();
                    assert_eq!(q.pop_front(), Some(1));
                    q.push_back(3).unwrap();
                    assert_eq!(q.pop_back(), Some(3));
                    assert_eq!(q.pop_back(), Some(2));
                }
            ''',
            "reference": ref("CVE-2020-35900"),
            "mutants": [
                mutation(
                    "restore_length_minus_one",
                    "&mut self.array[self.index(self.length - 1)],",
                    "&mut self.array[self.length - 1],",
                    "restores wrong pop_back index",
                ),
                mutation("push_skips_len", "self.length += 1;", "self.length += 0;", "skips push length"),
                mutation(
                    "pop_front_skips_len",
                    "self.start = self.index(1);\n            self.length -= 1;",
                    "self.start = self.index(1);\n            self.length -= 0;",
                    "skips pop_front length",
                ),
                mutation("is_empty_always", "self.length == 0", "true", "always empty"),
            ],
        },
    ]


def main() -> int:
    for spec in cases():
        if not spec["reference"].startswith("\n"):
            spec["reference"] = "\n" + spec["reference"]
        write_case(spec)
        print(f"wrote cases/{spec['id']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
