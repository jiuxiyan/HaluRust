#!/usr/bin/env python3
"""Build the 62-case CVE oracle census."""

from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from pathlib import Path


PRIVATE_ROOT = Path(__file__).resolve().parents[1]
MANIFEST_PATH = PRIVATE_ROOT / "manifests" / "cve_dataset_manifest_v1.json"
CENSUS_PATH = PRIVATE_ROOT / "manifests" / "oracle_census_v1.json"
EXPECTED_CASES = 62


def build_census() -> dict:
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    cases = []
    for item in manifest["cases"]:
        audit = item["audit"]
        cases.append({
            "case_id": item["case_id"],
            "project": item["project"],
            "cwe": item["cwe"],
            "source_sha256": item["files"]["source.rs"]["sha256"],
            "visible_test_sha256": item["files"]["test.rs"]["sha256"],
            "oracle_level": "P",
            "confidence": "high",
            "contract_scope": "audited vulnerability-adjacent safe entry, functional behavior, and safety invariants",
            "reason": "audited PASS reduction has a source-grounded safe entry, target trigger, normal behavior, and independently testable post-fix contract",
            "expected_ub_kinds": audit["expected_ub_kinds"],
            "evidence_strength": audit["upstream_verification"],
            "selection_batch": item["oracle"]["selection_batch"],
            "implementation_status": item["oracle"]["status"],
        })
    levels = Counter(item["oracle_level"] for item in cases)
    batches = Counter(item["selection_batch"] for item in cases)
    return {
        "schema_version": 1,
        "census_id": "cve_v2_oracle_census_v1",
        "generated_on": "2026-07-31",
        "manifest_id": manifest["manifest_id"],
        "total_cases": len(cases),
        "policy": {
            "E": "Complete executable behavior oracle for the reduced benchmark public safe API.",
            "P": "High-confidence executable oracle for the audited vulnerability-adjacent contract and key invariants.",
            "N": "Insufficient independent evidence for an executable semantic oracle; never silently removed.",
            "no_semantics_for_unsafe_precondition_violations": True,
        },
        "summary": {
            "level_counts": {level: levels.get(level, 0) for level in ("E", "P", "N")},
            "selection_batch_counts": dict(sorted(batches.items())),
        },
        "cases": cases,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    data = build_census()
    if data["total_cases"] != EXPECTED_CASES:
        print(f"error: census has {data['total_cases']} cases, expected {EXPECTED_CASES}", file=sys.stderr)
        return 2
    content = json.dumps(data, ensure_ascii=False, indent=2) + "\n"
    if args.check:
        if not CENSUS_PATH.is_file() or CENSUS_PATH.read_text(encoding="utf-8") != content:
            print("error: checked-in CVE census differs from regenerated data", file=sys.stderr)
            return 1
        print(f"CVE census OK: {EXPECTED_CASES} cases {data['summary']['level_counts']}")
        return 0
    CENSUS_PATH.parent.mkdir(parents=True, exist_ok=True)
    CENSUS_PATH.write_text(content, encoding="utf-8")
    print(f"wrote {CENSUS_PATH}: {data['summary']['level_counts']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
