#!/usr/bin/env python3
"""Audit the private CVE held-out suite against the expansion contract."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from collections import Counter
from pathlib import Path

try:
    import tomllib
except ModuleNotFoundError:
    import tomli as tomllib


PRIVATE_ROOT = Path(__file__).resolve().parents[1]
PROJECT_ROOT = PRIVATE_ROOT.parent
DATASET_ROOT = PROJECT_ROOT / "cve_safe_func_synth_without_data_race_v2"
CASES_ROOT = PRIVATE_ROOT / "cases"
MANIFEST_PATH = PRIVATE_ROOT / "manifests" / "cve_dataset_manifest_v1.json"
CENSUS_PATH = PRIVATE_ROOT / "manifests" / "oracle_census_v1.json"
SUMMARY_PATH = PRIVATE_ROOT / "manifests" / "oracle_validation_summary_v1.json"
EXPECTED = 62
ARTIFACTS = ("case.toml", "semantic_tests.rs", "reference_fix.rs", "oracle.md")


def _test_fns(text: str) -> set[str]:
    return set(re.findall(r"fn\s+(test_[A-Za-z0-9_]+)\s*\(", text))


def audit() -> list[str]:
    errors: list[str] = []
    if not MANIFEST_PATH.is_file() or not CENSUS_PATH.is_file():
        return ["missing manifest or census"]
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    census = json.loads(CENSUS_PATH.read_text(encoding="utf-8"))
    m_ids = [item["case_id"] for item in manifest["cases"]]
    c_ids = [item["case_id"] for item in census["cases"]]
    if len(m_ids) != EXPECTED or len(set(m_ids)) != EXPECTED:
        errors.append(f"manifest must have {EXPECTED} unique cases")
    if set(m_ids) != set(c_ids):
        errors.append("manifest/census case ID mismatch")
    disk_dirs = sorted(path.name for path in CASES_ROOT.glob("CVE-*") if path.is_dir()) if CASES_ROOT.is_dir() else []
    implemented = [
        item["case_id"]
        for item in manifest["cases"]
        if item["oracle"]["status"] == "implemented" or (CASES_ROOT / item["case_id"] / "case.toml").is_file()
    ]
    if set(disk_dirs) - set(m_ids):
        errors.append(f"extra case directories: {sorted(set(disk_dirs) - set(m_ids))}")
    for case_id in disk_dirs:
        case_dir = CASES_ROOT / case_id
        for name in ARTIFACTS:
            if not (case_dir / name).is_file():
                errors.append(f"{case_id}: missing {name}")
                continue
        if not (case_dir / "case.toml").is_file():
            continue
        with (case_dir / "case.toml").open("rb") as handle:
            config = tomllib.load(handle)
        tests = (case_dir / "semantic_tests.rs").read_text(encoding="utf-8")
        reference = (case_dir / "reference_fix.rs").read_text(encoding="utf-8")
        public = (DATASET_ROOT / case_id / "test.rs").read_text(encoding="utf-8")
        item = next(entry for entry in manifest["cases"] if entry["case_id"] == case_id)
        for name, expected in config.get("dataset_hashes", {}).items():
            actual = hashlib.sha256((DATASET_ROOT / case_id / name).read_bytes()).hexdigest()
            if actual != expected or item["files"][name]["sha256"] != actual:
                errors.append(f"{case_id}: hash drift on {name}")
        if config.get("test_count") != tests.count("#[test]"):
            errors.append(f"{case_id}: test_count mismatch")
        if tests.count("#[test]") < 5:
            errors.append(f"{case_id}: fewer than 5 held-out tests")
        overlap = _test_fns(tests) & _test_fns(public)
        if overlap:
            errors.append(f"{case_id}: public/hidden name overlap {sorted(overlap)}")
        if hashlib.sha256(tests.encode()).hexdigest() == hashlib.sha256(public.encode()).hexdigest():
            errors.append(f"{case_id}: semantic_tests identical to public test.rs")
        if hashlib.sha256(tests.encode()).hexdigest() == hashlib.sha256(reference.encode()).hexdigest():
            errors.append(f"{case_id}: semantic_tests identical to reference_fix")
        mutants = config.get("oracle_validation", {}).get("mutants", [])
        if len(mutants) < 4:
            errors.append(f"{case_id}: need >= 4 mutants, found {len(mutants)}")
    if SUMMARY_PATH.is_file():
        summary = json.loads(SUMMARY_PATH.read_text(encoding="utf-8"))
        if summary.get("implemented_oracles") != len(disk_dirs):
            errors.append("validation summary implemented_oracles mismatch")
        batch_total = sum(summary.get("batches", {}).get(name, {}).get("cases", 0) for name in summary.get("batches", {}))
        if disk_dirs and batch_total != len(disk_dirs):
            errors.append("validation summary batch counts do not sum to implemented cases")
    print(f"implemented_on_disk={len(disk_dirs)} selected={EXPECTED}")
    print(f"batch_counts={dict(Counter(item['oracle']['selection_batch'] for item in manifest['cases']))}")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--strict-complete", action="store_true",
                        help="require all 62 cases implemented")
    args = parser.parse_args()
    errors = audit()
    disk = sorted(path.name for path in CASES_ROOT.glob("CVE-*") if path.is_dir()) if CASES_ROOT.is_dir() else []
    if args.strict_complete and len(disk) != EXPECTED:
        errors.append(f"expected {EXPECTED} implemented cases, found {len(disk)}")
    if errors:
        for item in errors:
            print(f"error: {item}", file=sys.stderr)
        return 1
    print("CVE held-out suite audit OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
