#!/usr/bin/env python3
"""Generate batch_7 CVE held-out oracle cases (7)."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from case_writer import mutation, write_case

FIX_ROOT = Path("/tmp/cve_batch7_fix")


def ref(cid: str) -> str:
    return FIX_ROOT.joinpath(f"{cid}.rs").read_text(encoding="utf-8")


PEEK_READ = '''
                use std::io::{self, Cursor, Read, Seek, SeekFrom};
                struct PeekReader {
                    data: Vec<u8>,
                    pos: usize,
                }
                impl PeekReader {
                    fn new(data: Vec<u8>) -> Self { Self { data, pos: 0 } }
                }
                impl Read for PeekReader {
                    fn read(&mut self, buf: &mut [u8]) -> io::Result<usize> {
                        if !buf.is_empty() {
                            let x = buf[0];
                            std::hint::black_box(x);
                        }
                        let n = buf.len().min(self.data.len().saturating_sub(self.pos));
                        buf[..n].copy_from_slice(&self.data[self.pos..self.pos + n]);
                        self.pos += n;
                        Ok(n)
                    }
                }
                impl Seek for PeekReader {
                    fn seek(&mut self, pos: SeekFrom) -> io::Result<u64> {
                        let new_pos = match pos {
                            SeekFrom::Start(s) => s as i64,
                            SeekFrom::End(e) => self.data.len() as i64 + e,
                            SeekFrom::Current(c) => self.pos as i64 + c,
                        };
                        if new_pos < 0 {
                            return Err(io::Error::new(io::ErrorKind::InvalidInput, "neg"));
                        }
                        self.pos = new_pos as usize;
                        Ok(self.pos as u64)
                    }
                }
                fn sample_spirv() -> Vec<u8> {
                    vec![
                        0x03, 0x02, 0x23, 0x07,
                        0x00, 0x00, 0x01, 0x00,
                        0x00, 0x00, 0x00, 0x00,
                        0x01, 0x00, 0x00, 0x00,
                        0x00, 0x00, 0x00, 0x00,
                    ]
                }
'''


def cases() -> list[dict]:
    return [
        {
            "id": "CVE-2021-45689",
            "batch": "batch_7",
            "contract": "read_spirv zero-initializes words before exposing a byte view to Read.",
            "evidence": "audit uninit; from_raw_parts_mut on with_capacity buffer",
            "dimensions": "peek; cursor; bad magic; not divisible; emptyish",
            "symbols": ["read_spirv"],
            "tests": PEEK_READ + '''
                #[test]
                fn heldout_peek_safe() {
                    let r = PeekReader::new(sample_spirv());
                    let words = read_spirv(r).unwrap();
                    assert_eq!(words[0], 0x07230203);
                }
                #[test]
                fn heldout_cursor_ok() {
                    let words = read_spirv(Cursor::new(sample_spirv())).unwrap();
                    assert_eq!(words.len(), 5);
                    assert_eq!(words[0], 0x07230203);
                }
                #[test]
                fn heldout_bad_magic_errors() {
                    let mut bad = sample_spirv();
                    bad[0] = 0;
                    assert!(read_spirv(Cursor::new(bad)).is_err());
                }
                #[test]
                fn heldout_not_divisible_errors() {
                    assert!(read_spirv(Cursor::new(vec![1u8, 2, 3])).is_err());
                }
                #[test]
                fn heldout_endian_swap() {
                    // big-endian magic bytes
                    let be = vec![
                        0x07, 0x23, 0x02, 0x03,
                        0x00, 0x01, 0x00, 0x00,
                        0x00, 0x00, 0x00, 0x00,
                        0x00, 0x00, 0x00, 0x01,
                        0x00, 0x00, 0x00, 0x00,
                    ];
                    let words = read_spirv(Cursor::new(be)).unwrap();
                    assert_eq!(words[0], 0x07230203);
                }
            ''',
            "reference": ref("CVE-2021-45689"),
            "mutants": [
                mutation(
                    "restore_uninit",
                    "let mut result = vec![0u32; words];",
                    "let mut result = Vec::<u32>::with_capacity(words); unsafe { result.set_len(words); }",
                    "restores uninit words",
                ),
                mutation("always_bad_magic", "result[0] != MAGIC_NUMBER", "true", "always rejects"),
                mutation("skip_endian", "if result.len() > 0 && result[0] == MAGIC_NUMBER.swap_bytes() {", "if false {", "skips endian swap"),
                mutation("zero_words", "let words = (size / 4) as usize;", "let words = 0usize;", "forces empty"),
            ],
        },
        {
            "id": "CVE-2021-45694",
            "batch": "batch_7",
            "contract": "Window::new rejects oversized Read returns and truncates to actual size.",
            "evidence": "audit OOB; set_len without size<=capacity check",
            "dimensions": "normal short; full block; oversized err; empty; front values",
            "symbols": ["Window::new"],
            "tests": '''
                use std::io::Read;
                #[test]
                fn heldout_short_read_truncates() {
                    let data = vec![1u8, 2, 3, 4];
                    let w = Window::new(&data[..], 8).unwrap();
                    assert_eq!(w.front, vec![1, 2, 3, 4]);
                    assert_eq!(w.front.len(), 4);
                }
                #[test]
                fn heldout_full_block() {
                    let data = vec![9u8; 4];
                    let w = Window::new(&data[..], 2).unwrap();
                    assert_eq!(w.front, vec![9, 9]);
                    assert_eq!(w.back, vec![9, 9]);
                }
                #[test]
                fn heldout_oversized_read_errors() {
                    struct Lie;
                    impl Read for Lie {
                        fn read(&mut self, buf: &mut [u8]) -> std::io::Result<usize> {
                            Ok(buf.len() + 1)
                        }
                    }
                    assert!(Window::new(Lie, 16).is_err());
                }
                #[test]
                fn heldout_empty_reader() {
                    let data: &[u8] = &[];
                    let w = Window::new(data, 4).unwrap();
                    assert!(w.front.is_empty());
                    assert!(w.back.is_empty());
                }
                #[test]
                fn heldout_block_size_field() {
                    let data = vec![7u8, 8];
                    let w = Window::new(&data[..], 8).unwrap();
                    assert_eq!(w.block_size, 8);
                }
            ''',
            "reference": ref("CVE-2021-45694"),
            "mutants": [
                mutation(
                    "restore_set_len",
                    "if size > block_size {\n            return Err(Error::new(ErrorKind::InvalidData, \"read returned too many bytes\"));\n        }\n        front.truncate(size);",
                    "unsafe { front.set_len(size); }",
                    "restores unchecked set_len on front",
                ),
                mutation("no_truncate_front", "front.truncate(size);", "let _ = size;", "keeps full front"),
                mutation("zero_front", "let mut front = vec![0; block_size];", "let mut front = Vec::new();", "empty front"),
                mutation("zero_back", "back.truncate(size);", "back.truncate(0);", "empties back"),
            ],
        },
        {
            "id": "CVE-2021-45701",
            "batch": "batch_7",
            "contract": "merge_in_place owns event values before storing into 'static state.",
            "evidence": "audit UAF; transmute event-lifetime Value into static state",
            "dimensions": "borrowed survives; owned; overwrite; nested; empty state",
            "symbols": ["State::new", "merge_in_place"],
            "tests": '''
                use std::borrow::Cow;
                use std::collections::HashMap;
                #[test]
                fn heldout_borrowed_survives_drop() {
                    let mut state = State::new();
                    {
                        let buf = String::from("event-payload");
                        state.merge_in_place("k".into(), Value::Str(Cow::Borrowed(&buf)));
                    }
                    match &state.data {
                        Value::Object(m) => match m.get("k") {
                            Some(Value::Str(s)) => assert_eq!(&**s, "event-payload"),
                            _ => panic!("missing"),
                        },
                        _ => panic!("not object"),
                    }
                }
                #[test]
                fn heldout_owned_merge() {
                    let mut state = State::new();
                    state.merge_in_place("o".into(), Value::Str(Cow::Owned("own".into())));
                    match &state.data {
                        Value::Object(m) => match m.get("o") {
                            Some(Value::Str(s)) => assert_eq!(&**s, "own"),
                            _ => panic!("missing"),
                        },
                        _ => panic!("not object"),
                    }
                }
                #[test]
                fn heldout_overwrite_key() {
                    let mut state = State::new();
                    state.merge_in_place("k".into(), Value::Str(Cow::Owned("a".into())));
                    state.merge_in_place("k".into(), Value::Str(Cow::Owned("b".into())));
                    match &state.data {
                        Value::Object(m) => match m.get("k") {
                            Some(Value::Str(s)) => assert_eq!(&**s, "b"),
                            _ => panic!("missing"),
                        },
                        _ => panic!("not object"),
                    }
                }
                #[test]
                fn heldout_nested_object() {
                    let mut state = State::new();
                    let mut inner = HashMap::new();
                    inner.insert("x".into(), Value::Str(Cow::Owned("1".into())));
                    state.merge_in_place("obj".into(), Value::Object(inner));
                    match &state.data {
                        Value::Object(m) => match m.get("obj") {
                            Some(Value::Object(inner)) => assert!(inner.contains_key("x")),
                            _ => panic!("missing"),
                        },
                        _ => panic!("not object"),
                    }
                }
                #[test]
                fn heldout_new_empty_object() {
                    let state = State::new();
                    match state.data {
                        Value::Object(m) => assert!(m.is_empty()),
                        _ => panic!("not object"),
                    }
                }
            ''',
            "reference": ref("CVE-2021-45701"),
            "mutants": [
                mutation(
                    "restore_transmute",
                    "let static_value = into_static(event_value);",
                    "let static_value: Value<'static> = unsafe { std::mem::transmute(event_value) };",
                    "restores transmute",
                ),
                mutation("skip_insert", "map.insert(key, static_value);", "let _ = (key, static_value);", "skips insert"),
                mutation(
                    "str_empty",
                    "Value::Str(s) => Value::Str(Cow::Owned(s.into_owned())),",
                    "Value::Str(_) => Value::Str(Cow::Owned(String::new())),",
                    "empties strings",
                ),
                mutation("new_prefilled", "data: Value::Object(HashMap::new())", "data: Value::Str(Cow::Owned(\"x\".into()))", "non-object state"),
            ],
        },
        {
            "id": "CVE-2021-45702",
            "batch": "batch_7",
            "contract": "patch_in_place owns event values before storing into 'static state.",
            "evidence": "audit UAF; transmute event-lifetime Value into static state",
            "dimensions": "borrowed survives; owned; overwrite; status report; empty",
            "symbols": ["State::new", "patch_in_place", "StatusReport::state"],
            "tests": '''
                use std::borrow::Cow;
                #[test]
                fn heldout_borrowed_survives_drop() {
                    let mut state = State::new();
                    {
                        let buf = String::from("patched");
                        state.patch_in_place("k".into(), Value::Str(Cow::Borrowed(&buf)));
                    }
                    match &state.data {
                        Value::Object(m) => match m.get("k") {
                            Some(Value::Str(s)) => assert_eq!(&**s, "patched"),
                            _ => panic!("missing"),
                        },
                        _ => panic!("not object"),
                    }
                }
                #[test]
                fn heldout_owned_patch() {
                    let mut state = State::new();
                    state.patch_in_place("o".into(), Value::Str(Cow::Owned("v".into())));
                    match &state.data {
                        Value::Object(m) => match m.get("o") {
                            Some(Value::Str(s)) => assert_eq!(&**s, "v"),
                            _ => panic!("missing"),
                        },
                        _ => panic!("not object"),
                    }
                }
                #[test]
                fn heldout_overwrite() {
                    let mut state = State::new();
                    state.patch_in_place("k".into(), Value::Str(Cow::Owned("1".into())));
                    state.patch_in_place("k".into(), Value::Str(Cow::Owned("2".into())));
                    match &state.data {
                        Value::Object(m) => match m.get("k") {
                            Some(Value::Str(s)) => assert_eq!(&**s, "2"),
                            _ => panic!("missing"),
                        },
                        _ => panic!("not object"),
                    }
                }
                #[test]
                fn heldout_status_report_clone() {
                    let mut state = State::new();
                    state.patch_in_place("a".into(), Value::Str(Cow::Owned("z".into())));
                    let report = StatusReport { state: state.clone() };
                    let cloned = report.state();
                    match &cloned.data {
                        Value::Object(m) => match m.get("a") {
                            Some(Value::Str(s)) => assert_eq!(&**s, "z"),
                            _ => panic!("missing"),
                        },
                        _ => panic!("not object"),
                    }
                }
                #[test]
                fn heldout_new_empty() {
                    let state = State::new();
                    match state.data {
                        Value::Object(m) => assert!(m.is_empty()),
                        _ => panic!("not object"),
                    }
                }
            ''',
            "reference": ref("CVE-2021-45702"),
            "mutants": [
                mutation(
                    "restore_transmute",
                    "let static_value = into_static(event_value);",
                    "let static_value: Value<'static> = unsafe { std::mem::transmute(event_value) };",
                    "restores transmute",
                ),
                mutation("skip_insert", "map.insert(key, static_value);", "let _ = (key, static_value);", "skips insert"),
                mutation(
                    "str_empty",
                    "Value::Str(s) => Value::Str(Cow::Owned(s.into_owned())),",
                    "Value::Str(_) => Value::Str(Cow::Owned(String::new())),",
                    "empties strings",
                ),
                mutation("status_empty", "self.state.clone()", "State::new()", "drops report state"),
            ],
        },
        {
            "id": "CVE-2021-45703",
            "batch": "batch_7",
            "contract": "read_into_uninit_buffer zero-fills before Read::read.",
            "evidence": "audit uninit; set_len before read",
            "dimensions": "peek; write-only; empty; short; length",
            "symbols": ["read_into_uninit_buffer"],
            "tests": '''
                use std::io::{self, Cursor, Read};
                struct PeekReader;
                impl Read for PeekReader {
                    fn read(&mut self, buf: &mut [u8]) -> io::Result<usize> {
                        if !buf.is_empty() {
                            let x = buf[0];
                            std::hint::black_box(x);
                        }
                        for b in buf.iter_mut() { *b = 0x42; }
                        Ok(buf.len())
                    }
                }
                #[test]
                fn heldout_peek_safe() {
                    let n = read_into_uninit_buffer(PeekReader, 4).unwrap();
                    assert_eq!(n, 4);
                }
                #[test]
                fn heldout_cursor_partial() {
                    let n = read_into_uninit_buffer(Cursor::new(vec![1u8, 2]), 8).unwrap();
                    assert_eq!(n, 2);
                }
                #[test]
                fn heldout_empty_buf() {
                    let n = read_into_uninit_buffer(Cursor::new(vec![1u8]), 0).unwrap();
                    assert_eq!(n, 0);
                }
                #[test]
                fn heldout_exact() {
                    let n = read_into_uninit_buffer(Cursor::new(vec![9u8, 8, 7]), 3).unwrap();
                    assert_eq!(n, 3);
                }
                #[test]
                fn heldout_zero_fill_then_read() {
                    struct CheckThenWrite;
                    impl Read for CheckThenWrite {
                        fn read(&mut self, buf: &mut [u8]) -> io::Result<usize> {
                            assert!(buf.iter().all(|&b| b == 0));
                            for b in buf.iter_mut() { *b = 1; }
                            Ok(buf.len())
                        }
                    }
                    assert_eq!(read_into_uninit_buffer(CheckThenWrite, 5).unwrap(), 5);
                }
            ''',
            "reference": ref("CVE-2021-45703"),
            "mutants": [
                mutation(
                    "restore_set_len",
                    "let mut buf = vec![0u8; buf_size];",
                    "let mut buf = Vec::with_capacity(buf_size); unsafe { buf.set_len(buf_size); }",
                    "restores uninit",
                ),
                mutation("ignore_size", "vec![0u8; buf_size]", "vec![0u8; 0]", "empty buffer"),
                mutation("return_zero", "stream.read(&mut buf[..])", "Ok(0)", "always zero"),
                mutation("half_size", "vec![0u8; buf_size]", "vec![0u8; buf_size / 2]", "half buffer"),
            ],
        },
        {
            "id": "CVE-2022-46149",
            "batch": "batch_7",
            "contract": "pointer-list upgrade does not munge into struct data; reads stay in-segment.",
            "evidence": "audit OOB; munge ptr by data_words then copy past segment",
            "dimensions": "no-munge copy; short segment safe; words helper; zero count; values",
            "symbols": ["copy_upgraded_pointer_list", "Word::words_to_bytes"],
            "tests": '''
                use std::panic;
                #[test]
                fn heldout_unmunged_copy() {
                    let mut words = vec![Word::zero(); 2];
                    words[0].raw = [1, 0, 0, 0, 0, 0, 0, 0];
                    words[1].raw = [2, 0, 0, 0, 0, 0, 0, 0];
                    let segment = Word::words_to_bytes(&words);
                    let mut dst = [0u8; 16];
                    copy_upgraded_pointer_list(segment, 0, 2, &mut dst);
                    assert_eq!(&dst[0..8], &words[0].raw);
                    assert_eq!(&dst[8..16], &words[1].raw);
                }
                #[test]
                fn heldout_no_munge_short_segment_safe() {
                    let mut words = vec![Word::zero(); 4];
                    words[0].raw = [0x11; 8];
                    words[1].raw = [0x22; 8];
                    words[2].raw = [0x33; 8];
                    words[3].raw = [0; 8];
                    let segment = Word::words_to_bytes(&words);
                    let mut dst = [0u8; 16];
                    copy_upgraded_pointer_list(segment, 3, 2, &mut dst);
                    assert_eq!(&dst[0..8], &words[0].raw);
                    assert_eq!(&dst[8..16], &words[1].raw);
                }
                #[test]
                fn heldout_past_segment_panics() {
                    let words = vec![Word::zero(); 1];
                    let segment = Word::words_to_bytes(&words);
                    let mut dst = [0u8; 16];
                    assert!(panic::catch_unwind(panic::AssertUnwindSafe(|| {
                        copy_upgraded_pointer_list(segment, 0, 2, &mut dst);
                    })).is_err());
                }
                #[test]
                fn heldout_zero_elements() {
                    let words = vec![Word::zero(); 1];
                    let segment = Word::words_to_bytes(&words);
                    let mut dst = [0u8; 8];
                    copy_upgraded_pointer_list(segment, 0, 0, &mut dst);
                    assert_eq!(dst, [0u8; 8]);
                }
                #[test]
                fn heldout_words_to_bytes_len() {
                    let words = [Word::zero(), Word::zero()];
                    assert_eq!(Word::words_to_bytes(&words).len(), 16);
                }
            ''',
            "reference": ref("CVE-2022-46149"),
            "mutants": [
                mutation(
                    "restore_munge",
                    "ptr: segment.as_ptr(),\n        element_count,\n        segment_len: segment.len(),\n        base: segment.as_ptr(),",
                    "ptr: unsafe { segment.as_ptr().add(_data_words * 8) },\n        element_count,\n        segment_len: segment.len(),\n        base: unsafe { segment.as_ptr().add(_data_words * 8) },",
                    "restores pointer munge",
                ),
                mutation(
                    "remove_bounds",
                    "assert!(offset + 8 <= value.segment_len, \"pointer list read past segment\");\n        ",
                    "",
                    "removes segment bounds assert",
                ),
                mutation("zero_count", "element_count,", "0,", "forces empty list"),
                mutation("wrong_stride", "let offset = i * 8;", "let offset = i * 4;", "wrong stride"),
            ],
        },
        {
            "id": "CVE-2023-28448",
            "batch": "batch_7",
            "contract": "FamStructWrapper validates claimed entries against payload and bounds-checks gets.",
            "evidence": "audit OOB; claimed_entries unchecked against data length",
            "dimensions": "matched get; oversized claim panics; oob get; new zeros; multi",
            "symbols": ["FamStructWrapper::new", "deserialize_unchecked", "get_entry_unsafe"],
            "tests": '''
                use std::panic;
                #[test]
                fn heldout_matched_entries() {
                    let data = vec![1u8, 0, 0, 0, 2, 0, 0, 0];
                    let w = FamStructWrapper::deserialize_unchecked(2, &data);
                    assert_eq!(w.get_entry_unsafe(0), 1);
                    assert_eq!(w.get_entry_unsafe(1), 2);
                }
                #[test]
                fn heldout_oversized_claim_panics() {
                    let data = vec![1u8, 2, 3, 4];
                    assert!(panic::catch_unwind(|| {
                        FamStructWrapper::deserialize_unchecked(100, &data);
                    }).is_err());
                }
                #[test]
                fn heldout_oob_index_panics() {
                    let w = FamStructWrapper::new(2);
                    assert!(panic::catch_unwind(|| {
                        let _ = w.get_entry_unsafe(2);
                    }).is_err());
                }
                #[test]
                fn heldout_new_zeros() {
                    let w = FamStructWrapper::new(3);
                    assert_eq!(w.claimed_entries, 3);
                    assert_eq!(w.get_entry_unsafe(0), 0);
                    assert_eq!(w.get_entry_unsafe(2), 0);
                }
                #[test]
                fn heldout_extra_payload_ok() {
                    let data = vec![7u8, 0, 0, 0, 9, 9, 9, 9];
                    let w = FamStructWrapper::deserialize_unchecked(1, &data);
                    assert_eq!(w.get_entry_unsafe(0), 7);
                }
            ''',
            "reference": ref("CVE-2023-28448"),
            "mutants": [
                mutation(
                    "remove_deserialize_assert",
                    "assert!(\n            actual_data.len() >= claimed_entries.saturating_mul(4),\n            \"claimed entries exceed payload\"\n        );\n        ",
                    "",
                    "skips claim/payload check",
                ),
                mutation("get_always_zero", "std::ptr::read_unaligned(entry_ptr)", "0", "always zero entry"),
                mutation("wrong_offset", "let offset = index * 4;", "let offset = index * 8;", "wrong stride"),
                mutation("new_empty", "data: vec![0u8; entries * 4],", "data: Vec::new(),", "empty new data"),
            ],
        },
    ]


def main() -> int:
    for spec in cases():
        write_case(spec)
        print(f"wrote cases/{spec['id']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
