"""Helpers used only by private case generators."""

from __future__ import annotations

import hashlib
import json
import textwrap
from pathlib import Path


PRIVATE_ROOT = Path(__file__).resolve().parents[1]
PROJECT_ROOT = PRIVATE_ROOT.parent
DATASET_ROOT = PROJECT_ROOT / "cve_safe_func_synth_without_data_race_v2"
CASES_ROOT = PRIVATE_ROOT / "cases"


def d(value: str) -> str:
    return textwrap.dedent(value).strip() + "\n"


def q(value: str) -> str:
    return json.dumps(value, ensure_ascii=False)


def mutation(name: str, find: str, replace: str, reason: str) -> dict:
    return {"name": name, "find": find, "replace": replace, "reason": reason}


def write_case(spec: dict) -> None:
    case_id = spec["id"]
    case_dir = CASES_ROOT / case_id
    case_dir.mkdir(parents=True, exist_ok=True)
    dataset_dir = DATASET_ROOT / case_id
    tests = d(spec["tests"])
    reference = d(spec["reference"])
    lines = [
        "version = 1", f"case_id = {q(case_id)}", 'oracle_level = "P"',
        f"selection_batch = {q(spec['batch'])}", f"contract_summary = {q(spec['contract'])}",
        "protected_symbols = [" + ", ".join(q(item) for item in spec["symbols"]) + "]",
        f"test_count = {tests.count('#[test]')}", f"check_count = {tests.count('assert')}",
        'toolchain = "nightly"', f"timeout_seconds = {spec.get('timeout', 180)}", "",
        "[dataset_hashes]",
    ]
    for name in ("source.rs", "test.rs", "meta.json", "audit.json"):
        lines.append(f"{q(name)} = {q(hashlib.sha256((dataset_dir / name).read_bytes()).hexdigest())}")
    lines.extend(["", "[[profiles]]"])
    profiles = spec.get("profiles") or [{"name": "default", "flags": []}]
    for index, profile in enumerate(profiles):
        if index:
            lines.extend(["", "[[profiles]]"])
        lines.append(f"name = {q(profile['name'])}")
        flags = ", ".join(q(flag) for flag in profile.get("flags", []))
        lines.append(f"flags = [{flags}]")
    lines.extend(["", "[oracle_validation]", 'reference_fix = "reference_fix.rs"', ""])
    for item in spec["mutants"]:
        lines.extend(["[[oracle_validation.mutants]]", f"name = {q(item['name'])}",
                      'expected = "fail"', f"reason = {q(item['reason'])}",
                      f"find = {q(item['find'])}", f"replace = {q(item['replace'])}", ""])
    (case_dir / "case.toml").write_text("\n".join(lines), encoding="utf-8")
    (case_dir / "semantic_tests.rs").write_text(tests, encoding="utf-8")
    (case_dir / "reference_fix.rs").write_text(reference, encoding="utf-8")
    for item in spec["mutants"]:
        if "find" in item and reference.count(item["find"]) != 1:
            raise ValueError(f"{case_id}/{item['name']}: mutation find must occur exactly once in reference")
    (case_dir / "oracle.md").write_text(d(f"""
        # Oracle: `{case_id}`

        Level: P. Batch: `{spec['batch']}`.

        ## Contract

        {spec['contract']}

        ## Evidence

        {spec['evidence']}

        ## Held-out dimensions

        {spec['dimensions']}

        ## Scope limit

        This is a vulnerability-adjacent partial oracle for the reduced benchmark. It
        constrains observable safe-entry behavior and safety invariants, not a unique
        implementation or the complete semantics of the upstream crate.
    """), encoding="utf-8")
