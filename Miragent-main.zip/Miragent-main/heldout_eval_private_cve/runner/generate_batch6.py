#!/usr/bin/env python3
"""Generate batch_6 CVE held-out oracle cases (10)."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from case_writer import mutation, write_case

FIX_ROOT = Path("/tmp/cve_batch6_fix")


def ref(cid: str) -> str:
    return FIX_ROOT.joinpath(f"{cid}.rs").read_text(encoding="utf-8")


PEEK = '''
                use std::io::{self, Cursor, Read};
                struct PeekReader;
                impl Read for PeekReader {
                    fn read(&mut self, buf: &mut [u8]) -> io::Result<usize> {
                        if !buf.is_empty() {
                            let x = buf[0];
                            std::hint::black_box(x);
                        }
                        for b in buf.iter_mut() { *b = 0x11; }
                        Ok(buf.len())
                    }
                }
'''


def cases() -> list[dict]:
    return [
        {
            "id": "CVE-2021-29934",
            "batch": "batch_6",
            "contract": "fill_buf zero-initializes before read_exact so PeekReaders stay safe.",
            "evidence": "audit uninit; set_len before Read",
            "dimensions": "peek; cursor; empty; short; values",
            "symbols": ["PartialReader::new", "fill_buf"],
            "tests": PEEK + '''
                #[test]
                fn heldout_peek_safe() {
                    let mut r = PartialReader::new(PeekReader);
                    let v = r.fill_buf(4).unwrap();
                    assert!(v.iter().all(|&b| b == 0x11));
                }
                #[test]
                fn heldout_cursor_bytes() {
                    let mut r = PartialReader::new(Cursor::new(vec![1u8,2,3]));
                    assert_eq!(r.fill_buf(3).unwrap(), vec![1,2,3]);
                }
                #[test]
                fn heldout_empty() {
                    let mut r = PartialReader::new(Cursor::new(vec![]));
                    assert!(r.fill_buf(0).unwrap().is_empty());
                }
                #[test]
                fn heldout_short_errors() {
                    let mut r = PartialReader::new(Cursor::new(vec![9u8]));
                    assert!(r.fill_buf(3).is_err());
                }
                #[test]
                fn heldout_xor_use() {
                    let mut r = PartialReader::new(Cursor::new(vec![4u8,5,6,7]));
                    let v = r.fill_buf(4).unwrap();
                    assert_eq!(v.iter().fold(0u8, |a,b| a^b), 4^5^6^7);
                }
            ''',
            "reference": ref("CVE-2021-29934"),
            "mutants": [
                mutation("restore_set_len", "let mut buf = vec![0u8; len];", "let mut buf = Vec::with_capacity(len); unsafe { buf.set_len(len); }", "restores uninit"),
                mutation("read_not_exact", "self.inner.read_exact(&mut buf)?;", "let _ = self.inner.read(&mut buf)?;", "partial read"),
                mutation("return_empty", "Ok(buf)", "Ok(Vec::new())", "empty return"),
                mutation("under_alloc", "let mut buf = vec![0u8; len];", "let mut buf = vec![0u8; len.saturating_sub(1)];", "short buffer"),
            ],
        },
        {
            "id": "CVE-2021-29935",
            "batch": "batch_6",
            "contract": "Formatter stores owned Strings; result survives after temporary sources drop.",
            "evidence": "audit UAF; transmute to &'static",
            "dimensions": "push result; multi; empty; drop source; extend",
            "symbols": ["Formatter::new", "push_str", "result"],
            "tests": '''
                #[test]
                fn heldout_push_result() {
                    let mut f = Formatter::new();
                    f.push_str("hi");
                    assert_eq!(f.result(), "hi");
                }
                #[test]
                fn heldout_multi_parts() {
                    let mut f = Formatter::new();
                    f.push_str("a"); f.push_str("b"); f.push_str("c");
                    assert_eq!(f.result(), "abc");
                }
                #[test]
                fn heldout_survives_temp_drop() {
                    let mut f = Formatter::new();
                    {
                        let tmp = String::from("owned");
                        f.push_str(&tmp);
                    }
                    assert_eq!(f.result(), "owned");
                }
                #[test]
                fn heldout_empty_result() {
                    let f = Formatter::new();
                    assert_eq!(f.result(), "");
                }
                #[test]
                fn heldout_extend_lifetime_owned() {
                    let s = extend_lifetime("x");
                    assert_eq!(s, "x");
                }
            ''',
            "reference": ref("CVE-2021-29935"),
            "mutants": [
                mutation("push_empty", "self.parts.push(s.to_owned());", "self.parts.push(String::new());", "ignores input"),
                mutation("result_first_only", "self.parts.join(\"\")", "self.parts.first().cloned().unwrap_or_default()", "drops rest"),
                mutation("extend_empty", "pub fn extend_lifetime(s: &str) -> String {\n    s.to_owned()\n}", "pub fn extend_lifetime(s: &str) -> String {\n    String::new()\n}", "extend empties"),
                mutation("new_prefilled", "parts: Vec::new()", "parts: vec![\"x\".into()]", "nonempty new"),
            ],
        },
        {
            "id": "CVE-2021-29937",
            "batch": "batch_6",
            "contract": "vec_with_size pushes clones incrementally so panic cannot drop uninit slots.",
            "evidence": "audit uninit; set_len before clone loop",
            "dimensions": "ints; strings; panic clone; empty; size1",
            "symbols": ["vec_with_size"],
            "tests": '''
                use std::panic;
                #[test]
                fn heldout_int_values() {
                    let v = vec_with_size(3, 7i32);
                    assert_eq!(v, vec![7,7,7]);
                }
                #[test]
                fn heldout_strings() {
                    let v = vec_with_size(2, String::from("a"));
                    assert_eq!(v, vec!["a","a"]);
                }
                #[test]
                fn heldout_panic_clone_safe() {
                    #[derive(Debug)]
                    struct Boom(usize, String);
                    impl Clone for Boom {
                        fn clone(&self) -> Self {
                            if self.0 == 1 { panic!("clone"); }
                            Boom(self.0, self.1.clone())
                        }
                    }
                    let r = panic::catch_unwind(panic::AssertUnwindSafe(|| {
                        vec_with_size(3, Boom(1, String::from("x")))
                    }));
                    assert!(r.is_err());
                }
                #[test]
                fn heldout_empty() {
                    let v: Vec<u8> = vec_with_size(0, 0);
                    assert!(v.is_empty());
                }
                #[test]
                fn heldout_one() {
                    assert_eq!(vec_with_size(1, 9u8), vec![9]);
                }
            ''',
            "reference": ref("CVE-2021-29937"),
            "mutants": [
                mutation(
                    "restore_set_len",
                    "let mut vec: Vec<T> = Vec::with_capacity(size);\n    for _ in 0..size {\n        vec.push(value.clone());\n    }\n    vec",
                    "let mut vec: Vec<T> = Vec::with_capacity(size);\n    unsafe { vec.set_len(size); }\n    for i in 0..size {\n        unsafe { std::ptr::write(vec.as_mut_ptr().add(i), value.clone()); }\n    }\n    vec",
                    "restores set_len fill",
                ),
                mutation("push_default_only", "vec.push(value.clone());", "vec.push(value.clone()); vec.pop();", "pops each push"),
                mutation("return_empty_vec", "    vec\n}", "    Vec::new()\n}", "drops result"),
                mutation("loop_one_less", "for _ in 0..size", "for _ in 1..size", "skips one"),
            ],
        },
        {
            "id": "CVE-2021-29939",
            "batch": "batch_6",
            "contract": "StackVec::extend capacity-checks lower_bound before raw writes.",
            "evidence": "audit OOB; size_hint upper used for assert, lower written",
            "dimensions": "extend ok; bad hint panics; push; slice; empty",
            "symbols": ["StackVec::new", "push", "extend", "as_slice", "len"],
            "tests": '''
                use std::panic;
                #[test]
                fn heldout_extend_values() {
                    let mut v: StackVec<u32, 8> = StackVec::new();
                    v.extend(vec![1u32,2,3]);
                    assert_eq!(v.as_slice(), &[1,2,3]);
                    assert_eq!(v.len(), 3);
                }
                #[test]
                fn heldout_lying_hint_panics() {
                    struct Lie(usize);
                    impl Iterator for Lie {
                        type Item = u8;
                        fn next(&mut self) -> Option<u8> {
                            if self.0 == 0 { None } else { self.0 -= 1; Some(1) }
                        }
                        fn size_hint(&self) -> (usize, Option<usize>) { (8, Some(1)) }
                    }
                    let mut v: StackVec<u8, 4> = StackVec::new();
                    assert!(panic::catch_unwind(panic::AssertUnwindSafe(|| v.extend(Lie(8)))).is_err());
                }
                #[test]
                fn heldout_push_ok() {
                    let mut v: StackVec<i32, 2> = StackVec::new();
                    v.push(9);
                    assert_eq!(v.as_slice(), &[9]);
                }
                #[test]
                fn heldout_empty_extend() {
                    let mut v: StackVec<u8, 4> = StackVec::new();
                    v.extend(Vec::<u8>::new());
                    assert_eq!(v.len(), 0);
                }
                #[test]
                fn heldout_capacity() {
                    let v: StackVec<u8, 16> = StackVec::new();
                    assert_eq!(v.capacity(), 16);
                }
            ''',
            "reference": ref("CVE-2021-29939"),
            "mutants": [
                mutation(
                    "restore_upper_check",
                    "assert!(self.len() + lower_bound <= self.capacity());",
                    "assert!(self.len() + upper_bound <= self.capacity());",
                    "restores upper-bound capacity check",
                ),
                mutation("push_skips_len", "self.len += 1;", "self.len += 0;", "skips push len"),
                mutation("len_zero", "pub fn len(&self) -> usize {\n        self.len\n    }", "pub fn len(&self) -> usize {\n        0\n    }", "lies len"),
                mutation("extend_skips_set_len", "self.set_len(len + count);", "self.set_len(len);", "skips extend len"),
            ],
        },
        {
            "id": "CVE-2021-29940",
            "batch": "batch_6",
            "contract": "through/through_and use mem::take so panic cannot double-free.",
            "evidence": "audit UAF; ptr::read then panic",
            "dimensions": "success; panic; through_and; ints; strings",
            "symbols": ["through", "through_and"],
            "tests": '''
                use std::panic;
                #[test]
                fn heldout_through_ok() {
                    let mut s = String::from("ab");
                    through(&mut s, |x| x + "c");
                    assert_eq!(s, "abc");
                }
                #[test]
                fn heldout_through_panic_safe() {
                    let mut s = String::from("keep");
                    let r = panic::catch_unwind(panic::AssertUnwindSafe(|| {
                        through(&mut s, |_| panic!("x"));
                    }));
                    assert!(r.is_err());
                    assert_eq!(s, "");
                }
                #[test]
                fn heldout_through_and_ok() {
                    let mut n = 3i32;
                    let out = through_and(&mut n, |x| (x + 1, x));
                    assert_eq!(n, 4);
                    assert_eq!(out, 3);
                }
                #[test]
                fn heldout_through_int() {
                    let mut n = 1u8;
                    through(&mut n, |x| x + 2);
                    assert_eq!(n, 3);
                }
                #[test]
                fn heldout_through_and_panic_safe() {
                    let mut s = String::from("z");
                    let r = panic::catch_unwind(panic::AssertUnwindSafe(|| {
                        through_and(&mut s, |_: String| -> (String, i32) { panic!("y") });
                    }));
                    assert!(r.is_err());
                    assert_eq!(s, "");
                }
            ''',
            "reference": ref("CVE-2021-29940"),
            "mutants": [
                mutation(
                    "restore_ptr_through",
                    "let x = mem::take(elem);\n    *elem = func(x);",
                    "unsafe {\n        let x = std::ptr::read(elem);\n        let x = func(x);\n        std::ptr::write(elem, x);\n    }",
                    "restores ptr::read through",
                ),
                mutation(
                    "restore_ptr_through_and",
                    "let x = mem::take(elem);\n    let (x, out) = func(x);\n    *elem = x;\n    out",
                    "unsafe {\n        let x = std::ptr::read(elem);\n        let (x, out) = func(x);\n        std::ptr::write(elem, x);\n        out\n    }",
                    "restores ptr::read through_and",
                ),
                mutation("through_ignore", "*elem = func(x);", "*elem = x;", "ignores func"),
                mutation("through_and_swap_write", "*elem = x;\n    out", "*elem = Default::default();\n    out", "zeros elem"),
            ],
        },
        {
            "id": "CVE-2021-30454",
            "batch": "batch_6",
            "contract": "read_key_value zero-initializes before read_exact.",
            "evidence": "audit uninit; set_len before Read",
            "dimensions": "peek; cursor; empty; short; xor",
            "symbols": ["KeyValueReader::new", "read_key_value"],
            "tests": PEEK + '''
                #[test]
                fn heldout_peek_safe() {
                    let mut r = KeyValueReader::new(PeekReader);
                    let v = r.read_key_value(4).unwrap();
                    assert!(v.iter().all(|&b| b == 0x11));
                }
                #[test]
                fn heldout_cursor_ok() {
                    let mut r = KeyValueReader::new(Cursor::new(b"key=".to_vec()));
                    assert_eq!(r.read_key_value(4).unwrap(), b"key=");
                }
                #[test]
                fn heldout_empty() {
                    let mut r = KeyValueReader::new(Cursor::new(vec![]));
                    assert!(r.read_key_value(0).unwrap().is_empty());
                }
                #[test]
                fn heldout_short_err() {
                    let mut r = KeyValueReader::new(Cursor::new(vec![1u8]));
                    assert!(r.read_key_value(4).is_err());
                }
                #[test]
                fn heldout_xor() {
                    let mut r = KeyValueReader::new(Cursor::new(vec![1u8,2,3]));
                    let v = r.read_key_value(3).unwrap();
                    assert_eq!(v.iter().fold(0u8,|a,b|a^b), 0);
                }
            ''',
            "reference": ref("CVE-2021-30454"),
            "mutants": [
                mutation("restore_set_len", "let mut buf = vec![0u8; len];", "let mut buf = Vec::with_capacity(len); unsafe { buf.set_len(len); }", "restores uninit"),
                mutation("read_not_exact", "self.inner.read_exact(&mut buf)?;", "let _ = self.inner.read(&mut buf)?;", "partial"),
                mutation("return_empty", "Ok(buf)", "Ok(vec![])", "empty"),
                mutation("under_alloc", "let mut buf = vec![0u8; len];", "let mut buf = vec![0u8; len.saturating_sub(1)];", "short buffer"),
            ],
        },
        {
            "id": "CVE-2021-38190",
            "batch": "batch_6",
            "contract": "VecStorage requires data.len()==nrows*ncols and uses checked indexing.",
            "evidence": "audit OOB; get_unchecked without data length invariant",
            "dimensions": "valid index; short data panics; oob index; values; 1x1",
            "symbols": ["VecStorage::from_deserialize_unchecked", "Index"],
            "tests": '''
                use std::panic;
                #[test]
                fn heldout_index_ok() {
                    let s = VecStorage::from_deserialize_unchecked(2, 3, vec![1,2,3,4,5,6]);
                    assert_eq!(s[(0,0)], 1);
                    assert_eq!(s[(1,2)], 6);
                }
                #[test]
                fn heldout_short_data_panics() {
                    assert!(panic::catch_unwind(|| {
                        VecStorage::from_deserialize_unchecked(2, 2, vec![1i32,2,3]);
                    }).is_err());
                }
                #[test]
                fn heldout_oob_index_panics() {
                    let s = VecStorage::from_deserialize_unchecked(2, 2, vec![1,2,3,4]);
                    assert!(panic::catch_unwind(|| { let _ = s[(2,0)]; }).is_err());
                }
                #[test]
                fn heldout_one_by_one() {
                    let s = VecStorage::from_deserialize_unchecked(1, 1, vec![9u8]);
                    assert_eq!(s[(0,0)], 9);
                }
                #[test]
                fn heldout_strings() {
                    let s = VecStorage::<String>::from_deserialize_unchecked(
                        1, 2, vec!["a".into(), "b".into()],
                    );
                    assert_eq!(s[(0,1)], "b");
                }
            ''',
            "reference": ref("CVE-2021-38190"),
            "mutants": [
                mutation("remove_len_assert", "assert_eq!(data.len(), nrows.checked_mul(ncols).expect(\"overflow\"));\n        ", "", "skips length invariant"),
                mutation("swap_dims", "VecStorage { data, nrows, ncols }", "VecStorage { data, nrows: ncols, ncols: nrows }", "swaps dims"),
                mutation("always_first", "let offset = i * self.ncols + j;\n        &self.data[offset]", "let _ = (i, j);\n        &self.data[0]", "always first"),
                mutation("wrong_offset", "let offset = i * self.ncols + j;", "let offset = i + j;", "wrong offset"),
            ],
        },
        {
            "id": "CVE-2021-45681",
            "batch": "batch_6",
            "contract": "query_interface AddRefs before returning; release frees only at zero.",
            "evidence": "audit UAF; QI missing AddRef leads to premature free",
            "dimensions": "qi addref; release; get_data; double release; multi qi",
            "symbols": ["ComObject::new", "query_interface", "add_ref", "release", "get_data"],
            "tests": '''
                #[test]
                fn heldout_qi_bumps_refcount() {
                    let p = ComObject::new("x".into());
                    let q = ComObject::query_interface(p);
                    assert_eq!(q, p);
                    // two owners: original + QI
                    assert_eq!(ComObject::release(p), 1);
                    assert_eq!(ComObject::release(q), 0);
                }
                #[test]
                fn heldout_get_data_ok() {
                    let p = ComObject::new("data".into());
                    let s = unsafe { &*ComObject::get_data(p) };
                    assert_eq!(s, "data");
                    assert_eq!(ComObject::release(p), 0);
                }
                #[test]
                fn heldout_add_ref_manual() {
                    let p = ComObject::new("z".into());
                    assert_eq!(ComObject::add_ref(p), 2);
                    assert_eq!(ComObject::release(p), 1);
                    assert_eq!(ComObject::release(p), 0);
                }
                #[test]
                fn heldout_double_qi() {
                    let p = ComObject::new("a".into());
                    let q1 = ComObject::query_interface(p);
                    let q2 = ComObject::query_interface(p);
                    assert_eq!(ComObject::release(q1), 2);
                    assert_eq!(ComObject::release(q2), 1);
                    assert_eq!(ComObject::release(p), 0);
                }
                #[test]
                fn heldout_single_release() {
                    let p = ComObject::new("solo".into());
                    assert_eq!(ComObject::release(p), 0);
                }
            ''',
            "reference": ref("CVE-2021-45681"),
            "mutants": [
                mutation("remove_qi_addref", "Self::add_ref(this);\n        ", "", "QI without AddRef"),
                mutation("release_never_frees", "if old == 1", "if old == 0", "never frees"),
                mutation("add_ref_noop", "(*this).refcount.fetch_add(1, Ordering::SeqCst) + 1", "(*this).refcount.load(Ordering::SeqCst)", "no increment"),
                mutation("get_data_null", "unsafe { &(*this).data }", "std::ptr::null()", "null data"),
            ],
        },
        {
            "id": "CVE-2021-45684",
            "batch": "batch_6",
            "contract": "read_entry zero-fills the frame buffer before calling read_at.",
            "evidence": "audit uninit; set_len before read_at",
            "dimensions": "peek read_at; valid frame; short; validate; emptyish",
            "symbols": ["read_entry", "validate_entry", "Frame"],
            "tests": '''
                #[test]
                fn heldout_peek_read_at_safe() {
                    let frame = Frame { offset: 0, data_size: 2 };
                    let mut calls = 0usize;
                    let res = read_entry::<u32, _>(&frame, &mut |buf, _off| {
                        calls += 1;
                        if !buf.is_empty() {
                            let x = buf[0];
                            std::hint::black_box(x);
                        }
                        // data(2) + u32 size + u32 next; next >= offset+4+rest.len()
                        let payload = [0xAAu8, 0xBB, 0,0,0,2, 0,0,0,20];
                        assert_eq!(buf.len(), payload.len());
                        buf.copy_from_slice(&payload);
                        Ok(payload.len())
                    });
                    assert!(res.is_ok());
                    assert_eq!(calls, 1);
                    let rr = res.unwrap();
                    assert_eq!(rr.entry.data, vec![0xAA, 0xBB]);
                }
                #[test]
                fn heldout_short_read_errors() {
                    let frame = Frame { offset: 0, data_size: 4 };
                    let res = read_entry::<u32, _>(&frame, &mut |buf, _| {
                        buf[0] = 1;
                        Ok(1)
                    });
                    assert!(res.is_err());
                }
                #[test]
                fn heldout_data_start() {
                    let f = Frame { offset: 10, data_size: 3 };
                    assert_eq!(f.data_start(), 14);
                }
                #[test]
                fn heldout_validate_size_mismatch() {
                    let rest = vec![1u8,2, 0,0,0,9, 0,0,0,0,0,0,0,0];
                    assert!(validate_entry::<u64>(0, 2, &rest).is_err());
                }
                #[test]
                fn heldout_size_of_tail() {
                    assert_eq!(size_of_frame_tail::<u32>(), 8);
                }
            ''',
            "reference": ref("CVE-2021-45684"),
            "mutants": [
                mutation("restore_set_len", "let mut buf = vec![0u8; to_read];", "let mut buf = Vec::with_capacity(to_read); unsafe { buf.set_len(to_read); }", "restores uninit"),
                mutation("empty_entry_data", "data: buf,", "data: Vec::new(),", "empties entry data"),
                mutation("truncate_zero", "buf.truncate(frame.data_size);", "buf.truncate(0);", "empties data"),
                mutation("data_start_wrong", "self.offset + size_of::<u32>() as u64", "self.offset", "wrong start"),
            ],
        },
        {
            "id": "CVE-2021-45686",
            "batch": "batch_6",
            "contract": "preamble_skipcount zero-fills its buffer before Read::read.",
            "evidence": "audit uninit; set_len before read",
            "dimensions": "peek; newlines; zero; short; values",
            "symbols": ["preamble_skipcount"],
            "tests": '''
                use std::io::{self, Cursor, Read};
                struct PeekReader(Cursor<Vec<u8>>);
                impl Read for PeekReader {
                    fn read(&mut self, buf: &mut [u8]) -> io::Result<usize> {
                        if !buf.is_empty() {
                            let x = buf[0];
                            std::hint::black_box(x);
                        }
                        self.0.read(buf)
                    }
                }
                #[test]
                fn heldout_peek_safe() {
                    let mut r = PeekReader(Cursor::new(b"a\nb\nc\n".to_vec()));
                    let n = preamble_skipcount(&mut r, 2).unwrap();
                    assert!(n > 0);
                }
                #[test]
                fn heldout_zero_preamble() {
                    let mut c = Cursor::new(b"x".to_vec());
                    assert_eq!(preamble_skipcount(&mut c, 0).unwrap(), 0);
                }
                #[test]
                fn heldout_count_newlines() {
                    let mut c = Cursor::new(b"1\n2\n3\nrest".to_vec());
                    let n = preamble_skipcount(&mut c, 3).unwrap();
                    assert_eq!(n, 6);
                }
                #[test]
                fn heldout_partial_lines() {
                    let mut c = Cursor::new(b"no-newline".to_vec());
                    let n = preamble_skipcount(&mut c, 2).unwrap();
                    assert_eq!(n, 0);
                }
                #[test]
                fn heldout_one_line() {
                    let mut c = Cursor::new(b"only\n".to_vec());
                    assert_eq!(preamble_skipcount(&mut c, 1).unwrap(), 5);
                }
            ''',
            "reference": ref("CVE-2021-45686"),
            "mutants": [
                mutation("restore_set_len", "let mut buffer = vec![0u8; cap];", "let mut buffer = Vec::with_capacity(cap); unsafe { buffer.set_len(cap); }", "restores uninit"),
                mutation("zero_always", "if n_preamble_rows == 0", "if true", "always zero"),
                mutation("ignore_newlines", "if let Some(nl) = buffer[pos..n_read].iter().position(|&b| b == b'\\n')", "if let Some(nl) = None", "never finds nl"),
                mutation("small_cap", "let cap = 1 << 12;", "let cap = 1;", "tiny buffer"),
            ],
        },
    ]


def main() -> int:
    for spec in cases():
        if not spec["reference"].startswith("\n"):
            spec["reference"] = "\n" + spec["reference"]
        write_case(spec)
        print(f"wrote cases/{spec['id']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
