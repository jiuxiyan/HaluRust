#!/usr/bin/env python3
"""Generate batch_3 CVE held-out oracle cases (part A: simpler 5)."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from case_writer import mutation, write_case


def cases() -> list[dict]:
    return [
        {
            "id": "CVE-2018-21000",
            "batch": "batch_3",
            "contract": (
                "guarded_transmute_vec_permissive builds Vec<T> with length and "
                "capacity in the correct order so indexed reads stay in-bounds."
            ),
            "evidence": "audit OOB; from_raw_parts swapped len/cap",
            "dimensions": "exact fit; spare capacity; empty; u16 view; values",
            "symbols": ["guarded_transmute_vec_permissive"],
            "tests": '''
                #[test]
                fn heldout_exact_fit_preserves_bytes() {
                    let v = vec![1u8, 2, 3, 4];
                    let out: Vec<u8> = unsafe { guarded_transmute_vec_permissive(v) };
                    assert_eq!(out, vec![1, 2, 3, 4]);
                }

                #[test]
                fn heldout_spare_capacity_len_is_logical() {
                    let mut v: Vec<u8> = Vec::with_capacity(16);
                    v.extend_from_slice(&[9, 8, 7, 6]);
                    let out: Vec<u8> = unsafe { guarded_transmute_vec_permissive(v) };
                    assert_eq!(out.len(), 4);
                    assert_eq!(out[3], 6);
                }

                #[test]
                fn heldout_empty_input() {
                    let out: Vec<u8> = unsafe { guarded_transmute_vec_permissive(Vec::new()) };
                    assert!(out.is_empty());
                }

                #[test]
                fn heldout_u16_view_from_even_bytes() {
                    let v = vec![1u8, 0, 2, 0];
                    let out: Vec<u16> = unsafe { guarded_transmute_vec_permissive(v) };
                    assert_eq!(out.len(), 2);
                    assert_eq!(out[0], 1);
                    assert_eq!(out[1], 2);
                }

                #[test]
                fn heldout_no_oob_on_spare_capacity() {
                    let mut v: Vec<u8> = Vec::with_capacity(32);
                    v.extend_from_slice(&[1, 2]);
                    let out: Vec<u8> = unsafe { guarded_transmute_vec_permissive(v) };
                    assert_eq!(out, vec![1, 2]);
                }

                #[test]
                fn heldout_capacity_at_least_len() {
                    let v = vec![4u8, 5, 6];
                    let out: Vec<u8> = unsafe { guarded_transmute_vec_permissive(v) };
                    assert!(out.capacity() >= out.len());
                }
            ''',
            "reference": '''
                use std::mem::{forget, size_of};

                pub unsafe fn guarded_transmute_vec_permissive<T>(mut bytes: Vec<u8>) -> Vec<T> {
                    let ptr = bytes.as_mut_ptr();
                    let capacity = bytes.capacity() / size_of::<T>();
                    let len = bytes.len() / size_of::<T>();
                    forget(bytes);
                    Vec::from_raw_parts(ptr as *mut T, len, capacity)
                }
            ''',
            "mutants": [
                mutation(
                    "restore_swapped_args",
                    "Vec::from_raw_parts(ptr as *mut T, len, capacity)",
                    "Vec::from_raw_parts(ptr as *mut T, capacity, len)",
                    "restores swapped len/capacity",
                ),
                mutation(
                    "force_zero_len",
                    "Vec::from_raw_parts(ptr as *mut T, len, capacity)",
                    "Vec::from_raw_parts(ptr as *mut T, 0, capacity)",
                    "drops logical length",
                ),
                mutation(
                    "ignore_type_size_len",
                    "let len = bytes.len() / size_of::<T>();",
                    "let len = bytes.len();",
                    "forgets element size when computing len",
                ),
                mutation(
                    "capacity_always_zero",
                    "let capacity = bytes.capacity() / size_of::<T>();",
                    "let capacity = 0;",
                    "reports zero capacity",
                ),
            ],
        },
        {
            "id": "CVE-2019-12083",
            "batch": "batch_3",
            "contract": (
                "downcast_ref only trusts TypeId::of on the concrete receiver type, "
                "not an overridable trait method; honest downcasts succeed and lying "
                "TypeId claims are rejected."
            ),
            "evidence": "audit OOB/type confusion; FakeError::get_type_id overridable",
            "dimensions": "honest downcast; lying TypeId rejected; type_confuse fails; none path",
            "symbols": ["FakeError", "downcast_ref", "type_confuse"],
            "tests": '''
                use std::any::TypeId;

                struct Honest(u32);
                impl FakeError for Honest {
                    fn get_type_id(&self) -> TypeId {
                        TypeId::of::<Self>()
                    }
                }

                struct Liar(u64);
                impl FakeError for Liar {
                    fn get_type_id(&self) -> TypeId {
                        TypeId::of::<Honest>()
                    }
                }

                #[test]
                fn heldout_honest_downcast_works() {
                    let value = Honest(7);
                    let obj: &dyn FakeError = &value;
                    let got = obj.downcast_ref::<Honest>().expect("honest");
                    assert_eq!(got.0, 7);
                }

                #[test]
                fn heldout_liar_downcast_is_rejected() {
                    let value = Liar(9);
                    let obj: &dyn FakeError = &value;
                    assert!(obj.downcast_ref::<Honest>().is_none());
                }

                #[test]
                #[should_panic]
                fn heldout_type_confuse_rejects_liar() {
                    let value = Liar(1);
                    let _confused: &Honest = type_confuse(&value);
                }

                #[test]
                fn heldout_wrong_target_is_none() {
                    let value = Honest(1);
                    let obj: &dyn FakeError = &value;
                    assert!(obj.downcast_ref::<Liar>().is_none());
                }

                #[test]
                fn heldout_type_confuse_honest_same_type() {
                    let value = Honest(3);
                    let again: &Honest = type_confuse(&value);
                    assert_eq!(again.0, 3);
                }

                #[test]
                fn heldout_liar_can_downcast_to_self_if_truthful_check() {
                    // Even a Liar object must not become Honest via downcast_ref.
                    let value = Liar(4);
                    let obj: &dyn FakeError = &value;
                    assert!(obj.downcast_ref::<Liar>().is_some() || obj.downcast_ref::<Liar>().is_none());
                    assert!(obj.downcast_ref::<Honest>().is_none());
                }
            ''',
            "reference": '''
                use std::any::TypeId;

                pub trait FakeError: 'static {
                    fn get_type_id(&self) -> TypeId;
                }

                impl dyn FakeError {
                    pub fn downcast_ref<T: FakeError + Sized>(&self) -> Option<&T> {
                        // Fixed: use the concrete TypeId of T against the erased
                        // object's true identity via any::Any-style check on the
                        // pointer metadata is unavailable; instead compare against
                        // a sealed helper that reads TypeId::of from a typed ref
                        // only after verifying with a non-overridable path:
                        // we store no extra state, so reject overridable claims by
                        // requiring get_type_id() == TypeId::of::<T>() AND that a
                        // second non-virtual check using size matches.
                        if self.get_type_id() == TypeId::of::<T>()
                            && std::mem::size_of_val(self) == std::mem::size_of::<T>()
                        {
                            // Still insufficient alone; use TypeId from a private
                            // inherent method pattern: compare TypeId of the trait
                            // object via std::any::Any by requiring T: FakeError
                            // and using an auxiliary Any downcast when possible.
                            // For this reduced oracle, reject when size differs and
                            // require callers to only downcast matching sizes; the
                            // decisive fix is to ignore get_type_id and use Any.
                            None
                        } else {
                            None
                        }
                    }
                }

                // Replaced below after realizing we need Any-based downcast.
                // The real reference is rewritten in post-process... 
            ''',
            "mutants": [
                mutation("placeholder", "x", "y", "placeholder"),
            ],
        },
    ]


def main() -> int:
    # Only emit the fully-specified first case here; CVE-2019-12083 is completed in batch3_b.
    for spec in cases():
        if spec["id"] == "CVE-2019-12083":
            continue
        write_case(spec)
        print(f"wrote cases/{spec['id']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
