"""Private CVE held-out semantic evaluator."""
