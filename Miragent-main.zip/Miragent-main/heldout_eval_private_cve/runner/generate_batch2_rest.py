#!/usr/bin/env python3
"""Generate remaining batch_2 CVE held-out oracle cases."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from case_writer import mutation, write_case


def cases() -> list[dict]:
    return [
        {
            "id": "CVE-2018-1000657",
            "batch": "batch_2",
            "contract": (
                "VecDeque reserve grows only when new_cap exceeds buffer cap; wrapped "
                "near-full rings remain Miri-safe; contiguous push/pop preserve FIFO order."
            ),
            "evidence": "audit OOB; reserve compared against usable capacity() not buf cap",
            "dimensions": "contiguous fifo; wrapped reserve(0); empty; capacity; push_front",
            "symbols": ["VecDeque::with_capacity", "reserve", "push_back", "pop_front", "len"],
            "tests": '''
                #[test]
                fn heldout_contiguous_fifo_values() {
                    let mut d: VecDeque<i32> = VecDeque::with_capacity(7);
                    for i in 0..5 {
                        d.push_back(i);
                    }
                    assert_eq!(d.pop_front(), Some(0));
                    assert_eq!(d.pop_front(), Some(1));
                    d.push_back(5);
                    assert_eq!(d.len(), 4);
                    assert_eq!(d.pop_front(), Some(2));
                }

                #[test]
                fn heldout_wrapped_reserve_zero_is_safe() {
                    let mut d: VecDeque<u8> = VecDeque::with_capacity(7);
                    for i in 0..6u8 {
                        d.push_back(i);
                    }
                    assert_eq!(d.pop_front(), Some(0));
                    assert_eq!(d.pop_front(), Some(1));
                    d.push_back(6);
                    d.push_back(7);
                    d.push_back(8);
                    let _ = d.pop_front();
                    d.reserve(0);
                    d.push_back(9);
                    assert_eq!(d.pop_front(), Some(3));
                }

                #[test]
                fn heldout_empty_pop_none() {
                    let mut d: VecDeque<i32> = VecDeque::new();
                    assert!(d.is_empty());
                    assert_eq!(d.pop_front(), None);
                }

                #[test]
                fn heldout_capacity_is_seven_for_request_seven() {
                    let d: VecDeque<u8> = VecDeque::with_capacity(7);
                    assert_eq!(d.capacity(), 7);
                }

                #[test]
                fn heldout_push_front_order() {
                    let mut d: VecDeque<i32> = VecDeque::with_capacity(7);
                    d.push_back(2);
                    d.push_front(1);
                    d.push_front(0);
                    assert_eq!(d.pop_front(), Some(0));
                    assert_eq!(d.pop_front(), Some(1));
                    assert_eq!(d.pop_front(), Some(2));
                }

                #[test]
                fn heldout_fill_then_drain() {
                    let mut d: VecDeque<i32> = VecDeque::with_capacity(7);
                    for i in 0..7 {
                        d.push_back(i);
                    }
                    assert_eq!(d.len(), 7);
                    for i in 0..7 {
                        assert_eq!(d.pop_front(), Some(i));
                    }
                }
            ''',
            "reference": '''
                use std::alloc::{alloc, dealloc, handle_alloc_error, Layout};
                use std::ptr;

                pub struct VecDeque<T> {
                    ptr: *mut T,
                    cap: usize,
                    head: usize,
                    tail: usize,
                }

                impl<T> VecDeque<T> {
                    pub fn new() -> Self {
                        Self::with_capacity(7)
                    }

                    pub fn with_capacity(n: usize) -> Self {
                        let cap = (n + 1).next_power_of_two().max(8);
                        let layout = Layout::array::<T>(cap).unwrap();
                        let ptr = unsafe { alloc(layout) as *mut T };
                        if ptr.is_null() {
                            handle_alloc_error(layout);
                        }
                        Self { ptr, cap, head: 0, tail: 0 }
                    }

                    fn cap(&self) -> usize { self.cap }

                    pub fn capacity(&self) -> usize { self.cap() - 1 }

                    pub fn len(&self) -> usize {
                        count(self.tail, self.head, self.cap())
                    }

                    pub fn is_empty(&self) -> bool { self.head == self.tail }

                    pub fn reserve(&mut self, additional: usize) {
                        let old_cap = self.cap();
                        let used_cap = self.len() + 1;
                        let new_cap = used_cap
                            .checked_add(additional)
                            .and_then(|needed| needed.checked_next_power_of_two())
                            .expect("capacity overflow");
                        if new_cap > old_cap {
                            self.buf_reserve(new_cap);
                            unsafe { self.handle_cap_increase(old_cap); }
                        }
                    }

                    fn buf_reserve(&mut self, new_cap: usize) {
                        if new_cap <= self.cap { return; }
                        let old_layout = Layout::array::<T>(self.cap).unwrap();
                        let new_layout = Layout::array::<T>(new_cap).unwrap();
                        unsafe {
                            let new_ptr = alloc(new_layout) as *mut T;
                            if new_ptr.is_null() { handle_alloc_error(new_layout); }
                            if self.cap > 0 {
                                ptr::copy_nonoverlapping(self.ptr, new_ptr, self.cap);
                                dealloc(self.ptr as *mut u8, old_layout);
                            }
                            self.ptr = new_ptr;
                            self.cap = new_cap;
                        }
                    }

                    unsafe fn handle_cap_increase(&mut self, old_cap: usize) {
                        let new_cap = self.cap();
                        if self.tail <= self.head {
                        } else if self.head < old_cap - self.tail {
                            self.copy_nonoverlapping(old_cap, 0, self.head);
                            self.head += old_cap;
                        } else {
                            let new_tail = new_cap - (old_cap - self.tail);
                            self.copy_nonoverlapping(new_tail, self.tail, old_cap - self.tail);
                            self.tail = new_tail;
                        }
                    }

                    unsafe fn copy_nonoverlapping(&mut self, dst: usize, src: usize, len: usize) {
                        ptr::copy_nonoverlapping(self.ptr.add(src), self.ptr.add(dst), len);
                    }

                    pub fn push_back(&mut self, value: T) {
                        if self.len() == self.capacity() { self.reserve(1); }
                        unsafe { ptr::write(self.ptr.add(self.head), value); }
                        self.head = wrap_add(self.head, 1, self.cap());
                    }

                    pub fn push_front(&mut self, value: T) {
                        if self.len() == self.capacity() { self.reserve(1); }
                        self.tail = wrap_sub(self.tail, 1, self.cap());
                        unsafe { ptr::write(self.ptr.add(self.tail), value); }
                    }

                    pub fn pop_front(&mut self) -> Option<T> {
                        if self.is_empty() { return None; }
                        let value = unsafe { ptr::read(self.ptr.add(self.tail)) };
                        self.tail = wrap_add(self.tail, 1, self.cap());
                        Some(value)
                    }
                }

                impl<T> Drop for VecDeque<T> {
                    fn drop(&mut self) {
                        while self.pop_front().is_some() {}
                        if self.cap > 0 {
                            unsafe { dealloc(self.ptr as *mut u8, Layout::array::<T>(self.cap).unwrap()); }
                        }
                    }
                }

                fn wrap_add(idx: usize, addend: usize, cap: usize) -> usize {
                    (idx + addend) & (cap - 1)
                }
                fn wrap_sub(idx: usize, subtrahend: usize, cap: usize) -> usize {
                    idx.wrapping_sub(subtrahend) & (cap - 1)
                }
                fn count(tail: usize, head: usize, cap: usize) -> usize {
                    (head.wrapping_sub(tail)) & (cap - 1)
                }
            ''',
            "mutants": [
                mutation(
                    "restore_capacity_comparison",
                    "if new_cap > old_cap {",
                    "if new_cap > self.capacity() {",
                    "restores buggy reserve comparison",
                ),
                mutation(
                    "push_back_skips_write",
                    "unsafe { ptr::write(self.ptr.add(self.head), value); }",
                    "core::mem::forget(value);",
                    "drops pushed values",
                ),
                mutation(
                    "pop_front_wrong_advance",
                    "self.tail = wrap_add(self.tail, 1, self.cap());",
                    "self.tail = wrap_add(self.tail, 2, self.cap());",
                    "skips elements on pop",
                ),
                mutation(
                    "capacity_off_by_one",
                    "pub fn capacity(&self) -> usize { self.cap() - 1 }",
                    "pub fn capacity(&self) -> usize { self.cap() }",
                    "misreports usable capacity",
                ),
            ],
        },
        {
            "id": "CVE-2019-15551",
            "batch": "batch_2",
            "contract": (
                "SmallVec push spills correctly; grow(current_cap) is a no-op on spilled "
                "storage and must not free the live heap buffer."
            ),
            "evidence": "audit UAF; equal-cap grow deallocates live heap pointer",
            "dimensions": "inline push; spill; equal-cap grow; values after grow; len",
            "symbols": ["SmallVec::new", "push", "grow", "len", "spilled", "capacity"],
            "tests": '''
                #[test]
                fn heldout_inline_then_spill_values() {
                    let mut sv: SmallVec<u32, 2> = SmallVec::new();
                    sv.push(1);
                    sv.push(2);
                    assert!(!sv.spilled());
                    sv.push(3);
                    assert!(sv.spilled());
                    assert_eq!(sv.len(), 3);
                }

                #[test]
                fn heldout_equal_cap_grow_keeps_buffer() {
                    let mut sv: SmallVec<String, 2> = SmallVec::new();
                    sv.push("a".into());
                    sv.push("b".into());
                    sv.push("c".into());
                    assert!(sv.spilled());
                    let cap = sv.capacity();
                    sv.grow(cap);
                    assert_eq!(sv.len(), 3);
                    assert!(sv.spilled());
                    unsafe {
                        assert_eq!(&*sv.as_ptr(), "a");
                    }
                }

                #[test]
                fn heldout_grow_larger_preserves_prefix() {
                    let mut sv: SmallVec<u32, 2> = SmallVec::new();
                    sv.push(4);
                    sv.push(5);
                    sv.push(6);
                    let old = sv.capacity();
                    sv.grow(old * 2);
                    assert!(sv.capacity() >= old * 2);
                    assert_eq!(sv.len(), 3);
                }

                #[test]
                fn heldout_empty_len_zero() {
                    let sv: SmallVec<u8, 4> = SmallVec::new();
                    assert_eq!(sv.len(), 0);
                    assert!(!sv.spilled());
                }

                #[test]
                fn heldout_push_sequence_unique_values() {
                    let mut sv: SmallVec<i32, 1> = SmallVec::new();
                    for i in 0..5 {
                        sv.push(i);
                    }
                    assert_eq!(sv.len(), 5);
                }

                #[test]
                fn heldout_capacity_inline_is_n() {
                    let sv: SmallVec<u8, 3> = SmallVec::new();
                    assert_eq!(sv.capacity(), 3);
                }
            ''',
            "reference": '''
                use std::alloc::{self, Layout};
                use std::mem::MaybeUninit;
                use std::ptr;

                enum Data<T, const N: usize> {
                    Inline([MaybeUninit<T>; N]),
                    Heap(*mut T),
                }

                pub struct SmallVec<T, const N: usize> {
                    len: usize,
                    cap: usize,
                    data: Data<T, N>,
                }

                unsafe fn alloc_buffer<T>(cap: usize) -> *mut T {
                    if cap == 0 { return ptr::null_mut(); }
                    let layout = Layout::array::<T>(cap).unwrap();
                    alloc::alloc(layout) as *mut T
                }

                unsafe fn dealloc_buffer<T>(ptr: *mut T, cap: usize) {
                    if cap == 0 || ptr.is_null() { return; }
                    let layout = Layout::array::<T>(cap).unwrap();
                    alloc::dealloc(ptr as *mut u8, layout);
                }

                impl<T, const N: usize> SmallVec<T, N> {
                    pub fn new() -> Self {
                        SmallVec {
                            len: 0,
                            cap: N,
                            data: Data::Inline(unsafe { MaybeUninit::uninit().assume_init() }),
                        }
                    }

                    pub fn len(&self) -> usize { self.len }

                    pub fn as_ptr(&self) -> *const T {
                        match &self.data {
                            Data::Inline(arr) => arr.as_ptr() as *const T,
                            Data::Heap(ptr) => *ptr,
                        }
                    }

                    fn as_mut_ptr(&mut self) -> *mut T {
                        match &mut self.data {
                            Data::Inline(arr) => arr.as_mut_ptr() as *mut T,
                            Data::Heap(ptr) => *ptr,
                        }
                    }

                    pub fn capacity(&self) -> usize {
                        if self.spilled() { self.cap } else { N }
                    }

                    pub fn spilled(&self) -> bool {
                        matches!(self.data, Data::Heap(_))
                    }

                    pub fn push(&mut self, val: T) {
                        if self.len == self.capacity() {
                            self.grow(self.capacity() * 2);
                        }
                        unsafe { ptr::write(self.as_mut_ptr().add(self.len), val); }
                        self.len += 1;
                    }

                    pub fn grow(&mut self, new_cap: usize) {
                        unsafe {
                            let len = self.len;
                            assert!(new_cap >= len);
                            if new_cap <= N {
                                if !self.spilled() { return; }
                                let ptr = self.as_ptr() as *mut T;
                                let mut inline = [const { MaybeUninit::<T>::uninit() }; N];
                                ptr::copy_nonoverlapping(ptr, inline.as_mut_ptr() as *mut T, len);
                                dealloc_buffer(ptr, self.cap);
                                self.data = Data::Inline(inline);
                                self.cap = N;
                                return;
                            }
                            let cap = self.capacity();
                            if new_cap == cap {
                                return;
                            }
                            let old_ptr = self.as_ptr() as *mut T;
                            let unspilled = !self.spilled();
                            let new_ptr = alloc_buffer::<T>(new_cap);
                            ptr::copy_nonoverlapping(old_ptr, new_ptr, len);
                            self.data = Data::Heap(new_ptr);
                            self.cap = new_cap;
                            if !unspilled {
                                dealloc_buffer(old_ptr, cap);
                            }
                        }
                    }
                }

                impl<T, const N: usize> Drop for SmallVec<T, N> {
                    fn drop(&mut self) {
                        unsafe {
                            for i in 0..self.len {
                                ptr::drop_in_place(self.as_ptr().add(i) as *mut T);
                            }
                            if let Data::Heap(ptr) = self.data {
                                dealloc_buffer(ptr, self.cap);
                            }
                        }
                    }
                }
            ''',
            "mutants": [
                mutation(
                    "equal_cap_frees_live_buffer",
                    "if new_cap == cap {\n                return;\n            }",
                    "if new_cap == cap {\n                dealloc_buffer(self.as_ptr() as *mut T, cap);\n                return;\n            }",
                    "frees spilled buffer on equal-capacity grow",
                ),
                mutation(
                    "push_skips_len",
                    "self.len += 1;",
                    "",
                    "fails to increase length on push",
                ),
                mutation(
                    "grow_never_allocates",
                    "let new_ptr = alloc_buffer::<T>(new_cap);\n            ptr::copy_nonoverlapping(old_ptr, new_ptr, len);\n            self.data = Data::Heap(new_ptr);\n            self.cap = new_cap;",
                    "self.cap = new_cap;",
                    "updates cap without allocating heap buffer",
                ),
                mutation(
                    "capacity_always_n",
                    "if self.spilled() { self.cap } else { N }",
                    "N",
                    "misreports spilled capacity",
                ),
            ],
        },
        {
            "id": "CVE-2019-16140",
            "batch": "batch_2",
            "contract": (
                "From<Buffer> for Vec transfers ownership without double-free; constructed "
                "buffers retain bytes until converted or dropped."
            ),
            "evidence": "audit UAF; From creates Vec then Buffer Drop frees same allocation",
            "dimensions": "convert contents; empty; drop buffer; len after convert; repeated",
            "symbols": ["Buffer::new", "From<Buffer> for Vec<u8>"],
            "tests": '''
                #[test]
                fn heldout_buffer_to_vec_keeps_bytes() {
                    let buf = Buffer::new(vec![1, 2, 3, 4]);
                    let out: Vec<u8> = buf.into();
                    assert_eq!(out, vec![1, 2, 3, 4]);
                }

                #[test]
                fn heldout_empty_buffer_converts() {
                    let buf = Buffer::new(Vec::new());
                    let out: Vec<u8> = buf.into();
                    assert!(out.is_empty());
                }

                #[test]
                fn heldout_drop_buffer_without_convert_is_safe() {
                    let buf = Buffer::new(vec![9, 8, 7]);
                    drop(buf);
                }

                #[test]
                fn heldout_converted_vec_is_mutable() {
                    let buf = Buffer::new(vec![5, 6]);
                    let mut out: Vec<u8> = buf.into();
                    out.push(7);
                    assert_eq!(out, vec![5, 6, 7]);
                }

                #[test]
                fn heldout_largeish_payload() {
                    let data = (0u8..64).collect::<Vec<_>>();
                    let buf = Buffer::new(data.clone());
                    let out: Vec<u8> = buf.into();
                    assert_eq!(out, data);
                }

                #[test]
                fn heldout_capacity_preserved_enough_for_len() {
                    let buf = Buffer::new(vec![1, 2, 3]);
                    let out: Vec<u8> = buf.into();
                    assert!(out.capacity() >= out.len());
                }
            ''',
            "reference": '''
                use std::convert::From;
                use std::mem::ManuallyDrop;

                pub struct Buffer {
                    ptr: *mut u8,
                    len: usize,
                    cap: usize,
                }

                impl Buffer {
                    pub fn new(data: Vec<u8>) -> Self {
                        let mut data = data;
                        let ptr = data.as_mut_ptr();
                        let len = data.len();
                        let cap = data.capacity();
                        std::mem::forget(data);
                        Self { ptr, len, cap }
                    }
                }

                impl Drop for Buffer {
                    fn drop(&mut self) {
                        if !self.ptr.is_null() {
                            unsafe {
                                let _ = Vec::from_raw_parts(self.ptr, self.len, self.cap);
                            }
                        }
                    }
                }

                impl From<Buffer> for Vec<u8> {
                    fn from(buf: Buffer) -> Self {
                        let buf = ManuallyDrop::new(buf);
                        unsafe { Vec::from_raw_parts(buf.ptr, buf.len, buf.cap) }
                    }
                }
            ''',
            "mutants": [
                mutation(
                    "restore_double_free_from",
                    "let buf = ManuallyDrop::new(buf);\n        unsafe { Vec::from_raw_parts(buf.ptr, buf.len, buf.cap) }",
                    "unsafe { Vec::from_raw_parts(buf.ptr, buf.len, buf.cap) }",
                    "allows Buffer Drop after Vec creation",
                ),
                mutation(
                    "from_zero_len",
                    "unsafe { Vec::from_raw_parts(buf.ptr, buf.len, buf.cap) }",
                    "unsafe { Vec::from_raw_parts(buf.ptr, 0, buf.cap) }",
                    "drops payload length on convert",
                ),
                mutation(
                    "new_forgets_wrong_len",
                    "let len = data.len();",
                    "let len = 0;",
                    "stores wrong length in Buffer",
                ),
                mutation(
                    "drop_skips_free",
                    "let _ = Vec::from_raw_parts(self.ptr, self.len, self.cap);",
                    "",
                    "leaks Buffer allocation on drop",
                ),
            ],
        },
        {
            "id": "CVE-2019-16144",
            "batch": "batch_2",
            "contract": (
                "Context::new_uninit uses null para/ret; get_para/set_ret operate only on "
                "initialized pointers and preserve typed Option payloads."
            ),
            "evidence": "audit uninit; new_uninit assume_init then get_para reads uninit",
            "dimensions": "uninit get none; initialized take; set_ret; is_generator; mismatch panic",
            "symbols": ["Context::new_uninit", "with_initialized_para_ret", "get_para", "set_ret"],
            "profiles": [{"name": "default_ignore_leaks", "flags": ["-Zmiri-ignore-leaks"]}],
            "tests": '''
                use std::panic;

                #[test]
                fn heldout_uninit_get_para_is_none() {
                    let ctx = Context::new_uninit();
                    assert!(ctx.get_para::<i32>().is_none());
                }

                #[test]
                fn heldout_initialized_para_take() {
                    let mut slot: Option<i32> = Some(42);
                    let mut ret: Option<i32> = None;
                    let para: *mut dyn std::any::Any = &mut slot;
                    let ret_ptr: *mut dyn std::any::Any = &mut ret;
                    let ctx = Context::with_initialized_para_ret(para, ret_ptr);
                    assert_eq!(ctx.get_para::<i32>(), Some(42));
                    assert_eq!(ctx.get_para::<i32>(), None);
                }

                #[test]
                fn heldout_set_ret_writes_option() {
                    let mut slot: Option<i32> = None;
                    let mut ret: Option<i32> = None;
                    let para: *mut dyn std::any::Any = &mut slot;
                    let ret_ptr: *mut dyn std::any::Any = &mut ret;
                    let mut ctx = Context::with_initialized_para_ret(para, ret_ptr);
                    ctx.set_ret(7i32);
                    assert_eq!(ret, Some(7));
                }

                #[test]
                fn heldout_is_generator_true_by_default() {
                    let ctx = Context::new_uninit();
                    assert!(ctx.is_generator());
                }

                #[test]
                fn heldout_type_mismatch_panics() {
                    let mut slot: Option<i32> = Some(1);
                    let mut ret: Option<i32> = None;
                    let para: *mut dyn std::any::Any = &mut slot;
                    let ret_ptr: *mut dyn std::any::Any = &mut ret;
                    let ctx = Context::with_initialized_para_ret(para, ret_ptr);
                    let result = panic::catch_unwind(panic::AssertUnwindSafe(|| {
                        let _ = ctx.get_para::<String>();
                    }));
                    assert!(result.is_err());
                }

                #[test]
                fn heldout_ref_count_starts_at_one() {
                    let ctx = Context::new_uninit();
                    assert_eq!(ctx._ref, 1);
                }
            ''',
            "reference": '''
                use std::any::Any;

                pub struct Context {
                    pub para: *mut dyn Any,
                    pub ret: *mut dyn Any,
                    pub parent: *mut Context,
                    pub _ref: u32,
                }

                impl Context {
                    pub fn new_uninit() -> Self {
                        Context {
                            para: Box::leak(Box::new(None::<i32>)) as *mut dyn Any,
                            ret: Box::leak(Box::new(None::<i32>)) as *mut dyn Any,
                            parent: std::ptr::null_mut(),
                            _ref: 1,
                        }
                    }

                    pub fn with_initialized_para_ret(para: *mut dyn Any, ret: *mut dyn Any) -> Self {
                        Context {
                            para,
                            ret,
                            parent: std::ptr::null_mut(),
                            _ref: 1,
                        }
                    }

                    pub fn is_generator(&self) -> bool {
                        !std::ptr::eq(self.parent, self)
                    }

                    pub fn get_para<A>(&self) -> Option<A>
                    where
                        A: Any,
                    {
                        let para = unsafe { &mut *self.para };
                        match para.downcast_mut::<Option<A>>() {
                            Some(v) => v.take(),
                            None => panic!("get yield type mismatch error detected"),
                        }
                    }

                    pub fn set_ret<T>(&mut self, v: T)
                    where
                        T: Any,
                    {
                        let ret = unsafe { &mut *self.ret };
                        match ret.downcast_mut::<Option<T>>() {
                            Some(r) => *r = Some(v),
                            None => panic!("yield type mismatch error detected"),
                        }
                    }
                }
            ''',
            "mutants": [
                mutation(
                    "ref_starts_zero",
                    "parent: std::ptr::null_mut(),\n            _ref: 1,\n        }\n    }\n\n    pub fn with_initialized_para_ret",
                    "parent: std::ptr::null_mut(),\n            _ref: 0,\n        }\n    }\n\n    pub fn with_initialized_para_ret",
                    "breaks initial ref count for uninit contexts",
                ),
                mutation(
                    "restore_uninit_new",
                    "para: Box::leak(Box::new(None::<i32>)) as *mut dyn Any,\n            ret: Box::leak(Box::new(None::<i32>)) as *mut dyn Any,",
                    "para: unsafe { std::mem::MaybeUninit::uninit().assume_init() },\n            ret: unsafe { std::mem::MaybeUninit::uninit().assume_init() },",
                    "restores uninitialized para/ret",
                ),
                mutation(
                    "get_para_never_takes",
                    "Some(v) => v.take(),",
                    "Some(v) => None,",
                    "drops successful para payload",
                ),
                mutation(
                    "set_ret_skips_write",
                    "Some(r) => *r = Some(v),",
                    "Some(r) => {},",
                    "drops set_ret payload",
                ),
            ],
        },
        {
            "id": "CVE-2019-15552",
            "batch": "batch_2",
            "contract": (
                "MultiDecoder reads from the current member without parking an "
                "uninitialized reader on EOF; successful reads return exact bytes."
            ),
            "evidence": "audit uninit; mem::replace Err(uninitialized) on member EOF path",
            "dimensions": "normal read; EOF; partial; empty buf; into_inner; repeated",
            "symbols": ["MultiDecoder::new", "Read::read", "Decoder::into_inner"],
            "tests": '''
                use std::io::{Cursor, Read};

                #[test]
                fn heldout_reads_exact_payload() {
                    let mut dec = MultiDecoder::new(Cursor::new(vec![1, 2, 3, 4])).unwrap();
                    let mut buf = [0u8; 4];
                    assert_eq!(dec.read(&mut buf).unwrap(), 4);
                    assert_eq!(buf, [1, 2, 3, 4]);
                }

                #[test]
                fn heldout_eof_returns_zero() {
                    let mut dec = MultiDecoder::new(Cursor::new(Vec::<u8>::new())).unwrap();
                    let mut buf = [0u8; 2];
                    assert_eq!(dec.read(&mut buf).unwrap(), 0);
                }

                #[test]
                fn heldout_partial_then_eof() {
                    let mut dec = MultiDecoder::new(Cursor::new(vec![9, 8])).unwrap();
                    let mut buf = [0u8; 4];
                    assert_eq!(dec.read(&mut buf).unwrap(), 2);
                    assert_eq!(&buf[..2], &[9, 8]);
                    assert_eq!(dec.read(&mut buf).unwrap(), 0);
                }

                #[test]
                fn heldout_empty_output_buf() {
                    let mut dec = MultiDecoder::new(Cursor::new(vec![1, 2])).unwrap();
                    let mut buf = [];
                    assert_eq!(dec.read(&mut buf).unwrap(), 0);
                }

                #[test]
                fn heldout_decoder_into_inner_roundtrip() {
                    let dec = Decoder::new(Cursor::new(vec![5])).unwrap();
                    let inner = dec.into_inner();
                    assert_eq!(inner.into_inner(), vec![5]);
                }

                #[test]
                fn heldout_repeated_small_reads() {
                    let mut dec = MultiDecoder::new(Cursor::new(vec![1, 2, 3])).unwrap();
                    let mut a = [0u8; 1];
                    assert_eq!(dec.read(&mut a).unwrap(), 1);
                    assert_eq!(a, [1]);
                    assert_eq!(dec.read(&mut a).unwrap(), 1);
                    assert_eq!(a, [2]);
                }
            ''',
            "reference": '''
                use std::io::{self, Read};

                pub struct Decoder<R> {
                    inner: R,
                }

                impl<R> Decoder<R> {
                    pub fn new(inner: R) -> io::Result<Self> {
                        Ok(Decoder { inner })
                    }

                    pub fn into_inner(self) -> R {
                        self.inner
                    }
                }

                impl<R: Read> Read for Decoder<R> {
                    fn read(&mut self, buf: &mut [u8]) -> io::Result<usize> {
                        self.inner.read(buf)
                    }
                }

                pub struct Header;

                impl Header {
                    pub fn read_from<R: Read>(reader: &mut R) -> io::Result<Self> {
                        let mut buf = [0u8; 1];
                        reader.read_exact(&mut buf)?;
                        Ok(Header)
                    }
                }

                pub struct MultiDecoder<R> {
                    pub header: Header,
                    pub decoder: Result<Decoder<R>, R>,
                }

                impl<R: Read> MultiDecoder<R> {
                    pub fn new(inner: R) -> io::Result<Self> {
                        Ok(MultiDecoder {
                            header: Header,
                            decoder: Ok(Decoder::new(inner)?),
                        })
                    }
                }

                impl<R: Read> Read for MultiDecoder<R> {
                    fn read(&mut self, buf: &mut [u8]) -> io::Result<usize> {
                        match self.decoder {
                            Err(_) => Ok(0),
                            Ok(ref mut decoder) => {
                                let read_size = decoder.read(buf)?;
                                // Fixed reduced behavior: treat member EOF as terminal
                                // without parking an uninitialized reader value.
                                Ok(read_size)
                            }
                        }
                    }
                }
            ''',
            "mutants": [
                mutation(
                    "restore_uninit_replace_path",
                    "Ok(ref mut decoder) => {\n                let read_size = decoder.read(buf)?;\n                // Fixed reduced behavior: treat member EOF as terminal\n                // without parking an uninitialized reader value.\n                Ok(read_size)\n            }",
                    "Ok(ref mut decoder) => {\n                let read_size = decoder.read(buf)?;\n                if read_size == 0 {\n                    let mut reader = std::mem::replace(&mut self.decoder, Err(unsafe { std::mem::uninitialized() }))\n                        .ok()\n                        .expect(\"Never fails\")\n                        .into_inner();\n                    match Header::read_from(&mut reader) {\n                        Err(e) => {\n                            std::mem::forget(std::mem::replace(&mut self.decoder, Err(reader)));\n                            if e.kind() == io::ErrorKind::UnexpectedEof { Ok(0) } else { Err(e) }\n                        }\n                        Ok(_header) => {\n                            std::mem::forget(std::mem::replace(&mut self.decoder, Ok(Decoder::new(reader)?)));\n                            self.read(buf)\n                        }\n                    }\n                } else {\n                    Ok(read_size)\n                }\n            }",
                    "restores uninitialized replace on EOF",
                ),
                mutation(
                    "always_return_zero",
                    "let read_size = decoder.read(buf)?;\n                // Fixed reduced behavior: treat member EOF as terminal\n                // without parking an uninitialized reader value.\n                Ok(read_size)",
                    "Ok(0)",
                    "ignores readable payload",
                ),
                mutation(
                    "read_reports_short",
                    "Ok(read_size)\n            }",
                    "Ok(read_size.saturating_sub(1))\n            }",
                    "under-reports successful read length",
                ),
                mutation(
                    "decoder_new_fails",
                    "Ok(Decoder { inner })",
                    "Err(io::Error::new(io::ErrorKind::Other, \"boom\"))",
                    "breaks Decoder construction",
                ),
            ],
        },
    ]


def main() -> int:
    for spec in cases():
        write_case(spec)
        print(f"wrote cases/{spec['id']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
