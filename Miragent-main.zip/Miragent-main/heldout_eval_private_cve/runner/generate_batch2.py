#!/usr/bin/env python3
"""Generate batch_2 CVE held-out oracle cases (10)."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from case_writer import mutation, write_case


def cases() -> list[dict]:
    return [
        # ---- stacked borrows ----
        {
            "id": "CVE-2019-16882",
            "batch": "batch_2",
            "contract": (
                "StringInterner interns uniquely, resolves by id, and Clone rebuilds "
                "map keys against the clone's own storage so lookup after dropping the "
                "original remains defined."
            ),
            "evidence": "audit stacked_borrows; clone copies InternalStrRef into stale storage",
            "dimensions": "empty; intern/get/resolve; duplicate intern; clone+drop lookup; len",
            "symbols": ["StringInterner::new", "get_or_intern", "get", "resolve", "len"],
            "profiles": [{"name": "default_no_sb", "flags": ["-Zmiri-disable-stacked-borrows"]}],
            "tests": '''
                #[test]
                fn heldout_empty_resolve_is_none() {
                    let interner = StringInterner::new();
                    assert_eq!(interner.len(), 0);
                    assert!(interner.get("x").is_none());
                    assert!(interner.resolve(0).is_none());
                }

                #[test]
                fn heldout_intern_roundtrip_values() {
                    let mut interner = StringInterner::new();
                    let a = interner.get_or_intern("alpha");
                    let b = interner.get_or_intern("beta");
                    assert_ne!(a, b);
                    assert_eq!(interner.resolve(a), Some("alpha"));
                    assert_eq!(interner.resolve(b), Some("beta"));
                    assert_eq!(interner.get("alpha"), Some(a));
                }

                #[test]
                fn heldout_duplicate_intern_reuses_id() {
                    let mut interner = StringInterner::new();
                    let first = interner.get_or_intern("same");
                    let second = interner.get_or_intern("same");
                    assert_eq!(first, second);
                    assert_eq!(interner.len(), 1);
                }

                #[test]
                fn heldout_clone_survives_original_drop() {
                    let mut original = StringInterner::new();
                    let hello = original.get_or_intern("hello");
                    let world = original.get_or_intern("world");
                    let cloned = original.clone();
                    drop(original);
                    assert_eq!(cloned.get("hello"), Some(hello));
                    assert_eq!(cloned.get("world"), Some(world));
                    assert_eq!(cloned.resolve(hello), Some("hello"));
                }

                #[test]
                fn heldout_clone_len_matches() {
                    let mut original = StringInterner::new();
                    original.get_or_intern("one");
                    original.get_or_intern("two");
                    let cloned = original.clone();
                    assert_eq!(cloned.len(), 2);
                    assert_eq!(cloned, original);
                }

                #[test]
                fn heldout_resolve_out_of_range() {
                    let mut interner = StringInterner::new();
                    interner.get_or_intern("only");
                    assert!(interner.resolve(3).is_none());
                }
            ''',
            "reference": '''
                use std::collections::HashMap;
                use std::hash::{Hash, Hasher};

                #[derive(Debug, Copy, Clone, Eq)]
                struct InternalStrRef(*const str);

                impl InternalStrRef {
                    fn from_str(val: &str) -> Self {
                        InternalStrRef(val as *const str)
                    }

                    fn as_str(&self) -> &str {
                        unsafe { &*self.0 }
                    }
                }

                impl Hash for InternalStrRef {
                    fn hash<H: Hasher>(&self, state: &mut H) {
                        self.as_str().hash(state)
                    }
                }

                impl PartialEq for InternalStrRef {
                    fn eq(&self, other: &Self) -> bool {
                        self.as_str() == other.as_str()
                    }
                }

                #[derive(Debug, Eq)]
                pub struct StringInterner {
                    map: HashMap<InternalStrRef, usize>,
                    values: Vec<Box<str>>,
                }

                impl PartialEq for StringInterner {
                    fn eq(&self, rhs: &Self) -> bool {
                        self.len() == rhs.len() && self.values == rhs.values
                    }
                }

                impl Clone for StringInterner {
                    fn clone(&self) -> Self {
                        let mut out = StringInterner::new();
                        for value in &self.values {
                            out.get_or_intern(value);
                        }
                        out
                    }
                }

                impl StringInterner {
                    pub fn new() -> Self {
                        Self {
                            map: HashMap::new(),
                            values: Vec::new(),
                        }
                    }

                    pub fn get_or_intern(&mut self, val: &str) -> usize {
                        if let Some(id) = self.get(val) {
                            return id;
                        }
                        let id = self.values.len();
                        let boxed: Box<str> = Box::from(val);
                        let key = InternalStrRef::from_str(boxed.as_ref());
                        self.values.push(boxed);
                        self.map.insert(key, id);
                        id
                    }

                    pub fn get(&self, val: &str) -> Option<usize> {
                        self.map.get(&InternalStrRef::from_str(val)).copied()
                    }

                    pub fn resolve(&self, id: usize) -> Option<&str> {
                        self.values.get(id).map(|s| s.as_ref())
                    }

                    pub fn len(&self) -> usize {
                        self.values.len()
                    }
                }
            ''',
            "mutants": [
                mutation(
                    "derived_style_clone",
                    "fn clone(&self) -> Self {\n        let mut out = StringInterner::new();\n        for value in &self.values {\n            out.get_or_intern(value);\n        }\n        out\n    }",
                    "fn clone(&self) -> Self {\n        Self {\n            map: self.map.clone(),\n            values: self.values.clone(),\n        }\n    }",
                    "restores stale map-pointer clone",
                ),
                mutation(
                    "intern_always_new_id",
                    "if let Some(id) = self.get(val) {\n            return id;\n        }",
                    "",
                    "breaks uniqueness of interned ids",
                ),
                mutation(
                    "resolve_off_by_one",
                    "self.values.get(id).map(|s| s.as_ref())",
                    "self.values.get(id.wrapping_add(1)).map(|s| s.as_ref())",
                    "corrupts resolve indexing",
                ),
                mutation(
                    "len_reports_map",
                    "pub fn len(&self) -> usize {\n        self.values.len()\n    }",
                    "pub fn len(&self) -> usize {\n        self.map.len().saturating_add(1)\n    }",
                    "lies about interner length",
                ),
            ],
        },
        # ---- invalid deref ----
        {
            "id": "CVE-2020-35860",
            "batch": "batch_2",
            "contract": (
                "CBox/CSemiBox reject null construction; valid Box-backed pointers "
                "deref to the owned value and drop exactly once."
            ),
            "evidence": "audit invalid_deref; null from_raw then Deref is UB",
            "dimensions": "valid u64; valid String; null CBox rejected; null CSemiBox rejected; as_ptr",
            "symbols": ["CBox::from_raw", "CBox::as_ptr", "CSemiBox::from_raw", "Deref"],
            "tests": '''
                #[test]
                fn heldout_cbox_reads_u64() {
                    let ptr = Box::into_raw(Box::new(99u64));
                    let boxed = CBox::from_raw(ptr);
                    assert_eq!(*boxed, 99);
                    assert!(!boxed.as_ptr().is_null());
                }

                #[test]
                fn heldout_cbox_reads_string() {
                    let ptr = Box::into_raw(Box::new(String::from("heldout")));
                    let boxed = CBox::from_raw(ptr);
                    assert_eq!(&*boxed, "heldout");
                }

                #[test]
                #[should_panic]
                fn heldout_cbox_rejects_null() {
                    let boxed: CBox<u64> = CBox::from_raw(std::ptr::null_mut());
                    let _ = *boxed;
                }

                #[test]
                #[should_panic]
                fn heldout_csemibox_rejects_null() {
                    let boxed: CSemiBox<u64> = CSemiBox::from_raw(std::ptr::null());
                    let _ = *boxed;
                }

                #[test]
                fn heldout_csemibox_reads_stack_value() {
                    let value = 7u32;
                    let boxed = CSemiBox::from_raw(&value as *const u32);
                    assert_eq!(*boxed, 7);
                }

                #[test]
                fn heldout_cbox_as_ptr_matches_input() {
                    let ptr = Box::into_raw(Box::new(3u8));
                    let boxed = CBox::from_raw(ptr);
                    assert_eq!(boxed.as_ptr(), ptr as *const u8);
                }
            ''',
            "reference": '''
                use std::ops::Deref;

                pub struct CBox<T: ?Sized> {
                    ptr: *mut T,
                }

                impl<T: ?Sized> CBox<T> {
                    pub fn from_raw(ptr: *mut T) -> Self {
                        assert!(!ptr.is_null(), "CBox::from_raw rejected null pointer");
                        CBox { ptr }
                    }

                    pub fn as_ptr(&self) -> *const T {
                        self.ptr
                    }
                }

                impl<T: ?Sized> Deref for CBox<T> {
                    type Target = T;
                    fn deref(&self) -> &T {
                        unsafe { &*self.ptr }
                    }
                }

                impl<T: ?Sized> Drop for CBox<T> {
                    fn drop(&mut self) {
                        if !self.ptr.is_null() {
                            unsafe {
                                let _ = Box::from_raw(self.ptr);
                            }
                        }
                    }
                }

                pub struct CSemiBox<T: ?Sized> {
                    ptr: *const T,
                }

                impl<T: ?Sized> CSemiBox<T> {
                    pub fn from_raw(ptr: *const T) -> Self {
                        assert!(!ptr.is_null(), "CSemiBox::from_raw rejected null pointer");
                        CSemiBox { ptr }
                    }
                }

                impl<T: ?Sized> Deref for CSemiBox<T> {
                    type Target = T;
                    fn deref(&self) -> &T {
                        unsafe { &*self.ptr }
                    }
                }
            ''',
            "mutants": [
                mutation(
                    "cbox_accepts_null",
                    "assert!(!ptr.is_null(), \"CBox::from_raw rejected null pointer\");\n        CBox { ptr }",
                    "CBox { ptr }",
                    "removes null rejection for CBox",
                ),
                mutation(
                    "csemibox_accepts_null",
                    "assert!(!ptr.is_null(), \"CSemiBox::from_raw rejected null pointer\");\n        CSemiBox { ptr }",
                    "CSemiBox { ptr }",
                    "removes null rejection for CSemiBox",
                ),
                mutation(
                    "cbox_drops_without_free",
                    "let _ = Box::from_raw(self.ptr);",
                    "",
                    "leaks owned CBox allocation",
                ),
                mutation(
                    "as_ptr_returns_null",
                    "pub fn as_ptr(&self) -> *const T {\n        self.ptr\n    }",
                    "pub fn as_ptr(&self) -> *const T {\n        std::ptr::null()\n    }",
                    "breaks as_ptr contract",
                ),
            ],
        },
        # ---- invalid alignment (chacha) ----
        {
            "id": "CVE-2021-45709",
            "batch": "batch_2",
            "contract": (
                "ChaCha20 in-place XOR works for empty, aligned, and unaligned byte "
                "slices without constructing misaligned u32 references."
            ),
            "evidence": "audit invalid_alignment; from_raw_parts_mut as u32 without align check",
            "dimensions": "empty; aligned transform; unaligned transform; key length; decrypt alias",
            "symbols": ["Chacha20::new", "encrypt_slice", "decrypt_slice"],
            "tests": '''
                #[repr(align(4))]
                struct Align4<const N: usize>([u8; N]);

                #[test]
                fn heldout_empty_slice_noop() {
                    let cipher = Chacha20::new(&[0u8; 32]);
                    let mut data = [];
                    cipher.encrypt_slice(0, &[0u8; 12], &mut data);
                }

                #[test]
                fn heldout_aligned_xor_pattern() {
                    let cipher = Chacha20::new(&[1u8; 32]);
                    let mut backing = Align4([0u8; 8]);
                    cipher.encrypt_slice(0, &[0u8; 12], &mut backing.0);
                    assert_eq!(&backing.0[..4], &0xdeadbeefu32.to_le_bytes());
                    assert_eq!(&backing.0[4..8], &0xdeadbeefu32.to_le_bytes());
                }

                #[test]
                fn heldout_unaligned_slice_is_safe() {
                    let cipher = Chacha20::new(&[0u8; 32]);
                    let mut backing = Align4([0u8; 65]);
                    let slice = &mut backing.0[1..33];
                    assert_ne!((slice.as_ptr() as usize) % 4, 0);
                    cipher.encrypt_slice(0, &[0u8; 12], slice);
                    assert_eq!(&slice[..4], &0xdeadbeefu32.to_le_bytes());
                }

                #[test]
                fn heldout_remainder_bytes_xored() {
                    let cipher = Chacha20::new(&[0u8; 32]);
                    let mut data = [0u8; 5];
                    cipher.encrypt_slice(0, &[0u8; 12], &mut data);
                    assert_eq!(&data[..4], &0xdeadbeefu32.to_le_bytes());
                    assert_eq!(data[4], 0xff);
                }

                #[test]
                fn heldout_decrypt_matches_encrypt_transform() {
                    let cipher = Chacha20::new(&[9u8; 32]);
                    let mut a = [0u8; 4];
                    let mut b = [0u8; 4];
                    cipher.encrypt_slice(0, &[0u8; 12], &mut a);
                    cipher.decrypt_slice(0, &[0u8; 12], &mut b);
                    assert_eq!(a, b);
                }

                #[test]
                #[should_panic]
                fn heldout_rejects_short_key() {
                    let _ = Chacha20::new(&[0u8; 16]);
                }
            ''',
            "reference": '''
                pub struct Chacha20 {
                    pub key: [u8; 32],
                }

                impl Chacha20 {
                    pub const KEY_LEN: usize = 32;
                    pub const NONCE_LEN: usize = 12;

                    pub fn new(key: &[u8]) -> Self {
                        assert_eq!(key.len(), Self::KEY_LEN);
                        let mut k = [0u8; 32];
                        k.copy_from_slice(key);
                        Self { key: k }
                    }

                    pub fn encrypt_slice(
                        &self,
                        init_block_counter: u32,
                        nonce: &[u8],
                        plaintext_in_ciphertext_out: &mut [u8],
                    ) {
                        self.in_place(init_block_counter, nonce, plaintext_in_ciphertext_out)
                    }

                    pub fn decrypt_slice(
                        &self,
                        init_block_counter: u32,
                        nonce: &[u8],
                        ciphertext_in_plaintext_and: &mut [u8],
                    ) {
                        self.in_place(init_block_counter, nonce, ciphertext_in_plaintext_and)
                    }

                    fn in_place(&self, _counter: u32, _nonce: &[u8], data: &mut [u8]) {
                        let mut chunks = data.chunks_exact_mut(4);
                        for chunk in &mut chunks {
                            let mut word = u32::from_le_bytes(chunk.try_into().unwrap());
                            word ^= 0xdeadbeef;
                            chunk.copy_from_slice(&word.to_le_bytes());
                        }
                        for byte in chunks.into_remainder() {
                            *byte ^= 0xff;
                        }
                    }
                }
            ''',
            "mutants": [
                mutation(
                    "restore_unaligned_u32_view",
                    "let mut chunks = data.chunks_exact_mut(4);\n        for chunk in &mut chunks {\n            let mut word = u32::from_le_bytes(chunk.try_into().unwrap());\n            word ^= 0xdeadbeef;\n            chunk.copy_from_slice(&word.to_le_bytes());\n        }\n        for byte in chunks.into_remainder() {\n            *byte ^= 0xff;\n        }",
                    "unsafe {\n            let ptr = data.as_mut_ptr() as *mut u32;\n            let u32_len = data.len() / 4;\n            let u32_slice = std::slice::from_raw_parts_mut(ptr, u32_len);\n            for i in 0..u32_len {\n                u32_slice[i] ^= 0xdeadbeef;\n            }\n        }\n        let processed = (data.len() / 4) * 4;\n        for i in processed..data.len() {\n            data[i] ^= 0xff;\n        }",
                    "restores misaligned u32 reinterpretation",
                ),
                mutation(
                    "skip_remainder_xor",
                    "for byte in chunks.into_remainder() {\n            *byte ^= 0xff;\n        }",
                    "",
                    "drops remainder byte transform",
                ),
                mutation(
                    "wrong_xor_constant",
                    "word ^= 0xdeadbeef;",
                    "word ^= 0x0;",
                    "neutralizes block xor",
                ),
                mutation(
                    "encrypt_skips_all_chunks",
                    "for chunk in &mut chunks {\n            let mut word = u32::from_le_bytes(chunk.try_into().unwrap());\n            word ^= 0xdeadbeef;\n            chunk.copy_from_slice(&word.to_le_bytes());\n        }",
                    "for _chunk in &mut chunks {}",
                    "skips block xor updates",
                ),
            ],
        },
        # ---- invalid value / panic drop ----
        {
            "id": "CVE-2020-35888",
            "batch": "batch_2",
            "contract": (
                "Array initializes only written slots; panic during new_from_template "
                "drops only initialized elements; successful construction preserves values."
            ),
            "evidence": "audit invalid_value; Drop uses full len after partial clone init",
            "dimensions": "success values; panic safety; zero len; indexing bounds; Default new",
            "symbols": ["Array::new", "Array::zero", "Array::new_from_template", "len", "Index"],
            "tests": '''
                use std::cell::Cell;
                use std::panic;

                #[derive(Debug)]
                struct PanicCloner {
                    _data: String,
                    clone_count: Cell<usize>,
                    max_clones: usize,
                }

                impl PanicCloner {
                    fn new(max: usize) -> Self {
                        PanicCloner {
                            _data: "heap".to_string(),
                            clone_count: Cell::new(0),
                            max_clones: max,
                        }
                    }
                }

                impl Clone for PanicCloner {
                    fn clone(&self) -> Self {
                        let count = self.clone_count.get();
                        if count >= self.max_clones {
                            panic!("clone panic at {}", count);
                        }
                        self.clone_count.set(count + 1);
                        PanicCloner {
                            _data: "heap".to_string(),
                            clone_count: Cell::new(0),
                            max_clones: self.max_clones,
                        }
                    }
                }

                #[test]
                fn heldout_template_success_values() {
                    let arr: Array<String> = Array::new_from_template(3, &String::from("hi"));
                    assert_eq!(arr.len(), 3);
                    assert_eq!(arr[0], "hi");
                    assert_eq!(arr[2], "hi");
                }

                #[test]
                fn heldout_clone_panic_is_drop_safe() {
                    let template = PanicCloner::new(2);
                    let result = panic::catch_unwind(panic::AssertUnwindSafe(|| {
                        let _arr: Array<PanicCloner> = Array::new_from_template(5, &template);
                    }));
                    assert!(result.is_err());
                }

                #[test]
                fn heldout_default_new_len() {
                    let arr: Array<u32> = Array::new(4);
                    assert_eq!(arr.len(), 4);
                    assert_eq!(arr[0], 0);
                }

                #[test]
                fn heldout_zero_size_ok() {
                    let arr: Array<u8> = Array::new_from_template(0, &7u8);
                    assert_eq!(arr.len(), 0);
                }

                #[test]
                #[should_panic]
                fn heldout_index_out_of_bounds() {
                    let arr: Array<u8> = Array::new(2);
                    let _ = arr[2];
                }

                #[test]
                fn heldout_iter_collects_template() {
                    let arr: Array<i32> = Array::new_from_template(2, &9);
                    let values: Vec<_> = arr.iter().copied().collect();
                    assert_eq!(values, vec![9, 9]);
                }
            ''',
            "reference": '''
                use std::alloc::{alloc_zeroed, dealloc, Layout};

                pub struct Array<T> {
                    ptr: *mut T,
                    len: usize,
                    capacity: usize,
                }

                unsafe impl<T: Send> Send for Array<T> {}
                unsafe impl<T: Sync> Sync for Array<T> {}

                impl<T> Array<T> {
                    pub fn new(size: usize) -> Self where T: Default {
                        let mut arr = Self::allocate(size);
                        for i in 0..size {
                            unsafe { arr.ptr.add(i).write(T::default()); }
                            arr.len = i + 1;
                        }
                        arr
                    }

                    pub fn zero(size: usize) -> Self {
                        let layout = Layout::array::<T>(size.max(1)).unwrap();
                        let ptr = if size == 0 {
                            std::ptr::null_mut()
                        } else {
                            unsafe { alloc_zeroed(layout) as *mut T }
                        };
                        Array { ptr, len: size, capacity: size }
                    }

                    pub fn new_from_template(size: usize, template: &T) -> Self where T: Clone {
                        let mut arr = Self::allocate(size);
                        for i in 0..size {
                            unsafe { arr.ptr.add(i).write(template.clone()); }
                            arr.len = i + 1;
                        }
                        arr
                    }

                    fn allocate(size: usize) -> Self {
                        if size == 0 {
                            return Array { ptr: std::ptr::null_mut(), len: 0, capacity: 0 };
                        }
                        let layout = Layout::array::<T>(size).unwrap();
                        let ptr = unsafe { alloc_zeroed(layout) as *mut T };
                        if ptr.is_null() {
                            panic!("Allocation failed");
                        }
                        Array { ptr, len: 0, capacity: size }
                    }

                    pub fn len(&self) -> usize { self.len }

                    pub fn iter(&self) -> std::slice::Iter<'_, T> {
                        unsafe { std::slice::from_raw_parts(self.ptr, self.len).iter() }
                    }
                }

                impl<T> std::ops::Index<usize> for Array<T> {
                    type Output = T;
                    fn index(&self, idx: usize) -> &T {
                        assert!(idx < self.len);
                        unsafe { &*self.ptr.add(idx) }
                    }
                }

                impl<T> Drop for Array<T> {
                    fn drop(&mut self) {
                        if !self.ptr.is_null() {
                            for i in 0..self.len {
                                unsafe { std::ptr::drop_in_place(self.ptr.add(i)); }
                            }
                            let layout = Layout::array::<T>(self.capacity).unwrap();
                            unsafe { dealloc(self.ptr as *mut u8, layout); }
                        }
                    }
                }
            ''',
            "mutants": [
                mutation(
                    "set_len_before_init",
                    "let mut arr = Self::allocate(size);\n        for i in 0..size {\n            unsafe { arr.ptr.add(i).write(template.clone()); }\n            arr.len = i + 1;\n        }\n        arr",
                    "let mut arr = Self::allocate(size);\n        arr.len = size;\n        for i in 0..size {\n            unsafe { arr.ptr.add(i).write(template.clone()); }\n        }\n        arr",
                    "restores dropping uninit slots after panic",
                ),
                mutation(
                    "index_skips_bounds",
                    "assert!(idx < self.len);",
                    "",
                    "removes index bounds check",
                ),
                mutation(
                    "wrong_success_len",
                    "pub fn new_from_template(size: usize, template: &T) -> Self where T: Clone {\n        let mut arr = Self::allocate(size);\n        for i in 0..size {\n            unsafe { arr.ptr.add(i).write(template.clone()); }\n            arr.len = i + 1;\n        }\n        arr\n    }",
                    "pub fn new_from_template(size: usize, template: &T) -> Self where T: Clone {\n        let mut arr = Self::allocate(size);\n        for i in 0..size {\n            unsafe { arr.ptr.add(i).write(template.clone()); }\n            arr.len = i;\n        }\n        arr\n    }",
                    "undercounts initialized length",
                ),
                mutation(
                    "drop_uses_capacity",
                    "for i in 0..self.len {",
                    "for i in 0..self.capacity {",
                    "drops capacity slots instead of initialized len",
                ),
            ],
        },
        # ---- base64 OOB ----
        {
            "id": "CVE-2017-1000430",
            "batch": "batch_2",
            "contract": (
                "encoded_size uses checked arithmetic; encode allocates enough bytes "
                "for the logical output; small inputs keep ABCD mock encoding length."
            ),
            "evidence": "audit OOB; wrapping mul undersizes buffer then raw writes",
            "dimensions": "size table; small encode; overflow rejects; zero; exact chunk",
            "symbols": ["encode", "encoded_size_usize"],
            "tests": '''
                use std::panic;

                #[test]
                fn heldout_small_encode_length() {
                    let encoded = encode(b"hello world");
                    assert_eq!(encoded.len(), 16);
                    assert_eq!(encoded_size_usize(11), 16);
                }

                #[test]
                fn heldout_exact_chunk_size() {
                    assert_eq!(encoded_size_usize(3), 4);
                    assert_eq!(encode(b"abc").len(), 4);
                }

                #[test]
                fn heldout_zero_input() {
                    assert_eq!(encoded_size_usize(0), 0);
                    assert_eq!(encode(b""), "");
                }

                #[test]
                fn heldout_overflow_size_is_rejected() {
                    assert_eq!(encoded_size_usize(49155), usize::MAX);
                }

                #[test]
                fn heldout_overflow_input_does_not_oob() {
                    let result = panic::catch_unwind(|| {
                        let input = vec![0u8; 49155];
                        encode(&input)
                    });
                    assert!(result.is_err());
                }

                #[test]
                fn heldout_size_formula_mid() {
                    assert_eq!(encoded_size_usize(1), 4);
                    assert_eq!(encoded_size_usize(6), 8);
                }

                #[test]
                fn heldout_encode_prefix_bytes() {
                    let encoded = encode(b"xy");
                    assert!(encoded.as_bytes().starts_with(b"ABCD"));
                    assert_eq!(encoded.len(), 4);
                }
            ''',
            "reference": '''
                use std::ptr;

                type Size = u16;

                fn encoded_size(bytes_len: Size) -> Option<Size> {
                    let rem = bytes_len % 3;
                    let complete_input_chunks = bytes_len / 3;
                    let complete_output_chars = complete_input_chunks.checked_mul(4)?;
                    if rem == 0 {
                        Some(complete_output_chars)
                    } else {
                        complete_output_chars.checked_add(4)
                    }
                }

                pub fn encode(input: &[u8]) -> String {
                    let bytes_len = Size::try_from(input.len()).expect("input too large");
                    let size = encoded_size(bytes_len).expect("encoded size overflow") as usize;
                    let mut buf = Vec::with_capacity(size);
                    let written = unsafe { encode_into_ptr(input, buf.as_mut_ptr(), size) };
                    unsafe {
                        buf.set_len(written);
                        String::from_utf8_unchecked(buf)
                    }
                }

                unsafe fn encode_into_ptr(input: &[u8], out_ptr: *mut u8, cap: usize) -> usize {
                    let mut input_idx = 0usize;
                    let mut output_idx = 0usize;
                    while input_idx + 3 <= input.len() {
                        assert!(output_idx + 4 <= cap);
                        ptr::write(out_ptr.add(output_idx), b'A');
                        ptr::write(out_ptr.add(output_idx + 1), b'B');
                        ptr::write(out_ptr.add(output_idx + 2), b'C');
                        ptr::write(out_ptr.add(output_idx + 3), b'D');
                        input_idx += 3;
                        output_idx += 4;
                    }
                    if input_idx < input.len() {
                        assert!(output_idx + 4 <= cap);
                        ptr::write(out_ptr.add(output_idx), b'A');
                        ptr::write(out_ptr.add(output_idx + 1), b'B');
                        ptr::write(out_ptr.add(output_idx + 2), b'C');
                        ptr::write(out_ptr.add(output_idx + 3), b'D');
                        output_idx += 4;
                    }
                    output_idx
                }

                pub fn encoded_size_usize(bytes_len: usize) -> usize {
                    let Ok(len) = Size::try_from(bytes_len) else {
                        return usize::MAX;
                    };
                    encoded_size(len).map(|v| v as usize).unwrap_or(usize::MAX)
                }
            ''',
            "mutants": [
                mutation(
                    "restore_wrapping_size",
                    "pub fn encoded_size_usize(bytes_len: usize) -> usize {\n    let Ok(len) = Size::try_from(bytes_len) else {\n        return usize::MAX;\n    };\n    encoded_size(len).map(|v| v as usize).unwrap_or(usize::MAX)\n}",
                    "pub fn encoded_size_usize(bytes_len: usize) -> usize {\n    let Ok(len) = Size::try_from(bytes_len) else {\n        return usize::MAX;\n    };\n    let rem = len % 3;\n    let complete_output_chars = (len / 3).wrapping_mul(4);\n    if rem == 0 { complete_output_chars as usize } else { complete_output_chars.wrapping_add(4) as usize }\n}",
                    "restores wrapping encoded_size_usize",
                ),
                mutation(
                    "wrong_exact_chunk_size",
                    "if rem == 0 {\n        Some(complete_output_chars)\n    } else {\n        complete_output_chars.checked_add(4)\n    }",
                    "if rem == 0 {\n        Some(complete_output_chars.wrapping_add(1))\n    } else {\n        complete_output_chars.checked_add(4)\n    }",
                    "corrupts exact-chunk encoded size",
                ),
                mutation(
                    "encode_always_empty",
                    "String::from_utf8_unchecked(buf)",
                    "String::new()",
                    "drops encoded payload",
                ),
                mutation(
                    "encode_capacity_always_zero",
                    "let mut buf = Vec::with_capacity(size);",
                    "let mut buf = Vec::with_capacity(0);",
                    "undersizes encode buffer",
                ),
            ],
        },
    ]


def main() -> int:
    for spec in cases():
        write_case(spec)
        print(f"wrote cases/{spec['id']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
