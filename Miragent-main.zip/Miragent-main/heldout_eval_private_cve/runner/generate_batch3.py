#!/usr/bin/env python3
"""Generate batch_3 held-out oracles (cases 1-3). Remaining batch_3 cases in generate_batch3_rest.py."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from case_writer import mutation, write_case


def cases() -> list[dict]:
    return [
        {
            "id": "CVE-2018-21000",
            "batch": "batch_3",
            "contract": "guarded_transmute_vec_permissive uses (len, capacity) order for from_raw_parts.",
            "evidence": "audit OOB; swapped len/cap",
            "dimensions": "exact; spare cap; empty; longer; capacity>=len",
            "symbols": ["guarded_transmute_vec_permissive"],
            "tests": '''
                #[test]
                fn heldout_exact_fit_preserves_bytes() {
                    let out: Vec<u8> = unsafe { guarded_transmute_vec_permissive(vec![1, 2, 3, 4]) };
                    assert_eq!(out, vec![1, 2, 3, 4]);
                }
                #[test]
                fn heldout_spare_capacity_len_is_logical() {
                    let mut v: Vec<u8> = Vec::with_capacity(16);
                    v.extend_from_slice(&[9, 8, 7, 6]);
                    let out: Vec<u8> = unsafe { guarded_transmute_vec_permissive(v) };
                    assert_eq!(out.len(), 4);
                    assert_eq!(out[3], 6);
                }
                #[test]
                fn heldout_empty_input() {
                    let out: Vec<u8> = unsafe { guarded_transmute_vec_permissive(Vec::new()) };
                    assert!(out.is_empty());
                }
                #[test]
                fn heldout_longer_payload_values() {
                    let out: Vec<u8> = unsafe { guarded_transmute_vec_permissive(vec![10, 20, 30, 40, 50]) };
                    assert_eq!(out, vec![10, 20, 30, 40, 50]);
                }
                #[test]
                fn heldout_no_oob_on_spare_capacity() {
                    let mut v: Vec<u8> = Vec::with_capacity(32);
                    v.extend_from_slice(&[1, 2]);
                    let out: Vec<u8> = unsafe { guarded_transmute_vec_permissive(v) };
                    assert_eq!(out, vec![1, 2]);
                }
                #[test]
                fn heldout_capacity_at_least_len() {
                    let out: Vec<u8> = unsafe { guarded_transmute_vec_permissive(vec![4, 5, 6]) };
                    assert!(out.capacity() >= out.len());
                }
            ''',
            "reference": '''
                use std::mem::{forget, size_of};
                pub unsafe fn guarded_transmute_vec_permissive<T>(mut bytes: Vec<u8>) -> Vec<T> {
                    let ptr = bytes.as_mut_ptr();
                    let capacity = bytes.capacity() / size_of::<T>();
                    let len = bytes.len() / size_of::<T>();
                    forget(bytes);
                    Vec::from_raw_parts(ptr as *mut T, len, capacity)
                }
            ''',
            "mutants": [
                mutation("restore_swapped_args", "Vec::from_raw_parts(ptr as *mut T, len, capacity)", "Vec::from_raw_parts(ptr as *mut T, capacity, len)", "swaps len/cap"),
                mutation("force_zero_len", "Vec::from_raw_parts(ptr as *mut T, len, capacity)", "Vec::from_raw_parts(ptr as *mut T, 0, capacity)", "zeros len"),
                mutation("forget_skipped", "forget(bytes);", "", "double-frees by not forgetting bytes vec"),
                mutation("capacity_always_zero", "let capacity = bytes.capacity() / size_of::<T>();", "let capacity = 0;", "zeros capacity"),
            ],
        },
        {
            "id": "CVE-2019-12083",
            "batch": "batch_3",
            "contract": "downcast_ref uses Any identity, ignoring overridable get_type_id lies.",
            "evidence": "audit type confusion via FakeError::get_type_id",
            "dimensions": "honest; liar rejected; type_confuse panic; wrong target none",
            "symbols": ["FakeError", "downcast_ref", "type_confuse"],
            "tests": '''
                use std::any::TypeId;
                struct Honest(u32);
                impl FakeError for Honest {
                    fn get_type_id(&self) -> TypeId { TypeId::of::<Self>() }
                }
                struct Liar(u64);
                impl FakeError for Liar {
                    fn get_type_id(&self) -> TypeId { TypeId::of::<Honest>() }
                }
                #[test]
                fn heldout_honest_downcast_works() {
                    let value = Honest(7);
                    let obj: &dyn FakeError = &value;
                    assert_eq!(obj.downcast_ref::<Honest>().unwrap().0, 7);
                }
                #[test]
                fn heldout_liar_downcast_is_rejected() {
                    let value = Liar(9);
                    let obj: &dyn FakeError = &value;
                    assert!(obj.downcast_ref::<Honest>().is_none());
                }
                #[test]
                #[should_panic]
                fn heldout_type_confuse_rejects_liar() {
                    let value = Liar(1);
                    let _confused: &Honest = type_confuse(&value);
                }
                #[test]
                fn heldout_wrong_target_is_none() {
                    let value = Honest(1);
                    let obj: &dyn FakeError = &value;
                    assert!(obj.downcast_ref::<Liar>().is_none());
                }
                #[test]
                fn heldout_type_confuse_honest_same_type() {
                    let value = Honest(3);
                    assert_eq!(type_confuse::<Honest, Honest>(&value).0, 3);
                }
                #[test]
                fn heldout_liar_self_downcast_ok() {
                    let value = Liar(4);
                    let obj: &dyn FakeError = &value;
                    assert_eq!(obj.downcast_ref::<Liar>().unwrap().0, 4);
                }
            ''',
            "reference": '''
                use std::any::{Any, TypeId};
                pub trait FakeError: Any {
                    fn get_type_id(&self) -> TypeId;
                }
                impl dyn FakeError {
                    pub fn downcast_ref<T: FakeError + Sized>(&self) -> Option<&T> {
                        (self as &dyn Any).downcast_ref::<T>()
                    }
                }
                pub fn type_confuse<T: FakeError, U: FakeError>(val: &T) -> &U {
                    let trait_obj: &dyn FakeError = val;
                    trait_obj.downcast_ref::<U>().expect("Downcast failed")
                }
            ''',
            "mutants": [
                mutation(
                    "trust_get_type_id",
                    "(self as &dyn Any).downcast_ref::<T>()",
                    "if self.get_type_id() == TypeId::of::<T>() { unsafe { let raw: *const dyn FakeError = self; Some(&*(raw as *const T)) } } else { None }",
                    "restores overridable TypeId trust",
                ),
                mutation("always_none_via_helper", "impl dyn FakeError {\n    pub fn downcast_ref<T: FakeError + Sized>(&self) -> Option<&T> {\n        (self as &dyn Any).downcast_ref::<T>()\n    }\n}", "impl dyn FakeError {\n    pub fn downcast_ref<T: FakeError + Sized>(&self) -> Option<&T> {\n        let _ = self.get_type_id();\n        None\n    }\n}", "never downcasts"),
                mutation(
                    "type_confuse_force_cast",
                    "let trait_obj: &dyn FakeError = val;\n    trait_obj.downcast_ref::<U>().expect(\"Downcast failed\")",
                    "unsafe { &*(val as *const T as *const U) }",
                    "force casts without Any check",
                ),
                mutation(
                    "type_confuse_trusts_get_type_id",
                    "let trait_obj: &dyn FakeError = val;\n    trait_obj.downcast_ref::<U>().expect(\"Downcast failed\")",
                    "let trait_obj: &dyn FakeError = val;\n    if trait_obj.get_type_id() == TypeId::of::<U>() { unsafe { &*(val as *const T as *const U) } } else { panic!(\"Downcast failed\") }",
                    "uses overridable TypeId in type_confuse",
                ),
            ],
        },
        {
            "id": "CVE-2020-25016",
            "batch": "batch_3",
            "contract": "AsBytes for packed RGB/RGBA works; PaddedStruct does not expose padding bytes.",
            "evidence": "audit uninit padding via AsBytes on PaddedStruct",
            "dimensions": "RGB; RGBA; mut write; slice; padded safe view",
            "symbols": ["AsBytes", "RGB::new", "RGBA::new"],
            "tests": '''
                #[test]
                fn heldout_rgb_u8_bytes() {
                    assert_eq!(RGB::new(1u8, 2, 3).as_bytes(), &[1, 2, 3]);
                }
                #[test]
                fn heldout_rgba_u8_bytes() {
                    assert_eq!(RGBA::new(1u8, 2, 3, 4).as_bytes(), &[1, 2, 3, 4]);
                }
                #[test]
                fn heldout_rgb_roundtrip_fields() {
                    assert_eq!(RGB::new(9u8, 8, 7).as_bytes()[0], 9);
                }
                #[test]
                fn heldout_rgba_mut_write() {
                    let mut c = RGBA::new(0u8, 0, 0, 0);
                    c.as_bytes_mut()[3] = 5;
                    assert_eq!(c.a, 5);
                }
                #[test]
                fn heldout_rgb_slice_bytes_len() {
                    let arr = [RGB::new(1u8, 0, 0), RGB::new(2, 0, 0)];
                    assert_eq!(arr.as_bytes().len(), 6);
                }
                #[test]
                fn heldout_padded_does_not_expose_uninit_padding() {
                    let p = PaddedStruct { a: 1, b: 2 };
                    let bytes = p.as_bytes();
                    assert_eq!(bytes[0], 1);
                    let mut mix = 0u8;
                    for &byte in bytes {
                        mix ^= byte.wrapping_mul(3);
                    }
                    assert_eq!(mix, mix);
                }
            ''',
            "reference": '''
                use std::slice;
                use std::mem;
                pub unsafe trait AsBytes {
                    fn as_bytes(&self) -> &[u8] {
                        unsafe { slice::from_raw_parts(self as *const Self as *const u8, mem::size_of_val(self)) }
                    }
                    fn as_bytes_mut(&mut self) -> &mut [u8] {
                        unsafe { slice::from_raw_parts_mut(self as *mut Self as *mut u8, mem::size_of_val(self)) }
                    }
                }
                #[derive(Debug, Clone, Copy, PartialEq)]
                #[repr(C)]
                pub struct RGB<T> { pub r: T, pub g: T, pub b: T }
                impl<T> RGB<T> { pub fn new(r: T, g: T, b: T) -> Self { RGB { r, g, b } } }
                #[derive(Debug, Clone, Copy, PartialEq)]
                #[repr(C)]
                pub struct RGBA<T> { pub r: T, pub g: T, pub b: T, pub a: T }
                impl<T> RGBA<T> { pub fn new(r: T, g: T, b: T, a: T) -> Self { RGBA { r, g, b, a } } }
                unsafe impl AsBytes for RGB<u8> {}
                unsafe impl AsBytes for RGBA<u8> {}
                unsafe impl AsBytes for [RGB<u8>] {}
                unsafe impl AsBytes for [RGBA<u8>] {}
                #[repr(C)]
                pub struct PaddedStruct { pub a: u8, pub b: u32 }
                unsafe impl AsBytes for PaddedStruct {
                    fn as_bytes(&self) -> &[u8] {
                        // Only expose the initialized `a` byte; never the padding.
                        slice::from_ref(&self.a)
                    }
                    fn as_bytes_mut(&mut self) -> &mut [u8] {
                        slice::from_mut(&mut self.a)
                    }
                }
            ''',
            "mutants": [
                mutation(
                    "restore_default_padded_bytes",
                    "fn as_bytes(&self) -> &[u8] {\n        // Only expose the initialized `a` byte; never the padding.\n        slice::from_ref(&self.a)\n    }",
                    "fn as_bytes(&self) -> &[u8] {\n        unsafe { slice::from_raw_parts(self as *const Self as *const u8, mem::size_of_val(self)) }\n    }",
                    "restores full padded byte view",
                ),
                mutation(
                    "rgb_default_empty",
                    "unsafe impl AsBytes for RGB<u8> {}",
                    "unsafe impl AsBytes for RGB<u8> {\n    fn as_bytes(&self) -> &[u8] { &[] }\n}",
                    "empties RGB byte view",
                ),
                mutation("rgba_new_swaps", "RGBA { r, g, b, a }", "RGBA { r: a, g, b, a: r }", "swaps channels"),
                mutation("rgb_new_zeros", "RGB { r, g, b }", "RGB { r: 0, g: 0, b: 0 }", "zeros RGB"),
            ],
        },
    ]


def main() -> int:
    for spec in cases():
        write_case(spec)
        print(f"wrote cases/{spec['id']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
