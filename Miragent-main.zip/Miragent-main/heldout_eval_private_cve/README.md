# CVE held-out semantic evaluator (private)

Private post-hoc semantic tests for `cve_safe_func_synth_without_data_race_v2/`.

## Isolation

- Repair agents must not mount or read this directory.
- Evaluation runs only after an immutable final patch exists.
- Per-case failure details must not feed reflection, RAG, or repair retries.

## Layout

- `manifests/` — frozen 62-case dataset manifest, oracle census, validation summary
- `cases/CVE-*/` — `case.toml`, `semantic_tests.rs`, `reference_fix.rs`, `oracle.md`
- `runner/` — manifest/census builders, single/batch evaluators, suite audit, generators

## Quick commands

```bash
python3 heldout_eval_private_cve/runner/build_manifest.py --check
python3 heldout_eval_private_cve/runner/build_census.py --check
python3 heldout_eval_private_cve/runner/evaluate.py --case CVE-2020-25794 --validate-oracle
python3 heldout_eval_private_cve/runner/batch_evaluate.py --validate-oracle --batch pilot_1
python3 heldout_eval_private_cve/runner/audit_suite.py
```

See `CVE_HELDOUT_SEMANTIC_TESTS_EXPANSION_PLAN.md` for the full expansion contract.
