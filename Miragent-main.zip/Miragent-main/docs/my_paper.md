# Miragent — Paper Draft (ICSE 2027)

> **Title (working):** *Miragent: Repairing Undefined Behavior in Rust via a RAG-based Hallucination-Augmented Workflow*

---

## 1. Abstract — 整体骨架（已定稿）

| # | Goal (中文) | Key signals |
|---|---|---|
| S1 | Rust 是什么 + `unsafe` 引发 UB + UB 的影响 | Rust safety promise → unsafe → UB → CVE |
| S2 | 自动化 UB 修复问题定义 | semantics-preserving patches at code snippet / crate level |
| S3 | 三类相关研究 | C1 rule-driven (RUDRA, Thetis-Lathe) ; C2 skeleton-LLM (GiantRepair, AlphaRepair / Recoder) ; C3 agentic (RepairAgent, RustBrain) |
| S4 | 三类研究的局限（一一对应 P1/P2/P3） | P1 缺乏可扩展性 ; P2 限制 LLM + 缺乏严格 safety 验证 ; P3 幻觉破坏语义 |
| S5 | 提出 Miragent | hallucination-augmented multi-agent framework |
| S6 | Miragent 三个特点 | (a) Miri+AST 融合 (b) Semantic RAG (c) hallucination-as-prior |
| S6′ | 工作流 + 输出 | Reflection-Plan-Fix + multi-dim evaluators → UB-free, semantics-preserving 代码 |
| S7 | 实验效果 | **TBD** ：Miragent vs Thetis-Lathe / GiantRepair / RustBrain 在 81 CVE + 65 synth 上的提升 |

---

## 2. Abstract — 完整初稿（已含 S7 占位）

Automated repair of Undefined Behavior (UB) in Rust aims to eliminate UB in Rust programs while preserving the intended program semantics.

In this setting, a repair system takes Rust source code, available build metadata, and optional tests as input, and outputs a patched program together with repair diagnostics.

Existing methods for this problem can be broadly classified into two categories: *rule-based* and *LLM-based* repair. Rule-based repair heavily depends on the coverage and precision of hand-crafted rule sets. LLM-based repair is vulnerable to hallucinated patches that appear plausible but violate intended program semantics.

In this paper, we propose Miragent, a hallucination-augmented multi-agent framework for automated UB repair.

One distinctive feature of Miragent is *fighting hallucination with hallucination*: it deliberately elicits hallucinated fixes and converts them into contrastive priors for repair exploration instead of simply suppressing LLM hallucinations.

Experimental results on the Miri and real-world CVE datasets show that Miragent improves the fix rate over the average baselines by 6.7\%--14.4\% and the semantic consistency rate by 4.5\%--10.5\%, with acceptable time overhead.


---

## 3. Introduction — 当前 5 段定稿版本（含 ¶4/¶5 已完成）

> 与 §2 摘要严格对应：S1↔¶1 ; S3↔¶2 ; S4↔¶3 ; S5+S6↔¶4 ; S7↔¶5。

### 3.1 框架对应

| Para | 论证目标 | 锚点 | Words |
|---|---|---|---|
| ¶1 | Rust 安全 → `unsafe` 引发 UB → CVE 量化 → 问题定义 | S1 + S2 | ~115 |
| ¶2 | 两类既有方法（rule-based / LLM-based，并细分 LLM-based） | S3 | ~170 |
| ¶3 | 两类局限（rule-set dependence / hallucinated semantic drift） | S4 | ~170 |
| ¶4 | **Miragent 两个特点（呼应 Abstract）** | S5–S6 | ~190 |
| ¶5 | **Evaluation overview + Contributions（4 条）** | S7 + new | ~150 |
| **Total** | | | **~795** |

### 3.2 全文（可直接进文章）

#### ¶1 — 背景 + 问题定义

> Anchor: S1 + S2。Rust/UB 基础引用 Rust Reference、Rustonomicon、RustBelt、Stacked Borrows、Miri；生态漏洞数据引用 RustSec 与 Rust CVE 实证研究。

Rust guarantees memory safety for safe code through its ownership and borrowing discipline \cite{rust-book,rust-reference,rust-nomicon,rustbelt,stacked-borrows,oxide}. However, real-world crates often rely on unsafe code for low-level control and foreign-function interface (FFI) calls \cite{unsafe-rust-oopsla,is-rust-used-safely}. At these unsafe boundaries, part of the safety responsibility shifts from the compiler to the developer, and even a single defect can lead to Undefined Behavior (UB) \cite{rust-reference,unsafe-code-guidelines}. Such UB is not merely theoretical: the cumulative number of RustSec advisories with CVE aliases has grown from 31 by 2018 to 487 by 2025, with many involving unsafe-code soundness bugs \cite{rustsec,cve-program,rust-cve-study}. As the Rust ecosystem grows, the rising volume of reports makes manual diagnosis and repair increasingly difficult, motivating automated UB repair for Rust: a repair system should eliminate UB while preserving the intended program semantics.

#### ¶2 — 两类既有方法

> Anchor: S3。

Existing automated UB repair methods can be broadly classified into two categories. \textit{(1) Rule-based repair} applies predefined rules, static analysis, and pattern matching to detect and patch unsafe-code or UB patterns. Representative systems include RUDRA, Thetis-Lathe, and SafeDrop~\cite{rudra,thetis-lathe,safedrop}. \textit{(2) LLM-based repair} uses LLMs to generate candidate patches from source code, diagnostics, templates, or compiler feedback~\cite{codex,empirical-llm-apr}. Within LLM-based repair, existing methods mainly follow two lines. The first line follows a template-guided process, where LLM outputs are constrained, abstracted, instantiated, or ranked by predefined repair structures. Representative systems include template-guided or skeleton-guided APR methods such as TBar, Recoder, GiantRepair, and AlphaRepair~\cite{tbar,recoder,giantrepair,alpharepair}, as well as Rust-oriented LLM repair tools such as RustAssistant~\cite{rustassistant}. The second line treats repair as an iterative interaction process, where agents search code context, generate patches, invoke tools, inspect feedback, and revise candidates across multiple rounds~\cite{repairagent,swe-agent,autocoder,react,reflexion,rustbrain,akirarust}. These methods build on a broader APR lineage spanning search-based, constraint-based, template-based, and neural repair \cite{genprog,semfix,angelix,prophet,cure,getafix,sequencer}.

#### ¶3 — 两类局限（P1 / P2）

> Anchor: S4。

However, these methods face distinct limitations. Rule-based repair heavily depends on the coverage and precision of hand-crafted rule sets: its coverage drops sharply when unsafe patterns fall outside predefined rules, and expanding the rule set requires prohibitive domain expertise~\cite{rudra,thetis-lathe,safedrop}. LLM-based repair is vulnerable to hallucinated patches that violate intended semantics: Template-guided LLM repair may generate plausible patches under fixed templates or validation scripts, while agentic repair may explore more trajectories through tool feedback. Yet neither line fully eliminates hallucination risks. Both template-guided and agentic LLM repair can accept patches that silence compiler errors, ordinary tests, or the observed Miri report without preserving the original behavior~\cite{tbar,recoder,giantrepair,alpharepair,repairagent,swe-agent,reflexion,hallucination-survey,apr-overfitting,patch-correctness}. For UB repair, this risk is especially harmful because a patch can remove the immediate runtime symptom by deleting functionality, weakening checks, changing ownership relations, or altering API behavior, thereby producing a superficially safe but semantically inconsistent repair.

#### ¶4 — Miragent 两个特点（**本次完成**，呼应 Abstract）

> 设计目的：(1) 幻觉作为 contrastive prior，扩展 repair exploration 并帮助跳出刚性模板；(2) Reflection–Plan–Fix + multi-dimensional evaluators，约束 agentic repair 的验证与语义保持。

In this paper, we propose **Miragent**, a hallucination-augmented multi-agent framework for automated UB repair in Rust. Miragent has two key features: **(1) Turning LLM hallucinations into contrastive priors to guide repair exploration.** Miragent constructs a repair context from our UB knowledge base triples and deliberately elicits an imagined fix from a Hallucination Agent. Instead of treating this imagined fix as a candidate patch to trust, Miragent uses it as a contrastive signal that broadens the repair space, exposes risky transformations, and helps downstream agents reason beyond retrieved examples and rigid templates \cite{rag,hallucination-survey}. **(2) Integrating a Reflection-Plan-Fix workflow with multi-dimensional evaluators.** The Reflection Agent analyzes previous failures and verification feedback, the Plan Agent turns the analysis into an executable repair strategy, and the Fix Agent generates candidate patches \cite{react,reflexion,repairagent}. Each candidate is evaluated along multiple dimensions, including Miri verification, Clippy warnings, semantic consistency, and minimal change, so that failed candidates produce structured feedback for the next iteration and accepted patches are both UB-free and semantically consistent \cite{miri,clippy,apr-overfitting,patch-correctness}.

#### ¶5 — Contributions（**本次完成**）

> 4 条 contribution，与作者列出的 "提出 Miragent / 建立知识库 / 多维评估 / 在 Miri+CVE 上做实验" 对齐；实验结果与 §2 摘要中的 FR/SCR 指标保持一致。

We evaluate Miragent on the Miri dataset and the real-world Rust CVE dataset, comparing it with four baselines across three LLM backends. The results show that Miragent improves the fix rate over the average baselines by 6.7\% on the Miri dataset and 14.4\% on the CVE dataset. It also improves the semantic consistency rate by 4.5\% and 10.5\%, respectively.

The main contributions of this paper are summarized as follows:

- A hallucination-augmented multi-agent framework for automated UB repair. We propose Miragent, which turns LLM hallucinations into contrastive priors and integrates these priors into a Reflection–Plan–Fix workflow for Rust UB repair.
- A UB-aware repair context construction mechanism. We construct a UB repair knowledge base of triples and use Semantic RAG to provide concrete repair context for downstream agents \cite{rag}.
- A multi-dimensional evaluation loop for semantically consistent UB repair. We evaluate candidate patches along Miri verification, Clippy warnings, semantic consistency, and minimal change, guiding the repair process toward patches that eliminate UB while preserving intended behavior \cite{miri,clippy}.
- An empirical study on Rust UB repair benchmarks. We evaluate Miragent against four baselines on the Miri dataset and the real-world Rust CVEs, demonstrating its effectiveness across benchmark-style and real-world UB repair tasks.

The rest of this paper is organized as follows. Section 2 presents the design of Miragent, including its scope, overview, and four-stage repair pipeline. Section 3 describes the experimental setup and evaluation results. Section 4 discusses potential improvements and limitations. Section 5 concludes the paper.

---

## 4. Miragent Design — Detailed Outline

> 本节先作为 Method/Framework 章节的大纲草案。建议正式标题使用 **Miragent Design**：它既能覆盖系统架构，也能自然容纳 scope、overview、pipeline stages、agents 与 evaluators。正式写作时可将本节展开为论文的核心方法章节。

### 4.1 Scope and Problem Setting

> Goal: 明确 Miragent 解决什么问题、输入输出是什么、哪些假设成立，避免后文 pipeline 看起来像任意 APR 系统。

**Writing focus.**

- **Task definition.** Miragent targets automated repair of Undefined Behavior (UB) in Rust. Given a Rust function, file, or crate that can be executed under a UB detector such as Miri, Miragent aims to produce a patch that removes the detected UB while preserving intended program semantics \cite{miri}.
- **Input.** The system accepts buggy Rust source code, optional tests or harnesses, build metadata when available, and a UB-triggering execution signal. If tests are missing or insufficient, Miragent can generate or augment tests to expose UB under Miri.
- **Output.** The final output is a patched Rust program, together with evaluation evidence such as Miri results, Clippy diagnostics, semantic-preservation judgment, and minimal-change score.
- **Correctness target.** The repair is considered successful only if the candidate passes Miri on the witness execution and satisfies the semantic-preservation and minimal-change criteria defined by the evaluator.
- **Scope boundary.** Miragent focuses on UB caused by unsafe-code soundness bugs that can be exposed through executable tests or harnesses. It does not claim to prove global absence of UB for all possible executions; instead, it provides detector-grounded repair evidence for the observed UB.
- **Non-goals.** This section should explicitly exclude purely stylistic refactoring, performance optimization unrelated to UB, and vulnerabilities whose root cause cannot be exercised or localized by the available harness.

**Possible subsection structure.**

- `4.1.1 Repair Task`
- `4.1.2 Inputs and Outputs`
- `4.1.3 Assumptions and Non-goals`

### 4.2 Overview of Miragent

> Goal: 放 overview 大图，先让读者知道 Miragent 是一个四阶段闭环系统，再用一段话解释数据流。

![Overview of Miragent](Miragent-v1-1-beauty.jpg)

**Figure caption draft.** Overview of Miragent. The framework first obtains dynamic UB evidence and static code structure, then builds a repair context through Semantic RAG and hallucination augmentation, generates candidate repairs through a Reflection–Plan–Fix multi-agent workflow, and finally accepts or rejects candidates through multi-dimensional evaluation.

**Core narrative.**

Miragent is organized as a four-stage closed-loop pipeline:

- **Stage 1: UB Evidence and Code Structure Extraction.** Miragent runs the buggy program under Miri to obtain a UB report and parses the source code with Tree-sitter to obtain an AST. The goal is to combine executable evidence with source-level structure \cite{miri,tree-sitter}.
- **Stage 2: Context Construction and Hallucination Augmentation.** Miragent retrieves similar UB repair examples from a UB knowledge base and elicits an imagined fix from a Hallucination Agent. The imagined fix is treated as a contrastive prior, not as ground truth \cite{rag,hallucination-survey}.
- **Stage 3: Multi-Agent Repair.** Reflection, Plan, and Fix agents decompose repair into failure analysis, strategy construction, and candidate patch generation. The stage emits multiple candidate repaired programs, following the broader line of tool-using and self-reflective language agents \cite{repairagent,react,reflexion}.
- **Stage 4: Multi-Dimensional Evaluation and Decision.** Candidates are evaluated by Miri verification, Clippy warnings, semantic-preservation checking, and minimal-change scoring. Accepted candidates terminate the pipeline; failed candidates feed their diagnostic signals back to Reflection \cite{miri,reflexion,clippy}.

**Transition sentence to later subsections.**

The following subsections describe the four stages in execution order, emphasizing the information each stage consumes, the artifacts it produces, and how those artifacts constrain downstream repair.

### 4.3 Stage 1: UB Evidence and Structural Localization

> Goal: 展开“检测与表征”。这里不要只说 Miri，要解释为什么 Miri + AST 是后续 repair 的基础。

**Main components.**

- **Test Generate Agent.** When the existing harness is absent or insufficient, this agent generates or augments tests to trigger the suspected UB under Miri. The writing should clarify that this agent is used to obtain an executable witness, not to define semantic correctness.
- **Miri Runner.** Miri executes the program and reports UB with diagnostic text, stack frames, source spans, and error categories when available. This report becomes the dynamic evidence used throughout the pipeline \cite{miri}.
- **Error Report Normalization.** Raw Miri output is normalized into a repair-facing report: UB type, error message, source location, relevant stack frames, and snippets around the suspicious code.
- **Tree-sitter Parser.** Tree-sitter parses the source into an AST. The AST is used to align Miri locations with functions, unsafe blocks, expressions, and edit ranges \cite{tree-sitter}.

**Key design point.**

The stage fuses **dynamic evidence** and **static structure**: Miri explains what went wrong during execution, while Tree-sitter identifies where repairs should be applied and how large an edit is likely to be.

**Artifacts passed to Stage 2.**

- `Error Report`
- `AST`
- localized code slice
- optional test harness / Miri witness

### 4.4 Stage 2: Context Construction and Hallucination-Augmented Priors

> Goal: 展开 Miragent 的第一个核心特点：不是只做 RAG，也不是相信幻觉，而是把检索结果和 hallucinated fix 组合成 repair exploration 的 contrastive context。

**Main components.**

- **UB Repair Knowledge Base.** The knowledge base stores triples of *(buggy code, diagnostic report, fix)* across major Rust UB categories. This part should explain what each triple contains and why the diagnostic report is part of the key.
- **Semantic RAG.** The retrieval module first filters by UB category or diagnostic cues, then ranks candidate triples by semantic similarity between the current defect and stored examples. It outputs related fix patterns rather than directly copying patches \cite{rag}.
- **Related Fix Patterns.** Retrieved examples are summarized into reusable repair hints, such as common fixes for uninitialized memory, dangling references, invalid aliasing, or unsafe boundary restructuring.
- **Hallucination Agent.** Given the current defect and related patterns, this agent deliberately produces an imagined fix under a more exploratory setting. The imagined fix may be incorrect, but it can expose alternative repair directions, missing constraints, or plausible-but-risky transformations \cite{hallucination-survey}.
- **Contrastive Prior Construction.** Miragent packages the retrieved patterns and imagined fix into a repair context. Downstream agents use the hallucinated fix as a contrastive signal: useful for exploration, but always subject to verification.

**Key design point.**

This section should explicitly contrast Miragent with prior agentic repair: hallucination is not accepted as a patch, nor simply discarded as noise. It is converted into a prior that broadens search while remaining subordinate to evaluation.

**Artifacts passed to Stage 3.**

- `Related Fix Patterns`
- `Hallucinated Fix Reference`
- localized code context
- normalized Miri report
- AST-derived edit boundaries

### 4.5 Stage 3: Reflection–Plan–Fix Multi-Agent Repair

> Goal: 展开第二个核心特点中的 workflow 部分：为什么要拆成三个 agent，每个 agent 的输入输出是什么，如何形成候选补丁。

**Main components.**

- **Reflection Agent.** Reflection consumes the current repair context and, after the first iteration, previous evaluator feedback. It produces adjusted constraints, such as avoiding a failed ownership strategy, preserving API signatures, or prioritizing safe abstractions over unsafe rewrites.
- **Plan Agent.** Plan converts the reflection output and defect context into an executable fix plan. A fix plan should include the target code region, repair strategy, expected semantic effect, risks, and verification checklist.
- **Fix Agent.** Fix applies the plan to produce one or more candidate patches. Multiple candidates can be generated with different temperatures or strategy variants to cover conservative, balanced, and exploratory repairs.

**Iteration behavior.**

- First iteration may skip previous-failure reflection and use the initial context directly.
- Later iterations receive structured feedback from Stage 4.
- Failed candidates are not merely retried; their failure modes update the constraints used by Reflection and Plan.

**Artifacts passed to Stage 4.**

- `N Candidate Fixed Codes`
- fix plans and explanations
- edit metadata, such as changed functions or AST diff ranges

### 4.6 Stage 4: Multi-Dimensional Evaluation and Decision

> Goal: 展开 evaluator：Miri 是硬约束，其他维度帮助排序和防止语义漂移。这里要和 introduction 里的 “hallucination-induced semantic drift” 对应。

**Evaluation dimensions.**

- **Miri Verification.** The candidate is rerun under Miri. A candidate that still triggers UB is rejected or sent back for another iteration. Miri is the hard safety gate for the observed execution \cite{miri}.
- **Clippy Warnings.** Clippy checks whether the patch introduces suspicious idioms, avoidable unsafe patterns, or maintainability issues \cite{clippy}.
- **Semantic Preservation.** A semantic-preservation evaluator compares the original intent and the patched behavior, focusing on whether the patch changes APIs, invariants, return values, ownership behavior, or error-handling semantics beyond what is needed to remove UB.
- **Minimal Change.** An AST-diff-based scorer estimates whether the patch is local and reviewable. This dimension discourages broad rewrites when a smaller semantics-preserving fix exists.

**Critic and decision rule.**

- The Critic aggregates the four evaluator outputs into a decision.
- Miri pass is treated as a hard constraint.
- Among Miri-passing candidates, soft dimensions guide ranking.
- If no candidate passes the decision gate, failure diagnostics are sent back to the Reflection Agent.
- The loop terminates when a candidate is accepted or the iteration budget is exhausted.

**Output.**

- accepted patched code
- evaluation report
- optional explanation of the repair
- optional mined repair pattern for future knowledge-base updates

### 4.7 Design Rationale and Discussion Points

> Goal: 作为方法章节结尾的小节，解释为什么这些模块组合起来能回应 intro 里的三类局限。正式写作时也可以拆成 Discussion 或放到每个 stage 末尾。

**Rationale mapping.**

- Compared with rule-based repair, Miragent does not require a complete hand-written rule catalog; it retrieves examples and lets agents compose repair strategies.
- Compared with LLM-guided template-based repair, Miragent does not confine generation to a fixed skeleton; hallucinated priors and multi-agent planning support semantic restructuring.
- Compared with ordinary agent-based repair, Miragent does not rely only on free-form feedback; Miri verification and multi-dimensional evaluation constrain hallucination-induced semantic drift.

**Ablation hooks.**

This subsection can also foreshadow experiments:

- without Semantic RAG
- without Hallucination Agent
- without Reflection
- without semantic-preservation evaluator
- Miri-only versus multi-dimensional evaluation

---

## 5. Miragent Design

### 5.1 Scope

Miragent targets automated repair of UB in Rust programs. The input of Miragent consists of a buggy Rust program, optional tests, and available build metadata. If the existing tests are not provided or insufficient, Miragent can generate or augment tests to expose the UB under Miri \cite{miri}. The output of Miragent consists of a patched Rust program and a repair report. Miragent treats a repair as successful only if the candidate patch passes Miri and satisfies the additional evaluation dimensions in Stage 4.

The scope of Miragent is Miri-grounded UB repair rather than whole-program verification. Miragent focuses on unsafe-code soundness bugs that can be reproduced through Miri-executable tests \cite{miri,rust-reference,stacked-borrows}.

### 5.2 Overview

[Figure caption draft. Fig. 1 Miragent Overview. The framework first obtains dynamic UB evidence and static code structure (Stage 1), then constructs repair context through Semantic RAG and Hallucination Agent (Stage 2), generates candidate patches through a Reflection–Plan–Fix multi-agent workflow (Stage 3), and finally accepts or rejects candidates through multi-dimensional evaluation (Stage 4).]

Fig. 1 shows the overview of Miragent. The framework is organized as a four-stage closed-loop pipeline that starts from UB evidence extraction and ends with multi-dimensional candidate evaluation.

Miragent is organized as a four-stage closed-loop pipeline:

**Stage 1: Input and Detection.** Miragent processes the Rust source code along two parallel tracks. A dynamic analysis track runs the program under Miri and generates a structured UB error report, while a static analysis track parses the source code into an Abstract Syntax Tree (AST) with Tree-sitter. The two tracks jointly provide information about what went wrong at runtime and where it happened in the code \cite{miri,tree-sitter}.

**Stage 2: Context Construction.** Given the error report and AST, a Semantic RAG module retrieves the most relevant (defective code, error, fixed code) triples from a UB Example Library, and a Hallucination Agent elicits an imagined fix. The retrieved (grounded) triples and the imagined (hallucinated) fix together form a contrastive repair context \cite{rag,hallucination-survey}.

**Stage 3: Multi-Agent Repair.** A Reflection Agent analyzes and turns the previous round evaluation feedback of Stage 4 into adjusted constraints. A Plan Agent produces an executable fix plan, and a Fix Agent generates $N$ candidate patches with diverse sampling temperatures and repair strategies \cite{repairagent,react,reflexion}.

**Stage 4: Multi-Dimensional Evaluation and Decision.** Each candidate is evaluated along four dimension: Miri verification, Clippy warnings, semantic consistency, and minimal change. An Aggregated Scorer accepts the best candidate or rejects all candidates. On rejection, failure diagnostics are routed back to the Reflection Agent in Stage 3 of the next iteration. The pipeline terminates when a candidate is accepted or the maximum iteration budget is reached \cite{miri,reflexion,clippy,apr-overfitting,patch-correctness}.

### 5.3 Stage 1: Input and Detection

Stage 1 prepares the evidence and code representation required for UB repair. Miragent takes as input Rust source code, optional tests, and available build metadata. The input is processed through two parallel tracks: a dynamic analysis track and a static analysis track.

The **dynamic analysis track** obtains runtime evidence of UB. When existing tests are not provided or are insufficient to expose UB, Miragent invokes the Test Generation Agent to generate Miri tests or augment the provided tests. This process is iterative: if the generated test does not trigger UB under Miri, Miragent feeds the no-UB result back to the Test Generation Agent and asks it to revise the test, until Miri observes UB or the test-generation budget is exhausted. Once Miri detects UB, Miragent normalizes the raw diagnostic output into a structured UB error report. The error report records the error message, source location, relevant stack frames, and inferred UB category \cite{miri}.

The **static analysis track** extracts source-code structure. Miragent parses the Rust source code with Tree-sitter and constructs an Abstract Syntax Tree (AST). Miragent uses the AST to align Miri-reported locations with relevant code regions. This structural representation helps downstream agents identify the code most related to the reported UB and construct localized repair contexts instead of reasoning over the entire program \cite{tree-sitter}.

The output of Stage 1 consists of a structured UB error report, an AST representation of the source code and the Miri test. Together, these artifacts describe both what went wrong at runtime and where the relevant code appears in the program.

### 5.4 Stage 2: Context Construction

Stage 2 constructs the repair context used by downstream agents. Its input consists of the structured UB error report, the AST representation, the Miri test from Stage 1, and the Rust source code. Stage 2 contains three main components: the UB Example Library, Semantic RAG, and the Hallucination Agent.

**1) UB Example Library:** The library contains 101 repair examples, each represented as a triple of *(defective code, error report, fixed code)*. The defective code is collected from the official Miri repository and our self-constructed cases \cite{miri}. The fixed code is produced by multiple Rust experts as a high-quality repair for the corresponding defective code. These examples cover major Rust UB categories, such as uninitialized memory access, dangling references, invalid aliasing, misaligned pointer access and out-of-bounds access \cite{rust-reference,stacked-borrows}. In each triple, the defective code records a minimal or localized Rust snippet that triggers UB; the error report stores structured Miri diagnostic information in the same format as the error report generated in Stage 1; and the fixed code records a patch that eliminates the reported UB.

**2) Semantic RAG:** The Semantic RAG module retrieves relevant examples from the UB Example Library \cite{rag}. The retrieval process first uses diagnostic cues, including the inferred UB category and key Miri error terms to narrow the candidate set. It then ranks the remaining triples by semantic similarity between the current defect and the stored examples, considering both the defective code and the error report. The top-3 triples are summarized into *Related Fix Patterns*. These patterns describe reusable repair strategies, such as replacing uninitialized buffers with initialized allocations, changing raw-pointer operations into safe abstractions, preserving lifetimes through ownership restructuring, or inserting validation before unsafe dereference.

**3) Hallucination Agent:** After retrieval, Miragent invokes the Hallucination Agent to elicit an imagined fix. The Hallucination Agent receives the Related Fix Pattern and is guided to reinterpret the retrieved fixed code as if it were a new defective case, generating multiple fixes under a more exploratory setting. Miragent retains fixes that do not pass the Miri test or pass the Miri test but significantly change the program semantics, as *Hallucination Fixes*. The Hallucination Fixes are used as contrastive priors: they may suggest alternative repair directions, expose assumptions that the retrieved examples do not cover, or highlight risky transformations that later agents should avoid. In this way, hallucination is deliberately converted from an uncontrolled failure mode into structured repair context \cite{hallucination-survey,reflexion}.

The output of Stage 2 is a contrastive repair context. It consists of Related Fix Patterns and the Hallucinated Fix. The context is passed to Stage 3, where the Reflection, Plan, and Fix agents use it to reason about repair strategies and generate candidate patches.

**Illustrative example.** Figure 2 shows a representative case from the *uninitialized memory* category that illustrates how a Related Fix Pattern and a set of Hallucinated Fixes are jointly constructed. Suppose the defect under repair reads a byte from a `Vec<u8>` that was allocated with `Vec::with_capacity` but never initialized, causing Miri to report a read of uninitialized memory \cite{rust-reference,miri}. Conditioned on this error report, Semantic RAG retrieves the triple shown in Figure 2(a)–(c): the defective code allocates an uninitialized buffer and dereferences a raw pointer into it (Figure 2a); the Miri diagnostic pinpoints the uninitialized read (Figure 2b); and the expert fix replaces the uninitialized allocation with a zero-initialized one (`vec![0u8; 10]`) and the raw-pointer dereference with safe indexing (Figure 2c). Miragent summarizes this triple into the Related Fix Pattern: *"for uninitialized reads arising from `Vec::with_capacity` followed by raw-pointer access, replace the uninitialized allocation with an initialized one and replace the raw-pointer dereference with safe indexing."*

```rust
// (a) Defective code (retrieved)
fn main() {
    let v: Vec<u8> = Vec::with_capacity(10);
    let undef = unsafe { *v.as_ptr().add(5) }; // read of uninitialized byte
    let x = undef + 1;
}
```

```text
// (b) Error report (retrieved)
error: Undefined Behavior: reading memory at ALLOC[0x5..0x6], but memory is
       uninitialized at [0x5..0x6], and this operation requires initialized memory
  --> src/main.rs
   |   let undef = unsafe { *v.as_ptr().add(5) };
   |                        ^^^^^^^^^^^^^^^^^^ Undefined Behavior occurred here
```

```rust
// (c) Fixed code (retrieved): the Related Fix Pattern
fn main() {
    let v: Vec<u8> = vec![0u8; 10]; // initialized allocation
    let val = v[5];                  // safe indexing
    let x = val + 1;
}
```

```rust
// (d) Hallucinated Fix #1 — fake initialization (fails Miri, same UB)
fn main() {
    use std::mem::MaybeUninit;
    let mut v: Vec<MaybeUninit<u8>> = Vec::with_capacity(10);
    unsafe { v.set_len(10); }                  // length advertised, bytes still uninit
    let val = unsafe { v[5].assume_init() };   // re-introduces the uninitialized read
    let x = val + 1;
}
```

```rust
// (e) Hallucinated Fix #2 — defensive rewrite (passes Miri, changes semantics)
fn main() {
    let v: Vec<u8> = vec![0u8; 10];
    // a length guard + saturating arithmetic silently alter the original behavior
    let val = if v.len() > 5 { v[5] } else { return };
    let x = val.saturating_add(1);
}
```

```rust
// (f) Hallucinated Fix #3 — revert to raw pointers (fails Miri, new UB)
fn main() {
    let v: Vec<u8> = vec![0u8; 10];
    let val = unsafe { *v.as_ptr().add(15) }; // mis-computed offset → out-of-bounds read
    let x = val + 1;
}
```

> **Figure 2.** A representative Related Fix Pattern (a–c) and three corresponding Hallucinated Fixes (d–f) for an *uninitialized memory* defect. The Hallucination Agent reinterprets the correct fixed code (c) as if it were a new defect and is asked to repair it under an exploratory decoding setting, producing several diverse "fixes". Miragent keeps those that fail Miri or pass Miri but alter program semantics: (d) fakes initialization with `MaybeUninit` + `set_len`/`assume_init` and re-triggers the original uninitialized read; (e) adds a defensive guard and saturating arithmetic that pass Miri but change the program's observable behavior; and (f) reverts to raw-pointer access with a mis-computed offset, introducing a *different* UB (out-of-bounds). All three are retained as contrastive priors that signal anti-patterns to avoid.

To generate the Hallucinated Fixes, the Hallucination Agent takes the *fixed* code in Figure 2(c) — which is already UB-free — and is deliberately told that it still contains UB, prompting it to "repair" a non-existent defect. Under an exploratory decoding setting, the agent produces several diverse candidates, of which Miragent keeps three that expose distinct anti-patterns; together they span the main ways a plausible-looking repair can go wrong.

- **Fake initialization (Figure 2d).** The agent over-engineers the allocation, switching to `Vec<MaybeUninit<u8>>`, calling `set_len(10)` to advertise a length without writing any bytes, and reading the element back through `assume_init()`. The candidate compiles and looks idiomatic, yet it *fails Miri* because `assume_init()` reads memory that was never initialized — reproducing the original uninitialized-read UB. This anti-pattern is exactly the root cause of real-world vulnerabilities such as CVE-2021-26953 \cite{cve-2021-26953}.
- **Semantics-altering defensive rewrite (Figure 2e).** The agent treats the read as inherently dangerous and wraps it in a length guard that returns early, while replacing `+` with `saturating_add`. This candidate *passes Miri* — there is no UB — but it silently changes the program's observable behavior: it can terminate early on inputs the original program handled, and it suppresses the overflow semantics of the original arithmetic. Because it preserves safety only by drifting away from the intended semantics, Miragent retains it as a counter-example for the semantic-preservation objective.
- **Raw-pointer reversion with a new UB (Figure 2f).** The agent abandons safe indexing and returns to `unsafe` raw-pointer arithmetic, but mis-computes the offset (`add(15)` on a length-10 buffer). The candidate *fails Miri* with an out-of-bounds access — a *different* UB category from the original. It illustrates how reaching for `unsafe` to "fix" a problem can trade one UB for another.

These three Hallucinated Fixes turn hallucination into a structured *contrastive prior*. The Related Fix Pattern in Figure 2(c) tells the downstream agents what a correct repair direction looks like (initialize before reading, prefer safe abstractions), while the three counter-examples densely enumerate tempting but unsound transformations along three orthogonal axes: (i) *fake soundness* that leaves the original UB in place (d); (ii) *semantic drift* that removes UB at the cost of behavior (e); and (iii) *UB substitution* that introduces a new violation while patching the old one (f). By pairing one positive pattern with three negative ones, Stage 2 supplies Stage 3 with both a target to imitate and a spectrum of pitfalls to steer away from, which sharpens the planning and generation that follow and directly serves Miragent's goal of producing UB-free yet semantics-preserving patches.

### 5.5 Stage 3: Multi-Agent Repair

Stage 3 generates candidate patches based on the repair context constructed in the previous stages. Its input consists of the UB error report and AST representation from Stage 1, the Related Fix Patterns and Hallucination Fixes from Stage 2, and the original Rust source code. Stage 3 follows a Reflection-Plan-Fix multi-agent workflow:

**1) Plan Agent:** Before invoking the Plan Agent, Miragent uses the *Prompt Builder* to assemble a repair prompt from the available context. The input of the Prompt Builder includes the Rust source code, the UB error report, the AST representation, the Related Fix Patterns, the Hallucinated Fixes, and adjusted constraints produced by the Reflection Agent in later iterations. Based on the structured prompt, the Plan Agent generates an executable *Fix Plan*. The Fix Plan specifies the suspected root cause, the target code region, the intended repair strategy, constraints that should be preserved, and verification points that the generated patch should satisfy. Instead of directly modifying code, the Plan Agent translates heterogeneous repair context into a concrete strategy for patch generation.

**2) Fix Agent:** Given the Fix plan, the Fix Agent generates *Candidate Patches*. These candidates are produced with different sampling temperatures or repair strategies to cover conservative, balanced, and exploratory modifications. Each candidate patch is expected to eliminate the reported UB while preserving the intended program behavior. Miragent passes the Candidate Patches and lightweight metadata to Stage 4 for evaluation. The lightweight metadata includes the modified code region and a short repair explanation.

**3) Reflection Agent:** The Reflection Agent is activated after Miragent evaluates the candidate patches in Stage 4. If no candidate is accepted, Stage 4 returns detailed feedback to the Reflection Agent. The Reflection Agent analyzes these signals and produces *Adjusted Constraints* for the next repair iteration. These constraints may instruct the Plan Agent to avoid a failed repair strategy, preserve a specific API or ownership relation, reduce the edit scope, or prioritize a different safe abstraction. In this way, Miragent does not simply retry generation after failure but turns evaluation feedback into explicit constraints to guide the next generation.

The output of Stage 3 consists of the Candidate Patches, Fix Plan, and lightweight metadata. These candidates are passed to Stage 4 for multi-dimensional evaluation. When Stage 4 rejects all candidates, the feedback is routed back to the Reflection Agent to iterate repair until a candidate is accepted or the maximum iteration budget is reached.

### 5.6 Stage 4: Multi-Dimensional Evaluation and Decision

Stage 4 evaluates the candidate patches generated in Stage 3 along multiple dimensions and decides whether the repair loop should terminate or continue. Its input consists of the Candidate Patches, Fix Plan, and lightweight metadata from Stage 3, the Miri test, UB error report, and AST representation from Stage 1, and the Rust source code. The goal of Stage 4 is not only to check whether a patch removes the reported UB, but also to determine whether the patch preserves the intended program behavior. Miragent evaluates each candidate along four dimensions: Miri Verification, Clippy Analysis, Semantic Consistency, and Minimal Change.

**1) Miri Verification:** Miragent reruns the Miri test on each candidate patch and compares the result with the original UB report. If the candidate still triggers UB or a related runtime-safety violation, it is rejected and the Miri diagnostic is recorded as feedback. This design ensures that the repair process remains grounded in executable UB evidence \cite{miri}.

**2) Clippy Analysis:** Miragent runs Clippy on each candidate to check whether the patch introduces suspicious Rust idioms, unnecessary unsafe code, avoidable clones, lifetime workarounds, or other maintainability issues. Clippy is Rust's standard linter for detecting common mistakes, non-idiomatic code, and suspicious patterns \cite{clippy}. Clippy is not used as a hard correctness oracle, since a warning does not necessarily imply an incorrect repair. Clippy results serve as a quality signal: candidates that introduce many new warnings are ranked lower than candidates that introduce fewer warnings when both eliminate UB.

**3) Semantic Consistency:** UB repair is not successful if the patch merely silences Miri by changing the intended behavior of the program, a well-known risk in automated repair evaluation \cite{apr-overfitting,patch-correctness}. Miragent uses the Semantic Preservation evaluator to compare the original code, the Fix Plan, and the candidate patch. This evaluator checks whether the patch preserves API contracts, return values, ownership relationships, error-handling behavior, and other program-specific invariants implied by the original code. When a candidate passes Miri but changes the intended semantics, the evaluator records the mismatch as a semantic error and provides feedback to the Reflection Agent.

**4) Minimal Change:** Miragent prefers patches that remove UB with localized, reviewable edits. Using the AST representation and patch metadata, Miragent estimates the size and scope of each modification, including the number of changed nodes, affected functions, and whether the patch rewrites unrelated code. Large edits may be accepted when they are necessary, but unnecessary broad rewrites are penalized \cite{tree-sitter}.

After all dimensions are evaluated, the *Aggregated Scorer* combines the results into a decision. Miri verification is the hard safety gate, while Clippy Analysis, Semantic Consistency, and Minimal Change guide ranking among Miri-passing candidates. If one or more candidates satisfy the acceptance criteria, Miragent selects the best-ranked candidate as the final repair. If no candidate is accepted, Miragent constructs detailed feedback, including Miri failures, Clippy warnings, semantic consistency issues, minimal change scores, and the aggregated decision, and routes this feedback back to the Reflection Agent in Stage 3.

The output of Stage 4 is an accepted repair or a rejection report. For an accepted repair, Miragent outputs the patched Rust program and a repair report containing the Miri result, evaluator scores, modified code region, and repair explanation. For rejected candidates, Miragent outputs diagnostic feedback that drives the next repair iteration.

---

## 6. Experiments and Evaluation

In this section, we evaluate Miragent on both benchmark-style Miri cases and real-world Rust CVEs. The evaluation focuses on two aspects: whether Miragent can generate effective repairs that both eliminate the observed UB and preserve intended behavior, and how much each core component contributes to the overall repair performance. We first describe the datasets, baselines, model backends, and metrics, then report the overall repair results, followed by an ablation study of Miragent components.

### 6.1 Datasets

We evaluate Miragent on two datasets: a Miri dataset and a real-world Rust CVE dataset \cite{miri,rustsec,cve-program}.

**Miri Dataset**. The Miri dataset is collected from the official Miri failing test suite \cite{miri}. It contains Rust test cases that expose UB under Miri. These cases cover major UB categories, such as uninitialized memory access, dangling references, invalid aliasing, misaligned pointer access, out-of-bounds access, and data races \cite{rust-reference,stacked-borrows}. This dataset provides controlled and reproducible UB instances to evaluate whether Miragent can repair diverse Miri-detectable UB patterns.

**Real-world CVE Dataset.** The CVE dataset contains 65 real-world Rust CVEs we collected from vulnerable Rust crates \cite{rustsec,cve-program,rust-cve-study}. Compared with the Miri dataset, these cases are larger and more realistic. They may involve crate-level build configurations, project-specific APIs, and non-trivial unsafe-code contexts. We select CVEs according to three criteria: (1) the vulnerability should be related to memory safety, rather than purely logical errors, configuration issues, or denial-of-service bugs; (2) the root cause should be located in Rust code and should not primarily depend on UB inside external native FFI libraries, because such behavior is difficult for Miri to analyze directly; (3) the vulnerable source version and sufficient reproduction context should be available that can expose the bug. The purpose of this dataset is to evaluate whether Miragent can repair UB-related vulnerabilities in real-world Rust code rather than only synthetic or benchmark-style snippets. For each CVE, we collect the vulnerable source version, the relevant test when available, and metadata such as the affected crate, CVE identifier, and UB category.

**Semantic Consistency Test Sets.** Passing the original Miri-triggering test only shows that a patch removes the observed UB; it does not show that the patch preserves the intended behavior of the vulnerable program, a common concern in program repair benchmarks \cite{defects4j,apr-overfitting,patch-correctness}. Therefore, for both datasets, we manually construct augmented semantic consistency tests. These tests exercise the expected non-UB behavior of the repaired program, including public API behavior, return values, error handling, boundary conditions, ownership-sensitive behavior, and crate-specific invariants when applicable. For CVE cases, we construct these tests from vulnerability reports, available regression tests, crate documentation, and the behavior of the patched upstream version when available. The semantic consistency tests are held out from the repair process: they are not included in prompts, retrieval inputs, or repair feedback, and are used only for final evaluation.

Together, the two datasets evaluate complementary aspects of UB repair. The Miri dataset stresses UB-category coverage and controlled reproducibility, and the CVE dataset stresses realism, project complexity, and practical repairability. The semantic consistency test sets further evaluate whether Miri-passing patches preserve the intended behavior rather than merely silencing the observed UB.

### 6.2 Baselines

We compare Miragent with four baselines.

**LLM-Only.** It directly prompts the LLM to repair UB using the available error report and source context. It measures the benefit of Miragent over direct LLM repair \cite{codex,empirical-llm-apr}.

**Thetis-Lathe.** It represents rule-based repair. It uses predefined rules and pattern matching to detect and patch known unsafe-code or UB patterns. Its detection stage uses source-level features, unsafe-block extraction, regular-expression matching, and relevance filtering to identify suspicious unsafe-code patterns. Its fixing stage applies rule-specific transformations, such as replacing unsafe operations with safe APIs, using synchronization abstractions, converting unions to structs, or inserting contract-style assertions \cite{thetis-lathe}. In our evaluation on the CVE dataset, fully covering all CVE categories would require a large manually written repair-rule set. Therefore, we use the detection stage of Thetis-Lathe and feed its detection output, together with the Miri error report and source context, to the LLM. The LLM is then prompted to repair the code in a Thetis-Lathe-style rule-guided manner.

**GiantRepair.** It represents LLM-guided template-based repair. It constrains patch generation through predefined structural skeletons. Although GiantRepair was evaluated on Defects4J, its core pipeline is language-agnostic \cite{giantrepair,defects4j}. It generates an LLM patch, computes an AST-level difference, abstracts the patch into a repair skeleton, instantiates the skeleton with context-aware identifiers and expressions, and ranks candidate patches through validation. We adapt this template abstraction and instantiation workflow to Rust by using Rust source context and Rust-compatible repair skeletons.

**RustBrain.** It represents agent-based repair. It organizes LLM-based repair around a feedback-driven agent workflow in fast and slow thinking LLM processes \cite{rustbrain}. We include RustBrain to compare Miragent with an agentic repair approach that iterates on feedback.

All methods are evaluated on the same dataset cases and, whenever applicable, under the same tests, time limits, iteration budgets, and the same LLM configurations.

### 6.3 LLM Backends and Metrics

We evaluate LLM-based methods with three model backends: Gemini-3-Flash, GPT-5-mini, and DeepSeek-V4-Flash. We choose Flash/Mini-level models because they represent practical, cost-efficient deployment settings for automated repair systems. These models are capable of code reasoning, while still leaving enough room to evaluate whether the repair framework itself contributes beyond raw model capability. For different LLM calls, we use the same prompts, iteration budget, temperature settings, and tool-access configuration whenever possible.

Two quantitative metrics are used in the evaluation: Fix Rate and Repair Time.

*FR (Fix Rate).* FR measures the percentage of cases for which a method produces a valid repair. A case is counted as fixed only if the generated patch passes both the original Miri-triggering test and the held-out semantic consistency tests. Therefore, FR captures both UB elimination and semantic consistency. Formally, given a dataset \(D\) with \(N\) cases, let \(p_i\) denote the patch generated for case \(i\). We define:

\[
\mathrm{FR} =
\frac{1}{N}\sum_{i=1}^{N}
\mathbf{1}\left[
\mathrm{Miri}(p_i)=\mathrm{pass}
\land
\mathrm{SemTest}(p_i)=\mathrm{pass}
\right].
\]

If a method fails to generate a patch, times out, or produces a patch that fails either Miri or the semantic consistency tests, the corresponding case contributes 0 to FR.

*Repair Time.* Repair time measures the wall-clock time required for a method to produce an accepted patch or reach the maximum iteration budget. For methods that produce multiple candidate patches, we measure the time until the first candidate accepted by the method is produced. Repair time is used to evaluate the practical overhead of each method, but FR remains the primary metric because a fast patch is not useful unless it removes UB and preserves intended behavior.

### 6.4 Overall Repair Results

Table~\ref{tab:main_results} reports FR and repair time for Miragent and the four baselines on the Miri and CVE datasets. Since FR requires a patch to pass both the original Miri-triggering test and the held-out semantic consistency tests, a higher FR indicates that a method is more effective at producing true UB repairs rather than merely silencing the observed runtime symptom.

On the Miri dataset, Miragent achieves the highest FR across all three LLM backends: 93.61%, 93.15%, and 92.92% with Gemini-3-Flash, GPT-5 Mini, and DeepSeek-V4-Flash, respectively. The improvement over LLM-Only reaches 8.45, 8.90, and 8.90 percentage points. Compared with the strongest baseline under each backend, Miragent improves FR by 3.88 percentage points on all three backends. These results show that Miragent is effective even on compact Miri cases where several baselines already perform well. The gain comes from counting only patches that both remove the Miri-observed UB and satisfy semantic consistency tests, which penalizes superficial repairs that pass the original UB-triggering execution by changing intended behavior.

On the CVE dataset, Miragent also obtains the highest FR across all three LLM backends, achieving 72.31%, 70.77%, and 70.77%. The improvement is more significant than on the Miri dataset. Compared with LLM-Only, the improvement reaches 10.77, 10.77, and 12.31 percentage points. Compared with the strongest baseline under each backend, Miragent improves FR by 6.16, 6.15, and 7.69 percentage points. These results indicate that Miragent is especially effective on real-world UB repair tasks, where patches must respect crate-level APIs, project-specific behavior, boundary conditions, and implicit invariants in addition to eliminating the observed UB.

The results also show a trade-off between repair effectiveness and repair time. LLM-Only is the fastest method because it performs direct generation without retrieval, planning, or iterative evaluation, but it has the lowest FR, especially on real-world CVEs. RustBrain is the slowest baseline because its feedback-driven agent loop requires more iterations; on average, it takes 161.7 seconds on the Miri dataset and 795.3 seconds on the CVE dataset. Miragent introduces additional overhead over simpler baselines, but remains faster than RustBrain on both datasets, with average repair time of 112.7 seconds on Miri and 580.3 seconds on CVE. Overall, compared with the average of all baseline results, Miragent improves FR by 6.7% relatively on the Miri dataset and 14.4% relatively on the CVE dataset under acceptable time overhead.

### 6.5 Ablation Study

To evaluate how each core component contributes to Miragent, we conduct an ablation study on both the Miri and CVE datasets across the three LLM backends. Table~\ref{tab:main_results} reports the results. We compare the full Miragent system with four variants: w/o Semantic RAG, w/o Hallucination Agent, w/o Reflection Agent, and w/o Multi-dimensional Evaluation.

The ablation results show that Semantic RAG is especially important for real-world CVE repair. Removing Semantic RAG reduces the average FR from 93.23% to 90.33% on the Miri dataset and from 71.28% to 66.15% on the CVE dataset, corresponding to average drops of 2.89 and 5.13 percentage points. The larger drop on CVE cases suggests that retrieved UB repair examples provide important grounding when the repair space is larger and the unsafe-code context is more project-specific. Removing the Hallucination Agent also consistently hurts repair effectiveness. The average FR decreases to 91.17% on Miri and 67.69% on CVE, with larger degradation on CVE cases. This indicates that hallucination-based contrastive priors help broaden repair exploration beyond the retrieved examples, especially when useful repairs require ownership restructuring, API-preserving rewrites, or safer abstractions that are not directly captured by the top retrieved patterns.

Reflection has a smaller but stable contribution. Removing the Reflection Agent decreases the average FR from 93.23% to 92.77% on Miri and from 71.28% to 69.74% on CVE. This suggests that reflection mainly helps difficult cases that require iterative refinement after failed candidates. The w/o Multi-dimensional Evaluation variant reveals the importance of using semantic consistency as part of the acceptance criterion. Its average FR decreases to 90.18% on Miri and 67.18% on CVE. This shows that using Miri-oriented feedback alone can accept patches that remove the observed UB but fail semantic consistency tests. Multi-dimensional evaluation therefore acts as a quality gate that filters out superficially successful fixes and improves the likelihood that accepted patches remain semantically consistent.

---

## 7. Discussion

In this section, we discuss the potential improvements to Miragent. Miragent is bounded by the quality of its executable evidence, localization accuracy, and the scope of UB that Miri can directly observe. These limitations suggest several directions for improving Miragent in future work.

*Improvement for Root-Cause Localization*. Miragent currently localizes repair context by aligning Miri diagnostics with the AST representation of the source code. This design provides a practical bridge between runtime evidence and syntactic edit regions, but the location reported by Miri is not always the true root cause. A promising improvement is to integrate program slicing, data-flow analysis, and unsafe-block dependency tracing into Stage 1 \cite{program-slicing,static-analysis}. Such analyses could distinguish the observed failure site from the root-cause site, helping downstream agents construct more precise repair contexts.

*Improvement for Test Generation*. Miragent relies on Miri tests to expose UB and validate candidate repairs. For real-world crates, existing tests may be missing, incomplete, or unable to trigger UB. Although Miragent includes the Test Generation Agent, it is still limited to generating or augmenting tests for Miri execution. Future work could strengthen this component by incorporating coverage-guided fuzzing, property-based testing, or symbolic execution to explore deeper program paths \cite{libfuzzer,afl,quickcheck,klee}.

*FFI and External UB Support*. Miragent focuses on Miri-grounded UB repair, which is effective when UB can be reproduced inside Rust code under Miri. However, some Rust vulnerabilities arise at FFI boundaries or depend on behavior inside external native libraries \cite{rust-nomicon,unsafe-code-guidelines}. Such cases are difficult for Miri to analyze directly. A future extension could add explicit FFI boundary modeling, such as generating safe stubs for external functions, inferring contracts for FFI calls, or combining Miri with sanitizer and fuzzing feedback from native execution \cite{asan,ubsan,libfuzzer}. Another direction is to combine Miragent with Rust verification tools that reason beyond a single dynamic execution, such as Verus, Flux, Kani, and Crux-MIR \cite{verus,flux,kani,cruxmir}.

---

## 8. Conclusion

In this paper, we propose Miragent, a hallucination-augmented multi-agent framework for automated UB repair in Rust. Miragent combines Miri-grounded UB detection, Semantic RAG over a UB repair knowledge base, hallucination-based contrastive priors, a Reflection–Plan–Fix repair workflow, and multi-dimensional evaluation to generate patches that eliminate UB while preserving intended program semantics. We compare it with four baseline methods on the Miri dataset and real-world CVE dataset. The results demonstrate the performance of Miragent: it improves the average fix rate of four methods by 6.7% on the Miri dataset and 14.4% on the CVE dataset, and it improves the average semantic consistency rate by 4.5% on the Miri dataset and 10.5% on the CVE dataset. These results suggest that the hallucination-based repair priors are effective and Miri-based multi-agent repair is a promising direction for improving Rust software safety.

---

## 9. Experiments and Evaluation - Detailed Outline

> 本节先作为实验章节的详细文字初稿和组织大纲。正式写作时建议标题使用 **Experiments and Evaluation**。本节围绕四个 research questions 展开：UB 修复能力、语义保留能力、修复效率，以及核心组件贡献。

### 9.1 Research Questions

We design our evaluation to answer the following research questions:

- **RQ1: How effective is Miragent at repairing UB in Rust programs?** This question evaluates whether Miragent can generate patches that eliminate Miri-detected UB on both benchmark-style Miri cases and real-world Rust CVEs.
- **RQ2: To what extent do Miragent-generated patches preserve the intended semantics of the original vulnerable code?** This question evaluates whether a patch that removes UB still preserves the intended behavior of the original program.
- **RQ3: How efficient is Miragent in terms of repair time and token consumption?** This question evaluates the practical cost of Miragent, including wall-clock time, token usage, and iteration count.
- **RQ4: How much does each core component of Miragent contribute to its repair performance?** This question evaluates the contribution of Semantic RAG, the Hallucination Agent, the Reflection Agent, and the multi-dimensional evaluation stage through ablation studies.

We answer **RQ1** by measuring the UB fix rate of Miragent and comparing it with four baselines: LLM-Only, Thetis-Lathe, GiantRepair, and RustBrain. We answer **RQ2** by checking whether generated patches preserve the intended semantics after eliminating UB. We answer **RQ3** by measuring wall-clock repair time, token consumption, and iteration count across different LLM backends. We answer **RQ4** by removing one core component of Miragent at a time and measuring the resulting change in fix rate, semantic preservation, and efficiency.

### 9.2 Experimental Setup

#### 9.2.1 Datasets

We evaluate Miragent on two datasets: a Miri dataset and a real-world Rust CVE dataset.

**Miri dataset.** The Miri dataset contains Rust programs or test cases that expose UB under Miri. These cases cover major UB categories, such as uninitialized memory access, dangling references, invalid aliasing, misaligned pointer access, out-of-bounds access, and data races. The purpose of this dataset is to evaluate whether a repair system can handle diverse, detector-grounded UB patterns in a controlled setting. For each case, we provide the buggy Rust code, a Miri-triggering test or harness, and the corresponding Miri diagnostic.

**Real-world CVE dataset.** The CVE dataset contains 65 real-world Rust CVEs collected from vulnerable Rust crates. Compared with the Miri dataset, these cases are larger and more realistic: they may involve crate-level build configurations, project-specific APIs, and non-trivial unsafe-code contexts. The purpose of this dataset is to evaluate whether Miragent can repair UB-related vulnerabilities in real-world Rust code rather than only synthetic or benchmark-style snippets. For each CVE, we collect the vulnerable source version, the relevant test or harness, the Miri diagnostic when available, and metadata such as the affected crate, CVE identifier, and UB category.

Together, the two datasets evaluate complementary aspects of UB repair. The Miri dataset stresses coverage over UB categories and controlled reproducibility, while the CVE dataset stresses realism, project complexity, and practical repairability.

#### 9.2.2 Compared Methods

We compare Miragent with four baselines.

- **LLM-Only.** This baseline directly prompts the LLM to repair the buggy Rust code using the available error report and source context, without Semantic RAG, hallucination augmentation, multi-agent decomposition, or multi-dimensional feedback. It measures the benefit of Miragent over direct LLM repair.
- **Thetis-Lathe.** This baseline represents rule-based repair. It uses predefined rules and pattern matching to detect and patch known unsafe-code or UB patterns.
- **GiantRepair.** This baseline represents LLM-guided template-based repair. It constrains patch generation through predefined structural templates or repair skeletons.
- **RustBrain.** This baseline represents agent-based repair. It uses LLM agents and feedback-driven iteration to generate and refine patches.
- **Miragent.** Miragent is our full system, combining Semantic RAG, hallucination-augmented repair context, a Reflection–Plan–Fix workflow, and multi-dimensional evaluation.

All methods are evaluated on the same dataset cases and, whenever applicable, under the same test harnesses, time limits, and iteration budgets. For methods that require LLMs, we evaluate them with three LLM backends: Gemini-3-Flash, GPT-5-mini, and DeepSeek-V4-Flash.

#### 9.2.3 LLM Backends

We run LLM-based methods using three backends: **Gemini-3-Flash**, **GPT-5-mini**, and **DeepSeek-V4-Flash**. This design lets us evaluate whether Miragent's benefits are tied to a single model or remain consistent across different LLM families. For each backend, we use the same prompts, iteration budget, temperature settings, and tool-access configuration whenever possible. The final paper should report the exact model versions, decoding parameters, maximum iteration budget, and token limits.

#### 9.2.4 Metrics

We use the following metrics.

- **Fix Rate.** The percentage of cases for which a method produces a patch that passes Miri on the UB-triggering test or harness. This metric answers RQ1.
- **Semantic Preservation Rate.** The percentage of fixed cases whose patches preserve the intended behavior of the original program. This metric answers RQ2.
- **Repair Time.** The wall-clock time required to produce an accepted patch or reach the maximum iteration budget. This metric answers RQ3.
- **Token Consumption.** The total number of input and output tokens consumed during repair. This metric answers RQ3 for LLM-based methods.
- **Iteration Count.** The number of repair iterations required before acceptance or termination. This metric helps explain efficiency and convergence behavior.
- **Ablation Delta.** The change in fix rate, semantic preservation, time, and token consumption when a core component is removed. This metric answers RQ4.

### 9.3 RQ1: UB Repair Effectiveness

To answer RQ1, we compare the fix rate of Miragent with all baselines on both datasets and all LLM backends. A case is counted as fixed if the generated patch passes Miri on the UB-triggering execution. We report both absolute fix rates and relative improvements over the strongest baseline.

**Expected result narrative.** Miragent is expected to achieve a higher fix rate than LLM-Only because it provides richer repair context and uses multi-agent planning rather than direct patch generation. It is expected to outperform rule-based repair when the target UB pattern falls outside predefined rules, and to outperform template-based repair when the correct fix requires semantic restructuring beyond a fixed skeleton. Compared with other agent-based repair methods, Miragent should benefit from Miri-grounded evaluation and hallucination-aware repair exploration.

**Table to use.** The main result table should report, for each dataset, backend, and method: number fixed, total cases, and fix rate. This can be combined with the RQ2 and RQ3 metrics in one double-column table.

### 9.4 RQ2: Semantic Preservation

To answer RQ2, we evaluate whether Miri-passing patches preserve the intended program semantics. A patch may remove UB by deleting functionality, changing return values, weakening checks, altering ownership behavior, or rewriting APIs in a way that no longer matches the original intent. Such patches should not be counted as semantically preserved even if they pass Miri.

The semantic-preservation evaluation should combine manual inspection, project tests when available, and the Semantic Preservation evaluator used in Stage 4. The final paper should describe the exact protocol: who inspected the patches, how disagreements were resolved, and which evidence was used to decide whether semantics were preserved.

**Expected result narrative.** Miragent is expected to maintain a higher semantic-preservation rate than LLM-Only and ordinary agent-based repair because its repair loop explicitly incorporates semantic-preservation feedback. The comparison should show whether higher fix rate comes at the cost of semantic drift or whether Miragent improves both dimensions.

### 9.5 RQ3: Repair Efficiency

To answer RQ3, we measure the cost of repair in terms of wall-clock time, token consumption, and iteration count. We report average and median values, and optionally percentile statistics for long-tail cases. For LLM-based methods, token consumption includes all prompts and generated outputs across all iterations. For non-LLM or partially non-LLM baselines, token consumption can be reported as N/A where appropriate.

**Expected result narrative.** Miragent may consume more tokens than LLM-Only because it uses retrieval, hallucination, planning, fixing, reflection, and evaluation. However, its higher repair success rate may reduce wasted retries and improve the number of successful repairs per unit cost. The evaluation should therefore report both raw cost and cost-normalized effectiveness, such as time per successful repair or tokens per successful repair.

### 9.6 RQ4: Ablation Study

To answer RQ4, we evaluate four ablated variants of Miragent.

- **w/o Semantic RAG.** This variant removes retrieval from the UB Example Library. The repair agents receive the source code and error report, but not Related Fix Patterns.
- **w/o Hallucination Agent.** This variant removes Hallucinated Fixes from the repair context. It tests whether hallucination-as-prior improves repair exploration.
- **w/o Reflection Agent.** This variant removes feedback-to-constraint conversion. After failed candidates, the system retries planning and fixing without Adjusted Constraints.
- **w/o Multi-dimensional Evaluation.** This variant uses Miri as the only acceptance signal and removes Clippy Analysis, Semantic Preservation, and Minimal Change from the ranking and feedback loop.

For each ablation, we report fix rate, semantic-preservation rate, average repair time, token consumption, and iteration count. The comparison against full Miragent shows which components contribute most to repair success and which components mainly improve semantic preservation or efficiency.

**Expected result narrative.** Removing Semantic RAG is expected to reduce performance on cases where similar UB examples provide useful repair strategies. Removing the Hallucination Agent is expected to reduce exploration and hurt cases requiring non-template repairs. Removing the Reflection Agent is expected to increase repeated failures across iterations. Removing multi-dimensional evaluation is expected to increase semantic drift even when Miri pass rate remains high.

### 9.7 Result Tables

The final paper should include at least two double-column tables.

**Main result table.** The main table should report all methods across both datasets, three LLM backends, and five methods: Miragent, LLM-Only, Thetis-Lathe, GiantRepair, and RustBrain. The columns should include fix rate, semantic-preservation rate, average time, token consumption, and iteration count.

**Ablation table.** The ablation table should report Full Miragent and the four ablated variants on both datasets. The columns should include fix rate, semantic-preservation rate, average time, token consumption, and iteration count.

### 9.8 Threats to Validity

**Internal validity.** The repair outcome may depend on the quality of the test harnesses and the stability of LLM outputs. To mitigate this threat, all methods should use the same test harnesses and budgets, and each LLM-based configuration should be run with controlled decoding settings.

**External validity.** The datasets may not cover every Rust UB pattern or every project structure in the Rust ecosystem. To mitigate this threat, the evaluation uses both benchmark-style Miri cases and real-world Rust CVEs.

**Construct validity.** Miri passing on a witness execution does not prove global absence of UB. Similarly, semantic preservation is difficult to measure automatically. To mitigate this threat, we treat Miri as detector-grounded evidence for the observed UB and combine automated semantic checks with manual or test-based validation where possible.

**Conclusion validity.** LLM-based repair performance can vary across model backends and sampling settings. To mitigate this threat, we evaluate Miragent with three LLM backends and report time, token, and iteration costs alongside repair outcomes.

---

## 10. Introduction — 长版本备选（10 段，附 motivating example，供日后扩写时取用）

> ⚠️ 这一节是更详细的 **10 段长版本**（含 CVE-2021-26953 motivating example、三个 Observation 段、Figure 2 流水线总览、Roadmap）。当前正文使用 §3 的紧凑版；这里保留是为了将来如果想扩到 1 页以上的 intro 时可直接取用片段。

### 10.1 框架（10 段，目标 ~1 050 词）

| Para | 论证目标 | Word target | Abstract anchor |
|---|---|---|---|
| ¶1 | Rust 是什么样的语言 + `unsafe` 是不可避免的逃生口 | ~95 | S1 (前半) |
| ¶2 | UB 的真实影响 + **motivating example (CVE-2021-26953)** + 一段最小代码 | ~180 | S1 (后半) |
| ¶3 | 自动化 UB 修复问题形式化 + 为什么对 Rust 特别难 | ~110 | S2 |
| ¶4 | 三类既有方法（C1 / C2 / C3），点名代表作 | ~150 | S3 |
| ¶5 | 三类局限（P1 / P2 / P3），用更具体的失败样态展开 | ~160 | S4 |
| ¶6 | 三个核心 insight（Miri-as-verifier, Hallucination-as-prior, Multi-agent 解耦） | ~140 | (新，承接 S5–S6) |
| ¶7 | Miragent 流水线总览 + Figure 1 引用 | ~150 | S5–S6 |
| ¶8 | 实验设置与结果概览（带占位符） | ~95 | S7 |
| ¶9 | Contributions（4 条） | ~90 | (新) |
| ¶10 | Roadmap（一句话过 §2–§7） | ~30 | (标准结尾) |

### 10.2 详细英文内容（每段都可直接进文章）

#### ¶1 — Rust 与 `unsafe` 逃生口

> Anchor: S1 前半。建立"Rust 不是想象中那样'天生安全'"。

Rust has emerged as the most widely adopted memory-safe systems programming language, powering production codebases ranging from the Linux kernel and Firefox to Cloudflare and Amazon Firecracker. Its ownership and borrow-checker discipline statically eliminates entire classes of memory- and thread-safety bugs that have plagued C and C++ for decades \cite{rustbelt,is-rust-used-safely,unsafe-rust-oopsla}. Yet practical Rust projects routinely escape the safe sub-language: `unsafe` blocks, raw-pointer manipulation, and FFI calls into C libraries are unavoidable in any non-trivial systems crate, and any soundness slip inside such regions immediately falls into the language's catalogue of *Undefined Behavior* (UB) \cite{rust-reference,rust-nomicon}.

#### ¶2 — UB 的真实影响 + Motivating Example (CVE-2021-26953)

> Anchor: S1 后半 + 给 reviewer 一个 90 秒就能"看懂 + 共情"的例子。

The consequences are measurable. As of 2026, the RustSec advisory database lists hundreds of Rust security advisories, and prior Rust CVE studies identify memory-safety and unsafe-code soundness bugs as recurring root causes \cite{rustsec,rust-cve-study}. These issues span use-after-free, data races, reads of uninitialized memory, out-of-bounds and misaligned accesses, and stacked-borrows violations \cite{rust-reference,stacked-borrows,miri}. **Figure 1** shows a representative case, **CVE-2021-26953** in the `postscript` crate, distilled into seven lines of `unsafe` Rust:

```rust
pub fn read_bytes(&mut self, len: usize) -> io::Result<Vec<u8>> {
    let mut buf = Vec::with_capacity(len);
    unsafe { buf.set_len(len); }                  // grow without init
    self.inner.read_exact(&mut buf)?;             // pass uninit slice
    Ok(buf)
}
```

`Vec::with_capacity` allocates but does not initialize, while `set_len` advertises the buffer as fully initialized; `read_exact` then receives a `&mut [u8]` referring to uninitialized memory, which is UB by the Rust reference \cite{rust-reference}. Crucially, the snippet *type-checks* and *passes the borrow checker* — only Miri reports it, at the moment `read_exact` constructs a reference to uninitialized bytes \cite{miri}. Repairing this snippet requires more than localized rewriting: a sound fix has to choose between zero-initializing the buffer (`vec![0u8; len]`), using `MaybeUninit<u8>` with a manual length-tracking protocol, or restructuring the API to return `Bytes` instead — each option with different performance and ABI implications.

> 备选 motivating example：CVE-2018-1000657 (`VecDeque` non-power-of-two capacity → use-after-free in `pop_front`) — 更长但更"教科书式"。如要替换，把上面 7 行换成对应代码段即可。

#### ¶3 — 问题定义：自动化 UB 修复

> Anchor: S2。把 Miragent 想解决的问题形式化。

This motivates the problem of *automated UB repair* for Rust: given a function (or crate) whose execution exhibits UB under an executable dynamic detector such as Miri, automatically synthesize a patch $f'$ that **(i)** eliminates the reported UB, **(ii)** preserves the original program semantics on every UB-free input, **(iii)** still type-checks and compiles under the borrow checker and trait system, and **(iv)** keeps the edit small enough to be human-reviewed and merged \cite{miri}. The setting is markedly harder than mainstream automated program repair (APR) because every candidate patch must simultaneously satisfy Rust's lifetime, aliasing, and `unsafe`-boundary obligations — constraints that have no direct analogue in Java APR benchmarks such as Defects4J \cite{rust-reference,stacked-borrows,defects4j}.

#### ¶4 — 三类既有方法

> Anchor: S3。点名 6 个代表作，让 reviewer 立刻定位到引文坐标。

A growing body of work tackles automated UB repair in Rust along three largely disjoint lines.

**(C1) Rule-driven static analysis and rewriting.** Tools such as RUDRA, Thetis-Lathe, and SafeDrop \cite{rudra,thetis-lathe,safedrop} encode known UB recipes — e.g., `Send`/`Sync` mis-implementations, panic-on-uninitialized-drop, mis-aligned reads, or deallocation defects — into hand-written detectors and source-level rewrites that aim to discharge each obstacle with a safe equivalent.

**(C2) Skeleton-guided LLM repair.** Recent neuro-symbolic systems use a frontier LLM to propose a candidate patch and then project the patch onto a typed program-analysis skeleton that is re-instantiated from in-scope identifiers and operators. GiantRepair, AlphaRepair, and syntax-guided neural repair systems such as Recoder \cite{giantrepair,alpharepair,recoder} are representative entries.

**(C3) Agent-based and feedback-driven repair.** A third line wraps an LLM in an autonomous loop with tools (compiler, tests, search, memory). RepairAgent iterates on compiler diagnostics under an Act-Observe protocol \cite{repairagent}, general software-engineering agents such as SWE-agent and AutoCodeRover show the value of tool-use and repository navigation \cite{swe-agent,autocoder}, and Rust-specific systems such as RustBrain and AkiraRust study feedback-driven multi-agent reasoning for UB repair \cite{rustbrain,akirarust}.

#### ¶5 — 三类局限的具体展开

> Anchor: S4。把摘要里浓缩的"三句话局限"扩成具体失败样态，铺垫 §6 的 insight。

Each of these lines, however, leaves a Rust-UB-specific blind spot.

**(P1)** Rule-based pipelines are bounded by their hand-written catalogues of safety obstacles. When an unsafe pattern lies outside the catalogue — particularly for control-flow-sensitive UB such as data races and use-after-free — coverage drops sharply, and adding a new rule requires non-trivial expert effort that does not scale to the long tail of Rust idioms; in our reproduction (§5), Thetis-Lathe-style rewriting fails on $X\%$ of `data_race` and $Y\%$ of `use_after_free` CVEs because the rule set has no template for the offending pattern.

**(P2)** Skeleton-guided LLM repair constrains the LLM to produce edits that fit a pre-defined typed template, discarding the model's broader reasoning ability and forcing it to operate as a "patch oracle" rather than as a problem solver. Worse, the post-hoc instantiation step is a syntactic search guarded only by `cargo check` — it has *no soundness check beyond the borrow checker* — so passing patches frequently re-introduce the same UB at a different offset, which we observe in $Z\%$ of GiantRepair's "fixed" candidates.

**(P3)** Agent-based loops iterate on compiler errors or unit-test pass/fail signals, neither of which is a UB-grounded signal: a patch that silences the compiler can still violate Stacked Borrows, and the LLM driving the loop is free to hallucinate plausible-but-wrong fixes that the loop has no rigorous way to reject \cite{stacked-borrows,repairagent,hallucination-survey}. RustBrain's own evaluation also separates Miri pass rate from execution semantic acceptability, underscoring that safety-tool success is not the same as semantic preservation \cite{rustbrain}.

#### ¶6 — 三个核心 Insight

> Anchor: 新增段，桥接 S4 → S5。把 Miragent 的设计 insight 提前讲清楚，让 §3.2.7 的 pipeline 显得"有理有据"。

Three observations underpin our approach.

**Observation 1 (Miri-as-verifier).** Miri is an executable dynamic UB detector for Rust programs and can expose issues such as uninitialized memory, misaligned accesses, aliasing-rule violations, and data races on the executed witness \cite{miri}. Treating Miri not as a one-shot oracle but as the *inner-loop* verifier turns "Did the patch eliminate the observed UB?" from a heuristic into a checkable property, and lets us reject any candidate that re-triggers UB before it ever reaches a downstream evaluator.

**Observation 2 (Hallucination-as-prior).** Prior agent-based repair treats LLM hallucinations as a failure mode to be filtered away \cite{repairagent,hallucination-survey}. We argue the opposite: when explicitly elicited under a high-temperature setting and *labelled as imagined*, an "imagined fix" is in fact a high-information-density repair sketch that complements the sparse retrieval results from a UB-example library, and broadens the candidate space that the planner can reason over without committing to the imagined patch as ground truth \cite{rag}.

**Observation 3 (Multi-agent decoupling).** Concentrating reflection, planning, and code generation into a single LLM call conflates failure analysis with action selection. Decoupling these into distinct agents — each consuming the previous round's *adjusted constraints* rather than raw error strings — follows the broader finding that language agents benefit from explicit reasoning/action structure and reflection over feedback \cite{repairagent,react,reflexion}.

#### ¶7 — Miragent 流水线总览（配 Figure 2）

> Anchor: S5–S6。用一段话把 v1-1 文档里的四阶段流程压成 ~150 词，让 reviewer 把图和文字对得上。

Building on these observations, we present **Miragent**, a hallucination-augmented multi-agent framework for repairing Rust UB. **Figure 2** sketches the four-stage pipeline. **Stage 1 (Detection)** runs the buggy code through Miri to obtain an executable UB report and through Tree-sitter to obtain an aligned AST, fusing dynamic and structural evidence into a unified context \cite{miri,tree-sitter}. **Stage 2 (Context construction)** uses a *Semantic RAG* module to retrieve UB-typed `(buggy, error, fix)` triples from a curated UB-example library, and a *Hallucination Agent* to synthesise a deliberately imperfect, high-information-density imagined fix that downstream agents use as a contrastive prior \cite{rag,hallucination-survey}. **Stage 3 (Multi-agent repair)** drives a Reflection–Plan–Fix chain: *Reflection* digests the previous Critic feedback into adjusted constraints, *Plan* produces an executable Fix Plan, and *Fix* emits $N$ candidate patches under diverse sampling temperatures \cite{repairagent,reflexion}. **Stage 4 (Multi-dimensional evaluation)** scores each candidate along four axes — Miri (hard constraint), Clippy, an LLM-based semantic-preservation check, and an AST-diff-based minimal-change scorer — and either accepts the best candidate or feeds the failure signals back into Reflection, closing the outer loop until verification succeeds or the iteration budget is exhausted \cite{miri,clippy}.

#### ¶8 — 实验摘要

> Anchor: S7。占位符 + 数据集 + 三类基线，等数字回填。

We evaluate Miragent on **81 real Rust CVEs** (`cve_safe_func`) drawn from the RustSec advisory database and on **65 Miri-detectable synthesized cases** (`cve_safe_func_synth`), covering 11 CWE families ranging from CWE-119 (improper restriction of operations within bounds) to CWE-362 (concurrent execution using shared resource) \cite{miri,rustsec,rust-cve-study}. We compare against three category-leading baselines that we faithfully ported under a unified Miri harness: **Thetis-Lathe** (rule-based, C1), **GiantRepair** (skeleton-guided, C2), and **RustBrain** (agentic, C3) \cite{thetis-lathe,rustbrain,giantrepair}. Across both benchmarks Miragent achieves a **\\([fix\_rate]\%\\)** Miri-verified fix rate, improving over the strongest baseline by **\\([\Delta]\%\\)**, with the largest absolute gains on `data_race`, `use_after_free`, and `uninitialized_memory` categories.

#### ¶9 — Contributions

> Anchor: 新增。4 条 contribution，对应 ICSE 评审最关心的"新颖性 / 严谨性 / 工程价值 / 实证证据"四个维度。

This paper makes the following contributions:

- **A new framing of LLM hallucination for repair.** We introduce *hallucination-as-contrastive-prior*, recasting LLM hallucinations from a failure mode into a deliberately elicited repair sketch that complements semantic retrieval and broadens the candidate space.
- **A Miri-grounded multi-agent UB-repair framework.** Miragent decouples Reflection / Plan / Fix into specialised agents and verifies every candidate against Miri as a hard constraint, with Clippy, semantic-preservation, and minimal-change scorers as soft criteria — the first repair pipeline, to our knowledge, that uses Miri as an *inner-loop* verifier rather than a one-shot oracle.
- **Open evaluation infrastructure.** We release Miragent together with a curated benchmark of 81 real Rust CVEs and 65 synthesized UB cases, and faithful Rust ports of Thetis-Lathe / GiantRepair / RustBrain, enabling comparable future evaluation under a unified Miri harness.
- **Empirical evidence.** On both benchmarks, Miragent improves the Miri-verified fix rate by **\\([\Delta]\%\\)** over the strongest prior baseline, with breakdowns by UB type and ablations confirming the contribution of each design component.

#### ¶10 — Roadmap

> Anchor: 标准 ICSE 收尾句。

The rest of this paper is organized as follows. §2 gives background on Rust UB and Miri; §3 presents the Miragent pipeline in detail; §4 describes the multi-dimensional Critic; §5 reports our experimental setup and results, including ablations; §6 discusses related work; and §7 concludes.

---

## References — IEEE Style (LaTeX bibliography)

\begin{thebibliography}{99}
\bibitem{rust-reference} The Rust Project Developers, ``The Rust reference: Behavior considered undefined.'' [Online]. Available: https://doc.rust-lang.org/reference/behavior-considered-undefined.html. Accessed: Jun. 29, 2026.
\bibitem{rust-nomicon} The Rust Project Developers, \emph{The Rustonomicon}. [Online]. Available: https://doc.rust-lang.org/nomicon/. Accessed: Jun. 29, 2026.
\bibitem{unsafe-code-guidelines} Rust Unsafe Code Guidelines Working Group, ``Unsafe code guidelines reference.'' [Online]. Available: https://rust-lang.github.io/unsafe-code-guidelines/. Accessed: Jun. 29, 2026.
\bibitem{rust-book} S. Klabnik and C. Nichols, \emph{The Rust Programming Language}. No Starch Press, 2019.
\bibitem{rustsec} RustSec Working Group, ``RustSec advisory database.'' [Online]. Available: https://github.com/RustSec/advisory-db. Accessed: Jun. 29, 2026.
\bibitem{cve-program} MITRE Corporation, ``CVE program.'' [Online]. Available: https://www.cve.org/. Accessed: Jun. 29, 2026.
\bibitem{rust-cve-study} H. Xu, Z. Chen, M. Sun, Y. Zhou, and M. R. Lyu, ``Memory-safety challenge considered solved? An in-depth study with all Rust CVEs,'' arXiv:2003.03296, 2020.
\bibitem{unsafe-rust-oopsla} V. Astrauskas, C. Matheja, F. Poli, P. M{\"u}ller, and A. J. Summers, ``How do programmers use unsafe Rust?'' \emph{Proc. ACM Program. Lang.}, vol. 4, no. OOPSLA, Art. no. 136, pp. 1--27, Nov. 2020.
\bibitem{is-rust-used-safely} A. N. Evans, B. Campbell, and M. L. Soffa, ``Is Rust used safely by software developers?'' in \emph{Proc. ACM/IEEE 42nd Int. Conf. Software Engineering (ICSE)}, 2020, pp. 246--257.
\bibitem{rustbelt} R. Jung, J.-H. Jourdan, R. Krebbers, and D. Dreyer, ``RustBelt: Securing the foundations of the Rust programming language,'' \emph{Proc. ACM Program. Lang.}, vol. 2, no. POPL, Art. no. 66, pp. 1--34, Jan. 2018.
\bibitem{stacked-borrows} R. Jung, H.-H. Dang, J. Kang, and D. Dreyer, ``Stacked Borrows: An aliasing model for Rust,'' \emph{Proc. ACM Program. Lang.}, vol. 4, no. POPL, Art. no. 41, pp. 1--32, Jan. 2020.
\bibitem{oxide} A. Weiss, O. Patterson, N. D. Matsakis, and A. Ahmed, ``Oxide: The essence of Rust,'' arXiv:1903.00982, 2019.
\bibitem{rudra} Y. Bae, Y. Kim, A. Askar, J. Lim, and T. Kim, ``Rudra: Finding memory safety bugs in Rust at the ecosystem scale,'' in \emph{Proc. 28th ACM Symp. Operating Systems Principles (SOSP)}, 2021, pp. 84--99.
\bibitem{thetis-lathe} R. Jiang, P. Dong, Y. Ding, R. Wei, and Z. Jiang, ``Thetis-lathe: Guidance on reducing residual safety obstacle in system software from Rust source codes,'' \emph{ACM Trans. Embedded Comput. Syst.}, vol. 24, no. 4, Art. no. 56, pp. 1--25, Jul. 2025.
\bibitem{safedrop} M. Cui, C. Chen, H. Xu, and Y. Zhou, ``SafeDrop: Detecting memory deallocation bugs of Rust programs via static data-flow analysis,'' arXiv:2103.15420, 2021.
\bibitem{rustassistant} P. Deligiannis, A. Lal, N. Mehrotra, R. Poddar, and A. Rastogi, ``Fixing Rust compilation errors using LLMs,'' arXiv:2308.05177, 2023.
\bibitem{rustbrain} R. Jiang, P. Dong, Z. Duan, Y. Shi, X. Fang, Y. Ding, J. Ma, S. Zhao, and Z. Jiang, ``Unlocking a new Rust programming experience: Fast and slow thinking with LLMs to conquer undefined behaviors,'' arXiv:2503.02335, 2025.
\bibitem{akirarust} R. Jiang, Y. Wang, P. Dong, X. Fang, Z. Duan, T. Wang, Y. Hu, J. Yu, and Z. Jiang, ``AkiraRust: Re-thinking LLM-aided Rust repair using a feedback-guided thinking switch,'' arXiv:2602.21681, 2026.
\bibitem{genprog} C. Le Goues, T. Nguyen, S. Forrest, and W. Weimer, ``GenProg: A generic method for automatic software repair,'' \emph{IEEE Trans. Softw. Eng.}, vol. 38, no. 1, pp. 54--72, 2012.
\bibitem{prophet} F. Long and M. Rinard, ``Automatic patch generation by learning correct code,'' in \emph{Proc. ACM SIGPLAN-SIGACT Symp. Principles of Programming Languages (POPL)}, 2016, pp. 298--312.
\bibitem{semfix} H. D. T. Nguyen, D. Qi, A. Roychoudhury, and S. Chandra, ``SemFix: Program repair via semantic analysis,'' in \emph{Proc. 35th Int. Conf. Software Engineering (ICSE)}, 2013, pp. 772--781.
\bibitem{angelix} S. Mechtaev, J. Yi, and A. Roychoudhury, ``Angelix: Scalable multiline program patch synthesis via symbolic analysis,'' in \emph{Proc. 38th Int. Conf. Software Engineering (ICSE)}, 2016, pp. 691--701.
\bibitem{tbar} K. Liu, A. Koyuncu, D. Kim, and T. F. Bissyand{\'e}, ``TBar: Revisiting template-based automated program repair,'' \emph{ACM Trans. Softw. Eng. Methodol.}, vol. 29, no. 3, Art. no. 15, pp. 1--35, 2020.
\bibitem{recoder} Q. Zhu, Z. Sun, Y.-a. Xiao, W. Zhang, K. Yuan, Y. Xiong, and L. Zhang, ``A syntax-guided edit decoder for neural program repair,'' in \emph{Proc. 29th ACM Joint Eur. Software Engineering Conf. and Symp. Foundations of Software Engineering (ESEC/FSE)}, 2021, pp. 341--353.
\bibitem{cure} N. Jiang, T. Lutellier, and L. Tan, ``CURE: Code-aware neural machine translation for automatic program repair,'' in \emph{Proc. IEEE/ACM 43rd Int. Conf. Software Engineering (ICSE)}, 2021, pp. 1161--1173.
\bibitem{alpharepair} C. S. Xia and L. Zhang, ``Less training, more repairing please: Revisiting automated program repair via zero-shot learning,'' in \emph{Proc. ACM Joint Eur. Software Engineering Conf. and Symp. Foundations of Software Engineering (ESEC/FSE)}, 2022, pp. 959--971.
\bibitem{giantrepair} F. Li, J. Jiang, J. Sun, and H. Zhang, ``Hybrid automated program repair by combining large language models and program analysis,'' \emph{ACM Trans. Softw. Eng. Methodol.}, vol. 34, no. 7, Art. no. 202, pp. 1--28, 2025.
\bibitem{empirical-llm-apr} C. S. Xia, Y. Wei, and L. Zhang, ``Automated program repair in the era of large pre-trained language models,'' in \emph{Proc. IEEE/ACM 45th Int. Conf. Software Engineering (ICSE)}, 2023, pp. 1482--1494.
\bibitem{repairagent} I. Bouzenia, P. Devanbu, and M. Pradel, ``RepairAgent: An autonomous, LLM-based agent for program repair,'' arXiv:2403.17134, 2024.
\bibitem{swe-agent} J. Yang, C. E. Jimenez, A. Wettig, K. Lieret, S. Yao, K. Narasimhan, and O. Press, ``SWE-agent: Agent-computer interfaces enable automated software engineering,'' arXiv:2405.15793, 2024.
\bibitem{autocoder} Y. Zhang, H. Ruan, Z. Fan, and A. Roychoudhury, ``AutoCodeRover: Autonomous program improvement,'' arXiv:2404.05427, 2024.
\bibitem{react} S. Yao, J. Zhao, D. Yu, N. Du, I. Shafran, K. Narasimhan, and Y. Cao, ``ReAct: Synergizing reasoning and acting in language models,'' in \emph{Proc. Int. Conf. Learning Representations (ICLR)}, 2023.
\bibitem{reflexion} N. Shinn, F. Cassano, E. Berman, A. Gopinath, K. Narasimhan, and S. Yao, ``Reflexion: Language agents with verbal reinforcement learning,'' in \emph{Advances in Neural Information Processing Systems}, 2023.
\bibitem{rag} P. Lewis \emph{et al.}, ``Retrieval-augmented generation for knowledge-intensive NLP tasks,'' in \emph{Advances in Neural Information Processing Systems}, vol. 33, 2020, pp. 9459--9474.
\bibitem{hallucination-survey} Z. Ji \emph{et al.}, ``Survey of hallucination in natural language generation,'' \emph{ACM Comput. Surv.}, vol. 55, no. 12, Art. no. 248, pp. 1--38, 2023.
\bibitem{codex} M. Chen \emph{et al.}, ``Evaluating large language models trained on code,'' arXiv:2107.03374, 2021.
\bibitem{defects4j} R. Just, D. Jalali, and M. D. Ernst, ``Defects4J: A database of existing faults to enable controlled testing studies for Java programs,'' in \emph{Proc. Int. Symp. Software Testing and Analysis (ISSTA)}, 2014, pp. 437--440.
\bibitem{apr-overfitting} X. B. D. Le, D. Lo, and C. Le Goues, ``Overfitting in semantics-based automated program repair,'' \emph{Empirical Software Engineering}, vol. 23, no. 5, pp. 3007--3033, 2018.
\bibitem{patch-correctness} Z. Qi, F. Long, S. Achour, and M. Rinard, ``An analysis of patch plausibility and correctness for generate-and-validate patch generation systems,'' in \emph{Proc. Int. Symp. Software Testing and Analysis (ISSTA)}, 2015, pp. 24--36.
\bibitem{getafix} J. Bader, A. Scott, M. Pradel, and S. Chandra, ``Getafix: Learning to fix bugs automatically,'' \emph{Proc. ACM Program. Lang.}, vol. 3, no. OOPSLA, Art. no. 159, pp. 1--27, 2019.
\bibitem{sequencer} Z. Chen, S. Kommrusch, M. Monperrus, and M. Tufano, ``SequenceR: Sequence-to-sequence learning for end-to-end program repair,'' \emph{IEEE Trans. Softw. Eng.}, vol. 47, no. 9, pp. 1943--1959, 2021.
\bibitem{tree-sitter} Tree-sitter Project, ``Tree-sitter: Introduction.'' [Online]. Available: https://tree-sitter.github.io/tree-sitter/. Accessed: Jun. 29, 2026.
\bibitem{miri} The Rust Project Developers, ``Miri: An interpreter for Rust's mid-level intermediate representation.'' [Online]. Available: https://github.com/rust-lang/miri. Accessed: Jun. 29, 2026.
\bibitem{clippy} The Rust Project Developers, ``Clippy documentation.'' [Online]. Available: https://doc.rust-lang.org/clippy/. Accessed: Jun. 29, 2026.
\bibitem{cve-2021-26953} MITRE Corporation, ``CVE-2021-26953.'' [Online]. Available: https://www.cve.org/CVERecord?id=CVE-2021-26953. Accessed: Jun. 29, 2026.
\bibitem{program-slicing} M. Weiser, ``Program slicing,'' in \emph{Proc. 5th Int. Conf. Software Engineering (ICSE)}, 1981, pp. 439--449.
\bibitem{static-analysis} F. Nielson, H. R. Nielson, and C. Hankin, \emph{Principles of Program Analysis}. Berlin, Germany: Springer, 1999.
\bibitem{libfuzzer} LLVM Project, ``libFuzzer: A library for coverage-guided fuzz testing.'' [Online]. Available: https://llvm.org/docs/LibFuzzer.html. Accessed: Jun. 29, 2026.
\bibitem{afl} M. Zalewski, ``American fuzzy lop.'' [Online]. Available: https://lcamtuf.coredump.cx/afl/. Accessed: Jun. 29, 2026.
\bibitem{quickcheck} K. Claessen and J. Hughes, ``QuickCheck: A lightweight tool for random testing of Haskell programs,'' in \emph{Proc. ACM SIGPLAN Int. Conf. Functional Programming (ICFP)}, 2000, pp. 268--279.
\bibitem{klee} C. Cadar, D. Dunbar, and D. Engler, ``KLEE: Unassisted and automatic generation of high-coverage tests for complex systems programs,'' in \emph{Proc. USENIX Symp. Operating Systems Design and Implementation (OSDI)}, 2008, pp. 209--224.
\bibitem{asan} K. Serebryany, D. Bruening, A. Potapenko, and D. Vyukov, ``AddressSanitizer: A fast address sanity checker,'' in \emph{Proc. USENIX Annu. Tech. Conf. (USENIX ATC)}, 2012, pp. 309--318.
\bibitem{ubsan} LLVM Project, ``UndefinedBehaviorSanitizer.'' [Online]. Available: https://clang.llvm.org/docs/UndefinedBehaviorSanitizer.html. Accessed: Jun. 29, 2026.
\bibitem{verus} A. Lattuada, T. Hance, C. Cho, M. Brun, I. Subasinghe, Y. Zhou, J. Howell, B. Parno, and C. Hawblitzel, ``Verus: Verifying Rust programs using linear ghost types,'' \emph{Proc. ACM Program. Lang.}, vol. 7, no. OOPSLA1, Art. no. 85, pp. 286--315, 2023.
\bibitem{flux} Flux Developers, ``Flux: Liquid types for Rust.'' [Online]. Available: https://flux-rs.github.io/flux/. Accessed: Jun. 29, 2026.
\bibitem{kani} Amazon Web Services, ``Kani Rust verifier.'' [Online]. Available: https://model-checking.github.io/kani/. Accessed: Jun. 29, 2026.
\bibitem{cruxmir} Galois, Inc., ``Crux-MIR.'' [Online]. Available: https://github.com/GaloisInc/crucible/tree/master/crux-mir. Accessed: Jun. 29, 2026.
\end{thebibliography}
