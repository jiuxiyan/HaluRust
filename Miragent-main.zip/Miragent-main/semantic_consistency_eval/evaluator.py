"""End-to-end semantic-consistency evaluator.

Combines the four dimensions defined in this package:

- ``D1`` API surface preservation (:func:`static_metrics.api_surface_score`)
- ``D2`` trivialization detection (:func:`static_metrics.trivialization_score`)
- ``D3`` AST structural similarity
  (:func:`static_metrics.structural_similarity_score`)
- ``D4`` LLM judge (:class:`llm_judge.LLMJudge`)

into a single per-case evaluation, plus aggregated metrics per
baseline:

- **Fix Rate (FR)**       — already reported by every baseline.
- **Semantic Consistency Rate (SCR)** — fraction of *fixed* cases that
  pass the semantic-preservation threshold.
- **Effective Fix Rate (EFR)** = FR × SCR — fraction of *all* cases
  that are both UB-clean and semantically alive.
"""

from __future__ import annotations

import json
import logging
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Iterable, Optional

from .adapters import CaseInput, iter_cases
from .llm_judge import JudgeResult, JudgeVerdict, LLMJudge
from .static_metrics import (
    APISurfaceReport,
    TrivializationReport,
    api_surface_score,
    structural_similarity_score,
    trivialization_score,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------


@dataclass
class ScoreWeights:
    api: float = 0.20
    trivialization: float = 0.30
    structural: float = 0.15
    judge: float = 0.35

    def composite(
        self, *, d1: float, d2: float, d3: float, d4: float
    ) -> float:
        total_w = self.api + self.trivialization + self.structural + self.judge
        if total_w <= 0:
            return 0.0
        return (
            self.api * d1
            + self.trivialization * d2
            + self.structural * d3
            + self.judge * d4
        ) / total_w


@dataclass
class PreservationThreshold:
    composite_min: float = 0.6
    trivialization_min: float = 0.5
    forbidden_verdicts: tuple[str, ...] = ("broken",)


# ---------------------------------------------------------------------------
# Per-case + per-baseline records
# ---------------------------------------------------------------------------


@dataclass
class CaseEvaluation:
    cve_id: str
    cwe: str
    fix_succeeded: bool
    has_fixed_code: bool
    miri_kind: str

    api_score: float = 0.0
    api_report: Optional[APISurfaceReport] = None

    trivialization_score: float = 1.0
    trivialization_report: Optional[TrivializationReport] = None

    structural_score: float = 1.0

    judge_score: float = 0.5
    judge_result: Optional[JudgeResult] = None

    composite_score: float = 0.0
    semantically_preserved: bool = False
    duration_s: float = 0.0
    error: str = ""

    def to_dict(self) -> dict:
        return {
            "cve_id": self.cve_id,
            "cwe": self.cwe,
            "fix_succeeded": self.fix_succeeded,
            "has_fixed_code": self.has_fixed_code,
            "miri_kind": self.miri_kind,
            "api_score": self.api_score,
            "api_report": asdict(self.api_report) if self.api_report else None,
            "trivialization_score": self.trivialization_score,
            "trivialization_report": asdict(self.trivialization_report)
            if self.trivialization_report
            else None,
            "structural_score": self.structural_score,
            "judge_score": self.judge_score,
            "judge_result": self.judge_result.to_dict() if self.judge_result else None,
            "composite_score": self.composite_score,
            "semantically_preserved": self.semantically_preserved,
            "duration_s": self.duration_s,
            "error": self.error,
        }


@dataclass
class BaselineEvaluation:
    label: str
    results_dir: str
    layout: str

    total: int = 0
    fixed: int = 0
    fixed_and_preserved: int = 0

    fix_rate: float = 0.0
    scr: float = 0.0  # semantic consistency rate among fixes
    efr: float = 0.0  # effective fix rate = fixed_and_preserved / total

    avg_api: float = 0.0
    avg_trivialization: float = 0.0
    avg_structural: float = 0.0
    avg_judge: float = 0.0
    avg_composite: float = 0.0

    verdict_counts: dict[str, int] = field(default_factory=dict)
    cases: list[CaseEvaluation] = field(default_factory=list)

    def to_summary_dict(self) -> dict:
        return {
            "label": self.label,
            "results_dir": self.results_dir,
            "layout": self.layout,
            "total": self.total,
            "fixed": self.fixed,
            "fixed_and_preserved": self.fixed_and_preserved,
            "fix_rate": self.fix_rate,
            "scr": self.scr,
            "efr": self.efr,
            "avg_api": self.avg_api,
            "avg_trivialization": self.avg_trivialization,
            "avg_structural": self.avg_structural,
            "avg_judge": self.avg_judge,
            "avg_composite": self.avg_composite,
            "verdict_counts": self.verdict_counts,
        }


# ---------------------------------------------------------------------------
# Evaluator
# ---------------------------------------------------------------------------


class SemanticEvaluator:
    """Run all four dimensions on a result directory and aggregate."""

    def __init__(
        self,
        *,
        judge: Optional[LLMJudge],
        weights: Optional[ScoreWeights] = None,
        threshold: Optional[PreservationThreshold] = None,
        only_fixed: bool = True,
        concurrency: int = 4,
    ):
        self._judge = judge
        self._weights = weights or ScoreWeights()
        self._threshold = threshold or PreservationThreshold()
        self._only_fixed = only_fixed
        self._concurrency = max(1, concurrency)

    # ----- per-case -----------------------------------------------

    def evaluate_case(self, case: CaseInput) -> CaseEvaluation:
        t0 = time.time()
        ev = CaseEvaluation(
            cve_id=case.cve_id,
            cwe=case.cwe,
            fix_succeeded=case.fix_succeeded,
            has_fixed_code=bool(case.fixed.strip()),
            miri_kind=case.miri_kind,
        )

        try:
            if not case.original.strip() or not case.fixed.strip():
                ev.error = "missing original or fixed source"
                ev.duration_s = round(time.time() - t0, 2)
                return ev

            api = api_surface_score(case.original, case.fixed)
            ev.api_report = api
            ev.api_score = api.score

            triv = trivialization_score(case.original, case.fixed)
            ev.trivialization_report = triv
            ev.trivialization_score = triv.score

            ev.structural_score = structural_similarity_score(
                case.original, case.fixed
            )

            if self._judge is not None:
                jr = self._judge.judge(
                    cve_id=case.cve_id,
                    cwe=case.cwe,
                    cve_description=case.cve_description,
                    original=case.original,
                    fixed=case.fixed,
                    test=case.test,
                    miri_kind=case.miri_kind,
                )
                ev.judge_result = jr
                ev.judge_score = jr.preservation_score
            else:
                ev.judge_score = 0.5  # neutral when judge disabled

            ev.composite_score = self._weights.composite(
                d1=ev.api_score,
                d2=ev.trivialization_score,
                d3=ev.structural_score,
                d4=ev.judge_score,
            )

            verdict = (
                ev.judge_result.verdict.value if ev.judge_result else None
            )
            ev.semantically_preserved = (
                ev.composite_score >= self._threshold.composite_min
                and ev.trivialization_score >= self._threshold.trivialization_min
                and (verdict is None or verdict not in self._threshold.forbidden_verdicts)
            )
        except Exception as e:  # noqa: BLE001
            logger.exception("Failed to evaluate %s", case.cve_id)
            ev.error = str(e)[:500]

        ev.duration_s = round(time.time() - t0, 2)
        return ev

    # ----- per-baseline -------------------------------------------

    def evaluate_baseline(
        self,
        *,
        label: str,
        results_dir: Path,
        repo_root: Path,
        layout: Optional[str] = None,
        fallback_synth_root: Optional[Path] = None,
        progress_cb=None,
    ) -> BaselineEvaluation:
        cases = list(
            iter_cases(
                results_dir,
                repo_root=repo_root,
                layout=layout,
                fallback_synth_root=fallback_synth_root,
            )
        )

        targets = (
            [c for c in cases if c.fix_succeeded] if self._only_fixed else cases
        )
        evs_by_id: dict[str, CaseEvaluation] = {}

        def _wrap(c: CaseInput) -> CaseEvaluation:
            return self.evaluate_case(c)

        if self._concurrency == 1 or self._judge is None:
            for c in targets:
                ev = _wrap(c)
                evs_by_id[c.cve_id] = ev
                if progress_cb:
                    progress_cb(label, ev)
        else:
            with ThreadPoolExecutor(max_workers=self._concurrency) as ex:
                futs = {ex.submit(_wrap, c): c for c in targets}
                for f in as_completed(futs):
                    ev = f.result()
                    evs_by_id[ev.cve_id] = ev
                    if progress_cb:
                        progress_cb(label, ev)

        # Add zero-rows for unfixed cases so denominators are correct.
        all_evs: list[CaseEvaluation] = []
        for c in cases:
            ev = evs_by_id.get(c.cve_id)
            if ev is None:
                ev = CaseEvaluation(
                    cve_id=c.cve_id,
                    cwe=c.cwe,
                    fix_succeeded=c.fix_succeeded,
                    has_fixed_code=bool(c.fixed.strip()),
                    miri_kind=c.miri_kind,
                    semantically_preserved=False,
                    composite_score=0.0,
                )
            all_evs.append(ev)

        return self._aggregate(label, results_dir, layout or "auto", all_evs)

    # ----- aggregation --------------------------------------------

    def _aggregate(
        self,
        label: str,
        results_dir: Path,
        layout: str,
        evs: list[CaseEvaluation],
    ) -> BaselineEvaluation:
        total = len(evs)
        fixed_evs = [e for e in evs if e.fix_succeeded]
        n_fixed = len(fixed_evs)
        preserved_evs = [
            e for e in fixed_evs if e.semantically_preserved
        ]
        n_pres = len(preserved_evs)

        verdict_counts: dict[str, int] = {}
        for e in fixed_evs:
            v = e.judge_result.verdict.value if e.judge_result else "n/a"
            verdict_counts[v] = verdict_counts.get(v, 0) + 1

        def _avg(seq: list[float]) -> float:
            return sum(seq) / len(seq) if seq else 0.0

        return BaselineEvaluation(
            label=label,
            results_dir=str(results_dir),
            layout=layout,
            total=total,
            fixed=n_fixed,
            fixed_and_preserved=n_pres,
            fix_rate=n_fixed / total if total else 0.0,
            scr=n_pres / n_fixed if n_fixed else 0.0,
            efr=n_pres / total if total else 0.0,
            avg_api=_avg([e.api_score for e in fixed_evs]),
            avg_trivialization=_avg([e.trivialization_score for e in fixed_evs]),
            avg_structural=_avg([e.structural_score for e in fixed_evs]),
            avg_judge=_avg([e.judge_score for e in fixed_evs]),
            avg_composite=_avg([e.composite_score for e in fixed_evs]),
            verdict_counts=verdict_counts,
            cases=evs,
        )


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------


def write_baseline_artifacts(eval_: BaselineEvaluation, out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    per_case_dir = out_dir / "per_case_semantic"
    per_case_dir.mkdir(parents=True, exist_ok=True)
    for ev in eval_.cases:
        (per_case_dir / f"{ev.cve_id}.json").write_text(
            json.dumps(ev.to_dict(), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    summary = eval_.to_summary_dict()
    summary["cases"] = [
        {
            "cve_id": e.cve_id,
            "cwe": e.cwe,
            "fix_succeeded": e.fix_succeeded,
            "semantically_preserved": e.semantically_preserved,
            "composite_score": round(e.composite_score, 3),
            "api_score": round(e.api_score, 3),
            "trivialization_score": round(e.trivialization_score, 3),
            "structural_score": round(e.structural_score, 3),
            "judge_score": round(e.judge_score, 3),
            "judge_verdict": e.judge_result.verdict.value
            if e.judge_result
            else "n/a",
        }
        for e in eval_.cases
    ]
    (out_dir / "summary_semantic.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def write_comparison_table(
    evals: Iterable[BaselineEvaluation], out_path: Path
) -> None:
    """Write a Markdown comparison table for the multiple-baseline view."""
    rows = list(evals)
    lines = [
        "# Semantic Consistency Evaluation — comparison",
        "",
        "| baseline | n | fixed | fix_rate | preserved | SCR | EFR | "
        "avg D1 (API) | avg D2 (triv) | avg D3 (AST) | avg D4 (judge) | "
        "avg composite |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for r in rows:
        lines.append(
            "| {label} | {n} | {fixed} | {fr:.3f} | {pres} | {scr:.3f} | "
            "{efr:.3f} | {api:.3f} | {triv:.3f} | {struct:.3f} | "
            "{judge:.3f} | {comp:.3f} |".format(
                label=r.label,
                n=r.total,
                fixed=r.fixed,
                fr=r.fix_rate,
                pres=r.fixed_and_preserved,
                scr=r.scr,
                efr=r.efr,
                api=r.avg_api,
                triv=r.avg_trivialization,
                struct=r.avg_structural,
                judge=r.avg_judge,
                comp=r.avg_composite,
            )
        )
    lines.append("")
    lines.append("Verdict breakdown (LLM judge, fixed cases only):")
    lines.append("")
    lines.append("| baseline | preserved | minor_change | weakened | broken | error |")
    lines.append("|---|---:|---:|---:|---:|---:|")
    for r in rows:
        v = r.verdict_counts
        lines.append(
            "| {label} | {p} | {m} | {w} | {b} | {e} |".format(
                label=r.label,
                p=v.get("preserved", 0),
                m=v.get("minor_change", 0),
                w=v.get("weakened", 0),
                b=v.get("broken", 0),
                e=v.get("error", 0) + v.get("n/a", 0),
            )
        )
    out_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
