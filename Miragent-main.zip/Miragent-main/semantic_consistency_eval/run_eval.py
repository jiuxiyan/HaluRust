"""Command-line entry point for Semantic Consistency Evaluation.

Examples
--------

Evaluate one baseline (auto-detect its layout)::

    python -m semantic_consistency_eval \\
        --result thetis-lathe:thetis-lathe_baseline/results/cve_safe_func_deepseek \\
        --judge-model gemini-3-flash \\
        --out-dir semantic_eval_results/deepseek/thetis-lathe

Compare all four baselines in one run, writing a Markdown table::

    python -m semantic_consistency_eval \\
        --result halurust:cve_safe_func_fixed_deepseek \\
        --result thetis-lathe:thetis-lathe_baseline/results/cve_safe_func_deepseek \\
        --result rustbrain:rustbrain_baseline/results/cve_safe_func_deepseek \\
        --result giantrepair:giantrepair_baseline/results/cve_safe_func_synth_deepseek \\
        --judge-model gemini-3-flash \\
        --out-dir semantic_eval_results/deepseek

Skip the LLM judge (fast static-only sanity pass)::

    python -m semantic_consistency_eval \\
        --result thetis-lathe:thetis-lathe_baseline/results/cve_safe_func_deepseek \\
        --no-judge \\
        --out-dir semantic_eval_results/static-only/thetis-lathe
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path
from typing import Optional

try:
    from dotenv import load_dotenv  # type: ignore

    load_dotenv()
except ImportError:
    pass

from .evaluator import (
    BaselineEvaluation,
    PreservationThreshold,
    ScoreWeights,
    SemanticEvaluator,
    write_baseline_artifacts,
    write_comparison_table,
)
from .llm_judge import JudgeConfig, LLMJudge

logger = logging.getLogger("semantic_consistency_eval")


def _parse_result_arg(arg: str) -> tuple[str, Path]:
    if ":" not in arg:
        raise argparse.ArgumentTypeError(
            f"--result expects 'label:path', got {arg!r}"
        )
    label, raw_path = arg.split(":", 1)
    return label.strip(), Path(raw_path).expanduser().resolve()


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        prog="semantic_consistency_eval",
        description=(
            "Run Semantic Consistency Evaluation (D1+D2+D3+D4) on one or more "
            "baseline result directories. Produces summary_semantic.json per "
            "baseline and a comparison Markdown when more than one baseline is "
            "provided."
        ),
    )
    parser.add_argument(
        "--result",
        action="append",
        type=_parse_result_arg,
        required=True,
        metavar="LABEL:PATH",
        help=(
            "Repeatable. Example: "
            "--result thetis-lathe:thetis-lathe_baseline/results/cve_safe_func_deepseek"
        ),
    )
    parser.add_argument(
        "--out-dir", type=Path, required=True, help="Where to write artifacts."
    )
    parser.add_argument(
        "--repo-root",
        type=Path,
        default=Path(__file__).resolve().parent.parent,
        help="Halurust_1 repo root (used to locate cve_safe_func/* markdowns).",
    )
    parser.add_argument(
        "--fallback-synth-root",
        type=Path,
        default=None,
        help=(
            "Used when a baseline's per_case/ exists but its synth/ directory "
            "is missing — typically point this at cve_safe_func_synth/."
        ),
    )
    parser.add_argument(
        "--layout",
        choices=("synth", "halurust", "miri", "auto"),
        default="auto",
        help="Override the auto-detected results-dir layout.",
    )
    parser.add_argument(
        "--no-judge",
        action="store_true",
        help="Skip the LLM judge dimension (D4). D1+D2+D3 only.",
    )
    parser.add_argument(
        "--judge-model",
        default=None,
        help=(
            "Override JUDGE_MODEL/MODEL for the judge call. Recommended: a "
            "different vendor than the model that produced the fix."
        ),
    )
    parser.add_argument(
        "--include-unfixed",
        action="store_true",
        help=(
            "Run D1-D4 on unfixed cases too. Default only evaluates cases the "
            "baseline marked as fixed (since SCR is conditional on fixed)."
        ),
    )
    parser.add_argument(
        "--concurrency",
        type=int,
        default=4,
        help="Threaded concurrency for the judge calls.",
    )
    parser.add_argument(
        "--w-api", type=float, default=0.20, help="Weight for D1 (API).",
    )
    parser.add_argument(
        "--w-triv",
        type=float,
        default=0.30,
        help="Weight for D2 (trivialization).",
    )
    parser.add_argument(
        "--w-struct",
        type=float,
        default=0.15,
        help="Weight for D3 (AST similarity).",
    )
    parser.add_argument(
        "--w-judge", type=float, default=0.35, help="Weight for D4 (LLM judge).",
    )
    parser.add_argument(
        "--composite-threshold",
        type=float,
        default=0.6,
        help="Composite score below this -> not preserved.",
    )
    parser.add_argument(
        "--triv-threshold",
        type=float,
        default=0.5,
        help="D2 below this -> not preserved.",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Stream per-case progress lines.",
    )
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=logging.INFO if args.verbose else logging.WARNING,
        format="%(asctime)s %(levelname)s %(name)s | %(message)s",
    )

    args.out_dir.mkdir(parents=True, exist_ok=True)

    judge: Optional[LLMJudge] = None
    if not args.no_judge:
        cfg = JudgeConfig.from_env(model_override=args.judge_model)
        logger.info("Using judge model: %s", cfg.model)
        judge = LLMJudge(cfg)

    evaluator = SemanticEvaluator(
        judge=judge,
        weights=ScoreWeights(
            api=args.w_api,
            trivialization=args.w_triv,
            structural=args.w_struct,
            judge=args.w_judge,
        ),
        threshold=PreservationThreshold(
            composite_min=args.composite_threshold,
            trivialization_min=args.triv_threshold,
        ),
        only_fixed=not args.include_unfixed,
        concurrency=args.concurrency,
    )

    def _progress(label: str, ev) -> None:
        if not args.verbose:
            return
        v = ev.judge_result.verdict.value if ev.judge_result else "n/a"
        marker = "OK" if ev.semantically_preserved else "--"
        print(
            f"[{label}] {marker} {ev.cve_id} composite={ev.composite_score:.2f} "
            f"D1={ev.api_score:.2f} D2={ev.trivialization_score:.2f} "
            f"D3={ev.structural_score:.2f} D4={ev.judge_score:.2f} "
            f"verdict={v}",
            flush=True,
        )

    evals: list[BaselineEvaluation] = []
    layout_arg = None if args.layout == "auto" else args.layout
    for label, path in args.result:
        if not path.exists():
            print(f"warn: results dir does not exist: {path}", file=sys.stderr)
            continue
        print(f"==> Evaluating baseline {label!r}: {path}", flush=True)
        eval_ = evaluator.evaluate_baseline(
            label=label,
            results_dir=path,
            repo_root=args.repo_root.resolve(),
            layout=layout_arg,
            fallback_synth_root=args.fallback_synth_root,
            progress_cb=_progress,
        )
        evals.append(eval_)
        out_dir = args.out_dir / _safe_label(label)
        write_baseline_artifacts(eval_, out_dir)
        print(
            f"    total={eval_.total}  fixed={eval_.fixed}  "
            f"preserved={eval_.fixed_and_preserved}  "
            f"FR={eval_.fix_rate:.3f}  SCR={eval_.scr:.3f}  EFR={eval_.efr:.3f}",
            flush=True,
        )

    if len(evals) >= 2:
        write_comparison_table(evals, args.out_dir / "comparison.md")
        print(f"==> Wrote comparison table → {args.out_dir / 'comparison.md'}")

    return 0 if evals else 1


def _safe_label(label: str) -> str:
    out = []
    for ch in label:
        if ch.isalnum() or ch in "-_.":
            out.append(ch)
        else:
            out.append("_")
    return "".join(out) or "baseline"


if __name__ == "__main__":
    sys.exit(main())
