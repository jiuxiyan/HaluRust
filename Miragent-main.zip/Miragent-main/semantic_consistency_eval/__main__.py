"""Allow ``python -m semantic_consistency_eval ...``."""

from .run_eval import main

raise SystemExit(main())
