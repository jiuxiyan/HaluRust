"""Read result directories of every baseline + the halurust pipeline.

Every adapter yields :class:`CaseInput` records — a uniform tuple of
``(cve_id, cwe, miri_kind, original_source, fixed_source, test_code,
cve_description, fix_succeeded)`` — so the evaluator can stay agnostic
of which framework produced the fix.

Layouts we support:

================== =================================================== =============================
 layout name        directory shape                                       used by
================== =================================================== =============================
 ``synth``          ``synth/<cve>.source.rs`` + ``synth/<cve>.test.rs``  thetis-lathe, rustbrain,
                    + ``fixed/<cve>.rs`` + ``per_case/<cve>.json``       giantrepair (synth runners)
 ``halurust``       ``<cve>/result.json``  + ``<cve>/<cve>_last.rs``     halurust per-CVE results
                    (fall back to ``cve_safe_func_synth*`` for           (``cve_safe_func_fixed*``)
                    source/test if absent inside the case dir)
================== =================================================== =============================
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator, Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Public data
# ---------------------------------------------------------------------------


@dataclass
class CaseInput:
    cve_id: str
    cwe: str
    miri_kind: str
    original: str
    fixed: str
    test: str
    cve_description: str
    fix_succeeded: bool


# ---------------------------------------------------------------------------
# CVE description loader (shared)
# ---------------------------------------------------------------------------


_DESC_HEADER_RE = re.compile(r"^##\s*Description\s*$", re.IGNORECASE | re.MULTILINE)


def _load_cve_description(cve_id: str, repo_root: Path) -> str:
    """Try repo-root ``cve_safe_func/<cve>/<cve_id>.md`` first, then any \
markdown inside ``cve_safe_func*/<cve>/``. Extract the section under \
``## Description``; fall back to the whole markdown."""
    candidates = [
        repo_root / "cve_safe_func" / cve_id,
        repo_root / "cve_safe_func_without_data_race" / cve_id,
        repo_root / "cve_safe_func_ffi_related" / cve_id,
    ]
    for c in candidates:
        if not c.is_dir():
            continue
        for md in c.glob("*.md"):
            text = md.read_text(encoding="utf-8", errors="replace")
            return _extract_description(text)
    return ""


def _extract_description(md: str) -> str:
    m = _DESC_HEADER_RE.search(md)
    if not m:
        return md.strip()[:1500]
    rest = md[m.end():]
    nxt = re.search(r"^##\s+", rest, re.MULTILINE)
    section = rest[: nxt.start()] if nxt else rest
    return section.strip()


# ---------------------------------------------------------------------------
# Synth-style adapter (thetis-lathe / rustbrain / giantrepair)
# ---------------------------------------------------------------------------


def iter_synth_layout(
    results_dir: Path, *, repo_root: Path, fallback_synth_root: Optional[Path] = None
) -> Iterator[CaseInput]:
    per_case_dir = results_dir / "per_case"
    fixed_dir = results_dir / "fixed"
    synth_dir = results_dir / "synth"
    if not per_case_dir.is_dir():
        raise FileNotFoundError(f"{per_case_dir} not found")

    for case_json in sorted(per_case_dir.glob("CVE-*.json")):
        cve_id = case_json.stem
        try:
            rec = json.loads(case_json.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as e:
            logger.warning("Skipping %s: %s", case_json, e)
            continue

        cwe = rec.get("cwe", "")
        pipe = rec.get("pipeline") or {}
        miri_kind = pipe.get("initial_ub_kind") or rec.get("initial_ub_kind", "")
        succeeded = bool(
            pipe.get("succeeded")
            or rec.get("succeeded")
            or rec.get("final_status") == "fixed"
        )

        # Source / test
        source_path = synth_dir / f"{cve_id}.source.rs"
        test_path = synth_dir / f"{cve_id}.test.rs"
        if (not source_path.exists() or not test_path.exists()) and fallback_synth_root:
            source_path = fallback_synth_root / cve_id / "source.rs"
            test_path = fallback_synth_root / cve_id / "test.rs"
        original = _safe_read(source_path)
        test = _safe_read(test_path)

        # Fixed file
        fixed_path = fixed_dir / f"{cve_id}.rs"
        fixed = _safe_read(fixed_path)
        if not fixed and not succeeded:
            # No fixed file produced (timeout / pipeline_error). We still
            # emit the case but mark it unfixed; D2 won't be meaningful.
            fixed = ""

        cve_description = _load_cve_description(cve_id, repo_root)

        yield CaseInput(
            cve_id=cve_id,
            cwe=cwe,
            miri_kind=miri_kind or "unknown",
            original=original,
            fixed=fixed,
            test=test,
            cve_description=cve_description,
            fix_succeeded=succeeded,
        )


# ---------------------------------------------------------------------------
# Halurust-style adapter
# ---------------------------------------------------------------------------


def iter_halurust_layout(
    results_dir: Path,
    *,
    repo_root: Path,
    synth_root_hint: Optional[Path] = None,
) -> Iterator[CaseInput]:
    """Halurust writes one directory per CVE under ``cve_safe_func_fixed*/``."""
    if not results_dir.is_dir():
        raise FileNotFoundError(f"{results_dir} not found")

    # Best-effort detection of the synth root that holds source.rs / test.rs.
    candidate_synth_roots = [
        synth_root_hint,
        repo_root / "cve_safe_func_synth_without_data_race",
        repo_root / "cve_safe_func_synth",
    ]
    synth_roots = [p for p in candidate_synth_roots if p and p.is_dir()]

    for case_dir in sorted(results_dir.iterdir()):
        if not case_dir.is_dir() or not case_dir.name.startswith("CVE-"):
            continue
        cve_id = case_dir.name
        result_path = case_dir / "result.json"
        if not result_path.is_file():
            continue
        try:
            rec = json.loads(result_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as e:
            logger.warning("Skipping %s: %s", result_path, e)
            continue

        succeeded = bool(rec.get("succeeded"))
        miri_kind = rec.get("ub_type") or "unknown"
        cwe = rec.get("cwe", "")

        fixed = ""
        for cand in case_dir.glob("*_last.rs"):
            fixed = cand.read_text(encoding="utf-8", errors="replace")
            break
        if not fixed:
            for cand in case_dir.glob("*.rs"):
                fixed = cand.read_text(encoding="utf-8", errors="replace")
                break

        original = ""
        test = ""
        for sroot in synth_roots:
            sp = sroot / cve_id / "source.rs"
            tp = sroot / cve_id / "test.rs"
            if sp.is_file() and tp.is_file():
                original = sp.read_text(encoding="utf-8", errors="replace")
                test = tp.read_text(encoding="utf-8", errors="replace")
                break

        cve_description = _load_cve_description(cve_id, repo_root)

        yield CaseInput(
            cve_id=cve_id,
            cwe=cwe,
            miri_kind=miri_kind,
            original=original,
            fixed=fixed,
            test=test,
            cve_description=cve_description,
            fix_succeeded=succeeded,
        )


# ---------------------------------------------------------------------------
# Miri-official-fail adapter (run_miri_fail_bench.py output)
# ---------------------------------------------------------------------------


def iter_miri_layout(results_dir: Path) -> Iterator[CaseInput]:
    """Read ``miri_fail_results/<method>/`` produced by run_miri_fail_bench.py.

    Layout: ``per_case/<name>.json`` + ``source/<name>.rs`` (original test) +
    ``fixed/<name>.rs`` (repaired). There is no CVE markdown / intended-behavior
    document, so ``cve_description`` is empty and D4 judges source-vs-fixed only.
    """
    per_case_dir = results_dir / "per_case"
    fixed_dir = results_dir / "fixed"
    source_dir = results_dir / "source"
    if not per_case_dir.is_dir():
        raise FileNotFoundError(f"{per_case_dir} not found")

    for case_json in sorted(per_case_dir.glob("*.json")):
        name = case_json.stem
        try:
            rec = json.loads(case_json.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as e:
            logger.warning("Skipping %s: %s", case_json, e)
            continue

        miri_kind = rec.get("initial_ub_kind", "") or "unknown"
        # A case counts as "fixed" iff the final code passed Miri.
        succeeded = bool(rec.get("miri_passed") or rec.get("succeeded"))
        original = _safe_read(source_dir / f"{name}.rs")
        fixed = _safe_read(fixed_dir / f"{name}.rs")
        # Fall back to the redundant copy stored inside per_case/<name>.json.
        if not fixed.strip():
            fixed = rec.get("final_code", "") or ""

        yield CaseInput(
            cve_id=name,
            cwe=rec.get("category", ""),
            miri_kind=miri_kind,
            original=original,
            fixed=fixed,
            test="",
            cve_description="",
            fix_succeeded=succeeded,
        )


# ---------------------------------------------------------------------------
# Auto-detect
# ---------------------------------------------------------------------------


def detect_layout(results_dir: Path) -> str:
    per_case = (results_dir / "per_case").is_dir()
    if per_case and (results_dir / "synth").is_dir():
        return "synth"
    if per_case and (results_dir / "source").is_dir():
        return "miri"
    if per_case and (results_dir / "fixed").is_dir():
        return "synth"
    if any(p.is_dir() and p.name.startswith("CVE-") for p in results_dir.iterdir()):
        return "halurust"
    raise ValueError(
        f"Cannot recognise layout of {results_dir}. Expected a synth-style "
        f"results dir (per_case/, fixed/, synth/), a miri-style dir "
        f"(per_case/, source/, fixed/), or a halurust-style dir "
        f"with one folder per CVE."
    )


def iter_cases(
    results_dir: Path,
    *,
    repo_root: Path,
    layout: Optional[str] = None,
    fallback_synth_root: Optional[Path] = None,
) -> Iterator[CaseInput]:
    layout = layout or detect_layout(results_dir)
    if layout == "synth":
        yield from iter_synth_layout(
            results_dir,
            repo_root=repo_root,
            fallback_synth_root=fallback_synth_root,
        )
    elif layout == "miri":
        yield from iter_miri_layout(results_dir)
    elif layout == "halurust":
        yield from iter_halurust_layout(
            results_dir,
            repo_root=repo_root,
            synth_root_hint=fallback_synth_root,
        )
    else:
        raise ValueError(f"Unknown layout: {layout}")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _safe_read(p: Path) -> str:
    if not p.is_file():
        return ""
    try:
        return p.read_text(encoding="utf-8", errors="replace")
    except OSError as e:
        logger.warning("Failed to read %s: %s", p, e)
        return ""
