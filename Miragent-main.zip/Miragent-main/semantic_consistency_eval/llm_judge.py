"""LLM-as-judge dimension (D4) of the semantic consistency evaluator.

We deliberately ask for a structured JSON verdict so the result is
machine-readable and the prompt is harder to "talk around". The judge
is run with low temperature on a model that is *different* from the
model that produced the fix, to avoid self-bias.
"""

from __future__ import annotations

import json
import logging
import os
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

import httpx
from openai import OpenAI

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

JUDGE_SYSTEM = """You are a senior Rust code reviewer auditing automated CVE \
patches. You will see (1) a CVE description, (2) the original vulnerable \
function/library, (3) a candidate "fix", and (4) the test module that the \
repair tool used as oracle.

Your single job is to decide whether the candidate fix preserves the \
*intended* semantics of the original library on well-defined inputs, or \
whether the model trivialised the function to make Miri/tests happy.

Common ways automated tools cheat (you must catch these):

- A parameter the original body used is renamed to ``_x`` and is no longer \
  referenced.
- The body is replaced with a constant return such as ``Ok((1, 6))``, \
  ``Err(ErrorType::Syntax)``, ``None``, ``unimplemented!()``, ``panic!()``.
- A new ``static FOO: [u8; N] = [0; N]`` is introduced and the function \
  returns a pointer/reference into it regardless of inputs.
- The function unconditionally bails out at entry with ``return Err(...)``.
- The function body becomes drastically smaller while the original was \
  doing real computation (parsing, copying, indexing, casting, ...).

Output STRICT JSON only. No prose outside the JSON. Use this schema:

{
  "verdict": "preserved" | "minor_change" | "weakened" | "broken",
  "preservation_score": <float in [0.0, 1.0]>,
  "trivialization_signs": [<short strings>],
  "behavioral_diff": "<one or two sentences describing how observable \
behaviour differs on well-defined inputs, or 'none'>",
  "reason": "<one short sentence>"
}

Score guidance (be strict):
  - preserved        (1.00) — identical observable behaviour on every \
well-defined input; the unsafe operation is fixed without changing what \
the function returns.
  - minor_change     (0.85) — cosmetic changes, additional asserts, but \
same outputs on inputs the original handled correctly.
  - weakened         (0.50) — fix turns previously well-defined cases into \
errors / Nones; not a cheat per se but the function is strictly less useful.
  - broken           (0.00) — function is gutted: ignores inputs, returns \
constants, returns a static buffer, or unconditionally bails out.
"""


JUDGE_USER_TEMPLATE = """## CVE
{cve_id} ({cwe})

## CVE description
{cve_description}

## Original vulnerable library (source.rs)
```rust
{original}
```

## Candidate fix (fixed.rs)
```rust
{fixed}
```

## Test module the repair tool used as oracle
```rust
{test}
```

## Miri kind that the original triggered
{miri_kind}

Return ONLY the JSON object described in the system prompt.
"""


# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------


class JudgeVerdict(str, Enum):
    PRESERVED = "preserved"
    MINOR_CHANGE = "minor_change"
    WEAKENED = "weakened"
    BROKEN = "broken"
    ERROR = "error"


_VERDICT_DEFAULT_SCORE = {
    JudgeVerdict.PRESERVED: 1.0,
    JudgeVerdict.MINOR_CHANGE: 0.85,
    JudgeVerdict.WEAKENED: 0.5,
    JudgeVerdict.BROKEN: 0.0,
    JudgeVerdict.ERROR: 0.5,
}


@dataclass
class JudgeResult:
    verdict: JudgeVerdict
    preservation_score: float
    trivialization_signs: list[str] = field(default_factory=list)
    behavioral_diff: str = ""
    reason: str = ""
    raw_response: str = ""
    error: str = ""

    def to_dict(self) -> dict:
        return {
            "verdict": self.verdict.value,
            "preservation_score": self.preservation_score,
            "trivialization_signs": self.trivialization_signs,
            "behavioral_diff": self.behavioral_diff,
            "reason": self.reason,
            "raw_response": self.raw_response,
            "error": self.error,
        }


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------


@dataclass
class JudgeConfig:
    api_key: str
    base_url: Optional[str] = None
    model: str = "gpt-4o"
    temperature: float = 0.1
    max_input_chars: int = 20000  # truncate huge sources to keep prompts cheap
    max_retries: int = 1
    retry_backoff_s: list[int] = field(default_factory=lambda: [10])
    timeout_s: float = 120.0

    @classmethod
    def from_env(
        cls,
        *,
        model_override: Optional[str] = None,
        env_prefix: str = "JUDGE_",
    ) -> "JudgeConfig":
        """Pick up ``JUDGE_API_KEY``/``JUDGE_BASE_URL``/``JUDGE_MODEL`` first,
        then fall back to the standard ``API_KEY``/``BASE_URL``/``MODEL`` so
        that running the evaluator works out of the box from the repo's
        ``.env`` (you should still set ``JUDGE_MODEL`` to a different model
        from the one that generated the fix).
        """
        api_key = os.getenv(f"{env_prefix}API_KEY") or os.getenv("API_KEY") or ""
        base_url = os.getenv(f"{env_prefix}BASE_URL") or os.getenv("BASE_URL") or None
        model = (
            model_override
            or os.getenv(f"{env_prefix}MODEL")
            or os.getenv("MODEL")
            or "gpt-4o"
        )
        if not api_key:
            raise RuntimeError(
                "No API key for the judge model. Set JUDGE_API_KEY (preferred) "
                "or API_KEY in your .env."
            )
        return cls(api_key=api_key, base_url=base_url, model=model)


class LLMJudge:
    """Single-call semantic-preservation judge."""

    def __init__(self, config: JudgeConfig):
        self._config = config
        kwargs: dict = {
            "api_key": config.api_key,
            "timeout": httpx.Timeout(config.timeout_s, connect=30.0),
            "max_retries": 0,
        }
        if config.base_url:
            kwargs["base_url"] = config.base_url
        self._client = OpenAI(**kwargs)

    def judge(
        self,
        *,
        cve_id: str,
        cwe: str,
        cve_description: str,
        original: str,
        fixed: str,
        test: str,
        miri_kind: str = "unknown",
    ) -> JudgeResult:
        user = JUDGE_USER_TEMPLATE.format(
            cve_id=cve_id,
            cwe=cwe or "unknown",
            cve_description=_truncate(cve_description, 1500),
            original=_truncate(original, self._config.max_input_chars // 3),
            fixed=_truncate(fixed, self._config.max_input_chars // 3),
            test=_truncate(test, self._config.max_input_chars // 6),
            miri_kind=miri_kind or "unknown",
        )
        raw = self._call(user)
        if raw is None:
            return JudgeResult(
                verdict=JudgeVerdict.ERROR,
                preservation_score=0.5,
                error="LLM judge call failed after retries",
            )
        return _parse_judge_response(raw)

    # -- internals ----------------------------------------------------

    def _call(self, user: str) -> Optional[str]:
        last_err: Optional[Exception] = None
        for attempt in range(self._config.max_retries + 1):
            try:
                resp = self._client.chat.completions.create(
                    model=self._config.model,
                    temperature=self._config.temperature,
                    messages=[
                        {"role": "system", "content": JUDGE_SYSTEM},
                        {"role": "user", "content": user},
                    ],
                )
                return resp.choices[0].message.content or ""
            except Exception as e:  # noqa: BLE001
                last_err = e
                if attempt >= self._config.max_retries:
                    break
                wait = (
                    self._config.retry_backoff_s[
                        min(attempt, len(self._config.retry_backoff_s) - 1)
                    ]
                )
                logger.warning(
                    "Judge call failed (attempt %d): %s — retrying in %ds",
                    attempt + 1,
                    e,
                    wait,
                )
                time.sleep(wait)
        logger.error("Judge call exhausted retries: %s", last_err)
        return None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _truncate(s: str, limit: int) -> str:
    if not s:
        return ""
    if len(s) <= limit:
        return s
    head = s[: limit // 2]
    tail = s[-limit // 2 :]
    return head + "\n... <truncated " + str(len(s) - limit) + " chars> ...\n" + tail


_JSON_BLOCK_RE = re.compile(r"\{[\s\S]*\}")


def _parse_judge_response(raw: str) -> JudgeResult:
    raw = (raw or "").strip()
    if raw.startswith("```"):
        raw = re.sub(r"^```(?:json)?\s*", "", raw)
        raw = re.sub(r"\s*```$", "", raw)
    data: Optional[dict] = None
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        m = _JSON_BLOCK_RE.search(raw)
        if m:
            try:
                data = json.loads(m.group(0))
            except json.JSONDecodeError:
                data = None
    if not isinstance(data, dict):
        return JudgeResult(
            verdict=JudgeVerdict.ERROR,
            preservation_score=0.5,
            raw_response=raw,
            error="judge returned non-JSON",
        )

    verdict_raw = str(data.get("verdict", "")).strip().lower().replace(" ", "_")
    try:
        verdict = JudgeVerdict(verdict_raw)
    except ValueError:
        verdict = JudgeVerdict.ERROR

    score_val = data.get("preservation_score", None)
    if isinstance(score_val, (int, float)):
        score = max(0.0, min(1.0, float(score_val)))
    else:
        score = _VERDICT_DEFAULT_SCORE.get(verdict, 0.5)

    signs = data.get("trivialization_signs") or []
    if isinstance(signs, str):
        signs = [signs]
    signs = [str(x) for x in signs][:20]

    return JudgeResult(
        verdict=verdict,
        preservation_score=score,
        trivialization_signs=signs,
        behavioral_diff=str(data.get("behavioral_diff", ""))[:1000],
        reason=str(data.get("reason", ""))[:600],
        raw_response=raw,
    )
