# Semantic Consistency Evaluation (SCE)

A drop-in evaluation framework that augments the existing fix-rate metric
with a **semantic preservation** check. It is designed to answer a new
research question for the Halurust paper:

> **RQ:** Among the cases that a baseline reports as "fixed" (Miri PASS
> + cargo check OK), how many actually preserve the original program's
> intended semantics, and how many are *fake fixes* that only satisfy
> the test/Miri oracle by trivialising the function (e.g. ignoring
> parameters, returning constants, returning a freshly-introduced
> static buffer)?

This package was triggered by what we observed when running thetis-lathe
with DeepSeek-v4-flash: a 93.8% fix rate that is mostly explained by the
LLM gutting functions to evade the oracle (see e.g. `CVE-2019-12083`,
`CVE-2019-15550`).

## Metrics

For every baseline we already have:

- **Fix Rate (FR)** = `# Miri-passed fixes / # total cases`.

We add:

- **Semantic Consistency Rate (SCR)** =
  `# {Miri-passed ∧ semantically-preserved} / # Miri-passed`.
- **Effective Fix Rate (EFR)** = `FR × SCR` =
  `# {Miri-passed ∧ semantically-preserved} / # total cases`.

EFR is the metric we recommend reporting in the paper alongside FR.

## How a case is judged "semantically preserved"

For each ``(original_source, fixed_source)`` pair we compute four scores
in `[0, 1]`:

| Dim | Source | Default weight | What it captures |
|---|---|---|---|
| **D1** API surface | tree-sitter | 0.20 | Every original `pub fn` keeps its name, arity, return type, and `unsafe` qualifier. |
| **D2** Trivialisation | static rules + tree-sitter | 0.30 | The fix did NOT (a) rename a used parameter to `_x`, (b) collapse the body to `Ok(constant)` / `Err(...)` / `unimplemented!()` / `panic!()` / `None`, (c) collapse a 20+-node body to ≤6 AST nodes, (d) introduce a brand-new `static FOO: [...]` and return into it, (e) prepend a previously-absent `return Err(...)` bail-out. |
| **D3** Structural similarity | tree-sitter Jaccard | 0.15 | Bag-of-(depth, AST-type) Jaccard between original and fix. Drops line numbers (so vertical insertions don't tank the score). |
| **D4** LLM judge | independent strong LLM | 0.35 | A different-vendor model returns `verdict ∈ {preserved, minor_change, weakened, broken}` + `preservation_score ∈ [0,1]` + a behavioral diff rationale. Strict JSON. |

`composite = 0.20·D1 + 0.30·D2 + 0.15·D3 + 0.35·D4`.

A case is **semantically preserved** iff:

- `composite ≥ 0.6`, AND
- `D2 ≥ 0.5` (at least half of public functions did not get trivialised), AND
- D4 verdict is not `broken`.

The thresholds and weights are configurable on the CLI (`--w-*`,
`--composite-threshold`, `--triv-threshold`).

### Why this combination?

Each single dimension is gameable:

- D4 alone is easy for the model to talk around.
- D1 alone misses the case where the API stays but the body is gutted.
- D3 alone penalises legitimately large fixes (e.g. adding bound checks).
- D2 alone catches the pattern we cared about most but is brittle.

Combining them gives a metric that is hard to game with the kind of
short-circuit rewrites we observed.

### Why the LLM judge is on a *different* model

The judge call MUST run on a different vendor (or at least a different
model family) than the model that produced the fix. This is to avoid the
trivial self-bias: a model that cheats in a stylised way tends to
think its own cheats are fine. Configure with `JUDGE_MODEL` in `.env`
or pass `--judge-model`.

## Inputs / supported layouts

Auto-detected from the directory shape:

- **`synth`** layout: `per_case/<cve>.json`, `synth/<cve>.source.rs`,
  `synth/<cve>.test.rs`, `fixed/<cve>.rs`. Used by thetis-lathe,
  rustbrain, and giantrepair synth runners.
- **`halurust`** layout: `<results>/<cve>/result.json` and
  `<results>/<cve>/<cve>_last.rs`. Source/test pulled from
  `cve_safe_func_synth_without_data_race/<cve>/{source.rs,test.rs}` (or
  `cve_safe_func_synth/...` as fallback).

The CVE description (used in the D4 prompt) is loaded from
`cve_safe_func/<CVE-ID>/<...>.md` (or its `_without_data_race` /
`_ffi_related` siblings).

## Outputs

For each baseline, under `<out-dir>/<label>/`:

- `summary_semantic.json` — aggregated metrics (FR, SCR, EFR, mean
  D1/D2/D3/D4, verdict counts) plus a flat list of per-case rows.
- `per_case_semantic/<CVE>.json` — full per-case breakdown including
  the LLM raw response (so you can audit any judgement).

When two or more baselines are evaluated in the same run:

- `<out-dir>/comparison.md` — a Markdown table comparing FR / SCR /
  EFR / mean D1-D4 / verdict counts across baselines.

## Configuration

Reads `.env` at the repo root. Variables (all optional except an API key):

```dotenv
# Used for both halurust runs and as fallback for the judge.
API_KEY=...
BASE_URL=https://...
MODEL=deepseek-v4-flash

# Strongly recommended: a *different* model for the judge to avoid
# self-bias.
JUDGE_API_KEY=...
JUDGE_BASE_URL=https://...
JUDGE_MODEL=gemini-3-flash
```

## Quick run

Sanity-check D1-D3 only (no API quota needed; ~seconds):

```bash
python -m semantic_consistency_eval \
  --result thetis-lathe:thetis-lathe_baseline/results/cve_safe_func_deepseek \
  --no-judge \
  --out-dir semantic_eval_results/static-only/thetis-lathe \
  --verbose
```

Full four-baseline comparison on the DeepSeek runs:

```bash
python -m semantic_consistency_eval \
  --result halurust:cve_safe_func_fixed_deepseek \
  --result thetis-lathe:thetis-lathe_baseline/results/cve_safe_func_deepseek \
  --result rustbrain:rustbrain_baseline/results/cve_safe_func_deepseek \
  --result giantrepair:giantrepair_baseline/results/cve_safe_func_synth_deepseek \
  --judge-model gemini-3-flash \
  --concurrency 4 \
  --out-dir semantic_eval_results/deepseek
```

Same on the Gemini runs:

```bash
python -m semantic_consistency_eval \
  --result halurust:cve_safe_func_fixed \
  --result thetis-lathe:thetis-lathe_baseline/results/cve_safe_func_synth_20260505_155824 \
  --result rustbrain:rustbrain_baseline/results/cve_safe_func_gemini_3_flash \
  --result giantrepair:giantrepair_baseline/results/cve_safe_func_synth_gemini_3_flash \
  --judge-model deepseek-v4-flash \
  --concurrency 4 \
  --out-dir semantic_eval_results/gemini
```

## What to put in the paper

- A new RQ subsection: *"Are reported fixes semantically faithful?"*
- Table comparing FR vs SCR vs EFR for every (baseline, model) cell.
- One or two qualitative examples from `per_case_semantic/<CVE>.json`
  showing the trivialisation flags D2 found and the judge rationale
  D4 gave (CVE-2019-12083 and CVE-2019-15550 are clean specimens).
- A note that the judge runs on a *different* vendor than the model
  under evaluation, citing your specific judge model.
