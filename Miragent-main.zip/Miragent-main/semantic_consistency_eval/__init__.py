"""Semantic Consistency Evaluation (SCE).

A framework for measuring whether a CVE-fix candidate preserves the
original program's intended semantics, in addition to satisfying the
Miri / cargo-check oracle. See ``README.md`` for the full methodology.
"""

from .static_metrics import (
    APISurfaceReport,
    TrivializationReport,
    api_surface_score,
    trivialization_score,
    structural_similarity_score,
)
from .llm_judge import LLMJudge, JudgeVerdict, JudgeResult
from .evaluator import (
    CaseEvaluation,
    BaselineEvaluation,
    SemanticEvaluator,
)

__all__ = [
    "APISurfaceReport",
    "TrivializationReport",
    "api_surface_score",
    "trivialization_score",
    "structural_similarity_score",
    "LLMJudge",
    "JudgeVerdict",
    "JudgeResult",
    "CaseEvaluation",
    "BaselineEvaluation",
    "SemanticEvaluator",
]
