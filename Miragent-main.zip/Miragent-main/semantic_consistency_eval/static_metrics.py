"""Deterministic, static-analysis dimensions of semantic consistency.

Three scores in ``[0.0, 1.0]`` (higher = more semantics preserved):

- :func:`api_surface_score`        — D1, public-API preservation.
- :func:`trivialization_score`     — D2, detects "stub-rewrite" cheats.
- :func:`structural_similarity_score` — D3, tree-sitter AST Jaccard.

They share a tree-sitter-based public-function extractor. We deliberately
focus on ``pub fn`` items because:

- private helpers can be deleted/inlined without changing observable
  semantics, so penalising them would create false positives;
- the cheats we observed in practice (CVE-2019-12083, CVE-2019-15550,
  several CWE-787 cases) all gut a *public* function while keeping its
  signature, which is exactly what D1+D2 catch.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional

import tree_sitter_rust as tsrust
from tree_sitter import Language, Node, Parser

RUST_LANGUAGE = Language(tsrust.language())
_PARSER = Parser(RUST_LANGUAGE)


# =====================================================================
# Public-function extraction
# =====================================================================


@dataclass
class PubFnSig:
    """Compact signature of a public Rust function for D1/D2 matching."""

    name: str
    arity: int
    param_names: list[str]
    return_type: str
    is_unsafe: bool
    body_text: str
    body_node_count: int
    full_text: str
    start_line: int
    end_line: int


def _parse(source: str) -> Node:
    return _PARSER.parse(source.encode("utf-8")).root_node


def _node_text(src: bytes, node: Node) -> str:
    return src[node.start_byte : node.end_byte].decode("utf-8", errors="replace")


def _count_named(node: Node) -> int:
    n = 1 if node.is_named else 0
    for c in node.children:
        n += _count_named(c)
    return n


def _is_pub(fn_node: Node) -> bool:
    for child in fn_node.children:
        if child.type == "visibility_modifier":
            return True
    return False


def _has_unsafe_modifier(fn_node: Node) -> bool:
    for child in fn_node.children:
        if child.type == "function_modifiers":
            if "unsafe" in child.text.decode("utf-8", errors="replace"):
                return True
        # Older grammars expose ``unsafe`` directly as a leaf token.
        if child.type == "unsafe":
            return True
    return False


def _extract_param_names(params_node: Node) -> list[str]:
    """Pull identifier names out of a ``parameters`` node (``self`` skipped)."""
    names: list[str] = []
    for child in params_node.named_children:
        if child.type == "self_parameter":
            names.append("self")
            continue
        # ``parameter`` is the typical case: pattern + ':' + type.
        if child.type == "parameter":
            ident = _first_identifier_name(child)
            names.append(ident or "_")
    return names


def _first_identifier_name(node: Node) -> Optional[str]:
    """Find the first ``identifier`` token under ``node`` (used for params)."""
    if node.type == "identifier":
        return node.text.decode("utf-8", errors="replace")
    for child in node.named_children:
        found = _first_identifier_name(child)
        if found is not None:
            return found
    return None


def _extract_pub_fns(source: str) -> list[PubFnSig]:
    return _extract_fns(source, only_pub=True)


def _extract_fns(source: str, *, only_pub: bool) -> list[PubFnSig]:
    src_bytes = source.encode("utf-8")
    root = _parse(source)
    out: list[PubFnSig] = []
    _walk_fns(root, src_bytes, out, only_pub=only_pub)
    return out


def _walk_fns(
    node: Node, src: bytes, out: list[PubFnSig], *, only_pub: bool
) -> None:
    if node.type == "function_item":
        if (not only_pub) or _is_pub(node):
            sig = _build_sig(node, src)
            if sig is not None:
                out.append(sig)
    for c in node.children:
        _walk_fns(c, src, out, only_pub=only_pub)


def _build_sig(fn_node: Node, src: bytes) -> Optional[PubFnSig]:
    name_node = fn_node.child_by_field_name("name")
    if name_node is None:
        return None
    params_node = fn_node.child_by_field_name("parameters")
    body_node = fn_node.child_by_field_name("body")
    return_type_node = fn_node.child_by_field_name("return_type")

    param_names: list[str] = []
    if params_node is not None:
        param_names = _extract_param_names(params_node)
    return_type = ""
    if return_type_node is not None:
        return_type = _normalise_ws(_node_text(src, return_type_node))
    body_text = _node_text(src, body_node) if body_node is not None else ""
    body_count = _count_named(body_node) if body_node is not None else 0
    return PubFnSig(
        name=name_node.text.decode("utf-8", errors="replace"),
        arity=len([p for p in param_names if p != "self"]),
        param_names=param_names,
        return_type=return_type,
        is_unsafe=_has_unsafe_modifier(fn_node),
        body_text=body_text,
        body_node_count=body_count,
        full_text=_node_text(src, fn_node),
        start_line=fn_node.start_point[0] + 1,
        end_line=fn_node.end_point[0] + 1,
    )


def _normalise_ws(s: str) -> str:
    return re.sub(r"\s+", " ", s).strip()


def _is_pub_name_in_source(source: str, name: str) -> bool:
    """Cheap pre-filter for "is there a ``pub fn name`` in this source?"""
    return re.search(rf"\bpub\b[^\n]*\bfn\s+{re.escape(name)}\b", source) is not None


# =====================================================================
# D1: public-API preservation
# =====================================================================


@dataclass
class APISurfaceReport:
    score: float
    total: int
    preserved: int
    missing: list[str] = field(default_factory=list)
    arity_changed: list[str] = field(default_factory=list)
    return_type_changed: list[str] = field(default_factory=list)
    unsafe_qualifier_changed: list[str] = field(default_factory=list)


def api_surface_score(original: str, fixed: str) -> APISurfaceReport:
    """D1: fraction of original ``pub fn``s whose signature is preserved.

    The signature comparison is intentionally strict on **shape** (name,
    arity, return type, ``unsafe`` qualifier) but ignores parameter
    *names* and lifetime/where-clause cosmetics — those legitimately
    change in real fixes (e.g. adding ``where U: Sized``).
    """
    orig_fns = _extract_pub_fns(original)
    fixed_fns = {f.name: f for f in _extract_pub_fns(fixed)}

    if not orig_fns:
        # No public surface to begin with -> trivially "preserved".
        return APISurfaceReport(score=1.0, total=0, preserved=0)

    preserved = 0
    rep = APISurfaceReport(score=0.0, total=len(orig_fns), preserved=0)
    for o in orig_fns:
        f = fixed_fns.get(o.name)
        if f is None:
            rep.missing.append(o.name)
            continue
        ok = True
        if f.arity != o.arity:
            rep.arity_changed.append(o.name)
            ok = False
        if _normalise_ws(f.return_type) != _normalise_ws(o.return_type):
            rep.return_type_changed.append(o.name)
            ok = False
        if f.is_unsafe != o.is_unsafe:
            rep.unsafe_qualifier_changed.append(o.name)
            ok = False
        if ok:
            preserved += 1
    rep.preserved = preserved
    rep.score = preserved / len(orig_fns)
    return rep


# =====================================================================
# D2: trivialization detection
# =====================================================================


# Minimal-body templates we want to flag. Compared against the *normalised*
# function body (whitespace-stripped, comments removed).
_TRIVIAL_BODY_PATTERNS = [
    re.compile(r"^\{\s*unimplemented!\s*\([^)]*\)\s*;?\s*\}$"),
    re.compile(r"^\{\s*todo!\s*\([^)]*\)\s*;?\s*\}$"),
    re.compile(r"^\{\s*panic!\s*\([^)]*\)\s*;?\s*\}$"),
    re.compile(r"^\{\s*Err\(\s*[^()]*\s*\)\s*\}$"),
    re.compile(r"^\{\s*Ok\(\s*[^()]*\s*\)\s*\}$"),
    re.compile(r"^\{\s*None\s*\}$"),
    re.compile(r"^\{\s*Some\(\s*[^()]*\s*\)\s*\}$"),
    re.compile(r"^\{\s*-?\d+(?:\.\d+)?(?:[fui]\d*)?\s*\}$"),
    re.compile(r"^\{\s*\(\s*\)\s*\}$"),
    re.compile(r"^\{\s*&\s*[A-Z_][A-Z0-9_]*\s*\}$"),
]

_BODY_COMMENT_RE = re.compile(r"//[^\n]*|/\*.*?\*/", re.DOTALL)


def _strip_comments(s: str) -> str:
    return _BODY_COMMENT_RE.sub("", s)


def _normalise_body(body: str) -> str:
    return _normalise_ws(_strip_comments(body))


def _ident_referenced(body: str, ident: str) -> bool:
    """Is ``ident`` referenced in ``body`` outside its own declaration?

    We strip comments and string literals, then look for a word-boundary
    match. Good enough for the cheat heuristic.
    """
    if not ident or ident.startswith("_"):
        return False
    cleaned = _strip_comments(body)
    cleaned = re.sub(r'"(?:\\.|[^"\\])*"', "", cleaned)
    cleaned = re.sub(r"'(?:\\.|[^'\\])'", "", cleaned)
    return re.search(rf"\b{re.escape(ident)}\b", cleaned) is not None


_STATIC_DECL_RE = re.compile(r"^\s*static\s+([A-Z_][A-Z0-9_]*)\s*:", re.MULTILINE)


def _new_static_arrays(original: str, fixed: str) -> set[str]:
    """Names of ``static FOO: ...`` items that exist only in the fix."""
    o = set(_STATIC_DECL_RE.findall(original))
    f = set(_STATIC_DECL_RE.findall(fixed))
    return f - o


@dataclass
class FunctionTrivializationFinding:
    name: str
    flags: list[str]


@dataclass
class TrivializationReport:
    score: float
    total: int
    non_trivial: int
    findings: list[FunctionTrivializationFinding] = field(default_factory=list)


def trivialization_score(
    original: str,
    fixed: str,
    *,
    body_collapse_min_orig: int = 20,
    body_collapse_max_fixed: int = 6,
) -> TrivializationReport:
    """D2: fraction of public functions that look semantically alive.

    A function is *trivialised* if any of these flags fires:

    - ``stub_param``  — a parameter that the original body referenced is
      now renamed to ``_x`` (or kept unchanged but unused).
    - ``constant_body`` — body matches one of the constant-return templates
      and the original body wasn't already that template.
    - ``body_collapse`` — original body had ≥ ``body_collapse_min_orig``
      named AST nodes; fixed body has ≤ ``body_collapse_max_fixed``.
    - ``returns_new_static`` — body now references a ``static FOO`` that
      didn't exist in the original (typical of the ``ZERO_BUFFER`` cheat).
    - ``early_err`` — body's first statement is ``return Err(...)`` /
      ``return None`` and the original's wasn't.
    """
    orig_fns_all = _extract_fns(original, only_pub=False)
    # Only score functions whose original body did real work. Tiny helpers
    # (e.g. ``fn add(a, b) -> u8 { a + b }``) shouldn't dominate the score.
    orig_fns = [
        f
        for f in orig_fns_all
        if _is_pub_name_in_source(original, f.name)
        or f.body_node_count >= body_collapse_min_orig
    ]
    fixed_fns = {f.name: f for f in _extract_fns(fixed, only_pub=False)}
    if not orig_fns:
        return TrivializationReport(score=1.0, total=0, non_trivial=0)

    new_statics = _new_static_arrays(original, fixed)

    findings: list[FunctionTrivializationFinding] = []
    non_trivial = 0
    for o in orig_fns:
        f = fixed_fns.get(o.name)
        if f is None:
            findings.append(
                FunctionTrivializationFinding(name=o.name, flags=["missing"])
            )
            continue

        flags: list[str] = []

        # stub_param: param used in original but ignored / underscore-prefixed in fix.
        for i, orig_pname in enumerate(o.param_names):
            if orig_pname == "self" or orig_pname == "_":
                continue
            if i >= len(f.param_names):
                break
            fixed_pname = f.param_names[i]
            orig_used = _ident_referenced(o.body_text, orig_pname)
            fixed_base = fixed_pname.lstrip("_") or fixed_pname
            fixed_used = _ident_referenced(f.body_text, fixed_base)
            if orig_used and (fixed_pname.startswith("_") or not fixed_used):
                flags.append(f"stub_param:{orig_pname}")

        # constant_body: matches a trivial template.
        norm_fixed_body = _normalise_body(f.body_text)
        norm_orig_body = _normalise_body(o.body_text)
        for pat in _TRIVIAL_BODY_PATTERNS:
            if pat.match(norm_fixed_body) and not pat.match(norm_orig_body):
                flags.append("constant_body")
                break

        # body_collapse: large original body, tiny fixed body.
        if (
            o.body_node_count >= body_collapse_min_orig
            and f.body_node_count <= body_collapse_max_fixed
        ):
            flags.append(
                f"body_collapse:{o.body_node_count}->{f.body_node_count}"
            )

        # returns_new_static: cheat with new static buffer.
        if new_statics:
            for s in new_statics:
                if re.search(rf"\b{re.escape(s)}\b", f.body_text):
                    flags.append(f"returns_new_static:{s}")
                    break

        # early_err: first statement degenerated into a defensive bail-out.
        if _has_added_early_bailout(o.body_text, f.body_text):
            flags.append("early_err")

        if flags:
            findings.append(
                FunctionTrivializationFinding(name=o.name, flags=flags)
            )
        else:
            non_trivial += 1

    rep = TrivializationReport(
        score=non_trivial / len(orig_fns),
        total=len(orig_fns),
        non_trivial=non_trivial,
        findings=findings,
    )
    return rep


def _has_added_early_bailout(orig_body: str, fixed_body: str) -> bool:
    """First non-whitespace statement of fixed is a bail-out absent in orig."""
    bailout_re = re.compile(
        r"^\{\s*return\s+(Err\s*\(|None\s*;|Default::default)",
        re.MULTILINE,
    )
    fixed_match = bailout_re.search(_strip_comments(fixed_body))
    if not fixed_match:
        return False
    orig_match = bailout_re.search(_strip_comments(orig_body))
    return orig_match is None


# =====================================================================
# D3: AST structural similarity
# =====================================================================


def _node_signatures(node: Node, depth: int = 0, sigs: Optional[list[str]] = None) -> list[str]:
    if sigs is None:
        sigs = []
    if node.is_named:
        sigs.append(f"{depth}:{node.type}")
    for c in node.children:
        _node_signatures(c, depth + 1, sigs)
    return sigs


def structural_similarity_score(original: str, fixed: str) -> float:
    """D3: Jaccard similarity over (depth, ast-type) bag-signatures.

    We intentionally drop line numbers (unlike halurust's variant) so
    that vertically inserting a few lines doesn't tank the score; only
    *structural* edits count.
    """
    try:
        a = _parse(original)
        b = _parse(fixed)
    except Exception:
        return 0.5
    sa, sb = _node_signatures(a), _node_signatures(b)
    if not sa and not sb:
        return 1.0
    # Use multiset (Counter) Jaccard so deleting half of N identical nodes
    # actually reduces the score.
    from collections import Counter

    ca, cb = Counter(sa), Counter(sb)
    inter = sum((ca & cb).values())
    union = sum((ca | cb).values())
    if union == 0:
        return 1.0
    return inter / union
