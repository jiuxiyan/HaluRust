#!/usr/bin/env python3
"""Evaluate final Rust patches against private held-out semantic tests.

This module has no dependency on Miragent.  It consumes an already-final patch,
constructs an isolated temporary Cargo library, appends the private tests, and
runs `cargo +<toolchain> miri test`.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

try:
    import tomllib
except ModuleNotFoundError:  # Python 3.9/3.10
    import tomli as tomllib


PRIVATE_ROOT = Path(__file__).resolve().parents[1]
PROJECT_ROOT = PRIVATE_ROOT.parent
CASES_ROOT = PRIVATE_ROOT / "cases"
MANIFEST_PATH = PRIVATE_ROOT / "manifests" / "miri_dataset_manifest_v1.json"


@dataclass(frozen=True)
class Profile:
    name: str
    flags: tuple[str, ...]


def _load_case(case_id: str) -> tuple[Path, dict[str, Any]]:
    case_dir = CASES_ROOT / case_id
    config_path = case_dir / "case.toml"
    if not config_path.is_file():
        raise FileNotFoundError(f"unknown or unimplemented case: {case_id}")
    with config_path.open("rb") as handle:
        config = tomllib.load(handle)
    if config.get("case_id") != case_id:
        raise ValueError(f"case.toml case_id mismatch for {case_id}")
    return case_dir, config


def _load_manifest_case(case_id: str) -> dict[str, Any]:
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    for case in manifest["cases"]:
        if case["case_id"] == case_id:
            return case
    raise ValueError(f"{case_id} is not part of the frozen 423-case manifest")


def _verify_frozen_source(config: dict[str, Any], manifest_case: dict[str, Any]) -> None:
    expected_rel = config["source_relpath"]
    if manifest_case["rel_path"] != expected_rel:
        raise ValueError(
            f"source path mismatch: case.toml={expected_rel}, "
            f"manifest={manifest_case['rel_path']}"
        )
    source_path = PROJECT_ROOT / "miri_official_tests" / "fail" / expected_rel
    source = source_path.read_bytes()
    actual_hash = hashlib.sha256(source).hexdigest()
    if actual_hash != manifest_case["sha256"]:
        raise ValueError(f"frozen source hash mismatch for {config['case_id']}")
    configured_hash = config.get("source_sha256")
    if configured_hash and configured_hash != actual_hash:
        raise ValueError(f"case.toml source hash mismatch for {config['case_id']}")


def _profiles(config: dict[str, Any], selected: set[str] | None) -> list[Profile]:
    profiles = [
        Profile(item["name"], tuple(item.get("flags", [])))
        for item in config.get("profiles", [])
    ]
    if not profiles:
        profiles = [Profile("default", ())]
    if selected:
        profiles = [profile for profile in profiles if profile.name in selected]
        missing = selected - {profile.name for profile in profiles}
        if missing:
            raise ValueError(f"unknown profile(s): {', '.join(sorted(missing))}")
    return profiles


def _strip_test_annotations(source: str) -> str:
    """Remove compiletest expectation comments without changing Rust behavior."""
    kept: list[str] = []
    for line in source.splitlines():
        stripped = line.lstrip()
        if stripped.startswith("//@"):
            continue
        line = re.sub(r"\s*//~(?:\[[^\]]+\])?[\^|]*.*$", "", line)
        kept.append(line)
    return "\n".join(kept).rstrip() + "\n"


def _test_module(test_source: str) -> str:
    return (
        "\n#[cfg(test)]\n"
        "mod __miragent_heldout_semantics {\n"
        "    use super::*;\n"
        f"{test_source.rstrip()}\n"
        "}\n"
    )


def _classify_failure(stdout: str, stderr: str) -> tuple[str, str]:
    combined = f"{stdout}\n{stderr}"
    lower = combined.lower()
    if "undefined behavior" in lower or "error: unsupported operation" in lower:
        return "hidden_ub", "Miri reported undefined or unsupported behavior"
    if "panicked at" in lower or "test result: failed" in lower:
        return "semantic_fail", "a held-out assertion or test failed"
    if "could not compile" in lower or "error[e" in lower or "error:" in lower:
        return "compile_fail", "the final patch does not compile with the held-out contract"
    return "not_evaluable", "Miri failed without a recognized semantic/UB/compile outcome"


def _run_profile(
    *,
    case_id: str,
    fixed_source: str,
    test_source: str,
    profile: Profile,
    toolchain: str,
    timeout: int,
) -> dict[str, Any]:
    started = time.monotonic()
    with tempfile.TemporaryDirectory(prefix=f"miragent-heldout-{case_id}-") as tmp:
        crate = Path(tmp)
        (crate / "src").mkdir()
        package_name = "heldout_" + re.sub(r"[^A-Za-z0-9_]", "_", case_id)
        (crate / "Cargo.toml").write_text(
            "[package]\n"
            f'name = "{package_name}"\n'
            'version = "0.1.0"\n'
            'edition = "2021"\n'
            "publish = false\n",
            encoding="utf-8",
        )
        full_source = _strip_test_annotations(fixed_source) + _test_module(test_source)
        (crate / "src" / "lib.rs").write_text(full_source, encoding="utf-8")

        command = ["cargo", f"+{toolchain}", "miri", "test", "--quiet"]
        env = os.environ.copy()
        env["CARGO_TARGET_DIR"] = str(crate / "target")
        if profile.flags:
            env["MIRIFLAGS"] = " ".join(profile.flags)
        else:
            env.pop("MIRIFLAGS", None)
        try:
            result = subprocess.run(
                command,
                cwd=crate,
                env=env,
                capture_output=True,
                text=True,
                timeout=timeout,
                check=False,
            )
        except subprocess.TimeoutExpired as exc:
            return {
                "profile": profile.name,
                "flags": list(profile.flags),
                "status": "timeout",
                "passed": False,
                "reason": f"held-out Miri run exceeded {timeout}s",
                "duration_s": round(time.monotonic() - started, 3),
                "stdout_tail": (exc.stdout or "")[-4000:]
                if isinstance(exc.stdout, str)
                else "",
                "stderr_tail": (exc.stderr or "")[-8000:]
                if isinstance(exc.stderr, str)
                else "",
            }
        except FileNotFoundError:
            return {
                "profile": profile.name,
                "flags": list(profile.flags),
                "status": "not_evaluable",
                "passed": False,
                "reason": "cargo or the requested toolchain is unavailable",
                "duration_s": round(time.monotonic() - started, 3),
                "stdout_tail": "",
                "stderr_tail": "",
            }

    if result.returncode == 0:
        status, reason, passed = "pass", "all held-out tests passed under Miri", True
    else:
        status, reason = _classify_failure(result.stdout, result.stderr)
        passed = False
    return {
        "profile": profile.name,
        "flags": list(profile.flags),
        "status": status,
        "passed": passed,
        "reason": reason,
        "returncode": result.returncode,
        "duration_s": round(time.monotonic() - started, 3),
        "stdout_tail": result.stdout[-4000:],
        "stderr_tail": result.stderr[-8000:],
    }


def evaluate_source(
    *,
    case_id: str,
    source_path: Path,
    selected_profiles: set[str] | None = None,
    toolchain_override: str | None = None,
    timeout_override: int | None = None,
) -> dict[str, Any]:
    case_dir, config = _load_case(case_id)
    manifest_case = _load_manifest_case(case_id)
    _verify_frozen_source(config, manifest_case)
    test_path = case_dir / "semantic_tests.rs"
    if not test_path.is_file():
        raise FileNotFoundError(f"missing held-out tests for {case_id}")
    if not source_path.is_file():
        raise FileNotFoundError(f"missing final patch: {source_path}")

    source = source_path.read_text(encoding="utf-8")
    tests = test_path.read_text(encoding="utf-8")
    actual_test_count = tests.count("#[test]")
    if actual_test_count != int(config["test_count"]):
        raise ValueError(
            f"held-out test count mismatch for {case_id}: "
            f"case.toml={config['test_count']}, actual={actual_test_count}"
        )
    toolchain = toolchain_override or config.get("toolchain", "nightly")
    timeout = timeout_override or int(config.get("timeout_seconds", 180))
    profile_results = [
        _run_profile(
            case_id=case_id,
            fixed_source=source,
            test_source=tests,
            profile=profile,
            toolchain=toolchain,
            timeout=timeout,
        )
        for profile in _profiles(config, selected_profiles)
    ]
    overall_pass = bool(profile_results) and all(
        result["passed"] for result in profile_results
    )
    if overall_pass:
        status = "pass"
    else:
        priority = [
            "hidden_ub",
            "semantic_fail",
            "compile_fail",
            "timeout",
            "not_evaluable",
        ]
        observed = {result["status"] for result in profile_results}
        status = next((candidate for candidate in priority if candidate in observed), "not_evaluable")
    return {
        "schema_version": 1,
        "case_id": case_id,
        "source_file": str(source_path),
        "source_sha256": hashlib.sha256(source.encode("utf-8")).hexdigest(),
        "semantic_tests_sha256": hashlib.sha256(
            tests.encode("utf-8")
        ).hexdigest(),
        "case_config_sha256": hashlib.sha256(
            (case_dir / "case.toml").read_bytes()
        ).hexdigest(),
        "oracle_level": config["oracle_level"],
        "contract_summary": config["contract_summary"],
        "test_count": config["test_count"],
        "check_count": config["check_count"],
        "toolchain": toolchain,
        "status": status,
        "passed": overall_pass,
        "profiles": profile_results,
    }


def validate_oracle(
    *,
    case_id: str,
    selected_profiles: set[str] | None,
    toolchain: str | None,
    timeout: int | None,
) -> dict[str, Any]:
    case_dir, config = _load_case(case_id)
    validation = config.get("oracle_validation", {})
    reference = case_dir / validation["reference_fix"]
    reference_result = evaluate_source(
        case_id=case_id,
        source_path=reference,
        selected_profiles=selected_profiles,
        toolchain_override=toolchain,
        timeout_override=timeout,
    )
    mutant_results: list[dict[str, Any]] = []
    with tempfile.TemporaryDirectory(prefix=f"heldout-mutants-{case_id}-") as tmp:
        for index, mutant in enumerate(validation.get("mutants", []), 1):
            if "file" in mutant:
                mutant_path = case_dir / mutant["file"]
                mutant_label = mutant["file"]
            else:
                reference_source = reference.read_text(encoding="utf-8")
                find = mutant["find"]
                occurrences = reference_source.count(find)
                if occurrences != 1:
                    raise ValueError(
                        f"inline mutant {mutant['name']} for {case_id} expected "
                        f"one match, found {occurrences}"
                    )
                mutated_source = reference_source.replace(
                    find, mutant["replace"], 1
                )
                mutant_path = Path(tmp) / f"{index:02d}_{mutant['name']}.rs"
                mutant_path.write_text(mutated_source, encoding="utf-8")
                mutant_label = f"inline:{mutant['name']}"
            result = evaluate_source(
                case_id=case_id,
                source_path=mutant_path,
                selected_profiles=selected_profiles,
                toolchain_override=toolchain,
                timeout_override=timeout,
            )
            expected = mutant["expected"]
            expectation_met = (
                result["passed"] if expected == "pass" else not result["passed"]
            )
            mutant_results.append(
                {
                    "file": mutant_label,
                    "expected": expected,
                    "reason": mutant["reason"],
                    "expectation_met": expectation_met,
                    "result": result,
                }
            )
    killed = sum(
        1
        for item in mutant_results
        if item["expected"] == "fail" and not item["result"]["passed"]
    )
    killable = sum(1 for item in mutant_results if item["expected"] == "fail")
    all_expectations_met = reference_result["passed"] and all(
        item["expectation_met"] for item in mutant_results
    )
    return {
        "schema_version": 1,
        "case_id": case_id,
        "status": "pass" if all_expectations_met else "fail",
        "passed": all_expectations_met,
        "reference": reference_result,
        "mutants": mutant_results,
        "mutation_score": round(killed / killable, 4) if killable else None,
        "killed": killed,
        "killable": killable,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--case", required=True)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--fixed", type=Path)
    source.add_argument("--validate-oracle", action="store_true")
    parser.add_argument("--profile", action="append", default=[])
    parser.add_argument("--toolchain")
    parser.add_argument("--timeout", type=int)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    selected_profiles = set(args.profile) or None
    try:
        if args.validate_oracle:
            result = validate_oracle(
                case_id=args.case,
                selected_profiles=selected_profiles,
                toolchain=args.toolchain,
                timeout=args.timeout,
            )
        else:
            result = evaluate_source(
                case_id=args.case,
                source_path=args.fixed.resolve(),
                selected_profiles=selected_profiles,
                toolchain_override=args.toolchain,
                timeout_override=args.timeout,
            )
    except (FileNotFoundError, KeyError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    output = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(output, encoding="utf-8")
    else:
        sys.stdout.write(output)
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
