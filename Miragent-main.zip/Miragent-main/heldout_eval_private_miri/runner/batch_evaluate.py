#!/usr/bin/env python3
"""Batch wrapper for the private held-out evaluator.

Only final patch files are consumed.  The script does not invoke a repair
pipeline and never retries or modifies a patch based on held-out failures.
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path

from evaluate import CASES_ROOT, MANIFEST_PATH, evaluate_source


def _implemented_cases() -> list[str]:
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    return [
        case["case_id"]
        for case in manifest["cases"]
        if case["oracle"]["status"] == "implemented"
    ]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--fixed-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--case", action="append", default=[])
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--toolchain")
    parser.add_argument("--timeout", type=int)
    args = parser.parse_args()

    fixed_root = args.fixed_root.resolve()
    case_ids = args.case or _implemented_cases()
    unknown = [case_id for case_id in case_ids if not (CASES_ROOT / case_id).is_dir()]
    if unknown:
        print(f"error: unimplemented case(s): {', '.join(unknown)}", file=sys.stderr)
        return 2

    args.output_dir.mkdir(parents=True, exist_ok=True)
    per_case_dir = args.output_dir / "per_case"
    per_case_dir.mkdir(exist_ok=True)

    def evaluate(case_id: str) -> dict:
        fixed = fixed_root / f"{case_id}.rs"
        if not fixed.is_file():
            return {
                "schema_version": 1,
                "case_id": case_id,
                "status": "missing_patch",
                "passed": False,
                "source_file": str(fixed),
            }
        try:
            return evaluate_source(
                case_id=case_id,
                source_path=fixed,
                toolchain_override=args.toolchain,
                timeout_override=args.timeout,
            )
        except (FileNotFoundError, KeyError, ValueError) as exc:
            return {
                "schema_version": 1,
                "case_id": case_id,
                "status": "not_evaluable",
                "passed": False,
                "source_file": str(fixed),
                "error": str(exc),
            }

    results: list[dict] = []
    with ThreadPoolExecutor(max_workers=max(1, args.workers)) as pool:
        futures = {pool.submit(evaluate, case_id): case_id for case_id in case_ids}
        for future in as_completed(futures):
            result = future.result()
            results.append(result)
            (per_case_dir / f"{result['case_id']}.json").write_text(
                json.dumps(result, ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8",
            )

    results.sort(key=lambda item: item["case_id"])
    status_counts = Counter(result["status"] for result in results)
    provided = [result for result in results if result["status"] != "missing_patch"]
    evaluable = [
        result for result in provided if result["status"] != "not_evaluable"
    ]
    passed = sum(1 for result in evaluable if result["passed"])
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    total_frozen = manifest["dataset"]["runnable_case_count"]
    implemented_total = len(_implemented_cases())
    summary = {
        "schema_version": 1,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "fixed_root": str(fixed_root),
        "frozen_dataset_cases": total_frozen,
        "implemented_oracles": implemented_total,
        "oracle_coverage": round(implemented_total / total_frozen, 6),
        "requested_cases": len(results),
        "provided_patches": len(provided),
        "evaluable_patches": len(evaluable),
        "semantic_passes": passed,
        "semantic_consistency_rate_on_evaluable": (
            round(passed / len(evaluable), 6) if evaluable else None
        ),
        "status_counts": dict(sorted(status_counts.items())),
        "cases": results,
    }
    (args.output_dir / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(
        f"evaluated={len(evaluable)} pass={passed} "
        f"coverage={implemented_total}/{total_frozen} "
        f"output={args.output_dir}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
