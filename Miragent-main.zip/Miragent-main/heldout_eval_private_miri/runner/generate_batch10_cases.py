#!/usr/bin/env python3
"""Materialize batch 10: unchecked float-to-int on representable finite inputs."""

from __future__ import annotations

from generate_batch2_cases import DEFAULT, mutation, write_case
from generate_batch6_cases import main_case


CASES = [
    ("float_to_int_32_inf1", "f32", "i32"),
    ("float_to_int_32_infneg1", "f32", "i32"),
    ("float_to_int_32_nan", "f32", "u32"),
    ("float_to_int_32_nanneg", "f32", "u32"),
    ("float_to_int_32_neg", "f32", "u32"),
    ("float_to_int_32_too_big1", "f32", "i32"),
    ("float_to_int_32_too_big2", "f32", "u32"),
    ("float_to_int_32_too_small1", "f32", "i32"),
    ("float_to_int_64_inf1", "f64", "u128"),
    ("float_to_int_64_infneg1", "f64", "u128"),
    ("float_to_int_64_infneg2", "f64", "i128"),
    ("float_to_int_64_nan", "f64", "u32"),
    ("float_to_int_64_neg", "f64", "u128"),
    ("float_to_int_64_too_big1", "f64", "i32"),
    ("float_to_int_64_too_big2", "f64", "i64"),
    ("float_to_int_64_too_big3", "f64", "u64"),
    ("float_to_int_64_too_big4", "f64", "u128"),
    ("float_to_int_64_too_big5", "f64", "i128"),
    ("float_to_int_64_too_big6", "f64", "u128"),
    ("float_to_int_64_too_big7", "f64", "i128"),
]


def build(case_name: str, float_ty: str, int_ty: str):
    literal = f"42.75{float_ty}"
    call = (
        "std::intrinsics::float_to_int_unchecked"
        f"::<{float_ty},{int_ty}>({literal})"
    )
    reference = (
        "#![feature(core_intrinsics)]"
        f"fn main(){{let n=unsafe{{{call}}};assert_eq!(n,42{int_ty});}}"
    )
    tests = (
        "#[test]fn repaired_entry_completes(){main();}"
        "#[test]fn repaired_entry_repeats(){for _ in 0..8{main();}}"
        f"#[test]fn ordinary_representable_casts(){{assert_eq!(0.0{float_ty} as {int_ty},0{int_ty});"
        f"assert_eq!(1.99{float_ty} as {int_ty},1{int_ty});"
        f"assert_eq!(42.75{float_ty} as {int_ty},42{int_ty});}}"
    )
    mutants = [
        mutation(literal, f"41.75{float_ty}", "Changes the representable input."),
        mutation(f"n,42{int_ty}", f"n,41{int_ty}", "Wrong truncated result."),
        mutation(literal, f"43.75{float_ty}", "Changes the integer part."),
        mutation("fn main(){", "fn main(){panic!(\"main\");", "Panics on valid input."),
    ]
    return main_case(
        f"intrinsics__{case_name}",
        f"intrinsics/{case_name}.rs",
        f"float_to_int_unchecked::<{float_ty}, {int_ty}> truncates finite representable inputs toward zero.",
        [],
        DEFAULT,
        "The diagnostic source supplies a non-finite or out-of-range input; the oracle retains the same source and target types but uses only finite representable values.",
        reference,
        tests,
        mutants,
    )


SPECS = [build(*case) for case in CASES]


def main() -> None:
    for item in SPECS:
        write_case(item)
    print(f"wrote {len(SPECS)} batch-10 cases")


if __name__ == "__main__":
    main()
