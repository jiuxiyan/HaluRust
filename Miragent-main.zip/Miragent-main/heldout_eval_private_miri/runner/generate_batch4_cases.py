#!/usr/bin/env python3
"""Materialize the reviewed fourth batch of 20 partial semantic oracles."""

from __future__ import annotations

from generate_batch2_cases import DEFAULT, STACK_TREE, TREE, WEAK_STRICT, mutation, write_case


TREE_PERMISSIVE = [("tree-permissive", ["-Zmiri-tree-borrows", "-Zmiri-permissive-provenance"])]
DETERMINISTIC = [("deterministic", ["-Zmiri-deterministic-concurrency"])]
DETERMINISTIC_BOTH = [
    ("stacked-deterministic", ["-Zmiri-deterministic-concurrency"]),
    ("tree-deterministic", ["-Zmiri-deterministic-concurrency", "-Zmiri-tree-borrows"]),
]
UNALIGNED_VALID = [
    ("official-weakened", ["-Zmiri-disable-stacked-borrows", "-Cdebug-assertions=no"]),
    ("default-strict", []),
]
VALIDITY_WEAK_STRICT = [
    (
        "official-weakened",
        [
            "-Zmiri-disable-alignment-check",
            "-Zmiri-disable-stacked-borrows",
            "-Zmiri-disable-validation",
        ],
    ),
    ("default-strict", []),
]


SPECS = [
    {
        "id": "issue-miri-1112",
        "path": "issue-miri-1112.rs",
        "contract": "Meta::new returns size 0, alignment 1, and a drop_fn that accepts &mut () without changing it.",
        "symbols": ["Meta", "Meta::new"],
        "profiles": DEFAULT,
        "evidence": "The constructor literal explicitly sets `drop_fn: |_| {}`, `size: 0`, and `align: 1`.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn constructor_fields_are_exact(){for _ in 0..5{let meta=Meta::new();assert_eq!((meta.size,meta.align),(0,1));let mut unit=();(meta.drop_fn)(&mut unit);assert_eq!(unit,());}}
            #[test] fn instances_are_independent(){let a=Meta::new();let b=Meta::new();assert_eq!((a.size,a.align,b.size,b.align),(0,1,0,1));}
        """,
        "reference": """
            trait Empty{} #[repr(transparent)] pub struct FunnyPointer(dyn Empty);
            #[repr(C)] pub struct Meta{drop_fn:fn(&mut()),size:usize,align:usize}
            impl Meta{fn new()->Self{Meta{drop_fn:|_|{},size:0,align:1}}}
            fn main(){let meta=Meta::new();assert_eq!((meta.size,meta.align),(0,1));}
        """,
        "mutations": [
            mutation("size:0", "size:1", "Returns the wrong size."),
            mutation("align:1", "align:2", "Returns the wrong alignment."),
            mutation("drop_fn:|_|{}", "drop_fn:|_|panic!(\"drop\")", "Installs a panicking drop function."),
            mutation("Meta{drop_fn:|_|{},size:0,align:1}", "Meta{drop_fn:|_|{},size:8,align:8}", "Returns layout-like nonzero fields."),
        ],
    },
    {
        "id": "unaligned_pointers__reference_to_packed",
        "path": "unaligned_pointers/reference_to_packed.rs",
        "contract": "For a live properly aligned T pointer, raw_to_ref returns a shared reference to the same address and value.",
        "symbols": ["raw_to_ref"],
        "profiles": UNALIGNED_VALID,
        "evidence": "The helper is a direct pointer-to-reference transmute; the fixture fails only because the supplied packed-field pointer is unaligned.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn returns_same_aligned_i32(){for value in [i32::MIN,-1,0,42,i32::MAX]{let x=value;let r=unsafe{raw_to_ref(&x)};assert_eq!(*r,value);assert_eq!(r as *const i32,&x as *const i32);}}
            #[test] fn works_for_other_aligned_types(){let x=0x1122334455667788u64;let r=unsafe{raw_to_ref(&x)};assert_eq!(*r,x);assert_eq!(r as *const u64,&x);}
        """,
        "reference": """
            use std::mem;
            #[repr(packed)] struct Foo{x:i32,y:i32}
            unsafe fn raw_to_ref<'a,T>(x:*const T)->&'a T{mem::transmute(x)}
            fn main(){let x=42i32;assert_eq!(*unsafe{raw_to_ref(&x)},42);}
        """,
        "mutations": [
            mutation("{mem::transmute(x)}", "{&*x.wrapping_add(1)}", "Returns the next element."),
            mutation("{mem::transmute(x)}", "{&*x.wrapping_sub(1)}", "Returns the previous element."),
            mutation("{mem::transmute(x)}", "{&*std::ptr::null::<T>()}", "Returns a null-derived reference."),
            mutation("{mem::transmute(x)}", "{let _=x;panic!(\"no ref\")}", "Panics instead of returning."),
        ],
    },
    {
        "id": "dangling_pointers__stack_temporary",
        "path": "dangling_pointers/stack_temporary.rs",
        "contract": "For a live valid i32 pointer, make_ref returns a mutable reference to the same address and supports reads and writes.",
        "symbols": ["make_ref"],
        "profiles": WEAK_STRICT,
        "evidence": "The helper directly evaluates `&mut *x`; the fixture's failure is caused by ending the temporary's lifetime before use.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn aliases_live_storage(){for initial in [i32::MIN,-1,0,42,i32::MAX]{let mut x=initial;let p=&mut x as *mut i32;let r=unsafe{make_ref(p)};assert_eq!(*r,initial);assert_eq!(r as *mut i32,p);*r=17;assert_eq!(x,17);}}
            #[test] fn independent_pointers_stay_independent(){let(mut a,mut b)=(1,2);unsafe{*make_ref(&mut a)=3;*make_ref(&mut b)=4;}assert_eq!((a,b),(3,4));}
        """,
        "reference": """
            unsafe fn make_ref<'a>(x:*mut i32)->&'a mut i32{&mut *x}
            fn main(){let mut x=0;unsafe{*make_ref(&mut x)=7;}assert_eq!(x,7);}
        """,
        "mutations": [
            mutation("{&mut *x}", "{&mut *x.wrapping_add(1)}", "Returns the next address."),
            mutation("{&mut *x}", "{&mut *x.wrapping_sub(1)}", "Returns the previous address."),
            mutation("{&mut *x}", "{&mut *std::ptr::null_mut()}", "Returns a null-derived reference."),
            mutation("{&mut *x}", "{*x=0;&mut *x}", "Adds an observable write."),
        ],
    },
    {
        "id": "stacked_borrows__interior_mut2",
        "path": "stacked_borrows/interior_mut2.rs",
        "contract": "While the UnsafeCell allocation remains live, unsafe_cell_get returns a mutable reference to its contained T at the same address.",
        "symbols": ["unsafe_cell_get"],
        "profiles": DEFAULT,
        "evidence": "The source comment defines the helper as equivalent to `&mut *x.get()` without an intermediate raw pointer.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn exposes_same_live_cell_storage(){for initial in [-1,0,42]{let cell=std::cell::UnsafeCell::new(initial);let raw=cell.get();let r=unsafe{unsafe_cell_get(&cell)};assert_eq!(r as *mut i32,raw);assert_eq!(*r,initial);*r=9;assert_eq!(unsafe{*cell.get()},9);}}
            #[test] fn generic_values_round_trip(){let cell=std::cell::UnsafeCell::new((1u8,2u16));let r=unsafe{unsafe_cell_get(&cell)};r.1=7;assert_eq!(unsafe{*cell.get()},(1,7));}
        """,
        "reference": """
            use std::cell::UnsafeCell;use std::mem;
            #[allow(mutable_transmutes)] unsafe fn unsafe_cell_get<T>(x:&UnsafeCell<T>)->&'static mut T{mem::transmute(x)}
            fn main(){let cell=UnsafeCell::new(0i32);*unsafe{unsafe_cell_get(&cell)}=7;assert_eq!(unsafe{*cell.get()},7);}
        """,
        "mutations": [
            mutation("{mem::transmute(x)}", "{&mut *x.get().wrapping_add(1)}", "Returns the next address."),
            mutation("{mem::transmute(x)}", "{&mut *x.get().wrapping_sub(1)}", "Returns the previous address."),
            mutation("{mem::transmute(x)}", "{&mut *std::ptr::null_mut()}", "Returns a null-derived reference."),
            mutation("{mem::transmute(x)}", "{let _=x;panic!(\"no cell\")}", "Panics instead of returning."),
        ],
    },
    {
        "id": "uninit__uninit_alloc_diagnostic_with_provenance",
        "path": "uninit/uninit_alloc_diagnostic_with_provenance.rs",
        "contract": "For a valid fragment index, byte_with_provenance returns an initialized byte whose integer payload equals val.",
        "symbols": ["byte_with_provenance"],
        "profiles": WEAK_STRICT,
        "evidence": "The helper constructs every address byte from repeated `val` and returns the selected initialized fragment.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn every_fragment_carries_requested_byte(){let source=42u32;for val in [0u8,1,0x42,0xff]{for idx in 0..std::mem::size_of::<*const ()>(){let got=byte_with_provenance(val,&source,idx);assert_eq!(unsafe{got.assume_init()},val);}}}
            #[test] fn provenance_source_does_not_change_payload(){let a=1u8;let b=2u64;assert_eq!(unsafe{byte_with_provenance(7,&a,0).assume_init()},7);assert_eq!(unsafe{byte_with_provenance(7,&b,0).assume_init()},7);}
        """,
        "reference": """
            use std::mem::{self,MaybeUninit};
            fn byte_with_provenance<T>(val:u8,prov:*const T,frag_idx:usize)->MaybeUninit<u8>{let ptr=prov.with_addr(usize::from_ne_bytes([val;_]));let bytes:[MaybeUninit<u8>;mem::size_of::<*const()>()]=unsafe{mem::transmute(ptr)};bytes[frag_idx]}
            fn main(){let x=42u8;assert_eq!(unsafe{byte_with_provenance(7,&x,0).assume_init()},7);}
        """,
        "mutations": [
            mutation("bytes[frag_idx]", "MaybeUninit::new(0)", "Returns zero."),
            mutation("bytes[frag_idx]", "MaybeUninit::new(val.wrapping_add(1))", "Returns an off-by-one byte."),
            mutation("[val;_]", "[0;_]", "Drops the requested address payload."),
            mutation("bytes[frag_idx]", "MaybeUninit::uninit()", "Returns an uninitialized byte."),
        ],
    },
    {
        "id": "stacked_borrows__deallocate_against_protector1",
        "path": "stacked_borrows/deallocate_against_protector1.rs",
        "contract": "inner invokes its function-pointer callback exactly once with the same mutable i32 referent, permitting mutation but not deallocation.",
        "symbols": ["inner"],
        "profiles": DEFAULT,
        "evidence": "The source body directly calls `f(x)` once and explicitly states that mutation is permitted.",
        "tests": """
            fn set17(x:&mut i32){*x=17;}fn add3(x:&mut i32){*x+=3;}
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn forwards_same_reference(){for initial in [-1,0,42]{let mut x=initial;inner(&mut x,set17);assert_eq!(x,17);}}
            #[test] fn invokes_once(){let mut x=10;inner(&mut x,add3);assert_eq!(x,13);}
        """,
        "reference": """
            fn inner(x:&mut i32,f:fn(&mut i32)){f(x)}
            fn set17(x:&mut i32){*x=17;}fn main(){let mut x=0;inner(&mut x,set17);assert_eq!(x,17);}
        """,
        "mutations": [
            mutation("{f(x)}", "{}", "Drops the callback."),
            mutation("{f(x)}", "{f(x);f(x)}", "Calls the callback twice."),
            mutation("{f(x)}", "{let mut other=0;f(&mut other)}", "Passes unrelated storage."),
            mutation("{f(x)}", "{*x=0;f(x)}", "Mutates x before the callback."),
        ],
    },
    {
        "id": "tree_borrows__wildcard__strongly_protected_wildcard",
        "path": "tree_borrows/wildcard/strongly_protected_wildcard.rs",
        "contract": "inner calls its function pointer exactly once with the exposed address of x, allowing a non-deallocating callback to mutate x.",
        "symbols": ["inner"],
        "profiles": TREE_PERMISSIVE,
        "evidence": "The helper converts x to `*mut i32 as usize` and passes that value directly to f.",
        "tests": """
            fn set17(addr:usize){unsafe{*(addr as *mut i32)=17;}}fn add3(addr:usize){unsafe{*(addr as *mut i32)+=3;}}
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn forwards_exposed_address(){for initial in [-1,0,42]{let mut x=initial;inner(&mut x,set17);assert_eq!(x,17);}}
            #[test] fn invokes_once(){let mut x=10;inner(&mut x,add3);assert_eq!(x,13);}
        """,
        "reference": """
            fn inner(x:&mut i32,f:fn(usize)){f(x as *mut i32 as usize)}
            fn set17(addr:usize){unsafe{*(addr as *mut i32)=17;}}fn main(){let mut x=0;inner(&mut x,set17);assert_eq!(x,17);}
        """,
        "mutations": [
            mutation("{f(x as *mut i32 as usize)}", "{}", "Drops the callback."),
            mutation("{f(x as *mut i32 as usize)}", "{f(x as *mut i32 as usize);f(x as *mut i32 as usize)}", "Calls twice."),
            mutation("x as *mut i32 as usize", "0usize", "Passes a null address."),
            mutation("{f(x as *mut i32 as usize)}", "{*x=0;f(x as *mut i32 as usize)}", "Mutates x first."),
        ],
    },
    {
        "id": "enum-set-discriminant-niche-variant-wrong",
        "path": "enum-set-discriminant-niche-variant-wrong.rs",
        "contract": "On the valid Some domain, set_discriminant preserves the Some variant and its NonZero<i32> payload.",
        "symbols": ["Option", "set_discriminant"],
        "profiles": DEFAULT,
        "evidence": "The source says setting the already-Some niched variant is a no-op; only applying it to None is invalid.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn preserves_some_payloads(){for value in [-7,-1,1,42,i32::MAX]{let nz=std::num::NonZero::new(value).unwrap();let mut item=Option::Some(nz);set_discriminant(&mut item);match item{Option::Some(got)=>assert_eq!(got.get(),value),Option::None=>panic!(\"lost payload\")}}}
            #[test] fn repeated_calls_are_noops(){let mut item=Option::Some(std::num::NonZero::new(9).unwrap());for _ in 0..7{set_discriminant(&mut item);}match item{Option::Some(v)=>assert_eq!(v.get(),9),Option::None=>panic!(\"lost\")}}
        """,
        "reference": """
            use std::num::NonZero;#[allow(unused)]enum Option<T>{None,Some(T)}
            fn set_discriminant(ptr:&mut Option<NonZero<i32>>){match ptr{Option::Some(_)=>{},Option::None=>panic!(\"invalid domain\")}}
            fn main(){let mut v=Option::Some(NonZero::new(1).unwrap());set_discriminant(&mut v);}
        """,
        "mutations": [
            mutation("Option::Some(_)=>{}", "Option::Some(_)=>*ptr=Option::None", "Changes Some to None."),
            mutation("Option::Some(_)=>{}", "Option::Some(_)=>*ptr=Option::Some(NonZero::new(1).unwrap())", "Replaces the payload."),
            mutation("Option::Some(_)=>{}", "Option::Some(_)=>panic!(\"some\")", "Panics on the valid domain."),
            mutation("Option::Some(_)=>{}", "Option::Some(v)=>*v=NonZero::new(v.get().wrapping_add(1)).unwrap()", "Changes the payload."),
        ],
    },
    {
        "id": "data_race__local_variable_alloc_race",
        "path": "data_race/local_variable_alloc_race.rs",
        "contract": "When val_ptr already denotes live storage, spawn_thread plus finish joins the worker after it stores 127 through val_ptr.",
        "symbols": ["P", "spawn_thread", "finish"],
        "profiles": DETERMINISTIC,
        "evidence": "The worker explicitly stores 127 after P becomes non-null; finish publishes val_ptr, joins, and asserts 127.",
        "tests": """
            fn run_once(initial:u8)->u8{P.store(std::ptr::null_mut(),std::sync::atomic::Ordering::Relaxed);let mut value=initial;let value_ptr=std::ptr::addr_of_mut!(value);let worker=spawn_thread();finish(worker,value_ptr);value}
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn initializes_live_storage(){for initial in [0u8,1,126,127,255]{assert_eq!(run_once(initial),127);}}
            #[test] fn repeated_protocols_reset_cleanly(){for _ in 0..4{assert_eq!(run_once(9),127);}}
        """,
        "reference": """
            use std::sync::atomic::{AtomicPtr,Ordering::Relaxed};use std::thread::JoinHandle;
            static P:AtomicPtr<u8>=AtomicPtr::new(core::ptr::null_mut());
            fn spawn_thread()->JoinHandle<()>{std::thread::spawn(||{while P.load(Relaxed).is_null(){std::hint::spin_loop();}unsafe{let ptr=P.load(Relaxed);*ptr=127;}})}
            fn finish(t:JoinHandle<()>,val_ptr:*mut u8){P.store(val_ptr,Relaxed);t.join().unwrap();assert_eq!(unsafe{*val_ptr},127);}
            fn main(){P.store(core::ptr::null_mut(),Relaxed);let mut value=0;let value_ptr=std::ptr::addr_of_mut!(value);let t=spawn_thread();finish(t,value_ptr);assert_eq!(value,127);}
        """,
        "mutations": [
            mutation("*ptr=127", "*ptr=126", "Worker stores the wrong value."),
            mutation("assert_eq!(unsafe{*val_ptr},127)", "assert_eq!(unsafe{*val_ptr},126)", "finish validates the wrong value."),
            mutation("t.join().unwrap();assert_eq!", "drop(t);assert_eq!", "Reads before joining the worker."),
            mutation("*ptr=127", "*ptr=0", "Worker stores zero."),
        ],
        "timeout": 240,
    },
    {
        "id": "both_borrows__retag_data_race_write",
        "path": "both_borrows/retag_data_race_write.rs",
        "contract": "Under a sequential non-racing schedule, thread_1 preserves the pointee and thread_2 stores 5 through the same valid SendPtr.",
        "symbols": ["SendPtr", "thread_1", "thread_2"],
        "profiles": DETERMINISTIC_BOTH,
        "evidence": "thread_1 only forms a mutable reference, while thread_2 explicitly performs `*p = 5`.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn sequential_helpers_have_documented_effects(){for initial in [0u8,1,42,255]{let mut value=initial;let p=SendPtr(&mut value);thread_1(p);assert_eq!(value,initial);thread_2(p);assert_eq!(value,5);}}
            #[test] fn independent_pointers_do_not_mix(){let(mut a,mut b)=(1u8,2u8);thread_2(SendPtr(&mut a));thread_2(SendPtr(&mut b));assert_eq!((a,b),(5,5));}
        """,
        "reference": """
            #[derive(Copy,Clone)]struct SendPtr(*mut u8);unsafe impl Send for SendPtr{}
            fn thread_1(p:SendPtr){let p=p.0;unsafe{let _r=&mut *p;}}
            fn thread_2(p:SendPtr){let p=p.0;unsafe{*p=5;}}
            fn main(){let mut x=0;let p=SendPtr(&mut x);thread_1(p);thread_2(p);assert_eq!(x,5);}
        """,
        "mutations": [
            mutation("unsafe{*p=5;}", "unsafe{*p=4;}", "thread_2 stores the wrong value."),
            mutation("unsafe{*p=5;}", "{}", "thread_2 drops its write."),
            mutation("unsafe{let _r=&mut *p;}", "unsafe{*p=1;}", "thread_1 unexpectedly writes."),
            mutation("unsafe{let _r=&mut *p;}", "panic!(\"retag\")", "thread_1 panics."),
        ],
    },
    {
        "id": "function_calls__return_pointer_on_unwind",
        "path": "function_calls/return_pointer_on_unwind.rs",
        "contract": "docall propagates callee's panic without publishing a partial S return value into out; the original out value remains unchanged.",
        "symbols": ["S", "docall", "startpanic", "callee"],
        "profiles": [("no-alias-model", ["-Zmiri-disable-stacked-borrows"]), ("default-strict", [])],
        "evidence": "The source comment states that changes to RET do not propagate without reaching Return; normal call assignment must preserve out on unwind.",
        "tests": """
            fn run(initial:i32,byte:u8){let mut out=S(initial,[byte;128]);let result=std::panic::catch_unwind(std::panic::AssertUnwindSafe(||docall(&mut out)));assert!(result.is_err());assert_eq!(out.0,initial);assert_eq!(out.1,[byte;128]);}
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn panic_preserves_all_out_bytes(){for pair in [(0,0u8),(42,7),(-1,255)]{run(pair.0,pair.1);}}
            #[test] fn repeated_unwinds_do_not_publish_ret(){for _ in 0..5{run(9,3);}}
        """,
        "reference": """
            #[repr(C)]struct S(i32,[u8;128]);
            fn docall(out:&mut S){let next=callee();*out=next;}
            fn startpanic()->(){panic!()}
            fn callee()->S{startpanic();S(42,[0;128])}
            fn main(){let mut out=S(0,[1;128]);let result=std::panic::catch_unwind(std::panic::AssertUnwindSafe(||docall(&mut out)));assert!(result.is_err());assert_eq!(out.0,0);}
        """,
        "mutations": [
            mutation("{let next=callee();*out=next;}", "{out.0=42;let next=callee();*out=next;}", "Publishes field 0 before unwind."),
            mutation("{let next=callee();*out=next;}", "{out.1[0]=0;let next=callee();*out=next;}", "Publishes a byte before unwind."),
            mutation("{panic!()}", "{}", "Suppresses the panic and returns a value."),
            mutation("{let next=callee();*out=next;}", "{out.1[127]=0;let next=callee();*out=next;}", "Publishes the last byte before unwind."),
        ],
    },
    {
        "id": "both_borrows__box_noalias_violation",
        "path": "both_borrows/box_noalias_violation.rs",
        "contract": "On a Box and a distinct live y pointer, test stores 5 in the boxed allocation, forgets ownership, and returns the value read from y.",
        "symbols": ["test"],
        "profiles": STACK_TREE,
        "evidence": "The helper explicitly assigns `*x = 5`, forgets x, and evaluates `*y` as its return value.",
        "tests": """
            unsafe fn run(initial:i32,y:i32)->i32{let raw=Box::into_raw(Box::new(initial));let boxed=Box::from_raw(raw);let got=test(boxed,&y);assert_eq!(*raw,5);drop(Box::from_raw(raw));got}
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn writes_box_and_returns_distinct_y(){for pair in [(-1,0),(0,42),(99,i32::MIN)]{assert_eq!(unsafe{run(pair.0,pair.1)},pair.1);}}
            #[test] fn calls_use_independent_allocations(){assert_eq!(unsafe{(run(1,7),run(2,9))},(7,9));}
        """,
        "reference": """
            unsafe fn test(mut x:Box<i32>,y:*const i32)->i32{*x=5;std::mem::forget(x);*y}
            fn main(){let y=42;let raw=Box::into_raw(Box::new(0));let got=unsafe{test(Box::from_raw(raw),&y)};assert_eq!(got,42);assert_eq!(unsafe{*raw},5);unsafe{drop(Box::from_raw(raw));}}
        """,
        "mutations": [
            mutation("*x=5", "*x=4", "Stores the wrong boxed value."),
            mutation("*x=5;", "", "Drops the boxed write."),
            mutation(";*y}", ";5}", "Returns the boxed constant instead of y."),
            mutation(";*y}", ";(*y).wrapping_add(1)}", "Returns an off-by-one y value."),
        ],
    },
    {
        "id": "data_race__mixed_size_read_write",
        "path": "data_race/mixed_size_read_write.rs",
        "contract": "convert returns a two-element AtomicU8 view beginning at the same address as the supplied AtomicU16; this contract excludes concurrent mixed-size accesses.",
        "symbols": ["convert"],
        "profiles": DETERMINISTIC,
        "evidence": "The helper is a direct reference transmute from AtomicU16 to `[AtomicU8; 2]`; UB in main requires concurrent mixed-size accesses.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn view_has_same_base_and_two_bytes(){for value in [0u16,1,0x1234,u16::MAX]{let atomic=std::sync::atomic::AtomicU16::new(value);let view=convert(&atomic);assert_eq!(view.len(),2);assert_eq!(view.as_ptr() as *const u8,&atomic as *const _ as *const u8);assert_eq!(unsafe{view.as_ptr().add(1)} as *const u8,unsafe{(&atomic as *const _ as *const u8).add(1)});}}
            #[test] fn views_follow_each_allocation(){let a=std::sync::atomic::AtomicU16::new(0);let b=std::sync::atomic::AtomicU16::new(0);assert_ne!(convert(&a).as_ptr(),convert(&b).as_ptr());}
        """,
        "reference": """
            use std::sync::atomic::{AtomicU8,AtomicU16};
            fn convert(a:&AtomicU16)->&[AtomicU8;2]{unsafe{std::mem::transmute(a)}}
            fn main(){let a=AtomicU16::new(0);assert_eq!(convert(&a).as_ptr() as *const u8,&a as *const _ as *const u8);}
        """,
        "mutations": [
            mutation("{unsafe{std::mem::transmute(a)}}", "{unsafe{&*((a as *const AtomicU16 as *const [AtomicU8;2]).add(1))}}", "Returns the next array-sized region."),
            mutation("{unsafe{std::mem::transmute(a)}}", "{unsafe{&*((a as *const AtomicU16 as *const u8).add(1) as *const [AtomicU8;2])}}", "Returns a one-byte-shifted view."),
            mutation("{unsafe{std::mem::transmute(a)}}", "{static Z:[AtomicU8;2]=[AtomicU8::new(0),AtomicU8::new(0)];&Z}", "Returns unrelated static storage."),
            mutation("{unsafe{std::mem::transmute(a)}}", "{let _=a;panic!(\"no view\")}", "Panics instead of converting."),
        ],
    },
    {
        "id": "validity__invalid_enum_cast",
        "path": "validity/invalid_enum_cast.rs",
        "contract": "For a valid E pointer, cast completes after reading its discriminant and leaves the enum value unchanged.",
        "symbols": ["E", "cast"],
        "profiles": VALIDITY_WEAK_STRICT,
        "evidence": "The helper only evaluates `*ptr as u32`; the fixture fails because main supplies an invalid discriminant.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn accepts_and_preserves_all_variants(){for mut value in [E::A,E::B,E::C]{let before=value as u32;cast(&value);assert_eq!(value as u32,before);}}
            #[test] fn repeated_valid_casts_are_side_effect_free(){let value=E::B;for _ in 0..8{cast(&value);assert_eq!(value as u32,E::B as u32);}}
        """,
        "reference": """
            #[derive(Copy,Clone)]#[allow(unused)]enum E{A,B,C}
            fn cast(ptr:*const E){unsafe{let _val=*ptr as u32;}}
            fn main(){let value=E::A;cast(&value);}
        """,
        "mutations": [
            mutation("unsafe{let _val=*ptr as u32;}", "unsafe{*(ptr as *mut E)=E::B;}", "Mutates the enum to B."),
            mutation("unsafe{let _val=*ptr as u32;}", "unsafe{*(ptr as *mut E)=E::C;}", "Mutates the enum to C."),
            mutation("unsafe{let _val=*ptr as u32;}", "panic!(\"no cast\")", "Panics on valid input."),
            mutation("unsafe{let _val=*ptr as u32;}", "unsafe{let _val=*ptr.add(1) as u32;}", "Reads outside the valid object."),
        ],
    },
    {
        "id": "validity__invalid_char_match",
        "path": "validity/invalid_char_match.rs",
        "contract": "For a valid char pointer, switch_int completes its match and leaves the character unchanged.",
        "symbols": ["switch_int"],
        "profiles": VALIDITY_WEAK_STRICT,
        "evidence": "The custom MIR only switches on `*ptr`; the fixture supplies an invalid 32-bit char encoding.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn accepts_and_preserves_valid_chars(){for mut value in ['\\0','0','A','λ',char::MAX]{let before=value;switch_int(&value);assert_eq!(value,before);}}
            #[test] fn both_match_arms_complete(){let zero='0';let other='x';for _ in 0..6{switch_int(&zero);switch_int(&other);assert_eq!((zero,other),('0','x'));}}
        """,
        "reference": """
            fn switch_int(ptr:*const char){match unsafe{*ptr}{'0'=>{},_=>{}}}
            fn main(){let value='0';switch_int(&value);}
        """,
        "mutations": [
            mutation("{'0'=>{},_=>{}}", "{'0'=>panic!(\"zero\"),_=>{}}", "Panics in the zero arm."),
            mutation("{'0'=>{},_=>{}}", "{'0'=>{},_=>panic!(\"other\")}", "Panics in the other arm."),
            mutation("match unsafe{*ptr}", "match unsafe{*(ptr.add(1))}", "Reads outside the valid char."),
            mutation("{'0'=>{},_=>{}}", "{_=>unsafe{*(ptr as *mut char)='z'}}", "Mutates the character."),
        ],
    },
    {
        "id": "stacked_borrows__illegal_read1",
        "path": "stacked_borrows/illegal_read1.rs",
        "contract": "For a valid live i32 pointer, callee completes its read without changing the pointee.",
        "symbols": ["callee"],
        "profiles": DEFAULT,
        "evidence": "The helper only reads `*xraw`; the fixture's later alias use, not a write in callee, triggers the failure.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn preserves_valid_pointees(){for initial in [i32::MIN,-1,0,42,i32::MAX]{let mut x=initial;callee(&mut x);assert_eq!(x,initial);}}
            #[test] fn repeated_reads_are_side_effect_free(){let mut x=77;for _ in 0..8{callee(&mut x);assert_eq!(x,77);}}
        """,
        "reference": """
            fn callee(xraw:*mut i32){let _val=unsafe{*xraw};}
            fn main(){let mut x=15;callee(&mut x);assert_eq!(x,15);}
        """,
        "mutations": [
            mutation("{let _val=unsafe{*xraw};}", "{unsafe{*xraw=0;}}", "Writes zero."),
            mutation("{let _val=unsafe{*xraw};}", "{unsafe{*xraw=1;}}", "Writes one."),
            mutation("{let _val=unsafe{*xraw};}", "{let _val=unsafe{*xraw.add(1)};}", "Reads outside the object."),
            mutation("{let _val=unsafe{*xraw};}", "{panic!(\"no read\")}", "Panics on valid input."),
        ],
    },
    {
        "id": "stacked_borrows__illegal_read2",
        "path": "stacked_borrows/illegal_read2.rs",
        "contract": "For a valid live i32 pointer, callee's intermediate shared-reference read completes without changing the pointee.",
        "symbols": ["callee"],
        "profiles": DEFAULT,
        "evidence": "The helper creates `shr = &*xraw` and only reads through shr.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn preserves_valid_pointees(){for initial in [i32::MIN,-1,0,42,i32::MAX]{let mut x=initial;callee(&mut x);assert_eq!(x,initial);}}
            #[test] fn repeated_reads_are_side_effect_free(){let mut x=77;for _ in 0..8{callee(&mut x);assert_eq!(x,77);}}
        """,
        "reference": """
            fn callee(xraw:*mut i32){let shr=unsafe{&*xraw};let _val=*shr;}
            fn main(){let mut x=15;callee(&mut x);assert_eq!(x,15);}
        """,
        "mutations": [
            mutation("{let shr=unsafe{&*xraw};let _val=*shr;}", "{unsafe{*xraw=0;}}", "Writes zero."),
            mutation("{let shr=unsafe{&*xraw};let _val=*shr;}", "{unsafe{*xraw=1;}}", "Writes one."),
            mutation("&*xraw", "&*xraw.add(1)", "Creates an out-of-range shared reference."),
            mutation("{let shr=unsafe{&*xraw};let _val=*shr;}", "{panic!(\"no read\")}", "Panics on valid input."),
        ],
    },
    {
        "id": "stacked_borrows__invalidate_against_protector1",
        "path": "stacked_borrows/invalidate_against_protector1.rs",
        "contract": "On distinct live inputs, inner reads through x and preserves both the x pointee and the mutable y pointee.",
        "symbols": ["inner"],
        "profiles": DEFAULT,
        "evidence": "The helper only reads `*x` and does not access y; failure requires x and y to alias.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn preserves_distinct_inputs(){for pair in [(-1,0),(0,42),(i32::MAX,i32::MIN)]{let(mut x,mut y)=pair;inner(&mut x,&mut y);assert_eq!((x,y),pair);}}
            #[test] fn repeated_calls_are_side_effect_free(){let(mut x,mut y)=(7,9);for _ in 0..8{inner(&mut x,&mut y);assert_eq!((x,y),(7,9));}}
        """,
        "reference": """
            fn inner(x:*mut i32,_y:&mut i32){let _val=unsafe{*x};}
            fn main(){let(mut x,mut y)=(1,2);inner(&mut x,&mut y);assert_eq!((x,y),(1,2));}
        """,
        "mutations": [
            mutation("{let _val=unsafe{*x};}", "{unsafe{*x=0;}}", "Writes x."),
            mutation("{let _val=unsafe{*x};}", "{*_y=0;}", "Writes y."),
            mutation("{let _val=unsafe{*x};}", "{unsafe{*x=*_y;}}", "Copies y into x."),
            mutation("{let _val=unsafe{*x};}", "{panic!(\"no read\")}", "Panics on valid input."),
        ],
    },
    {
        "id": "both_borrows__pass_invalid_shr_tuple",
        "path": "both_borrows/pass_invalid_shr_tuple.rs",
        "contract": "foo accepts a pair of valid shared i32 references, completes, and leaves both referents unchanged.",
        "symbols": ["foo"],
        "profiles": STACK_TREE,
        "evidence": "The helper body is empty; all failure behavior in the fixture comes from passing an already-invalidated reference.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn accepts_and_preserves_pairs(){for pair in [(-1,0),(0,42),(i32::MAX,i32::MIN)]{let(a,b)=pair;foo((&a,&b));assert_eq!((a,b),pair);}}
            #[test] fn repeated_valid_calls_are_noops(){let(a,b)=(7,9);for _ in 0..8{foo((&a,&b));assert_eq!((a,b),(7,9));}}
        """,
        "reference": """
            #![allow(invalid_reference_casting)]
            fn foo(_:(&i32,&i32)){}
            fn main(){let(a,b)=(1,2);foo((&a,&b));assert_eq!((a,b),(1,2));}
        """,
        "mutations": [
            mutation("fn foo(_:(&i32,&i32)){}", "fn foo(x:(&i32,&i32)){unsafe{*(x.0 as *const _ as *mut i32)=0;}}", "Mutates the first referent."),
            mutation("fn foo(_:(&i32,&i32)){}", "fn foo(x:(&i32,&i32)){unsafe{*(x.1 as *const _ as *mut i32)=0;}}", "Mutates the second referent."),
            mutation("fn foo(_:(&i32,&i32)){}", "fn foo(x:(&i32,&i32)){if *x.0==0{panic!(\"zero\")}}", "Panics for a valid first value."),
            mutation("fn foo(_:(&i32,&i32)){}", "fn foo(x:(&i32,&i32)){if *x.1==42{panic!(\"forty-two\")}}", "Panics for a valid second value."),
        ],
    },
    {
        "id": "both_borrows__pass_invalid_shr_option",
        "path": "both_borrows/pass_invalid_shr_option.rs",
        "contract": "foo accepts None or Some(valid shared i32 reference), completes, and leaves a Some referent unchanged.",
        "symbols": ["foo"],
        "profiles": STACK_TREE,
        "evidence": "The helper body is empty; the fixture failure depends entirely on Some carrying an invalidated reference.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn accepts_none_and_preserves_some(){foo(None);for value in [i32::MIN,-1,0,42,i32::MAX]{let x=value;foo(Some(&x));assert_eq!(x,value);}}
            #[test] fn repeated_calls_are_noops(){let x=7;for _ in 0..8{foo(Some(&x));foo(None);assert_eq!(x,7);}}
        """,
        "reference": """
            #![allow(invalid_reference_casting)]
            fn foo(_:Option<&i32>){}
            fn main(){let x=1;foo(None);foo(Some(&x));assert_eq!(x,1);}
        """,
        "mutations": [
            mutation("fn foo(_:Option<&i32>){}", "fn foo(x:Option<&i32>){if let Some(r)=x{unsafe{*(r as *const _ as *mut i32)=0;}}}", "Mutates Some's referent."),
            mutation("fn foo(_:Option<&i32>){}", "fn foo(x:Option<&i32>){if let Some(r)=x{unsafe{*(r as *const _ as *mut i32)=1;}}}", "Overwrites Some's referent."),
            mutation("fn foo(_:Option<&i32>){}", "fn foo(x:Option<&i32>){if x.is_none(){panic!(\"none\")}}", "Rejects None."),
            mutation("fn foo(_:Option<&i32>){}", "fn foo(x:Option<&i32>){if x.is_some(){panic!(\"some\")}}", "Rejects Some."),
        ],
    },
]


def main() -> None:
    for spec in SPECS:
        write_case(spec)
    print(f"wrote {len(SPECS)} batch-4 cases")


if __name__ == "__main__":
    main()
