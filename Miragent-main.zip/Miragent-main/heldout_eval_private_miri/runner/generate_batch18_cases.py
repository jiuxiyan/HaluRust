#!/usr/bin/env python3
"""Materialize batch 18: provenance-preserving repairs and leak/never boundaries."""

from __future__ import annotations

from generate_batch2_cases import DEFAULT, mutation, write_case
from generate_batch6_cases import main_case


STRICT = [("official-strict", ["-Zmiri-strict-provenance"]), ("default-strict", [])]
WEAK = [
    (
        "official-checks-disabled",
        ["-Zmiri-disable-alignment-check", "-Zmiri-disable-stacked-borrows", "-Zmiri-disable-validation"],
    ),
    ("default-strict", []),
]
NO_VALID = [("official-no-validation", ["-Zmiri-disable-validation"]), ("default-strict", [])]


def c(case_id, path, contract, symbols, profiles, evidence, reference, tests, muts):
    return main_case(case_id, path, contract, symbols, profiles, evidence, reference, tests, muts)


def entry_tests(extra: str) -> str:
    return (
        "#[test]fn repaired_entry_completes(){main();}"
        "#[test]fn repeats(){for _ in 0..6{main();}}"
        f"#[test]fn independent_valid_domain(){{{extra}}}"
    )


P = mutation("fn main(){", 'fn main(){panic!("main");', "Rejects the valid repaired entry.")
PROV = (
    "The source isolates provenance loss caused by integer-typed, partial, or provenance-free reconstruction. "
    "The oracle preserves the same address-level operation while retaining one complete live pointer provenance."
)


SPECS = [
    c(
        "provenance__int_copy_looses_provenance0",
        "provenance/int_copy_looses_provenance0.rs",
        "Copying the pointer-plus-bool pair at its pointer type preserves the live pointer to 42 and the true flag.",
        [],
        DEFAULT,
        PROV,
        "fn main(){let x=42i32;let ptrs=[(&x as*const i32,true)];let copy=ptrs;assert_eq!(unsafe{*copy[0].0},42);assert!(copy[0].1);}",
        entry_tests("let x=7i32;let a=[(&x as*const i32,false)];let b=a;assert_eq!(unsafe{*b[0].0},7);assert!(!b[0].1);"),
        [
            mutation("x=42i32", "x=41i32", "Changes the pointee."),
            mutation("*copy[0].0},42", "*copy[0].0},41", "Claims the wrong pointee."),
            mutation("true)];", "false)];", "Changes the copied flag."),
            P,
        ],
    ),
    c(
        "provenance__int_copy_looses_provenance1",
        "provenance/int_copy_looses_provenance1.rs",
        "Copying a one-element pointer array at pointer type preserves its live pointer to 42.",
        [],
        DEFAULT,
        PROV,
        "fn main(){let x=42i32;let ptrs=[&x as*const i32];let copy=ptrs;assert_eq!(copy[0],&x as*const i32);assert_eq!(unsafe{*copy[0]},42);}",
        entry_tests("let x=7i32;let a=[&x as*const i32];let b=a;assert_eq!(unsafe{*b[0]},7);"),
        [
            mutation("x=42i32", "x=41i32", "Changes the pointee."),
            mutation("*copy[0]},42", "*copy[0]},41", "Claims the wrong pointee."),
            mutation("let copy=ptrs", "let copy=[std::ptr::null()]", "Drops the live provenance."),
            P,
        ],
    ),
    c(
        "provenance__int_copy_looses_provenance2",
        "provenance/int_copy_looses_provenance2.rs",
        "A typed copy of a pair of live references preserves both pointees, each equal to 42.",
        [],
        DEFAULT,
        PROV,
        "fn main(){let a=42i32;let b=42i32;let ptrs=[(&a,&b)];let copy=ptrs;assert_eq!((*copy[0].0,*copy[0].1),(42,42));}",
        entry_tests("let(a,b)=(7i32,8i32);let x=[(&a,&b)];let y=x;assert_eq!((*y[0].0,*y[0].1),(7,8));"),
        [
            mutation("let b=42i32", "let b=41i32", "Changes the metadata-side pointee."),
            mutation("(42,42)", "(42,41)", "Claims the wrong pair."),
            mutation("let copy=ptrs", 'let copy=ptrs;panic!("copy")', "Rejects the typed copy."),
            P,
        ],
    ),
    c(
        "provenance__mix-ptrs1",
        "provenance/mix-ptrs1.rs",
        "A complete copied pointer retains one coherent provenance and with_addr at its original address dereferences to 0.",
        [],
        DEFAULT,
        PROV,
        "fn main(){let x=0i32;let p=&x as*const i32;let copy=p;let q=copy.with_addr(p.addr());assert_eq!(unsafe{*q},0);assert_eq!(q,p);}",
        entry_tests("let x=7i32;let p=&x as*const i32;assert_eq!(unsafe{*p.with_addr(p.addr())},7);"),
        [
            mutation("x=0i32", "x=1i32", "Changes the pointee."),
            mutation("*q},0", "*q},1", "Claims the wrong pointee."),
            mutation("let copy=p", "let copy=std::ptr::without_provenance(p.addr())", "Removes provenance."),
            P,
        ],
    ),
    c(
        "provenance__mix-ptrs2",
        "provenance/mix-ptrs2.rs",
        "Changing only a complete pointer's address to its own address preserves provenance and reads 42.",
        [],
        DEFAULT,
        PROV,
        "fn main(){let x=42i32;let p=&x as*const i32;let q=p.with_addr(p.addr());assert_eq!(q,p);assert_eq!(unsafe{*q},42);}",
        entry_tests("let x=9i32;let p=&x as*const i32;let q=p.with_addr(p.addr());assert_eq!(unsafe{*q},9);"),
        [
            mutation("x=42i32", "x=41i32", "Changes the pointee."),
            mutation("*q},42", "*q},41", "Claims the wrong pointee."),
            mutation("p.with_addr(p.addr())", "std::ptr::without_provenance(p.addr())", "Drops provenance."),
            P,
        ],
    ),
    c(
        "provenance__pointer_partial_overwrite",
        "provenance/pointer_partial_overwrite.rs",
        "Replacing a pointer as one complete typed value makes it point to the live integer 43.",
        [],
        WEAK,
        PROV,
        "fn main(){let a=42i32;let b=43i32;let mut p=&a as*const i32;p=&b as*const i32;assert_eq!(unsafe{*p},43);}",
        entry_tests("let(a,b)=(7i32,8i32);let mut p=&a as*const i32;p=&b;assert_eq!(unsafe{*p},8);"),
        [
            mutation("b=43i32", "b=44i32", "Changes the replacement pointee."),
            mutation("*p},43", "*p},44", "Claims the wrong pointee."),
            mutation("p=&b as*const i32", 'panic!("replace")', "Rejects complete pointer replacement."),
            P,
        ],
    ),
    c(
        "provenance__ptr_copy_loses_partial_provenance0",
        "provenance/ptr_copy_loses_partial_provenance0.rs",
        "An unaligned write and read of one complete raw pointer at the same byte offset preserves its live pointee 42.",
        [],
        DEFAULT,
        PROV,
        "fn main(){let x=42i32;let mut bytes=[0u8;32];let at=std::mem::size_of::<*const()>()/2;unsafe{bytes.as_mut_ptr().add(at).cast::<*const i32>().write_unaligned(&x);let p=bytes.as_ptr().add(at).cast::<*const i32>().read_unaligned();assert_eq!(*p,42);}}",
        entry_tests("let x=7i32;let mut b=[0u8;32];unsafe{b.as_mut_ptr().add(1).cast::<*const i32>().write_unaligned(&x);let p=b.as_ptr().add(1).cast::<*const i32>().read_unaligned();assert_eq!(*p,7);}"),
        [
            mutation("x=42i32", "x=41i32", "Changes the pointee."),
            mutation("*p,42", "*p,41", "Claims the wrong pointee."),
            mutation("as_ptr().add(at)", "as_ptr().add(at+1)", "Reads a shifted partial pointer."),
            P,
        ],
    ),
    c(
        "provenance__ptr_copy_loses_partial_provenance1",
        "provenance/ptr_copy_loses_partial_provenance1.rs",
        "A complete fn() pointer copied unaligned at one byte offset remains callable and records one invocation.",
        ["target"],
        DEFAULT,
        PROV,
        "use std::sync::atomic::{AtomicUsize,Ordering};static SEEN:AtomicUsize=AtomicUsize::new(0);fn target(){SEEN.store(1,Ordering::SeqCst)}fn main(){SEEN.store(0,Ordering::SeqCst);let mut bytes=[0u8;32];unsafe{bytes.as_mut_ptr().add(1).cast::<fn()>().write_unaligned(target);let f=bytes.as_ptr().add(1).cast::<fn()>().read_unaligned();f();}assert_eq!(SEEN.load(Ordering::SeqCst),1);}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn target_is_callable(){main();}#[test]fn function_pointer_layout(){assert_eq!(std::mem::size_of::<fn()>(),std::mem::size_of::<usize>());}",
        [
            mutation("store(1", "store(2", "Changes the target effect."),
            mutation("SeqCst),1", "SeqCst),2", "Claims the wrong effect."),
            mutation("as_ptr().add(1)", "as_ptr().add(2)", "Reads a shifted partial pointer."),
            P,
        ],
    ),
    c(
        "provenance__ptr_invalid",
        "provenance/ptr_invalid.rs",
        "with_addr on the original live pointer at its own address retains provenance and reads 42.",
        [],
        DEFAULT,
        PROV,
        "fn main(){let x=42i32;let p=&x as*const i32;let q=p.with_addr(p.addr());assert_eq!(q,p);assert_eq!(unsafe{*q},42);}",
        entry_tests("let x=7i32;let p=&x as*const i32;assert_eq!(unsafe{*p.with_addr(p.addr())},7);"),
        [
            mutation("x=42i32", "x=41i32", "Changes the pointee."),
            mutation("*q},42", "*q},41", "Claims the wrong pointee."),
            mutation("p.with_addr(p.addr())", "std::ptr::without_provenance(p.addr())", "Removes provenance."),
            P,
        ],
    ),
    c(
        "provenance__ptr_invalid_offset",
        "provenance/ptr_invalid_offset.rs",
        "Offsetting a live in-bounds u8 pointer by one reaches and reads the second byte 23.",
        [],
        STRICT,
        PROV,
        "fn main(){let x=[22u8,23];let p=x.as_ptr();let q=unsafe{p.offset(1)};assert_eq!(unsafe{*q},23);assert_eq!(q,unsafe{p.add(1)});}",
        entry_tests("let x=[7u8,8,9];for i in 0..x.len(){assert_eq!(unsafe{*x.as_ptr().add(i)},x[i]);}"),
        [
            mutation("[22u8,23]", "[22u8,24]", "Changes the offset pointee."),
            mutation("*q},23", "*q},24", "Claims the wrong pointee."),
            mutation("p.offset(1)", "p.offset(2)", "Offsets beyond the allocation."),
            P,
        ],
    ),
    c(
        "provenance__strict_provenance_cast",
        "provenance/strict_provenance_cast.rs",
        "Under strict provenance, with_addr on the original pointer at its own address reads the live value 0.",
        [],
        STRICT,
        PROV,
        "fn main(){let x=0i32;let p=&x as*const i32;let q=p.with_addr(p.addr());assert_eq!(q,p);assert_eq!(unsafe{*q},0);}",
        entry_tests("let x=7i32;let p=&x as*const i32;assert_eq!(unsafe{*p.with_addr(p.addr())},7);"),
        [
            mutation("x=0i32", "x=1i32", "Changes the pointee."),
            mutation("*q},0", "*q},1", "Claims the wrong pointee."),
            mutation("p.with_addr(p.addr())", "std::ptr::without_provenance(p.addr())", "Uses a provenance-free reconstruction."),
            P,
        ],
    ),
    c(
        "memleak",
        "memleak.rs",
        "An owned Box containing 42 is observed and then dropped exactly once.",
        [],
        DEFAULT,
        "The source explicitly allocates Box::new(42); only forgetting ownership causes the failure.",
        "fn main(){let b=Box::new(42i32);assert_eq!(*b,42);drop(b);}",
        entry_tests("for x in [-1i32,0,42]{let b=Box::new(x);assert_eq!(*b,x);drop(b);}"),
        [
            mutation("Box::new(42i32)", "Box::new(41i32)", "Changes the owned value."),
            mutation("*b,42", "*b,41", "Claims the wrong value."),
            mutation("drop(b)", "std::mem::forget(b)", "Leaks the allocation."),
            P,
        ],
    ),
    c(
        "memleak_no_backtrace",
        "memleak_no_backtrace.rs",
        "An owned Box containing 42 is observed and released even when leak backtraces are disabled.",
        [],
        [("official-no-leak-backtrace", ["-Zmiri-disable-leak-backtraces"]), ("default-strict", [])],
        "The source explicitly allocates Box::new(42); only forgetting ownership causes the failure.",
        "fn main(){let b=Box::new(42i32);assert_eq!(*b,42);drop(b);}",
        entry_tests("let b=Box::new(7i32);assert_eq!(*b,7);drop(b);"),
        [
            mutation("Box::new(42i32)", "Box::new(41i32)", "Changes the owned value."),
            mutation("*b,42", "*b,41", "Claims the wrong value."),
            mutation("drop(b)", "std::mem::forget(b)", "Leaks the allocation."),
            P,
        ],
    ),
    c(
        "never_match_never",
        "never_match_never.rs",
        "The never type is zero-sized; no uninhabited tuple field is materialized or matched.",
        [],
        NO_VALID,
        "The source names the tuple `(i32, !)` and then enters unreachable code. The oracle retains only its well-defined layout boundary.",
        "#![feature(never_type)]fn main(){assert_eq!(std::mem::size_of::<!>(),0);assert_eq!(std::mem::align_of::<!>(),1);}",
        entry_tests("assert_eq!(std::mem::size_of::<!>(),0);"),
        [
            mutation("size_of::<!>(),0", "size_of::<!>(),1", "Claims the wrong size."),
            mutation("align_of::<!>(),1", "align_of::<!>(),2", "Claims the wrong alignment."),
            mutation("assert_eq!(std::mem::size", "assert_ne!(std::mem::size", "Negates the size invariant."),
            P,
        ],
    ),
    c(
        "never_say_never",
        "never_say_never.rs",
        "The original f maps an impossible never input to never; only the never type's zero-sized layout is executable.",
        ["f"],
        NO_VALID,
        "The helper `f(x: !) -> ! { x }` is explicit but has no well-defined callable input. The oracle preserves its signature and the never layout.",
        "#![feature(never_type)]fn f(x:!)->!{x}fn main(){assert_eq!(std::mem::size_of::<!>(),0);}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn never_layout(){assert_eq!(std::mem::size_of::<!>(),0);}#[test]fn helper_signature(){let _f:fn(!)-> ! =f;}",
        [
            mutation("size_of::<!>(),0", "size_of::<!>(),1", "Claims the wrong size."),
            mutation("fn f(x:!)->!{x}", "fn f(x:!)->i32{match x{}}", "Changes the protected helper return type."),
            mutation("assert_eq!", "assert_ne!", "Negates the invariant."),
            P,
        ],
    ),
    c(
        "never_transmute_humans",
        "never_transmute_humans.rs",
        "Human and the never type are both zero-sized, but no Human value is transmuted into never.",
        ["Human"],
        NO_VALID,
        "The source declares the unit struct Human and `!`; their layouts are independent of the invalid transmute.",
        "#![feature(never_type)]struct Human;fn main(){assert_eq!(std::mem::size_of::<Human>(),0);assert_eq!(std::mem::size_of::<!>(),0);let _h=Human;}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn layouts(){assert_eq!(std::mem::size_of::<Human>(),0);assert_eq!(std::mem::size_of::<!>(),0);}#[test]fn human_constructs(){let _=Human;}",
        [
            mutation("struct Human;", "struct Human(u8);", "Changes Human's layout."),
            mutation("size_of::<Human>(),0", "size_of::<Human>(),1", "Claims the wrong Human size."),
            mutation("size_of::<!>(),0", "size_of::<!>(),1", "Claims the wrong never size."),
            P,
        ],
    ),
    c(
        "never_transmute_void",
        "never_transmute_void.rs",
        "m::Void and the never return type are zero-sized; no value of the private uninhabited field is fabricated.",
        ["m::Void", "m::f"],
        NO_VALID,
        "The module explicitly defines Void around an empty enum and f as an exhaustive impossible match. The oracle preserves those declarations without constructing Void.",
        "#![feature(never_type)]mod m{enum VoidI{}pub struct Void(VoidI);pub fn f(v:Void)->!{match v.0{}}}fn main(){assert_eq!(std::mem::size_of::<m::Void>(),0);}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn void_layout(){assert_eq!(std::mem::size_of::<m::Void>(),0);}#[test]fn helper_signature(){let _f:fn(m::Void)-> ! =m::f;}",
        [
            mutation("struct Void(VoidI)", "struct Void(VoidI,u8)", "Changes Void's layout."),
            mutation("size_of::<m::Void>(),0", "size_of::<m::Void>(),1", "Claims the wrong size."),
            mutation("assert_eq!", "assert_ne!", "Negates the invariant."),
            P,
        ],
    ),
    c(
        "tls_macro_leak",
        "tls_macro_leak.rs",
        "A spawned thread owns, observes, and drops Box::new(123) before join returns.",
        [],
        DEFAULT,
        "The source's observable payload is 123 and the thread is joined; the failure is retaining leaked ownership after thread exit.",
        "fn main(){std::thread::spawn(||{let b=Box::new(123i32);assert_eq!(*b,123);drop(b);}).join().unwrap();}",
        entry_tests("std::thread::spawn(||{let b=Box::new(7i32);assert_eq!(*b,7);}).join().unwrap();"),
        [
            mutation("Box::new(123i32)", "Box::new(122i32)", "Changes the thread payload."),
            mutation("*b,123", "*b,122", "Claims the wrong payload."),
            mutation("drop(b)", "std::mem::forget(b)", "Leaks thread-owned memory."),
            P,
        ],
    ),
    c(
        "tls_static_leak",
        "tls_static_leak.rs",
        "A spawned thread owns, observes, and drops Box::new(123) before join returns.",
        [],
        DEFAULT,
        "The source's observable payload is 123 and the thread is joined; the failure is retaining leaked ownership in TLS after thread exit.",
        "fn main(){std::thread::spawn(||{let b=Box::new(123i32);assert_eq!(*b,123);drop(b);}).join().unwrap();}",
        entry_tests("std::thread::spawn(||{let b=Box::new(8i32);assert_eq!(*b,8);}).join().unwrap();"),
        [
            mutation("Box::new(123i32)", "Box::new(122i32)", "Changes the thread payload."),
            mutation("*b,123", "*b,122", "Claims the wrong payload."),
            mutation("drop(b)", "std::mem::forget(b)", "Leaks thread-owned memory."),
            P,
        ],
    ),
    c(
        "dyn-upcast-nop-wrong-trait",
        "dyn-upcast-nop-wrong-trait.rs",
        "A matching Debug+Send+Sync trait object upcasts to Debug, retains size four, and formats the i32 value 0.",
        [],
        DEFAULT,
        "The invalid fixture starts from a Display vtable. The valid domain constructs the required Debug+Send+Sync object directly before the same Debug upcast.",
        "use std::fmt;fn main(){let x=0i32;let p:&(dyn fmt::Debug+Send+Sync)=&x;let q:&dyn fmt::Debug=p;assert_eq!(format!(\"{:?}\",q),\"0\");assert_eq!(std::mem::size_of_val(q),4);}",
        entry_tests("let x=7i32;let p:&(dyn std::fmt::Debug+Send+Sync)=&x;let q:&dyn std::fmt::Debug=p;assert_eq!(format!(\"{:?}\",q),\"7\");"),
        [
            mutation("x=0i32", "x=1i32", "Changes the concrete value."),
            mutation('),"0"', '),"1"', "Claims the wrong Debug output."),
            mutation("size_of_val(q),4", "size_of_val(q),8", "Claims the wrong dynamic size."),
            P,
        ],
    ),
]


def main() -> None:
    for item in SPECS:
        write_case(item)
    print(f"wrote {len(SPECS)} batch-18 cases")


if __name__ == "__main__":
    main()
