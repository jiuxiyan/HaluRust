#!/usr/bin/env python3
"""Materialize batch 21: Tree Borrows live-owner and wildcard-address invariants."""

from __future__ import annotations

from generate_batch2_cases import mutation, write_case
from generate_batch6_cases import main_case


TREE = [("tree-borrows", ["-Zmiri-tree-borrows"])]
TREE_NO_GC = [("tree-no-gc", ["-Zmiri-tree-borrows", "-Zmiri-provenance-gc=0"])]
WILD = [
    ("tree-permissive", ["-Zmiri-tree-borrows", "-Zmiri-permissive-provenance"]),
    ("strict-address-preserving", ["-Zmiri-tree-borrows"]),
]
P = mutation("fn main(){", 'fn main(){panic!("main");', "Rejects the valid repaired entry.")
EVIDENCE = (
    "The fixture explicitly initializes the allocation and identifies the read/write value. "
    "The oracle keeps the access in the same live allocation but uses one current owner or a provenance-preserving raw pointer."
)


def s(case_id, path, contract, reference, muts, symbols=None, profiles=None, tests=None, evidence=EVIDENCE):
    if tests is None:
        tests = (
            "#[test]fn repaired_entry_completes(){main();}"
            "#[test]fn repeats(){for _ in 0..7{main();}}"
            "#[test]fn independent_live_allocation(){main();}"
        )
    return main_case(
        case_id, path, contract, symbols or [], profiles or TREE,
        evidence, reference, tests, muts + [P],
    )


SPECS = [
    s(
        "tree_borrows__alternate-read-write",
        "tree_borrows/alternate-read-write.rs",
        "A current mutable reference reads 0, increments once, and leaves the owner equal to 1.",
        "fn main(){let mut x=0u8;let y=&mut x;assert_eq!(*y,0);*y+=1;assert_eq!(x,1);}",
        [mutation("x=0u8", "x=2u8", "Changes the input."), mutation("*y+=1", "*y+=2", "Changes the increment."), mutation("x,1", "x,2", "Claims the wrong result.")],
    ),
    s(
        "tree_borrows__cell-inside-struct",
        "tree_borrows/cell-inside-struct.rs",
        "Foo keeps frozen field1=42 while its Cell field2 changes from 88 to 10.",
        "use std::cell::Cell;struct Foo{field1:u32,field2:Cell<u32>}fn main(){let root=Foo{field1:42,field2:Cell::new(88)};root.field2.set(10);assert_eq!(root.field1,42);assert_eq!(root.field2.get(),10);}",
        [mutation("field1:42", "field1:41", "Changes the frozen field."), mutation("set(10)", "set(11)", "Changes the Cell write."), mutation("get(),10", "get(),11", "Claims the wrong Cell value.")],
        symbols=["Foo"],
    ),
    s(
        "tree_borrows__error-range",
        "tree_borrows/error-range.rs",
        "Within a 16-byte array, indices 3, 4, and 5 are incremented to 1 and remain in bounds.",
        "fn main(){let mut data=[0u8;16];for i in 3..=5{data[i]+=1;}assert_eq!(&data[3..6],&[1,1,1]);assert!(data[..3].iter().all(|&x|x==0));}",
        [mutation("3..=5", "3..=4", "Omits index 5."), mutation("[1,1,1]", "[1,1,0]", "Claims the wrong range."), mutation("data[i]+=1", "data[i]+=2", "Changes the writes.")],
    ),
    s(
        "tree_borrows__frozen-lazy-write-to-surrounding",
        "tree_borrows/frozen-lazy-write-to-surrounding.rs",
        "The pair's writable i32 field changes from 1 to 0 while the unit field remains intact.",
        "fn main(){let mut pair=((),1i32);let p=std::ptr::addr_of_mut!(pair.1);unsafe{p.write(0)};assert_eq!(pair.1,0);assert_eq!(pair.0,());}",
        [mutation("let mut pair=((),1i32)", 'panic!("pair");let mut pair=((),1i32)', "Rejects the valid pair."), mutation("write(0)", "write(2)", "Changes the write."), mutation("pair.1,0", "pair.1,2", "Claims the wrong result.")],
    ),
    s(
        "tree_borrows__reserved__cell-protected-write",
        "tree_borrows/reserved/cell-protected-write.rs",
        "A protected mutable UnsafeCell reference writes byte 1 through its own live interior pointer.",
        "use std::cell::UnsafeCell;fn write_second(x:&mut UnsafeCell<u8>){unsafe{*x.get()=1}}fn main(){let mut n=UnsafeCell::new(0u8);write_second(&mut n);assert_eq!(unsafe{*n.get()},1);}",
        [mutation("*x.get()=1", "*x.get()=2", "Changes the write."), mutation("*n.get()},1", "*n.get()},2", "Claims the wrong result."), mutation("let mut n=UnsafeCell::new", 'panic!("cell");let mut n=UnsafeCell::new', "Rejects the valid cell.")],
        symbols=["write_second"],
        profiles=TREE_NO_GC,
    ),
    s(
        "tree_borrows__reserved__int-protected-write",
        "tree_borrows/reserved/int-protected-write.rs",
        "A protected mutable u8 reference writes 0 through itself and the owner observes 0.",
        "fn write_second(x:&mut u8){*x=0}fn main(){let mut n=7u8;write_second(&mut n);assert_eq!(n,0);}",
        [mutation("*x=0", "*x=1", "Changes the write."), mutation("n,0", "n,1", "Claims the wrong result."), mutation("let mut n=7u8", 'panic!("value");let mut n=7u8', "Rejects the valid value.")],
        symbols=["write_second"],
        profiles=TREE_NO_GC,
    ),
]


def wildcard_case(case_id: str, path: str, writes: list[int], final: int):
    body = "".join(f"unsafe{{p.write({value})}};" for value in writes)
    altered = writes[:-1] + [writes[-1] + 1]
    altered_body = "".join(f"unsafe{{p.write({value})}};" for value in altered)
    return s(
        case_id,
        path,
        f"A provenance-preserving pointer in one live u32 allocation performs writes {writes} and leaves {final}.",
        f"fn main(){{let mut x=42u32;let p=&mut x as*mut u32;{body}assert_eq!(x,{final});assert_eq!(p.addr(),(&x as*const u32).addr());}}",
        [
            mutation(body, altered_body, "Changes the final explicit write in the sequence."),
            mutation(f"x,{final}", f"x,{final + 1}", "Claims the wrong final value."),
            mutation("let p=&mut x as*mut u32", "let p=std::ptr::null_mut();let _=&mut x", "Drops the live allocation pointer."),
        ],
        profiles=WILD,
    )


SPECS += [
    wildcard_case("tree_borrows__wildcard__cross_tree_from_main", "tree_borrows/wildcard/cross_tree_from_main.rs", [13], 13),
    wildcard_case("tree_borrows__wildcard__cross_tree_update_main", "tree_borrows/wildcard/cross_tree_update_main.rs", [13], 13),
    wildcard_case("tree_borrows__wildcard__cross_tree_update_main_invalid_exposed", "tree_borrows/wildcard/cross_tree_update_main_invalid_exposed.rs", [4, 13], 13),
    wildcard_case("tree_borrows__wildcard__cross_tree_update_main_invalid_exposed2", "tree_borrows/wildcard/cross_tree_update_main_invalid_exposed2.rs", [4, 13], 13),
    wildcard_case("tree_borrows__wildcard__cross_tree_update_newer", "tree_borrows/wildcard/cross_tree_update_newer.rs", [13], 13),
    wildcard_case("tree_borrows__wildcard__cross_tree_update_newer_exposed", "tree_borrows/wildcard/cross_tree_update_newer_exposed.rs", [13], 13),
    wildcard_case("tree_borrows__wildcard__cross_tree_update_older", "tree_borrows/wildcard/cross_tree_update_older.rs", [13], 13),
    wildcard_case("tree_borrows__wildcard__cross_tree_update_older_invalid_exposed", "tree_borrows/wildcard/cross_tree_update_older_invalid_exposed.rs", [13], 13),
    wildcard_case("tree_borrows__wildcard__cross_tree_update_older_invalid_exposed2", "tree_borrows/wildcard/cross_tree_update_older_invalid_exposed2.rs", [13], 13),
    wildcard_case("tree_borrows__wildcard__multi_exposed_child", "tree_borrows/wildcard/multi_exposed_child.rs", [43, 42, 43], 43),
    wildcard_case("tree_borrows__wildcard__multi_exposed_child_unique_writer", "tree_borrows/wildcard/multi_exposed_child_unique_writer.rs", [42], 42),
    wildcard_case("tree_borrows__wildcard__multi_exposed_siblings_disable", "tree_borrows/wildcard/multi_exposed_siblings_disable.rs", [13], 13),
    wildcard_case("tree_borrows__wildcard__multi_exposed_siblings_foreign", "tree_borrows/wildcard/multi_exposed_siblings_foreign.rs", [13], 13),
    wildcard_case("tree_borrows__wildcard__multi_exposed_siblings_local", "tree_borrows/wildcard/multi_exposed_siblings_local.rs", [41, 0], 0),
]


def main() -> None:
    for item in SPECS:
        write_case(item)
    print(f"wrote {len(SPECS)} batch-21 cases")


if __name__ == "__main__":
    main()
