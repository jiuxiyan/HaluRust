#!/usr/bin/env python3
"""Materialize batch 20: remaining high-confidence alias, layout, and call invariants."""

from __future__ import annotations

from generate_batch2_cases import DEFAULT, STACK_TREE, mutation, write_case
from generate_batch6_cases import main_case


WEAK_ALIAS = [
    ("stack-no-validation", ["-Zmiri-disable-validation"]),
    ("tree-no-validation", ["-Zmiri-disable-validation", "-Zmiri-tree-borrows"]),
]
PERMISSIVE_BOTH = [
    ("stack-permissive", ["-Zmiri-permissive-provenance"]),
    ("tree-permissive", ["-Zmiri-permissive-provenance", "-Zmiri-tree-borrows"]),
]
P = mutation("fn main(){", 'fn main(){panic!("main");', "Rejects the valid repaired entry.")
EVIDENCE = (
    "The source supplies the concrete values, types, and operation. The oracle retains that local contract "
    "but uses one live owner/reference at a time, matching layouts, or a matching function signature."
)


def s(case_id, path, contract, reference, muts, symbols=None, profiles=None, tests=None, evidence=EVIDENCE):
    if tests is None:
        tests = (
            "#[test]fn repaired_entry_completes(){main();}"
            "#[test]fn repeats(){for _ in 0..7{main();}}"
            "#[test]fn independent_valid_domain(){main();}"
        )
    return main_case(
        case_id, path, contract, symbols or [], profiles or STACK_TREE,
        evidence, reference, tests, muts + [P],
    )


SPECS = [
    s(
        "both_borrows__illegal_read_despite_exposed1",
        "both_borrows/illegal_read_despite_exposed1.rs",
        "One live mutable pointer changes 42 to 0 and the owner observes 0.",
        "fn main(){let mut root=42i32;let p=&mut root as*mut i32;unsafe{*p=0};assert_eq!(root,0);}",
        [mutation("*p=0", "*p=1", "Changes the write."), mutation("root,0", "root,1", "Claims the wrong result."), mutation("let mut root=42i32", 'panic!("root");let mut root=42i32', "Rejects the valid root.")],
        profiles=PERMISSIVE_BOTH,
    ),
    s(
        "both_borrows__illegal_read_despite_exposed2",
        "both_borrows/illegal_read_despite_exposed2.rs",
        "One current mutable reference writes 42 then 3, leaving root equal to 3.",
        "fn main(){let mut root=0i32;let r=&mut root;*r=42;assert_eq!(*r,42);*r=3;assert_eq!(root,3);}",
        [mutation("*r=42", "*r=41", "Changes the first write."), mutation("*r=3", "*r=4", "Changes the final write."), mutation("root,3", "root,4", "Claims the wrong result.")],
        profiles=PERMISSIVE_BOTH,
    ),
    s(
        "both_borrows__illegal_write1",
        "both_borrows/illegal_write1.rs",
        "A Box-owned u32 is mutated through its unique borrow from 42 to 43.",
        "fn main(){let mut target=Box::new(42u32);let r=&mut*target;assert_eq!(*r,42);*r=43;assert_eq!(*target,43);}",
        [mutation("42u32", "41u32", "Changes the input."), mutation("*r=43", "*r=44", "Changes the write."), mutation("*target,43", "*target,44", "Claims the wrong result.")],
    ),
    s(
        "both_borrows__illegal_write_despite_exposed1",
        "both_borrows/illegal_write_despite_exposed1.rs",
        "A single live mutable reference writes 0 and reads 0.",
        "fn main(){let mut root=42i32;let r=&mut root;*r=0;assert_eq!(*r,0);}",
        [mutation("*r=0", "*r=1", "Changes the write."), mutation("*r,0", "*r,1", "Claims the wrong read."), mutation("let mut root=42i32", 'panic!("root");let mut root=42i32', "Rejects the valid root.")],
        profiles=PERMISSIVE_BOTH,
    ),
    s(
        "both_borrows__issue-miri-1050-1",
        "both_borrows/issue-miri-1050-1.rs",
        "A Box<u16> owns value 0 and is reconstructed and dropped with the same pointee type.",
        "fn main(){let p=Box::into_raw(Box::new(0u16));assert_eq!(unsafe{*p},0);unsafe{drop(Box::from_raw(p));}}",
        [mutation("new(0u16)", "new(1u16)", "Changes the value."), mutation("*p},0", "*p},1", "Claims the wrong value."), mutation("Box::from_raw(p)", "Box::from_raw(p as*mut u32)", "Reconstructs with the wrong type.")],
        profiles=WEAK_ALIAS,
    ),
    s(
        "both_borrows__issue-miri-1050-2",
        "both_borrows/issue-miri-1050-2.rs",
        "A real Box<i32> allocation containing 42 is reconstructed from its live raw pointer and dropped once.",
        "fn main(){let p=Box::into_raw(Box::new(42i32));assert_eq!(unsafe{*p},42);unsafe{drop(Box::from_raw(p));}}",
        [mutation("42i32", "41i32", "Changes the value."), mutation("*p},42", "*p},41", "Claims the wrong value."), mutation("drop(Box::from_raw(p))", "drop(Box::from_raw(std::ptr::NonNull::<i32>::dangling().as_ptr()))", "Uses a dangling pointer.")],
        profiles=WEAK_ALIAS,
    ),
    s(
        "both_borrows__load_invalid_shr",
        "both_borrows/load_invalid_shr.rs",
        "A boxed current shared reference observes its live target value 42.",
        "fn main(){let x=42i32;let r=&x;let b=Box::new(r);assert_eq!(**b,42);assert_eq!(*r,42);}",
        [mutation("x=42i32", "x=41i32", "Changes the target."), mutation("**b,42", "**b,41", "Claims the wrong boxed read."), mutation("*r,42", "*r,41", "Claims the wrong direct read.")],
        profiles=WEAK_ALIAS,
    ),
    s(
        "both_borrows__mut_exclusive_violation2",
        "both_borrows/mut_exclusive_violation2.rs",
        "One NonNull-derived mutable reference reads 0, writes 3, and the owner observes 3.",
        "use std::ptr::NonNull;fn main(){let mut x=0i32;let mut p=NonNull::from(&mut x);let r=unsafe{p.as_mut()};assert_eq!(*r,0);*r=3;assert_eq!(x,3);}",
        [mutation("*r,0", "*r,1", "Claims the wrong initial read."), mutation("*r=3", "*r=2", "Changes the write."), mutation("x,3", "x,2", "Claims the wrong result.")],
    ),
    s(
        "both_borrows__shr_frozen_violation2",
        "both_borrows/shr_frozen_violation2.rs",
        "A shared reference observes 0; after its scope ends, x is changed to 1 and observed as 1.",
        "fn main(){let mut x=0i32;{let frozen=&x;assert_eq!(*frozen,0);}x=1;assert_eq!(x,1);}",
        [mutation("x=0i32", "x=2i32", "Changes the first observation."), mutation("*frozen,0", "*frozen,2", "Claims the wrong frozen value."), mutation("x=1", "x=2", "Changes the final write.")],
    ),
    s(
        "stacked_borrows__drop_in_place_protector",
        "stacked_borrows/drop_in_place_protector.rs",
        "HasDrop is dropped once as part of a live tuple whose byte field is 0.",
        "use std::sync::atomic::{AtomicUsize,Ordering};static DROPS:AtomicUsize=AtomicUsize::new(0);#[repr(transparent)]struct HasDrop;impl Drop for HasDrop{fn drop(&mut self){DROPS.fetch_add(1,Ordering::SeqCst);}}fn main(){DROPS.store(0,Ordering::SeqCst);let x=(HasDrop,0u8);assert_eq!(x.1,0);drop(x);assert_eq!(DROPS.load(Ordering::SeqCst),1);}",
        [mutation("fetch_add(1", "fetch_add(2", "Changes the drop effect."), mutation("x.1,0", "x.1,1", "Claims the wrong tuple byte."), mutation("SeqCst),1", "SeqCst),2", "Claims the wrong drop count.")],
        symbols=["HasDrop"],
        profiles=DEFAULT,
    ),
    s(
        "stacked_borrows__unescaped_local",
        "stacked_borrows/unescaped_local.rs",
        "A provenance-carrying raw pointer to local x writes 13 and x observes 13.",
        "fn main(){let mut x=42i32;let p=&mut x as*mut i32;unsafe{*p=13};assert_eq!(x,13);}",
        [mutation("*p=13", "*p=12", "Changes the write."), mutation("x,13", "x,12", "Claims the wrong result."), mutation("let p=&mut x", "let p=std::ptr::null_mut();let _=&mut x", "Drops the live provenance.")],
        profiles=[("official-permissive", ["-Zmiri-permissive-provenance"]), ("default-strict", [])],
    ),
    s(
        "stacked_borrows__unescaped_static",
        "stacked_borrows/unescaped_static.rs",
        "A pointer derived from the whole static array reaches its second byte and reads 1.",
        "static ARRAY:[u8;2]=[0,1];fn main(){let p=ARRAY.as_ptr();assert_eq!(unsafe{*p.add(1)},1);assert_eq!(ARRAY,[0,1]);}",
        [mutation("static ARRAY:[u8;2]=[0,1]", "static ARRAY:[u8;2]=[0,2]", "Changes the second byte."), mutation("*p.add(1)},1", "*p.add(1)},2", "Claims the wrong byte."), mutation("p.add(1)", "p.add(2)", "Moves out of bounds.")],
        profiles=DEFAULT,
    ),
    s(
        "const-ub-checks",
        "const-ub-checks.rs",
        "The constant evaluates an aligned four-byte zero representation to u32 value 0.",
        "const ALIGNED_READ:u32=u32::from_ne_bytes([0u8;4]);fn main(){assert_eq!(ALIGNED_READ,0);}",
        [mutation("[0u8;4]", "[1u8;4]", "Changes the bytes."), mutation("ALIGNED_READ,0", "ALIGNED_READ,1", "Claims the wrong value."), mutation("fn main(){", "const _:()=assert!(ALIGNED_READ==1);fn main(){", "Claims the wrong constant at compile time.")],
        profiles=DEFAULT,
        tests="#[test]fn repaired_entry_completes(){main();}#[test]fn constant_value(){assert_eq!(ALIGNED_READ,0);}#[test]fn repeats(){for _ in 0..8{main();}}",
    ),
    s(
        "erroneous_const2",
        "erroneous_const2.rs",
        "With X=5 and Y=6, the absolute difference FOO is 1 without evaluating an overflowing branch.",
        "const X:u32=5;const Y:u32=6;const FOO:u32=if X<Y{Y-X}else{X-Y};fn main(){assert_eq!(FOO,1);}",
        [mutation("Y:u32=6", "Y:u32=7", "Changes the input constant."), mutation("FOO,1", "FOO,2", "Claims the wrong difference."), mutation("Y-X", "Y-X+1", "Changes the selected expression.")],
        profiles=DEFAULT,
        tests="#[test]fn repaired_entry_completes(){main();}#[test]fn constants(){assert_eq!((X,Y,FOO),(5,6,1));}#[test]fn repeats(){main();main();}",
    ),
    s(
        "reading_half_a_pointer",
        "reading_half_a_pointer.rs",
        "The packed Data pointer field is read as one complete unaligned pointer and dereferences to static G=0.",
        "use std::ptr;#[repr(C,packed)]struct Data{pad:u8,ptr:&'static i32}struct Wrapper{align:u64,data:Data}static G:i32=0;fn main(){let w=Wrapper{align:0,data:Data{pad:0,ptr:&G}};let p=unsafe{ptr::addr_of!(w.data.ptr).read_unaligned()};assert_eq!(*p,0);assert_eq!(p,&G);}",
        [mutation("G:i32=0", "G:i32=1", "Changes the pointee."), mutation("*p,0", "*p,1", "Claims the wrong value."), mutation("addr_of!(w.data.ptr)", "addr_of!(w.data.pad).cast()", "Reads only part of the pointer.")],
        symbols=["Data", "Wrapper"],
        profiles=DEFAULT,
    ),
    s(
        "validity__box-custom-alloc-dangling-ptr",
        "validity/box-custom-alloc-dangling-ptr.rs",
        "MyBox<i32> contains a NonNull pointer to live value 42 and allocator fields (0,0).",
        "#![feature(allocator_api)]use std::ptr::NonNull;#[derive(Debug,PartialEq)]struct MyAlloc(usize,usize);#[repr(C)]struct MyBox<T>{ptr:NonNull<T>,alloc:MyAlloc}fn main(){let mut x=42i32;let b=MyBox{ptr:NonNull::from(&mut x),alloc:MyAlloc(0,0)};assert_eq!(unsafe{*b.ptr.as_ptr()},42);assert_eq!(b.alloc,MyAlloc(0,0));}",
        [mutation("x=42i32", "x=41i32", "Changes the pointee."), mutation("*b.ptr.as_ptr()},42", "*b.ptr.as_ptr()},41", "Claims the wrong pointee."), mutation("MyAlloc(0,0)}", "MyAlloc(1,0)}", "Changes allocator state.")],
        symbols=["MyAlloc", "MyBox"],
        profiles=[("official-no-stacked", ["-Zmiri-disable-stacked-borrows"]), ("default-strict", [])],
    ),
    s(
        "validity__box-custom-alloc-invalid-alloc",
        "validity/box-custom-alloc-invalid-alloc.rs",
        "MyBox<i32> contains a live pointer and a fully initialized MyAlloc with fields 1 and 2.",
        "#![feature(allocator_api)]use std::{mem::MaybeUninit,ptr::NonNull};#[derive(Debug,PartialEq)]struct MyAlloc{my_alloc_field1:usize,my_alloc_field2:usize}#[repr(C)]struct MyBox<T>{ptr:NonNull<T>,alloc:MaybeUninit<MyAlloc>}fn main(){let mut x=42i32;let b=MyBox{ptr:NonNull::from(&mut x),alloc:MaybeUninit::new(MyAlloc{my_alloc_field1:1,my_alloc_field2:2})};assert_eq!(unsafe{*b.ptr.as_ptr()},42);assert_eq!(unsafe{b.alloc.assume_init_ref()},&MyAlloc{my_alloc_field1:1,my_alloc_field2:2});}",
        [mutation("x=42i32", "x=41i32", "Changes the pointee."), mutation("*b.ptr.as_ptr()},42", "*b.ptr.as_ptr()},41", "Claims the wrong pointee."), mutation("my_alloc_field2:2})};", "my_alloc_field2:3})};", "Changes allocator state.")],
        symbols=["MyAlloc", "MyBox"],
        profiles=[("official-no-stacked", ["-Zmiri-disable-stacked-borrows"]), ("default-strict", [])],
    ),
    s(
        "validity__cast_fn_ptr_invalid_callee_arg",
        "validity/cast_fn_ptr_invalid_callee_arg.rs",
        "A matching fn(&i32)->i32 pointer receives a live reference and returns its value 42.",
        "fn f(x:&i32)->i32{*x}fn main(){let x=42i32;let g:fn(&i32)->i32=f;assert_eq!(g(&x),42);}",
        [mutation("*x}", "*x+1}", "Changes f."), mutation("g(&x),42", "g(&x),43", "Claims the wrong result."), mutation("=f", '=|_|panic!("call")', "Rejects the matching call.")],
        symbols=["f"],
        profiles=[("official-permissive", ["-Zmiri-permissive-provenance"]), ("default-strict", [])],
    ),
    s(
        "tail_calls__cc-mismatch",
        "tail_calls/cc-mismatch.rs",
        "The original extern C function f is called with its declared ABI and completes.",
        "#![feature(explicit_tail_calls)]#![allow(incomplete_features)]extern \"C\" fn f(){}fn main(){f();}",
        [mutation('fn f(){}', 'fn f(){panic!("f")}', "Changes f behavior."), mutation("fn main(){f();}", 'fn main(){panic!("main-call");f();}', "Rejects the call."), mutation('extern "C" fn f', "fn f", "Changes the protected ABI.")],
        symbols=["f"],
        profiles=DEFAULT,
        tests="#[test]fn repaired_entry_completes(){main();}#[test]fn declared_abi_callable(){let g:extern \"C\" fn()=f;g();}#[test]fn repeats(){for _ in 0..6{f();}}",
    ),
    s(
        "tail_calls__signature-mismatch-arg",
        "tail_calls/signature-mismatch-arg.rs",
        "f accepts u32 and calls original g(i32) after an explicit checked-domain conversion; g observes the converted value.",
        "#![feature(explicit_tail_calls)]#![allow(incomplete_features)]use std::sync::atomic::{AtomicI32,Ordering};static SEEN:AtomicI32=AtomicI32::new(-1);fn f(x:u32){assert!(x<=i32::MAX as u32);g(x as i32);}fn g(x:i32){SEEN.store(x,Ordering::SeqCst);}fn main(){f(0);assert_eq!(SEEN.load(Ordering::SeqCst),0);f(42);assert_eq!(SEEN.load(Ordering::SeqCst),42);}",
        [mutation("x as i32", "(x+1)as i32", "Changes the forwarded value."), mutation("f(42)", "f(u32::MAX)", "Violates the checked domain."), mutation("fn g(x:i32)", "fn g(x:u32)", "Changes the protected signature.")],
        symbols=["f", "g"],
        profiles=DEFAULT,
        tests="#[test]fn repaired_entry_completes(){main();}#[test]fn valid_arguments(){for x in [0u32,1,42,i32::MAX as u32]{f(x);assert_eq!(SEEN.load(std::sync::atomic::Ordering::SeqCst),x as i32);}}#[test]fn signatures(){let _f:fn(u32)=f;let _g:fn(i32)=g;}",
    ),
]


def main() -> None:
    for item in SPECS:
        write_case(item)
    print(f"wrote {len(SPECS)} batch-20 cases")


if __name__ == "__main__":
    main()
