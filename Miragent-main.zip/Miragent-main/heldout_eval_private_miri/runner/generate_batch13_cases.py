#!/usr/bin/env python3
"""Materialize batch 13: finite fast-math and live/in-bounds pointer operations."""

from __future__ import annotations

from generate_batch2_cases import DEFAULT, mutation, write_case
from generate_batch6_cases import main_case


WEAK = [("official-weakened",["-Zmiri-disable-alignment-check","-Zmiri-disable-stacked-borrows","-Zmiri-disable-validation"]),("default-strict",[])]
NO_VALID = [("official-weakened",["-Zmiri-disable-validation","-Zmiri-permissive-provenance"]),("default-strict",[])]
PERM = [("permissive",["-Zmiri-permissive-provenance"]),("default-strict",[])]


def s(case_id, path, contract, reference, extra, muts, profiles=DEFAULT, symbols=None):
    return main_case(
        case_id, path, contract, symbols or [], profiles,
        "The failing source supplies non-finite arithmetic or a dead/null/out-of-bounds pointer; the oracle retains the operation on finite values or a live in-bounds allocation.",
        reference,
        "#[test]fn repaired_entry_completes(){main();}"
        "#[test]fn repaired_entry_repeats(){for _ in 0..8{main();}}"
        f"#[test]fn independent_valid_domain(){{{extra}}}",
        muts,
    )


P = mutation("fn main(){","fn main(){panic!(\"main\");","Panics on valid input.")


SPECS = [
    s("intrinsics__fast_math_both","intrinsics/fast_math_both.rs","fsub_fast subtracts finite f32 operands and produces a finite result.",
      "#![feature(core_intrinsics)]fn main(){let x=unsafe{core::intrinsics::fsub_fast(7.5f32,2.25)};assert!((x-5.25).abs()<0.01);}",
      "assert_eq!(7.5f32-2.25,5.25);",
      [mutation("7.5f32","6.5f32","Changes lhs."),mutation("x-5.25","x-4.25","Wrong result."),mutation("fsub_fast","fadd_fast","Uses addition."),P]),
    s("intrinsics__fast_math_first","intrinsics/fast_math_first.rs","frem_fast computes a finite f32 remainder for finite operands and nonzero rhs.",
      "#![feature(core_intrinsics)]fn main(){let x=unsafe{core::intrinsics::frem_fast(8.0f32,3.0)};assert!((x-2.0).abs()<0.01);}",
      "assert_eq!(8.0f32%3.0,2.0);",
      [mutation("8.0f32","7.0f32","Changes lhs."),mutation("x-2.0","x-1.0","Wrong result."),mutation("frem_fast","fdiv_fast","Uses division."),P]),
    s("intrinsics__fast_math_result","intrinsics/fast_math_result.rs","fdiv_fast divides finite f32 operands with nonzero rhs and a finite result.",
      "#![feature(core_intrinsics)]fn main(){let x=unsafe{core::intrinsics::fdiv_fast(8.0f32,2.0)};assert!((x-4.0).abs()<0.01);}",
      "assert_eq!(8.0f32/2.0,4.0);",
      [mutation("8.0f32","6.0f32","Changes lhs."),mutation("x-4.0","x-3.0","Wrong result."),mutation("fdiv_fast","fmul_fast","Uses multiplication."),P]),
    s("intrinsics__fast_math_second","intrinsics/fast_math_second.rs","fmul_fast multiplies finite f32 operands when the result remains finite.",
      "#![feature(core_intrinsics)]fn main(){let x=unsafe{core::intrinsics::fmul_fast(3.5f32,2.0)};assert!((x-7.0).abs()<0.01);}",
      "assert_eq!(3.5f32*2.0,7.0);",
      [mutation("3.5f32","3.0f32","Changes lhs."),mutation("x-7.0","x-6.0","Wrong result."),mutation("fmul_fast","fdiv_fast","Uses division."),P]),
    s("intrinsics__ptr_metadata_uninit_thin","intrinsics/ptr_metadata_uninit_thin.rs","deref_meta accepts an initialized pointer-to-thin-pointer; its metadata is unit.", 
      "pub unsafe fn deref_meta(p:*const*const i32)->(){let q=*p;assert!(!q.is_null());()}fn main(){let x=7i32;let q=&x as*const i32;unsafe{deref_meta(&q)}}",
      "let x=9i32;let q=&x as*const i32;unsafe{deref_meta(&q)};",
      [mutation("assert!(!q.is_null())","assert!(q.is_null())","Negates non-null precondition."),mutation("deref_meta(&q)","panic!(\"meta\")","Rejects initialized pointer."),mutation("let q=&x as*const i32","let q=std::ptr::null::<i32>()","Uses null thin pointer value."),P],NO_VALID,["deref_meta"]),
    s("intrinsics__zero_fn_ptr","intrinsics/zero_fn_ptr.rs","A valid function pointer points to callable code and invokes it exactly once.",
      "fn target(x:&mut u8){*x+=1}fn main(){let f:fn(&mut u8)=target;let mut x=0;f(&mut x);assert_eq!(x,1);}",
      "fn f(x:&mut u8){*x=7}let mut x=0;let p:fn(&mut u8)=f;p(&mut x);assert_eq!(x,7);",
      [mutation("*x+=1","*x+=2","Changes effect."),mutation("x,1","x,2","Wrong result."),mutation("f(&mut x)","panic!(\"call\")","Rejects call."),P]),
    s("dangling_pointers__dangling_pointer_deref","dangling_pointers/dangling_pointer_deref.rs","A raw pointer may be dereferenced while its Box allocation remains alive.",
      "fn main(){let b=Box::new(42i32);let p=&*b as*const i32;assert_eq!(unsafe{*p},42);drop(b);}",
      "let b=Box::new(7);let p=&*b as*const i32;assert_eq!(unsafe{*p},7);",
      [mutation("42i32","41i32","Changes pointee."),mutation("*p},42","*p},41","Wrong result."),mutation("drop(b);","drop(b);panic!(\"drop\")","Rejects valid lifetime."),P],WEAK),
    s("dangling_pointers__dangling_pointer_offset","dangling_pointers/dangling_pointer_offset.rs","Pointer offset zero remains valid while the Box allocation is alive.",
      "fn main(){let b=Box::new(42i32);let p=&*b as*const i32;let q=unsafe{p.offset(0)};assert_eq!(unsafe{*q},42);drop(b);}",
      "let a=[1,2];let p=a.as_ptr();assert_eq!(unsafe{*p.offset(1)},2);",
      [mutation("offset(0)","offset(1)","Moves out of bounds."),mutation("*q},42","*q},41","Wrong result."),mutation("42i32","41i32","Changes pointee."),P],WEAK),
]


def tuple_case(case_id):
    return s(case_id,f"dangling_pointers/{case_id.split('__',1)[1]}.rs",
      "Projecting tuple field 1 through a live in-bounds raw pointer yields 2.",
      "fn main(){let t=(1u8,2u8,3u8,4u8);let p=&t as*const(u8,u8,u8,u8);let x=unsafe{(*p).1};assert_eq!(x,2);}",
      "let t=(5u8,6u8);let p=&t as*const(u8,u8);assert_eq!(unsafe{(*p).1},6);",
      [mutation("2u8","5u8","Changes field."),mutation("x,2","x,5","Wrong result."),mutation("(*p).1","(*p).2","Projects another field."),P],WEAK)


SPECS += [
    tuple_case("dangling_pointers__dangling_pointer_project_underscore_let"),
    tuple_case("dangling_pointers__dangling_pointer_project_underscore_let_type_annotation"),
    tuple_case("dangling_pointers__dangling_pointer_project_underscore_match"),
    s("dangling_pointers__dangling_primitive","dangling_pointers/dangling_primitive.rs","A pointer to a live usize local dereferences to its initialized value.",
      "fn main(){let x=42usize;let p=&x as*const usize;assert_eq!(unsafe{*p},42);}",
      "let x=7usize;let p=&x as*const usize;assert_eq!(unsafe{*p},7usize);",
      [mutation("x=42usize","x=41usize","Changes value."),mutation("*p},42","*p},41","Wrong result."),mutation("let p=&x","let p=std::ptr::null()","Uses null."),P]),
    s("dangling_pointers__deref-invalid-ptr","dangling_pointers/deref-invalid-ptr.rs","A raw pointer derived from a live u32 can be reborrowed and preserves 16.",
      "fn main(){let x=16u32;let p=&x as*const u32;let q=unsafe{&*p as*const u32};assert_eq!(unsafe{*q},16);}",
      "let x=7u32;let p=&x as*const u32;assert_eq!(unsafe{*p},7u32);",
      [mutation("x=16u32","x=15u32","Changes value."),mutation("*q},16","*q},15","Wrong result."),mutation("let p=&x","let p=std::ptr::null()","Uses null."),P],NO_VALID),
    s("dangling_pointers__null_pointer_deref","dangling_pointers/null_pointer_deref.rs","Dereferencing a non-null pointer to a live i32 yields its initialized value.",
      "#[allow(deref_nullptr)]fn main(){let x=42i32;let p=&x as*const i32;assert_eq!(unsafe{*p},42);}",
      "let x=7;assert_eq!(unsafe{*(&x as*const i32)},7);",
      [mutation("x=42i32","x=41i32","Changes value."),mutation("*p},42","*p},41","Wrong result."),mutation("let p=&x","let p=std::ptr::null()","Uses null."),P]),
    s("dangling_pointers__null_pointer_write","dangling_pointers/null_pointer_write.rs","Writing through a non-null pointer to a live mutable i32 stores zero.",
      "#[allow(deref_nullptr)]fn main(){let mut x=7i32;let p=&mut x as*mut i32;unsafe{*p=0};assert_eq!(x,0);}",
      "let mut x=9;unsafe{*(&mut x as*mut i32)=0};assert_eq!(x,0);",
      [mutation("*p=0","*p=1","Writes wrong value."),mutation("x,0","x,1","Wrong result."),mutation("let p=&mut x","let p=std::ptr::null_mut()","Uses null."),P]),
    s("dangling_pointers__out_of_bounds_project","dangling_pointers/out_of_bounds_project.rs","Projecting field 1 of a live three-u32 tuple stays in bounds and yields 2.",
      "fn main(){let v=(1u32,2u32,3u32);let p=&v as*const(u32,u32,u32);let x=unsafe{(*p).1};assert_eq!(x,2);}",
      "let v=(4u32,5u32);let p=&v as*const(u32,u32);assert_eq!(unsafe{(*p).1},5);",
      [mutation("2u32","4u32","Changes field."),mutation("x,2","x,4","Wrong result."),mutation("(*p).1","(*p).2","Projects another field."),P],WEAK),
    s("dangling_pointers__out_of_bounds_read","dangling_pointers/out_of_bounds_read.rs","Reading an aligned in-bounds u16 vector element returns its initialized value.",
      "fn main(){let v=vec![1u16,2u16];assert_eq!(unsafe{*v.as_ptr().add(1)},2);}",
      "let v=[7u16,8];assert_eq!(unsafe{*v.as_ptr().add(1)},8);",
      [mutation("add(1)","add(0)","Reads first element."),mutation("},2","},1","Wrong result."),mutation("2u16","3u16","Changes value."),P]),
    s("dangling_pointers__out_of_bounds_read_neg_offset","dangling_pointers/out_of_bounds_read_neg_offset.rs","Subtracting two bytes from the second u16 pointer reaches the aligned first element.",
      "fn main(){let v=vec![1u16,2u16];let p=unsafe{v.as_ptr().add(1).byte_sub(2)};assert_eq!(unsafe{*p},1);}",
      "let v=[7u16,8];let p=unsafe{v.as_ptr().add(1).sub(1)};assert_eq!(unsafe{*p},7);",
      [mutation("byte_sub(2)","byte_sub(0)","Stays at second element."),mutation("*p},1","*p},2","Wrong result."),mutation("1u16","3u16","Changes first value."),P]),
    s("dangling_pointers__out_of_bounds_write","dangling_pointers/out_of_bounds_write.rs","Writing an aligned in-bounds u16 vector element updates only that element.",
      "fn main(){let mut v=vec![1u16,2u16];unsafe{*v.as_mut_ptr().add(1)=7};assert_eq!(v,[1,7]);}",
      "let mut v=[3u16,4];unsafe{*v.as_mut_ptr().add(1)=9};assert_eq!(v,[3,9]);",
      [mutation("add(1)","add(0)","Writes first element."),mutation("=7","=8","Writes wrong value."),mutation("[1,7]","[1,8]","Wrong result."),P]),
    s("dangling_pointers__wild_pointer_deref","dangling_pointers/wild_pointer_deref.rs","A raw pointer derived from a live i32 dereferences to 44.",
      "fn main(){let x=44i32;let p=&x as*const i32;assert_eq!(unsafe{*p},44);}",
      "let x=7;let p=&x as*const i32;assert_eq!(unsafe{*p},7);",
      [mutation("x=44i32","x=43i32","Changes value."),mutation("*p},44","*p},43","Wrong result."),mutation("let p=&x","let p=std::ptr::null()","Uses null."),P],PERM),
]


def main() -> None:
    for item in SPECS:
        write_case(item)
    print(f"wrote {len(SPECS)} batch-13 cases")


if __name__ == "__main__":
    main()
