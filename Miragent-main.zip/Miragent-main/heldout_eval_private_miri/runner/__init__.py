"""Private, post-hoc held-out evaluator for Miragent."""

