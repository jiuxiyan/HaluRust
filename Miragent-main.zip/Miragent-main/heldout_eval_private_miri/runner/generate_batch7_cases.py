#!/usr/bin/env python3
"""Materialize the seventh batch: validity, padding, and ABI invariants."""

from __future__ import annotations

from generate_batch2_cases import DEFAULT, mutation, write_case
from generate_batch6_cases import main_case


WEAK_STRICT = [
    ("official-weakened", ["-Zmiri-disable-validation"]),
    ("default-strict", []),
]
RECURSIVE = [("recursive-validation", ["-Zmiri-recursive-validation"])]


SPECS = [
    main_case(
        "validity__invalid_bool", "validity/invalid_bool.rs",
        "The two valid byte encodings of bool decode to false and true; invalid encodings are never materialized.",
        [], DEFAULT, "The diagnostic fixture fails only because it transmutes byte 2 into bool.",
        "#![allow(unnecessary_transmutes)]fn main(){unsafe{assert!(!std::mem::transmute::<u8,bool>(0));assert!(std::mem::transmute::<u8,bool>(1));}}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn valid_bool_encodings(){unsafe{assert!(!std::mem::transmute::<u8,bool>(0));assert!(std::mem::transmute::<u8,bool>(1));}}#[test]fn bool_layout(){assert_eq!(std::mem::size_of::<bool>(),1);}",
        [mutation("::<u8,bool>(0)","::<u8,bool>(1)","False uses the true encoding."),mutation("::<u8,bool>(1)","::<u8,bool>(0)","True uses the false encoding."),mutation("assert!(!","assert!(","Negates false."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")],
    ),
    main_case(
        "validity__invalid_char_op", "validity/invalid_char_op.rs",
        "0xFFFFFF is rejected by char::from_u32, while scalar endpoints 0 and char::MAX decode successfully.",
        [], [("official-weakened",["-Zmiri-disable-alignment-check","-Zmiri-disable-stacked-borrows","-Zmiri-disable-validation"]),("default-strict",[])],
        "The source explicitly asserts rejection before materializing the invalid char.",
        "fn main(){let c=0xFFFFFFu32;assert!(std::char::from_u32(c).is_none());assert_eq!(std::char::from_u32(0),Some('\\0'));assert_eq!(std::char::from_u32(char::MAX as u32),Some(char::MAX));}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn invalid_is_rejected(){assert!(char::from_u32(0xFFFFFF).is_none());}#[test]fn endpoints_decode(){assert_eq!(char::from_u32(0),Some('\\0'));assert_eq!(char::from_u32(char::MAX as u32),Some(char::MAX));}",
        [mutation("0xFFFFFFu32","('x'as u32)","Uses a valid scalar."),mutation(".is_none()",".is_some()","Negates rejection."),mutation("Some('\\0')","Some('x')","Wrong lower endpoint."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")],
    ),
    main_case(
        "validity__invalid_enum_tag", "validity/invalid_enum_tag.rs",
        "repr(C) enum Foo has the four valid discriminants A=0 through D=3 and occupies one i32 word.",
        ["Foo"], DEFAULT, "Only transmuting the out-of-range tag 42 is invalid.",
        "#[repr(C)]#[derive(Copy,Clone,Debug,PartialEq)]pub enum Foo{A,B,C,D}fn main(){assert_eq!(std::mem::size_of::<Foo>(),std::mem::size_of::<i32>());assert_eq!((Foo::A as i32,Foo::B as i32,Foo::C as i32,Foo::D as i32),(0,1,2,3));}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn valid_tags(){assert_eq!((Foo::A as i32,Foo::B as i32,Foo::C as i32,Foo::D as i32),(0,1,2,3));}#[test]fn c_layout(){assert_eq!(std::mem::size_of::<Foo>(),std::mem::size_of::<i32>());}",
        [mutation("Foo{A,B,C,D}","Foo{A=1,B,C,D}","Shifts all tags."),mutation("(0,1,2,3)","(1,2,3,4)","Wrong expected tags."),mutation("repr(C)","repr(u8)","Changes layout."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")],
    ),
    main_case(
        "validity__nonzero", "validity/nonzero.rs",
        "The transparent NonZero<T> wrapper accepts values at or above 1 and has the same layout as T.",
        ["NonZero"], DEFAULT, "The declared scalar valid range starts at 1; only constructing zero is invalid.",
        "#![feature(rustc_attrs)]#![allow(unused_attributes)]#[rustc_layout_scalar_valid_range_start(1)]#[repr(transparent)]pub(crate)struct NonZero<T>(pub(crate)T);fn main(){let a=unsafe{NonZero(1u32)};let b=unsafe{NonZero(u32::MAX)};assert_eq!((a.0,b.0),(1,u32::MAX));}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn valid_values_roundtrip(){for x in [1u32,2,u32::MAX]{let n=unsafe{NonZero(x)};assert_eq!(n.0,x);}}#[test]fn transparent_layout(){assert_eq!(std::mem::size_of::<NonZero<u32>>(),std::mem::size_of::<u32>());assert_eq!(std::mem::align_of::<NonZero<u32>>(),std::mem::align_of::<u32>());}",
        [mutation("NonZero(1u32)","NonZero(0u32)","Constructs zero."),mutation("(1,u32::MAX)","(2,u32::MAX)","Wrong lower value."),mutation("struct NonZero<T>(pub(crate)T)","struct NonZero<T>(pub(crate)T,pub(crate)u8)","Violates transparent single-field layout."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")],
    ),
    main_case(
        "validity__recursive-validity-box-bool", "validity/recursive-validity-box-bool.rs",
        "A Box<bool> owns a valid boolean and dereferences to the value used to construct it.",
        [], RECURSIVE, "The fixture fails solely by reinterpreting a reference to byte 3 as Box<bool>.",
        "fn main(){for expected in [false,true]{let x=Box::new(expected);assert_eq!(*x,expected);}}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn boxed_bools_roundtrip(){for x in [false,true]{let b=Box::new(x);assert_eq!(*b,x);}}#[test]fn independent_boxes(){let a=Box::new(false);let b=Box::new(true);assert_ne!(*a,*b);}",
        [mutation("for expected in [false,true]{","for expected in [false,true]{panic!(\"input\");","Rejects valid inputs."),mutation("Box::new(expected)","Box::new(!expected)","Stores opposite value."),mutation("assert_eq!(*x,expected)","assert_ne!(*x,expected)","Wrong relation."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")],
    ),
    main_case(
        "validity__recursive-validity-ref-bool", "validity/recursive-validity-ref-bool.rs",
        "References to valid bool values preserve false and true when dereferenced.",
        [], RECURSIVE, "The fixture fails solely by reinterpreting a reference to byte 3 as &bool.",
        "fn main(){for expected in [false,true]{let x=&expected;assert_eq!(*x,expected);}}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn bool_refs_roundtrip(){for x in [false,true]{let r=&x;assert_eq!(*r,x);}}#[test]fn distinct_values(){let a=false;let b=true;assert_ne!(*&a,*&b);}",
        [mutation("for expected in [false,true]{","for expected in [false,true]{panic!(\"input\");","Rejects valid inputs."),mutation("let x=&expected","let x=&!expected","References opposite value."),mutation("assert_eq!(*x,expected)","assert_ne!(*x,expected)","Wrong relation."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")],
    ),
    main_case(
        "validity__match_binder_checks_validity2", "validity/match_binder_checks_validity2.rs",
        "A union bool field initialized with valid byte encodings 0 or 1 binds as false or true.",
        [], DEFAULT, "Only binding union storage initialized with invalid bool byte 3 is rejected.",
        "fn main(){#[derive(Copy,Clone)]union Uninit<T:Copy>{value:T,uninit:u8}unsafe{let f=Uninit::<bool>{uninit:0}.value;let t=Uninit::<bool>{uninit:1}.value;assert!(!f);assert!(t);}}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn valid_union_bools(){#[derive(Copy,Clone)]union U{value:bool,uninit:u8}unsafe{assert!(!U{uninit:0}.value);assert!(U{uninit:1}.value);}}#[test]fn bool_bytes_are_exact(){assert_eq!(false as u8,0);assert_eq!(true as u8,1);}",
        [mutation("uninit:0","uninit:1","Wrong false encoding."),mutation("uninit:1","uninit:0","Wrong true encoding."),mutation("assert!(!f)","assert!(f)","Negates false."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")],
    ),
    main_case(
        "validity__transmute_through_ptr", "validity/transmute_through_ptr.rs",
        "evil preserves Bool::True as a valid enum value; it must not write an out-of-range tag.",
        ["Bool","evil"], DEFAULT, "The original helper's write of tag 44 is the entire invalid behavior.",
        "#[repr(u32)]#[derive(Debug,PartialEq)]enum Bool{True}fn evil(x:&mut Bool){let p=x as*mut _ as*mut u32;unsafe{*p=0;}}fn main(){let mut x=Bool::True;evil(&mut x);assert_eq!(x,Bool::True);}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn evil_preserves_validity(){for _ in 0..8{let mut x=Bool::True;evil(&mut x);assert_eq!(x,Bool::True);}}#[test]fn layout_and_tag(){assert_eq!(std::mem::size_of::<Bool>(),4);assert_eq!(Bool::True as u32,0);}",
        [mutation("*p=0","panic!(\"invalid write\")","Rejects the valid value."),mutation("assert_eq!(x,Bool::True)","panic!(\"changed\")","Rejects output."),mutation("repr(u32)","repr(u8)","Changes layout."),mutation("fn evil(x:&mut Bool){","fn evil(_x:&mut Bool){panic!(\"evil\")}fn unused(x:&mut Bool){","Panics.")],
    ),
    main_case(
        "uninit__padding-struct-in-union", "uninit/padding-struct-in-union.rs",
        "Foo and Bar are eight-byte C-layout values; assigning Foo(1,2) preserves both payload fields without reading Foo padding through Bar.",
        ["Foo","Bar","FooBar"], DEFAULT, "The fixture's final cross-field read alone observes reset padding.",
        "#[repr(C)]#[derive(Debug,Copy,Clone)]struct Foo{val16:u16,val32:u32}#[repr(C)]#[derive(Debug,Copy,Clone)]struct Bar{bytes:[u8;8]}#[repr(C)]union FooBar{foo:Foo,bar:Bar}fn main(){let mut u=FooBar{bar:Bar{bytes:[0;8]}};u.foo=Foo{val16:1,val32:2};let f=unsafe{u.foo};assert_eq!((f.val16,f.val32),(1,2));}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn layouts_are_eight(){assert_eq!(std::mem::size_of::<Foo>(),8);assert_eq!(std::mem::size_of::<Bar>(),8);assert_eq!(std::mem::size_of::<FooBar>(),8);}#[test]fn payload_assignment(){let u=FooBar{foo:Foo{val16:7,val32:9}};let f=unsafe{u.foo};assert_eq!((f.val16,f.val32),(7,9));}",
        [mutation("val16:1","val16:3","Wrong first field."),mutation("val32:2","val32:4","Wrong second field."),mutation("(1,2)","(2,1)","Swaps expectation."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")],
    ),
    main_case(
        "uninit__padding-struct", "uninit/padding-struct.rs",
        "The C-layout Pair occupies four bytes and a zero representation yields zero payload fields; padding is not read.",
        ["Pair"], DEFAULT, "Only explicitly reading the padding byte is invalid.",
        "use std::mem;#[repr(C)]#[derive(Copy,Clone)]struct Pair(u8,u16);fn main(){let p:Pair=unsafe{mem::transmute(0u32)};assert_eq!((p.0,p.1),(0,0));}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn pair_layout(){assert_eq!(std::mem::size_of::<Pair>(),4);assert_eq!(std::mem::align_of::<Pair>(),2);}#[test]fn fields_roundtrip(){let p=Pair(5,700);assert_eq!((p.0,p.1),(5,700));}",
        [mutation("transmute(0u32)","transmute(1u32)","Changes first payload."),mutation("(0,0)","(1,0)","Wrong expectation."),mutation("repr(C)","repr(packed)","Changes layout."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")],
    ),
    main_case(
        "uninit__padding-union", "uninit/padding-union.rs",
        "The C-layout union U occupies four bytes and its initialized tuple field preserves the u8 and u16 payloads without reading padding.",
        ["U"], DEFAULT, "The fixture fails only by reading the entire representation including tuple padding.",
        "#[allow(unused)]#[repr(C)]union U{field:(u8,u16)}fn main(){let p=U{field:(5,700)};let f=unsafe{p.field};assert_eq!(f,(5,700));}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn union_layout(){assert_eq!(std::mem::size_of::<U>(),4);assert_eq!(std::mem::align_of::<U>(),2);}#[test]fn field_roundtrip(){for f in [(0u8,0u16),(1,2),(u8::MAX,u16::MAX)]{let u=U{field:f};assert_eq!(unsafe{u.field},f);}}",
        [mutation("field:(5,700)","field:(6,700)","Wrong first payload."),mutation("assert_eq!(f,(5,700))","assert_eq!(f,(5,701))","Wrong expectation."),mutation("repr(C)","repr(packed)","Changes layout."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")],
    ),
]


def abi_case(case_id, path, contract, symbols, reference, tests, mutants):
    return main_case(case_id, path, contract, symbols, DEFAULT,
                     "The original fixture intentionally calls through an ABI-incompatible transmuted function pointer.",
                     reference, tests, mutants)


SPECS += [
    abi_case("function_pointers__abi_mismatch_array_vs_struct","function_pointers/abi_mismatch_array_vs_struct.rs","S and A each occupy four i32 words, but repaired calls retain their declared argument type.",["S","A"],
             "#![feature(portable_simd)]struct S(i32,i32,i32,i32);type A=[i32;4];fn main(){fn f(_:S){}f(S(1,2,3,4));assert_eq!(std::mem::size_of::<S>(),std::mem::size_of::<A>());}",
             "#[test]fn repaired_entry_completes(){main();}#[test]fn equal_size_distinct_shapes(){assert_eq!(std::mem::size_of::<S>(),16);assert_eq!(std::mem::size_of::<A>(),16);}#[test]fn fields_exist(){let s=S(1,2,3,4);assert_eq!((s.0,s.1,s.2,s.3),(1,2,3,4));}",
             [mutation("fn f(_:S){}","fn f(_:S){panic!(\"f\")}","Rejects the valid call."),mutation("size_of::<A>()","8","Wrong comparison."),mutation("struct S(i32,i32,i32,i32)","struct S(i32,i32,i32)","Changes layout."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")]),
    abi_case("function_pointers__abi_mismatch_int_vs_float","function_pointers/abi_mismatch_int_vs_float.rs","The repaired call passes an f32 to the declared fn(f32) callee.",[],
             "fn main(){fn f(x:f32)->f32{x}assert_eq!(f(42.0),42.0);}",
             "#[test]fn repaired_entry_completes(){main();}#[test]fn repeated_valid_calls(){for x in [-1.0f32,0.0,42.0]{assert_eq!(({fn f(x:f32)->f32{x}f})(x),x);}}",
             [mutation("f(42.0)","f(41.0)","Wrong input."),mutation("->f32{x}","->f32{x+1.0}","Changes callee result."),mutation(",42.0)",",41.0)","Wrong expectation."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")]),
    abi_case("function_pointers__abi_mismatch_raw_pointer","function_pointers/abi_mismatch_raw_pointer.rs","The repaired call passes a valid raw slice pointer to fn(*const [i32]).",[],
             "fn main(){fn f(p:*const[i32])->usize{unsafe{(&*p).len()}}let a=[1,2,3];assert_eq!(f(&a),3);}",
             "#[test]fn repaired_entry_completes(){main();}#[test]fn valid_slice_metadata(){for n in [0usize,1,4]{let a=[0i32;4];let p=std::ptr::slice_from_raw_parts(a.as_ptr(),n);assert_eq!(unsafe{(&*p).len()},n);}}",
             [mutation("f(&a),3","f(&a),2","Wrong length."),mutation("(&*p).len()","(&*p).len()+1","Changes result."),mutation("[1,2,3]","[1,2]","Changes slice."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")]),
    abi_case("function_pointers__abi_mismatch_repr_C","function_pointers/abi_mismatch_repr_C.rs","S1 and S2 are four-byte C-layout wrappers; repaired calls pass S2 to callee.",["S1","S2","callee"],
             "use std::num::NonZero;#[repr(C)]struct S1(NonZero<i32>);#[repr(C)]struct S2(i32);fn callee(_s:S2){}fn main(){callee(S2(1));assert_eq!(std::mem::size_of::<S1>(),4);assert_eq!(std::mem::size_of::<S2>(),4);}",
             "#[test]fn repaired_entry_completes(){main();}#[test]fn wrapper_layouts(){assert_eq!(std::mem::size_of::<S1>(),4);assert_eq!(std::mem::size_of::<S2>(),4);}#[test]fn valid_callee_calls(){for x in [-1,0,1]{callee(S2(x));}}",
             [mutation("callee(S2(1))","callee(S2(2));panic!(\"value\")","Rejects call."),mutation("size_of::<S1>(),4","size_of::<S1>(),8","Wrong S1 size."),mutation("struct S2(i32)","struct S2(i64)","Changes S2 layout."),mutation("fn callee(_s:S2){}","fn callee(_s:S2){panic!(\"callee\")}","Panics.")]),
    abi_case("function_pointers__abi_mismatch_return_type","function_pointers/abi_mismatch_return_type.rs","The declared fn() -> u32 return value is preserved as 42.",[],
             "fn main(){fn f()->u32{42}assert_eq!(f(),42);}",
             "#[test]fn repaired_entry_completes(){main();}#[test]fn declared_return_is_used(){for _ in 0..8{main();}}",
             [mutation("->u32{42}","->u32{41}","Wrong return."),mutation("f(),42","f(),41","Wrong expectation."),mutation("fn f()->u32{42}","fn f()->u32{panic!(\"f\")}","Panics."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")]),
    abi_case("function_pointers__abi_mismatch_simple","function_pointers/abi_mismatch_simple.rs","The repaired call passes the complete (i32,i32) tuple to its declared callee.",[],
             "fn main(){fn f(x:(i32,i32))->i32{x.0+x.1}assert_eq!(f((20,22)),42);}",
             "#[test]fn repaired_entry_completes(){main();}#[test]fn tuple_inputs_are_preserved(){for _ in 0..6{main();}}",
             [mutation("(20,22)","(20,21)","Wrong tuple."),mutation("x.0+x.1","x.0-x.1","Changes result."),mutation(")),42",")),41","Wrong expectation."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")]),
    abi_case("function_pointers__abi_mismatch_too_few_args","function_pointers/abi_mismatch_too_few_args.rs","The repaired call supplies the tuple argument required by fn((i32,i32)).",[],
             "fn main(){fn f(x:(i32,i32))->i32{x.0+x.1}assert_eq!(f((1,2)),3);}",
             "#[test]fn repaired_entry_completes(){main();}#[test]fn required_argument_is_used(){for _ in 0..6{main();}}",
             [mutation("(1,2)","(1,3)","Wrong tuple."),mutation("x.0+x.1","x.0*x.1","Changes result."),mutation(")),3",")),4","Wrong expectation."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")]),
    abi_case("function_pointers__abi_mismatch_too_many_args","function_pointers/abi_mismatch_too_many_args.rs","The repaired call invokes fn() with no extra argument and completes.",[],
             "fn main(){fn f()->i32{42}assert_eq!(f(),42);}",
             "#[test]fn repaired_entry_completes(){main();}#[test]fn zero_arg_call_repeats(){for _ in 0..8{main();}}",
             [mutation("->i32{42}","->i32{41}","Wrong return."),mutation("f(),42","f(),41","Wrong expectation."),mutation("fn f()->i32{42}","fn f()->i32{panic!(\"f\")}","Panics."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")]),
    abi_case("function_pointers__abi_mismatch_vector","function_pointers/abi_mismatch_vector.rs","The repaired call retains the declared u32x8 vector type and its eight lanes.",[],
             "#![feature(portable_simd)]use std::simd;fn main(){fn f(x:simd::u32x8)->simd::u32x8{x}let x=simd::u32x8::from_array([1,2,3,4,5,6,7,8]);assert_eq!(f(x).to_array(),[1,2,3,4,5,6,7,8]);assert_eq!(std::mem::size_of::<simd::u32x8>(),32);}",
             "#[test]fn repaired_entry_completes(){main();}#[test]fn vector_layout(){assert_eq!(std::mem::size_of::<std::simd::u32x8>(),32);}#[test]fn lanes_roundtrip(){main();}",
             [mutation("from_array([1,2,3,4,5,6,7,8])","from_array([8,7,6,5,4,3,2,1])","Reverses input only."),mutation("u32x8{x}","u32x8{simd::u32x8::splat(0)}","Drops lanes."),mutation("size_of::<simd::u32x8>(),32","size_of::<simd::u32x8>(),16","Wrong size."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")]),
]


def main() -> None:
    for spec in SPECS:
        write_case(spec)
    print(f"wrote {len(SPECS)} batch-7 cases")


if __name__ == "__main__":
    main()
