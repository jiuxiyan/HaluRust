#!/usr/bin/env python3
"""Materialize batch 11: bounded copies, pointer offsets, and remaining scalar conversions."""

from __future__ import annotations

from generate_batch2_cases import DEFAULT, mutation, write_case
from generate_batch6_cases import main_case
from generate_batch10_cases import build as float_case


PERMISSIVE = [("permissive", ["-Zmiri-permissive-provenance"]), ("default-strict", [])]


def s(case_id, contract, reference, extra_test, muts, profiles=DEFAULT):
    return main_case(
        case_id, case_id.replace("intrinsics__", "intrinsics/") + ".rs",
        contract, [], profiles,
        "The source identifies a concrete precondition violation; the oracle keeps the operation within one live allocation, representable bounds, correct alignment, and non-overlapping ranges as applicable.",
        reference,
        "#[test]fn repaired_entry_completes(){main();}"
        "#[test]fn repaired_entry_repeats(){for _ in 0..8{main();}}"
        f"#[test]fn independent_valid_domain(){{{extra_test}}}",
        muts,
    )


P = mutation("fn main(){", "fn main(){panic!(\"main\");", "Panics on valid input.")


SPECS = [
    float_case("float_to_int_64_too_small1", "f64", "i32"),
    float_case("float_to_int_64_too_small2", "f64", "i64"),
    float_case("float_to_int_64_too_small3", "f64", "i128"),
    s("intrinsics__funnel_shl","unchecked_funnel_shl combines two u32 values for shift counts below 32.",
      "#![feature(core_intrinsics,funnel_shifts)]fn main(){let n=unsafe{std::intrinsics::unchecked_funnel_shl(0x12345678u32,0x9abcdef0,8)};assert_eq!(n,0x3456789a);}",
      "assert_eq!((0x12345678u32<<8)|(0x9abcdef0u32>>24),0x3456789a);",
      [mutation(",8)",",4)","Changes shift."),mutation("0x3456789a","0x3456789b","Wrong result."),mutation("unchecked_funnel_shl","unchecked_funnel_shr","Uses opposite funnel."),P]),
    s("intrinsics__funnel_shr","unchecked_funnel_shr combines two u32 values for shift counts below 32.",
      "#![feature(core_intrinsics,funnel_shifts)]fn main(){let n=unsafe{std::intrinsics::unchecked_funnel_shr(0x12345678u32,0x9abcdef0,8)};assert_eq!(n,0x789abcde);}",
      "assert_eq!((0x9abcdef0u32>>8)|(0x12345678u32<<24),0x789abcde);",
      [mutation(",8)",",4)","Changes shift."),mutation("0x789abcde","0x789abcdf","Wrong result."),mutation("unchecked_funnel_shr","unchecked_funnel_shl","Uses opposite funnel."),P]),
    s("intrinsics__copy_overflow","copy_from copies one initialized i32 when the total byte size is representable.",
      "fn main(){let x=42i32;let mut y=0i32;unsafe{(&mut y as*mut i32).copy_from(&x,1)}assert_eq!(y,42);}",
      "let x=7i32;let mut y=0;unsafe{std::ptr::copy(&x,&mut y,1)}assert_eq!(y,7);",
      [mutation("x=42i32","x=41i32","Wrong source."),mutation("copy_from(&x,1)","copy_from(&x,0)","Copies zero elements."),mutation("y,42","y,41","Wrong result."),P]),
    s("intrinsics__copy_overlapping","copy_nonoverlapping copies between disjoint ranges in one live allocation.",
      "#![feature(core_intrinsics)]fn main(){let mut d=[1u8,2,0,0,0,0];unsafe{let p=d.as_mut_ptr();std::intrinsics::copy_nonoverlapping(p,p.add(4),2)}assert_eq!(d,[1,2,0,0,1,2]);}",
      "let mut d=[1u8,2,0,0];unsafe{let p=d.as_mut_ptr();std::ptr::copy_nonoverlapping(p,p.add(2),2)}assert_eq!(d,[1,2,1,2]);",
      [mutation("p.add(4)","p.add(3)","Changes destination."),mutation(",2)}",",1)}","Copies one element."),mutation("[1,2,0,0,1,2]","[1,2,0,1,2,0]","Wrong layout."),P]),
    s("intrinsics__copy_unaligned","zero- or one-element copy_nonoverlapping uses correctly aligned u16 pointers.",
      "#![feature(core_intrinsics)]fn main(){let src=7u16;let mut dst=0u16;unsafe{std::intrinsics::copy_nonoverlapping(&src,&mut dst,1)}assert_eq!(dst,7);}",
      "let src=9u16;let mut dst=0;unsafe{std::ptr::copy_nonoverlapping(&src,&mut dst,1)}assert_eq!(dst,9);",
      [mutation("src=7u16","src=6u16","Wrong source."),mutation("&mut dst,1","&mut dst,0","Copies zero elements."),mutation("dst,7","dst,6","Wrong result."),P]),
    s("intrinsics__ptr_offset_from_different_allocs","offset_from reports element distance for two pointers derived from the same array.",
      "fn main(){let a=[0u8;8];let p=a.as_ptr();assert_eq!(unsafe{p.add(5).offset_from(p)},5);}",
      "let a=[0u8;4];let p=a.as_ptr();assert_eq!(unsafe{p.add(3).offset_from(p)},3);",
      [mutation("p.add(5)","p.add(4)","Changes endpoint."),mutation(")},5",")},4","Wrong distance."),mutation("[0u8;8]","[0u8;4]","Makes endpoint out of bounds."),P]),
    s("intrinsics__ptr_offset_from_different_ints","byte_offset_from of a pointer with itself is zero for a live ZST.",
      "fn main(){let unit=();let p=&unit as*const();assert_eq!(unsafe{p.byte_offset_from(p)},0);}",
      "let x=0u8;let p=&x as*const u8;assert_eq!(unsafe{p.byte_offset_from(p)},0);",
      [mutation("assert_eq!(unsafe{p.byte_offset_from(p)},0)","panic!(\"offset\")","Rejects self distance."),mutation(")},0",")},1","Wrong distance."),mutation("let unit=()","let unit=();panic!(\"unit\")","Rejects live ZST."),P]),
    s("intrinsics__ptr_offset_from_oob","offset_from reports an in-bounds byte distance within one array.",
      "fn main(){let a=[0u8;4];let p=a.as_ptr();assert_eq!(unsafe{p.add(3).offset_from(p)},3);}",
      "let a=[0u8;2];let p=a.as_ptr();assert_eq!(unsafe{p.add(1).offset_from(p)},1);",
      [mutation("p.add(3)","p.add(2)","Changes endpoint."),mutation(")},3",")},2","Wrong distance."),mutation("[0u8;4]","[0u8;2]","Makes endpoint out of bounds."),P]),
    s("intrinsics__ptr_offset_from_unsigned_neg","offset_from_unsigned reports a forward distance when the first pointer has the greater address.",
      "fn main(){let a=[0u8;8];let p=a.as_ptr();assert_eq!(unsafe{p.add(4).offset_from_unsigned(p)},4);}",
      "let a=[0u8;3];let p=a.as_ptr();assert_eq!(unsafe{p.add(2).offset_from_unsigned(p)},2);",
      [mutation("p.add(4)","p.add(3)","Changes endpoint."),mutation(")},4",")},3","Wrong distance."),mutation("offset_from_unsigned(p)","offset_from_unsigned(p.add(1))","Changes base."),P]),
    s("intrinsics__ptr_offset_int_plus_int","offset by one is valid for a pointer into a live two-byte array.",
      "fn main(){let a=[10u8,20];let p=a.as_ptr();assert_eq!(unsafe{*p.offset(1)},20);}",
      "let a=[1u8,2,3];let p=a.as_ptr();assert_eq!(unsafe{*p.offset(2)},3);",
      [mutation("offset(1)","offset(0)","Changes offset."),mutation(")},20",")},10","Wrong value."),mutation("[10u8,20]","[10u8,21]","Changes destination value."),P],PERMISSIVE),
    s("intrinsics__ptr_offset_int_plus_ptr","offset zero preserves a live Box pointer and its value.",
      "fn main(){let b=Box::new(42u32);let p=Box::into_raw(b);unsafe{let q=p.offset(0);assert_eq!(*q,42);drop(Box::from_raw(p));}}",
      "let x=7u32;let p=&x as*const u32;assert_eq!(unsafe{*p.offset(0)},7);",
      [mutation("offset(0)","offset(1)","Moves out of bounds."),mutation("*q,42","*q,41","Wrong value."),mutation("42u32","41u32","Changes allocation."),P],PERMISSIVE),
    s("intrinsics__ptr_offset_out_of_bounds","offset may form the one-past pointer of a four-byte array.",
      "fn main(){let v=[0i8;4];let p=v.as_ptr();let end=unsafe{p.offset(4)};assert_eq!(unsafe{end.offset_from(p)},4);}",
      "let a=[0u8;2];let p=a.as_ptr();assert_eq!(unsafe{p.add(2).offset_from(p)},2);",
      [mutation("offset(4)","offset(5)","Moves out of bounds."),mutation(")},4",")},3","Wrong distance."),mutation("[0i8;4]","[0i8;3]","Shrinks allocation."),P]),
    s("intrinsics__ptr_offset_out_of_bounds_neg","a pointer at index one may offset by -1 back to the array start.",
      "fn main(){let v=[7i8,9,11,13];let p=unsafe{v.as_ptr().add(1).offset(-1)};assert_eq!(unsafe{*p},7);}",
      "let a=[3u8,4];let p=unsafe{a.as_ptr().add(1).offset(-1)};assert_eq!(unsafe{*p},3);",
      [mutation("offset(-1)","offset(0)","Does not return to start."),mutation("assert_eq!(unsafe{*p},7)","assert_eq!(unsafe{*p},9)","Wrong value."),mutation("[7i8,9,11,13]","[8i8,9,11,13]","Changes first value."),P]),
    s("intrinsics__ptr_offset_out_of_bounds_neg2","two successive -1 offsets from index two remain within the allocation and reach its start.",
      "fn main(){let v=[7i8,9,11,13];let p=unsafe{v.as_ptr().add(2).offset(-1).offset(-1)};assert_eq!(unsafe{*p},7);}",
      "let a=[3u8,4,5];let p=unsafe{a.as_ptr().add(2).offset(-1).offset(-1)};assert_eq!(unsafe{*p},3);",
      [mutation("add(2)","add(1)","Starts too early."),mutation("offset(-1).offset(-1)","offset(-1).offset(0)","Stops at index one."),mutation("assert_eq!(unsafe{*p},7)","assert_eq!(unsafe{*p},9)","Wrong value."),P]),
    s("intrinsics__ptr_offset_overflow","offset zero preserves an in-bounds pointer and pointee.",
      "fn main(){let v=[7i8,8,9,10];let p=v.as_ptr();let q=unsafe{p.offset(0)};assert_eq!(unsafe{*q},7);}",
      "let x=9i8;let p=&x as*const i8;assert_eq!(unsafe{*p.offset(0)},9);",
      [mutation("offset(0)","offset(1)","Moves to another element."),mutation("*q},7","*q},8","Wrong value."),mutation("[7i8,8,9,10]","[6i8,8,9,10]","Changes pointee."),P]),
    s("intrinsics__ptr_offset_unsigned_overflow","byte_offset(-1) and byte_add(0) stay within the same i32 array allocation.",
      "fn main(){let a=[11i32,22];let p=unsafe{a.as_ptr().add(1).byte_offset(-4)};assert_eq!(unsafe{*p.byte_add(0)},11);}",
      "let a=[1u8,2];let p=unsafe{a.as_ptr().add(1).byte_offset(-1)};assert_eq!(unsafe{*p.byte_add(0)},1);",
      [mutation("byte_offset(-4)","byte_offset(0)","Stays at second element."),mutation(")},11",")},22","Wrong value."),mutation("byte_add(0)","byte_add(4)","Moves to second element."),P]),
    s("intrinsics__write_bytes_overflow","write_bytes initializes one i32 object when the total byte size is representable.",
      "fn main(){let mut y=7i32;unsafe{(&mut y as*mut i32).write_bytes(0u8,1)}assert_eq!(y,0);}",
      "let mut a=[1u8;4];unsafe{a.as_mut_ptr().write_bytes(0,4)}assert_eq!(a,[0;4]);",
      [mutation("write_bytes(0u8,1)","write_bytes(1u8,1)","Writes nonzero bytes."),mutation("y,0","y,1","Wrong value."),mutation("write_bytes(0u8,1)","write_bytes(0u8,0)","Writes zero elements."),P]),
]


def main() -> None:
    for item in SPECS:
        write_case(item)
    print(f"wrote {len(SPECS)} batch-11 cases")


if __name__ == "__main__":
    main()
