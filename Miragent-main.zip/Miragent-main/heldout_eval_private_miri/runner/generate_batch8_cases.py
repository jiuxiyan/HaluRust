#!/usr/bin/env python3
"""Materialize the eighth batch: positive local, layout, and lifetime invariants."""

from __future__ import annotations

from generate_batch2_cases import DEFAULT, STACK_TREE, mutation, write_case
from generate_batch6_cases import main_case


WEAK = [("official-weakened", ["-Zmiri-disable-validation"]), ("default-strict", [])]
NO_STACK = [("official-no-stacked", ["-Zmiri-disable-stacked-borrows"]), ("default-strict", [])]


def c(case_id, path, contract, symbols, reference, tests, muts, profiles=DEFAULT, evidence=None):
    return main_case(
        case_id, path, contract, symbols, profiles,
        evidence or "The positive behavior is explicit in the source before or apart from the diagnostic-only invalid operation.",
        reference, tests, muts,
    )


SPECS = [
    c("async-shared-mutable","async-shared-mutable.rs",
      "Polling the pending future twice may update interior-mutable state on each poll and remains Pending.",[],
      "use core::cell::Cell;use core::future::Future;use core::pin::pin;use core::task::{Context,Poll,Waker};fn main(){let x=Cell::new(0u8);let mut f=pin!(core::future::poll_fn(|_|{x.set(x.get()+1);Poll::<()>::Pending}));let mut cx=Context::from_waker(&Waker::noop());assert_eq!(f.as_mut().poll(&mut cx),Poll::Pending);assert_eq!(f.as_mut().poll(&mut cx),Poll::Pending);drop(f);assert_eq!(x.get(),2);}",
      "#[test]fn repaired_entry_completes(){main();}#[test]fn repeated_polls_are_valid(){main();main();}#[test]fn pending_is_stable(){assert_eq!(core::task::Poll::<()>::Pending,core::task::Poll::Pending);}",
      [mutation("x.get()+1","x.get()+2","Wrong update."),mutation("x.get(),2","x.get(),1","Wrong final count."),mutation("Poll::<()>::Pending","Poll::<()>::Ready(())","Becomes ready."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")],STACK_TREE,
      "The fixture explicitly says it should pass and asserts Pending after both polls."),
    c("branchless-select-i128-pointer","branchless-select-i128-pointer.rs",
      "Selecting between the two string literals yields `true !` for true and `false !` for false without integerizing pointers.",["TwoPtrs"],
      "#[cfg(target_pointer_width=\"32\")]type TwoPtrs=i64;#[cfg(target_pointer_width=\"64\")]type TwoPtrs=i128;fn main(){assert_eq!(std::mem::size_of::<TwoPtrs>(),2*std::mem::size_of::<usize>());for &b in &[true,false]{let val=if b{\"true !\"}else{\"false !\"};assert_eq!(val,if b{\"true !\"}else{\"false !\"});}}",
      "#[test]fn repaired_entry_completes(){main();}#[test]fn both_branches(){assert_eq!(if true{\"true !\"}else{\"false !\"},\"true !\");assert_eq!(if false{\"true !\"}else{\"false !\"},\"false !\");}#[test]fn carrier_matches_two_pointers(){assert_eq!(std::mem::size_of::<TwoPtrs>(),2*std::mem::size_of::<usize>());}",
      [mutation("let val=if b{\"true !\"}else{\"false !\"}","let val=if b{\"false !\"}else{\"true !\"}","Swaps selected values."),mutation("assert_eq!(val,if b{\"true !\"}else{\"false !\"})","assert_eq!(val,\"true !\")","Rejects the false branch."),mutation("2*std::mem::size_of::<usize>()","std::mem::size_of::<usize>()","Wrong carrier size."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")]),
    c("memleak_rc","memleak_rc.rs",
      "The temporary Rc cycle is broken before return, leaving one strong owner and allowing the allocation to be reclaimed.",["Dummy"],
      "use std::cell::RefCell;use std::rc::Rc;struct Dummy(Rc<RefCell<Option<Dummy>>>);fn main(){let x=Dummy(Rc::new(RefCell::new(None)));let y=Dummy(x.0.clone());*x.0.borrow_mut()=Some(y);drop(x.0.borrow_mut().take());assert_eq!(Rc::strong_count(&x.0),1);}",
      "#[test]fn repaired_entry_completes(){main();}#[test]fn cycles_are_broken(){for _ in 0..6{main();}}#[test]fn acyclic_dummy_count(){let x=Dummy(std::rc::Rc::new(std::cell::RefCell::new(None)));assert_eq!(std::rc::Rc::strong_count(&x.0),1);}",
      [mutation(".take()",".replace(Dummy(x.0.clone()))","Keeps the cycle."),mutation("strong_count(&x.0),1","strong_count(&x.0),2","Wrong count."),mutation("drop(x.0.borrow_mut().take());","","Does not break cycle."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")]),
    c("static_memory_modification1","static_memory_modification1.rs",
      "X remains the read-only value 5 while writable local storage may be updated to 6.",["X"],
      "static X:usize=5;fn main(){let mut local=X;local=6;assert_eq!(local,6);assert_eq!(X,5);}",
      "#[test]fn repaired_entry_completes(){main();}#[test]fn static_is_unchanged(){main();assert_eq!(X,5);}#[test]fn repeatable(){for _ in 0..8{main();}}",
      [mutation("local=6","local=7","Wrong local value."),mutation("local,6","local,5","Wrong expectation."),mutation("X,5","X,6","Claims static changed."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")],NO_STACK),
    c("static_memory_modification2","static_memory_modification2.rs",
      "An owned byte buffer may change byte 4 to 42 while retaining all other bytes.",[],
      "fn main(){let mut bs=b\"this is a test\".to_vec();let before=bs.clone();bs[4]=42;assert_eq!(bs[4],42);assert_eq!(&bs[..4],&before[..4]);assert_eq!(&bs[5..],&before[5..]);}",
      "#[test]fn repaired_entry_completes(){main();}#[test]fn owned_storage_repeats(){for _ in 0..8{main();}}#[test]fn source_literal_unchanged(){assert_eq!(b\"this is a test\"[4],b' ');}",
      [mutation("bs[4]=42","bs[4]=41","Wrong byte."),mutation("bs[4],42","bs[4],41","Wrong expectation."),mutation("&bs[5..],&before[5..]","&bs[4..],&before[4..]","Claims changed suffix is equal."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")],NO_STACK),
    c("static_memory_modification3","static_memory_modification3.rs",
      "An owned copy of the byte string may change byte 4 to 42 without modifying the static literal.",[],
      "fn main(){let mut bs=b\"this is a test\".to_vec();bs[4]=42;assert_eq!(bs[4],42);assert_eq!(b\"this is a test\"[4],b' ');}",
      "#[test]fn repaired_entry_completes(){main();}#[test]fn owned_copy_is_writable(){for _ in 0..8{main();}}#[test]fn literal_stays_read_only(){assert_eq!(b\"this is a test\"[4],b' ');}",
      [mutation("bs[4]=42","bs[4]=41","Wrong byte."),mutation("bs[4],42","bs[4],41","Wrong expectation."),mutation("[4],b' '","[4],b'*'","Wrong literal value."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")],NO_STACK),
    c("storage-live-dead-var","storage-live-dead-var.rs",
      "A live initialized local stores and reads the value 42.",[],
      "fn main(){let val:i32=42;assert_eq!(val,42);}",
      "#[test]fn repaired_entry_completes(){main();}#[test]fn live_value_repeats(){for _ in 0..10{main();}}#[test]fn ordinary_local(){let x=42i32;assert_eq!(x,42);}",
      [mutation("val:i32=42","val:i32=41","Wrong value."),mutation("val,42","val,41","Wrong expectation."),mutation("let val:i32=42;","","Drops initialization and check input."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")]),
    c("storage-live-resets-var","storage-live-resets-var.rs",
      "After any lifetime reset, the local is reinitialized to 42 before it is read.",[],
      "fn main(){let mut val:i32=0;val=42;let observed=val;assert_eq!(observed,42);}",
      "#[test]fn repaired_entry_completes(){main();}#[test]fn reinitialized_value_repeats(){for _ in 0..10{main();}}#[test]fn ordinary_reinit(){let mut x=0;x=42;assert_eq!(x,42);}",
      [mutation("val=42","val=41","Wrong reinitialization."),mutation("observed,42","observed,41","Wrong expectation."),mutation("let observed=val","let observed=val+1","Changes observation."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")]),
    c("overlapping_assignment_aggregate","overlapping_assignment_aggregate.rs",
      "Copying the initialized one-byte array through a temporary preserves its value without overlapping assignment.",[],
      "fn main(){let mut x=([0u8;1],);let tmp=x.0;x=(tmp,);assert_eq!(x.0,[0]);}",
      "#[test]fn repaired_entry_completes(){main();}#[test]fn aggregate_copy_repeats(){for _ in 0..10{main();}}#[test]fn payload_shape(){assert_eq!(std::mem::size_of::<([u8;1],)>(),1);}",
      [mutation("[0u8;1]","[1u8;1]","Wrong initial value."),mutation("x.0,[0]","x.0,[1]","Wrong expectation."),mutation("let tmp=x.0","let tmp=[2]","Changes temporary."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")]),
    c("ptr_swap_nonoverlapping","ptr_swap_nonoverlapping.rs",
      "swap_nonoverlapping exchanges two distinct initialized usize locations.",[],
      "fn main(){let(mut a,mut b)=(1usize,2usize);unsafe{std::ptr::swap_nonoverlapping(&mut a,&mut b,1)};assert_eq!((a,b),(2,1));}",
      "#[test]fn repaired_entry_completes(){main();}#[test]fn distinct_swaps(){for (x,y) in [(0usize,1usize),(7,9),(usize::MAX,0)]{let(mut a,mut b)=(x,y);unsafe{std::ptr::swap_nonoverlapping(&mut a,&mut b,1)};assert_eq!((a,b),(y,x));}}#[test]fn repeatable(){main();main();}",
      [mutation("(1usize,2usize)","(1usize,1usize)","Indistinguishable inputs."),mutation("(a,b),(2,1)","(a,b),(1,2)","Wrong result."),mutation("swap_nonoverlapping(&mut a,&mut b,1)","swap_nonoverlapping(&mut a,&mut b,0)","Swaps zero elements."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")]),
    c("read_from_trivial_switch","read_from_trivial_switch.rs",
      "A trivial or-pattern reads an initialized i32 and preserves the value 42.",[],
      "fn main(){let value=42i32;let r=&value;let &(0|_)=r;assert_eq!(*r,42);}",
      "#[test]fn repaired_entry_completes(){main();}#[test]fn initialized_pattern_repeats(){for _ in 0..10{main();}}#[test]fn alternatives_are_total(){for x in [0i32,1,-1]{let &(0|_)=&x;assert_eq!(x,x);}}",
      [mutation("value=42i32","value=41i32","Wrong value."),mutation("*r,42","*r,41","Wrong expectation."),mutation("let r=&value","let r=&0","Changes reference."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")]),
    c("uninit__uninit-after-aggregate-assign","uninit/uninit-after-aggregate-assign.rs",
      "Assigning S(0,0) initializes both payload fields; its padding is not observed.",["S"],
      "#[repr(C)]struct S(u8,u16);fn main(){let s=S(0,0);assert_eq!((s.0,s.1),(0,0));}",
      "#[test]fn repaired_entry_completes(){main();}#[test]fn layout_and_fields(){assert_eq!(std::mem::size_of::<S>(),4);let s=S(7,900);assert_eq!((s.0,s.1),(7,900));}#[test]fn zero_fields(){main();}",
      [mutation("S(0,0)","S(1,0)","Wrong first field."),mutation("(s.0,s.1),(0,0)","(s.0,s.1),(1,0)","Wrong expectation."),mutation("repr(C)","repr(packed)","Changes layout."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")]),
    c("uninit__uninit_alloc_diagnostic","uninit/uninit_alloc_diagnostic.rs",
      "A 32-byte allocation is fully initialized before two 16-byte slices are compared and then deallocated.",[],
      "use std::alloc::{Layout,alloc,dealloc};fn main(){let layout=Layout::from_size_align(32,8).unwrap();unsafe{let p=alloc(layout);assert!(!p.is_null());std::ptr::write_bytes(p,0,32);p.copy_from_nonoverlapping(b\"ABCD\".as_ptr(),4);let a=std::slice::from_raw_parts(p,16);let b=std::slice::from_raw_parts(p.add(16),16);assert_eq!(a.cmp(b),std::cmp::Ordering::Greater);dealloc(p,layout);}}",
      "#[test]fn repaired_entry_completes(){main();}#[test]fn initialized_allocation_repeats(){for _ in 0..5{main();}}#[test]fn expected_order(){assert!(b\"ABCD\"[..]>[0u8;4][..]);}",
      [mutation("write_bytes(p,0,32)","write_bytes(p,0,16)","Leaves second half uninitialized."),mutation("Ordering::Greater","Ordering::Less","Wrong comparison."),mutation("dealloc(p,layout);","","Leaks allocation."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")],WEAK),
    c("uninit__uninit_byte_read","uninit/uninit_byte_read.rs",
      "Reading index 5 of a ten-byte initialized vector yields 5 and adding one yields 6.",[],
      "fn main(){let v:Vec<u8>=(0..10).collect();let value=v[5];assert_eq!(value,5);assert_eq!(value+1,6);}",
      "#[test]fn repaired_entry_completes(){main();}#[test]fn initialized_bytes(){let v:Vec<u8>=(0..10).collect();assert_eq!(v[5],5);}#[test]fn repeatable(){for _ in 0..8{main();}}",
      [mutation("v[5]","v[4]","Reads wrong index."),mutation("value,5","value,4","Wrong value."),mutation("value+1,6","value+1,7","Wrong sum."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")],NO_STACK),
    c("match__closures__deref-in-pattern","match/closures/deref-in-pattern.rs",
      "A closure may capture and match a live nested reference to 42.",[],
      "fn main(){let value=42u32;let r=&value;let x=&r;let f=||match x{&&y=>assert_eq!(y,42)};f();}",
      "#[test]fn repaired_entry_completes(){main();}#[test]fn live_capture_repeats(){for _ in 0..8{main();}}#[test]fn nested_refs(){let x=42;assert_eq!(**&&x,42);}",
      [mutation("value=42u32","value=41u32","Wrong value."),mutation("y,42","y,41","Wrong expectation."),mutation("f();","panic!(\"closure\");","Rejects closure."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")]),
    c("match__closures__partial-pattern","match/closures/partial-pattern.rs",
      "A closure may capture the first component of a live pair of references and observe 21.",[],
      "fn main(){let(a,b)=(21u32,37u32);let pair=(&a,&b);let x=&pair;let f=||match x{(&y,_)=>assert_eq!(y,21)};f();}",
      "#[test]fn repaired_entry_completes(){main();}#[test]fn live_pair_capture(){for _ in 0..8{main();}}#[test]fn pair_values(){let(a,b)=(21,37);assert_eq!((*&a,*&b),(21,37));}",
      [mutation("21u32","20u32","Wrong first value."),mutation("y,21","y,20","Wrong expectation."),mutation("f();","panic!(\"closure\");","Rejects closure."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")]),
    c("match__single_variant","match/single_variant.rs",
      "The valid repr(u8) tag 42 constructs both single-variant enums and preserves their u8 payload.",["Exhaustive","NonExhaustive"],
      "#![allow(dead_code)]#[repr(u8)]enum Exhaustive{A(u8)=42}#[repr(u8)]#[non_exhaustive]enum NonExhaustive{A(u8)=42}fn main(){match Exhaustive::A(7){Exhaustive::A(x)=>assert_eq!(x,7)}match NonExhaustive::A(9){NonExhaustive::A(x)=>assert_eq!(x,9)}}",
      "#[test]fn repaired_entry_completes(){main();}#[test]fn layouts(){assert_eq!(std::mem::size_of::<Exhaustive>(),2);assert_eq!(std::mem::size_of::<NonExhaustive>(),2);}#[test]fn valid_payloads(){main();}",
      [mutation("A(7)","A(6)","Wrong first payload."),mutation("x,7","x,6","Wrong expectation."),mutation("A(9)","A(8)","Wrong second payload."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")]),
    c("match__single_variant_uninit","match/single_variant_uninit.rs",
      "Fully initialized tag 0 and payload bytes match both single-variant enums and expose payload 7.",["Exhaustive","NonExhaustive"],
      "#![allow(dead_code)]#[repr(u8)]enum Exhaustive{A(u8)=0}#[repr(u8)]#[non_exhaustive]enum NonExhaustive{A(u8)=0}fn main(){match Exhaustive::A(7){Exhaustive::A(x)=>assert_eq!(x,7)}match NonExhaustive::A(7){NonExhaustive::A(x)=>assert_eq!(x,7)}}",
      "#[test]fn repaired_entry_completes(){main();}#[test]fn initialized_variants(){main();}#[test]fn layouts(){assert_eq!(std::mem::size_of::<Exhaustive>(),2);assert_eq!(std::mem::size_of::<NonExhaustive>(),2);}",
      [mutation("match Exhaustive::A(7)","match Exhaustive::A(6)","Wrong exhaustive payload."),mutation("NonExhaustive::A(7)","NonExhaustive::A(6)","Wrong non-exhaustive payload."),mutation("match Exhaustive::A(7){Exhaustive::A(x)=>assert_eq!(x,7)}","match Exhaustive::A(7){Exhaustive::A(x)=>assert_eq!(x,6)}","Wrong exhaustive expectation."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")]),
    c("zst_local_oob","zst_local_oob.rs",
      "The unit local is zero-sized and may be observed as `()` without reading any byte from its address.",[],
      "fn main(){let x=();assert_eq!(std::mem::size_of_val(&x),0);assert_eq!(x,());}",
      "#[test]fn repaired_entry_completes(){main();}#[test]fn unit_is_zst(){assert_eq!(std::mem::size_of::<()>(),0);assert_eq!(std::mem::align_of::<()>(),1);}#[test]fn repeats(){for _ in 0..10{main();}}",
      [mutation("size_of_val(&x),0","size_of_val(&x),1","Wrong size."),mutation("x,()","(),panic!(\"unit\")","Rejects unit."),mutation("let x=()","let x=(0u8,)","Changes type and size."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")]),
    c("validity__invalid_wide_raw","validity/invalid_wide_raw.rs",
      "A raw trait-object pointer built from a live implementing value has non-null data and valid vtable metadata.",[],
      "fn main(){trait T{}struct V;impl T for V{}struct S{#[allow(dead_code)]x:*mut dyn T}let mut v=V;let p:&mut dyn T=&mut v;let s=S{x:p};assert!(!s.x.is_null());}",
      "#[test]fn repaired_entry_completes(){main();}#[test]fn valid_wide_pointer_repeats(){for _ in 0..8{main();}}#[test]fn thin_null_is_null(){assert!((std::ptr::null::<u8>()).is_null());}",
      [mutation("x:p","x:unsafe{std::mem::transmute((0usize,0usize))}","Uses invalid vtable."),mutation("assert!(!s.x.is_null())","assert!(s.x.is_null())","Negates pointer check."),mutation("impl T for V{}","impl T for u8{}","V no longer implements the trait."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")],WEAK),
]


def main() -> None:
    for spec in SPECS:
        write_case(spec)
    print(f"wrote {len(SPECS)} batch-8 cases")


if __name__ == "__main__":
    main()
