#!/usr/bin/env python3
"""Materialize batch 12: SIMD valid lanes/alignment and typed non-overlapping swaps."""

from __future__ import annotations

from generate_batch2_cases import DEFAULT, mutation, write_case
from generate_batch6_cases import main_case


def s(case_id, contract, symbols, reference, tests, muts):
    return main_case(
        case_id, case_id.replace("intrinsics__", "intrinsics/") + ".rs",
        contract, symbols, DEFAULT,
        "The source pinpoints an invalid lane value, index, alignment, range, or overlap; the oracle retains the original operation and type while satisfying that precondition.",
        reference, tests, muts,
    )


def entry_tests(extra: str) -> str:
    return (
        "#[test]fn repaired_entry_completes(){main();}"
        "#[test]fn repaired_entry_repeats(){for _ in 0..6{main();}}"
        f"#[test]fn independent_valid_domain(){{{extra}}}"
    )


P = mutation("fn main(){", "fn main(){panic!(\"main\");", "Panics on valid input.")
REPR = "#![feature(core_intrinsics,repr_simd,portable_simd)]use std::intrinsics::simd::*;#[repr(simd)]#[allow(non_camel_case_types)]#[derive(Copy,Clone)]struct i32x2([i32;2]);"
PORT = "#![feature(core_intrinsics,portable_simd)]use std::intrinsics::simd::*;use std::simd::*;"


SPECS = [
    s("intrinsics__simd-div-by-zero","simd_div divides each i32 lane when every divisor is nonzero.",["i32x2"],
      REPR+"fn main(){use std::simd::i32x2 as V;let r=V::from_array([12,-21])/V::from_array([3,7]);assert_eq!(r.to_array(),[4,-3]);}",
      entry_tests("assert_eq!([12/3,-21/7],[4,-3]);"),
      [mutation("[3,7]","[4,7]","Changes divisor."),mutation("[4,-3]","[3,-3]","Wrong quotient."),mutation(")/V::from_array",")%V::from_array","Uses remainder."),P]),
    s("intrinsics__simd-div-overflow","simd_div accepts signed lanes whose quotients are representable.",["i32x2"],
      REPR+"fn main(){use std::simd::i32x2 as V;let r=V::from_array([i32::MIN,-20])/V::from_array([2,-4]);assert_eq!(r.to_array(),[i32::MIN/2,5]);}",
      entry_tests("assert_eq!([i32::MIN/2,-20/-4],[i32::MIN/2,5]);"),
      [mutation("[2,-4]","[4,-4]","Changes divisor."),mutation("[i32::MIN/2,5]","[i32::MIN/4,5]","Wrong quotient."),mutation(")/V::from_array",")%V::from_array","Uses remainder."),P]),
    s("intrinsics__simd-extract","simd_extract returns the selected lane for indices 0 through 3.",[],
      "#![feature(portable_simd,core_intrinsics)]use std::simd::*;fn main(){let v=i32x4::from_array([10,20,30,40]);let x:i32=unsafe{std::intrinsics::simd::simd_extract(v,3)};assert_eq!(x,40);}",
      entry_tests("let a=[10,20,30,40];assert_eq!(a[3],40);"),
      [mutation("v,3","v,2","Changes lane."),mutation("x,40","x,30","Wrong lane value."),mutation("[10,20,30,40]","[10,20,30,41]","Changes lane data."),P]),
    s("intrinsics__simd-float-to-int","to_int_unchecked truncates finite representable f32 lanes toward zero.",[],
      "#![feature(portable_simd)]use std::simd::prelude::*;fn main(){let x:i32x2=unsafe{f32x2::from_array([1.9,-2.9]).to_int_unchecked()};assert_eq!(x.to_array(),[1,-2]);}",
      entry_tests("assert_eq!([1.9f32 as i32,-2.9f32 as i32],[1,-2]);"),
      [mutation("[1.9,-2.9]","[2.9,-2.9]","Changes first lane."),mutation("[1,-2]","[2,-2]","Wrong conversion."),mutation("[1.9,-2.9]","[1.9,-3.9]","Changes second lane."),P]),
    s("intrinsics__simd-funnel_shl-too-far","simd_funnel_shl rotates each i32 lane for shift counts in 0..32.",[],
      PORT+"fn main(){let x=i32x2::from_array([1,2]);let n=i32x2::from_array([1,2]);let r:i32x2=unsafe{simd_funnel_shl(x,x,n)};assert_eq!(r.to_array(),[2,8]);}",
      entry_tests("assert_eq!([1i32.rotate_left(1),2i32.rotate_left(2)],[2,8]);"),
      [mutation("[1,2]);let n","[2,2]);let n","Changes value."),mutation("[1,2]);let r","[2,2]);let r","Changes counts."),mutation("[2,8]","[4,8]","Wrong result."),P]),
    s("intrinsics__simd-funnel_shr-too-far","simd_funnel_shr rotates each i32 lane for shift counts in 0..32.",[],
      PORT+"fn main(){let x=i32x2::from_array([1,2]);let n=i32x2::from_array([1,2]);let r:i32x2=unsafe{simd_funnel_shr(x,x,n)};assert_eq!(r.to_array(),[i32::MIN,i32::MIN]);}",
      entry_tests("assert_eq!([1i32.rotate_right(1),2i32.rotate_right(2)],[i32::MIN,i32::MIN]);"),
      [mutation("[1,2]);let n","[2,2]);let n","Changes value."),mutation("[1,2]);let r","[2,2]);let r","Changes counts."),mutation("[i32::MIN,i32::MIN]","[0,i32::MIN]","Wrong result."),P]),
    s("intrinsics__simd-gather","gather_select_unchecked gathers all four in-bounds selected indices.",[],
      "#![feature(portable_simd)]use std::simd::*;fn main(){let v:&[i8]=&[10,11,12,13,14,15,16,17,18];let idx=Simd::from_array([8,3,0,7]);let r=unsafe{Simd::gather_select_unchecked(v,Mask::splat(true),idx,Simd::splat(0))};assert_eq!(r.to_array(),[18,13,10,17]);}",
      entry_tests("let v=[10,11,12,13,14,15,16,17,18];assert_eq!([v[8],v[3],v[0],v[7]],[18,13,10,17]);"),
      [mutation("[8,3,0,7]","[7,3,0,7]","Changes index."),mutation("[18,13,10,17]","[17,13,10,17]","Wrong gather."),mutation("Mask::splat(true)","Mask::splat(false)","Disables lanes."),P]),
    s("intrinsics__simd-reduce-invalid-bool","simd_reduce_any accepts mask lanes encoded as all-zero or all-one bits.",["i32x2"],
      REPR+"fn main(){assert!(unsafe{simd_reduce_any(i32x2([0,-1]))});assert!(!unsafe{simd_reduce_any(i32x2([0,0]))});}",
      entry_tests("assert!([false,true].into_iter().any(|x|x));assert!(![false,false].into_iter().any(|x|x));"),
      [mutation("[0,-1]","[0,0]","Drops true lane."),mutation("assert!(!unsafe","assert!(unsafe","Negates false result."),mutation("[0,0]","[-1,-1]","Changes all-false mask."),P]),
    s("intrinsics__simd-rem-by-zero","simd_rem computes each i32 remainder when every divisor is nonzero.",["i32x2"],
      REPR+"fn main(){use std::simd::i32x2 as V;let r=V::from_array([13,-21])%V::from_array([5,4]);assert_eq!(r.to_array(),[3,-1]);}",
      entry_tests("assert_eq!([13%5,-21%4],[3,-1]);"),
      [mutation("[5,4]","[4,4]","Changes divisor."),mutation("[3,-1]","[1,-1]","Wrong remainder."),mutation(")%V::from_array",")/V::from_array","Uses quotient."),P]),
    s("intrinsics__simd-scatter","scatter_select_unchecked stores four lanes at distinct in-bounds selected indices.",[],
      "#![feature(portable_simd)]use std::simd::*;fn main(){let mut v=vec![10i8,11,12,13,14,15,16,17,18];let idx=Simd::from_array([8,3,0,7]);unsafe{Simd::from_array([-27,82,-41,124]).scatter_select_unchecked(&mut v,Mask::splat(true),idx)}assert_eq!(v,[-41,11,12,82,14,15,16,124,-27]);}",
      entry_tests("let mut v=[0;4];for(i,x)in[3usize,1,0,2].into_iter().zip([4,5,6,7]){v[i]=x}assert_eq!(v,[6,5,7,4]);"),
      [mutation("[8,3,0,7]","[7,3,0,8]","Swaps indices."),mutation("[-27,82,-41,124]","[-26,82,-41,124]","Changes lane."),mutation("[-41,11,12,82,14,15,16,124,-27]","[-41,11,12,82,14,15,16,-27,124]","Wrong scatter."),P]),
    s("intrinsics__simd-select-invalid-bool","simd_select uses all-zero/all-one mask lanes to select false/true inputs.",["i32x2"],
      REPR+"fn main(){use std::simd::{i32x2 as V,Mask};let r=Mask::<i32,2>::from_array([false,true]).select(V::from_array([10,20]),V::from_array([1,2]));assert_eq!(r.to_array(),[1,20]);}",
      entry_tests("assert_eq!([if false{10}else{1},if true{20}else{2}],[1,20]);"),
      [mutation("[false,true]","[true,true]","Changes mask."),mutation("[1,20]","[10,20]","Wrong select."),mutation("[10,20]","[10,21]","Changes selected true lane."),P]),
    s("intrinsics__simd-shl-too-far","simd_shl shifts each i32 lane by a count in 0..32.",["i32x2"],
      REPR+"fn main(){use std::simd::i32x2 as V;let r=V::from_array([1,3])<<V::from_array([2,3]);assert_eq!(r.to_array(),[4,24]);}",
      entry_tests("assert_eq!([1i32<<2,3i32<<3],[4,24]);"),
      [mutation("[2,3]","[1,3]","Changes count."),mutation("[4,24]","[2,24]","Wrong shift."),mutation("<<V::from_array",">>V::from_array","Uses right shift."),P]),
    s("intrinsics__simd-shr-too-far","simd_shr shifts each i32 lane by a count in 0..32.",["i32x2"],
      REPR+"fn main(){use std::simd::i32x2 as V;let r=V::from_array([16,-16])>>V::from_array([2,3]);assert_eq!(r.to_array(),[4,-2]);}",
      entry_tests("assert_eq!([16i32>>2,-16i32>>3],[4,-2]);"),
      [mutation("[2,3]","[1,3]","Changes count."),mutation("[4,-2]","[8,-2]","Wrong shift."),mutation(">>V::from_array","<<V::from_array","Uses left shift."),P]),
]


def masked(case_id, contract, reference, expected, mutation_target):
    return s(
        case_id, contract, [], PORT + reference,
        entry_tests(expected),
        [
            mutation(mutation_target[0], mutation_target[1], "Changes transferred data."),
            mutation("i32x4::splat(-1)", "i32x4::splat(0)", "Disables all lanes."),
            mutation("fn main(){", "fn main(){panic!(\"main\");", "Panics."),
            mutation(mutation_target[2], mutation_target[3], "Wrong expected result."),
        ],
    )


SPECS += [
    masked("intrinsics__simd_masked_load_element_misaligned","element-aligned masked load reads four selected i32 lanes.",
           "fn main(){let b=[1i32,2,3,4];let r:i32x4=unsafe{simd_masked_load::<_,_,_,{SimdAlign::Element}>(i32x4::splat(-1),b.as_ptr(),i32x4::splat(0))};assert_eq!(r.to_array(),[1,2,3,4]);}",
           "assert_eq!([1,2,3,4],[1,2,3,4]);",("[1i32,2,3,4]","[5i32,2,3,4]","[1,2,3,4]","[5,2,3,4]")),
    masked("intrinsics__simd_masked_load_vector_misaligned","vector-aligned masked load reads four selected lanes from an aligned Simd value.",
           "fn main(){let b=i32x4::from_array([1,2,3,4]);let r:i32x4=unsafe{simd_masked_load::<_,_,_,{SimdAlign::Vector}>(i32x4::splat(-1),b.as_array().as_ptr(),i32x4::splat(0))};assert_eq!(r.to_array(),[1,2,3,4]);}",
           "assert_eq!([1,2,3,4],[1,2,3,4]);",("from_array([1,2,3,4])","from_array([5,2,3,4])","r.to_array(),[1,2,3,4]","r.to_array(),[5,2,3,4]")),
    masked("intrinsics__simd_masked_store_element_misaligned","element-aligned masked store writes four selected i32 lanes.",
           "fn main(){let mut b=[0i32;4];unsafe{simd_masked_store::<_,_,_,{SimdAlign::Element}>(i32x4::splat(-1),b.as_mut_ptr(),i32x4::from_array([1,2,3,4]))};assert_eq!(b,[1,2,3,4]);}",
           "let mut b=[0;4];b.copy_from_slice(&[1,2,3,4]);assert_eq!(b,[1,2,3,4]);",("from_array([1,2,3,4])","from_array([5,2,3,4])","b,[1,2,3,4]","b,[5,2,3,4]")),
    masked("intrinsics__simd_masked_store_vector_misaligned","vector-aligned masked store writes four selected lanes into an aligned Simd value.",
           "fn main(){let mut b=i32x4::splat(0);unsafe{simd_masked_store::<_,_,_,{SimdAlign::Vector}>(i32x4::splat(-1),b.as_mut_array().as_mut_ptr(),i32x4::from_array([1,2,3,4]))};assert_eq!(b.to_array(),[1,2,3,4]);}",
           "assert_eq!([1,2,3,4],[1,2,3,4]);",("from_array([1,2,3,4])","from_array([5,2,3,4])","b.to_array(),[1,2,3,4]","b.to_array(),[5,2,3,4]")),
    s("intrinsics__typed-swap-invalid-array","invalid_array preserves its original signature but swaps two valid bool arrays.",["invalid_array"],
      "#![feature(core_intrinsics,rustc_attrs)]use std::intrinsics::typed_swap_nonoverlapping;fn invalid_array(){let mut a=[true;100];let mut b=[false;100];unsafe{typed_swap_nonoverlapping(&mut a,&mut b)}assert!(a.iter().all(|x|!*x));assert!(b.iter().all(|x|*x));}fn main(){invalid_array();}",
      "#[test]fn repaired_entry_completes(){main();}#[test]fn helper_completes(){invalid_array();}#[test]fn helper_repeats(){for _ in 0..5{invalid_array();}}",
      [mutation("[true;100]","[false;100]","Changes first input."),mutation("typed_swap_nonoverlapping(&mut a,&mut b)","typed_swap_nonoverlapping(&mut a,&mut a)","Overlaps."),mutation("all(|x|!*x)","all(|x|*x)","Wrong result."),P]),
    s("intrinsics__typed-swap-invalid-scalar","invalid_scalar preserves its original signature but swaps two valid bool scalars.",["invalid_scalar"],
      "#![feature(core_intrinsics,rustc_attrs)]use std::intrinsics::typed_swap_nonoverlapping;fn invalid_scalar(){let mut a=true;let mut b=false;unsafe{typed_swap_nonoverlapping(&mut a,&mut b)}assert_eq!((a,b),(false,true));}fn main(){invalid_scalar();}",
      "#[test]fn repaired_entry_completes(){main();}#[test]fn helper_completes(){invalid_scalar();}#[test]fn helper_repeats(){for _ in 0..8{invalid_scalar();}}",
      [mutation("a=true","a=false","Changes first input."),mutation("typed_swap_nonoverlapping(&mut a,&mut b)","typed_swap_nonoverlapping(&mut a,&mut a)","Overlaps."),mutation("(false,true)","(true,false)","Wrong result."),P]),
    s("intrinsics__typed-swap-overlap","typed_swap_nonoverlapping swaps two distinct u8 locations.",[],
      "#![feature(core_intrinsics,rustc_attrs)]use std::intrinsics::typed_swap_nonoverlapping;fn main(){let(mut a,mut b)=(1u8,2u8);unsafe{typed_swap_nonoverlapping(&mut a,&mut b)}assert_eq!((a,b),(2,1));}",
      entry_tests("let(mut a,mut b)=(3u8,4u8);std::mem::swap(&mut a,&mut b);assert_eq!((a,b),(4,3));"),
      [mutation("(1u8,2u8)","(1u8,3u8)","Changes second input."),mutation("typed_swap_nonoverlapping(&mut a,&mut b)","typed_swap_nonoverlapping(&mut a,&mut a)","Overlaps."),mutation("(2,1)","(1,2)","Wrong result."),P]),
]


def main() -> None:
    for item in SPECS:
        write_case(item)
    print(f"wrote {len(SPECS)} batch-12 cases")


if __name__ == "__main__":
    main()
