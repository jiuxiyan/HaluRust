#!/usr/bin/env python3
"""Build the E/P/N oracle census for all 423 frozen cases."""

from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter
from pathlib import Path


PRIVATE_ROOT = Path(__file__).resolve().parents[1]
PROJECT_ROOT = PRIVATE_ROOT.parent
MANIFEST_PATH = (
    PRIVATE_ROOT
    / "manifests"
    / "miri_dataset_manifest_v1.json"
)
CENSUS_PATH = (
    PRIVATE_ROOT
    / "manifests"
    / "oracle_census_v1.json"
)
DATASET_ROOT = PROJECT_ROOT / "miri_official_tests" / "fail"

def _features(source: str) -> dict:
    function_names = re.findall(
        r"(?m)^\s*(?:pub(?:\([^)]*\))?\s+)?(?:unsafe\s+)?fn\s+"
        r"([A-Za-z_][A-Za-z0-9_]*)\s*\(",
        source,
    )
    non_main = [name for name in function_names if name != "main"]
    return {
        "top_level_function_count_approx": len(function_names),
        "non_main_function_count_approx": len(non_main),
        "non_main_functions_approx": non_main[:20],
        "assertion_count": len(re.findall(r"\bassert(?:_eq|_ne)?!\s*\(", source)),
        "has_stdout": bool(re.search(r"\b(?:print|println|dbg)!\s*\(", source)),
        "has_explicit_contract_comment": bool(
            re.search(
                r"(?i)\b(?:must return|will return|assert|should return|"
                r"expected|preserve|same value|copy)\b",
                source,
            )
        ),
    }


def _n_reason(case: dict, features: dict) -> str:
    category = case["category"]
    if category in {"data_race", "concurrency", "weak_memory"}:
        return "concurrency_or_memory_model_diagnostic_without_frozen_functional_contract"
    directives = case["directives"]
    if directives["only_targets"] or directives["ignore_targets"]:
        return "platform_specific_diagnostic_without_selected_independent_oracle"
    if features["non_main_function_count_approx"] == 0:
        return "diagnostic_trigger_only_no_independently_callable_contract"
    return "no_high_confidence_well_defined_contract_selected_in_conservative_census"


def build_census() -> dict:
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    entries: list[dict] = []
    for case in manifest["cases"]:
        source = (DATASET_ROOT / case["rel_path"]).read_text(encoding="utf-8")
        features = _features(source)
        oracle = case["oracle"]
        if oracle["level"] == "P":
            reason = (
                "source_grounded_callable_type_or_local_invariant_on_well_"
                "defined_inputs_but_whole_UB_entrypoint_remains_partial"
            )
            confidence = "high"
        else:
            reason = _n_reason(case, features)
            confidence = "conservative"
        entries.append(
            {
                "case_id": case["case_id"],
                "category": case["category"],
                "rel_path": case["rel_path"],
                "source_sha256": case["sha256"],
                "oracle_level": oracle["level"],
                "confidence": confidence,
                "reason": reason,
                "selection_batch": oracle["selection_batch"],
                "implementation_status": oracle["status"],
                "features": features,
            }
        )
    observed_counts = Counter(entry["oracle_level"] for entry in entries)
    counts = {level: observed_counts.get(level, 0) for level in ("E", "P", "N")}
    batches = Counter(
        entry["selection_batch"]
        for entry in entries
        if entry["selection_batch"] is not None
    )
    return {
        "schema_version": 1,
        "census_id": "miri_oracle_census_v1",
        "generated_on": "2026-07-30",
        "manifest_id": manifest["manifest_id"],
        "total_cases": len(entries),
        "policy": {
            "E": (
                "Complete independently executable behavior oracle for the "
                "whole benchmark case. No raw Miri fail case met this bar in "
                "the conservative first census."
            ),
            "P": (
                "High-confidence executable oracle for one or more original "
                "callable contracts, type/layout properties, or explicit "
                "local invariants on well-defined inputs; the deliberately "
                "UB entrypoint remains only partially specified."
            ),
            "N": (
                "No high-confidence independent functional oracle selected. "
                "N means absent in this conservative census, not a proof that "
                "no future source-grounded oracle can ever be constructed."
            ),
            "no_semantics_for_ub_inputs": True,
            "private_signature_is_benchmark_contract": True,
        },
        "summary": {
            "level_counts": counts,
            "selection_batch_counts": dict(sorted(batches.items())),
        },
        "cases": entries,
    }


def _serialize(data: dict) -> str:
    return json.dumps(data, ensure_ascii=False, indent=2) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    data = build_census()
    if data["total_cases"] != 423:
        print(f"error: census has {data['total_cases']} cases, expected 423", file=sys.stderr)
        return 2
    content = _serialize(data)
    if args.check:
        if not CENSUS_PATH.is_file() or CENSUS_PATH.read_text(encoding="utf-8") != content:
            print("error: checked-in census differs from regenerated census", file=sys.stderr)
            return 1
        print(
            f"census OK: {data['total_cases']} cases "
            f"{data['summary']['level_counts']}"
        )
        return 0
    CENSUS_PATH.parent.mkdir(parents=True, exist_ok=True)
    CENSUS_PATH.write_text(content, encoding="utf-8")
    print(
        f"wrote {CENSUS_PATH}: {data['summary']['level_counts']} "
        f"batches={data['summary']['selection_batch_counts']}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
