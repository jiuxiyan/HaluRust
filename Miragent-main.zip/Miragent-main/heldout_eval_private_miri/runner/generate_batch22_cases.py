#!/usr/bin/env python3
"""Materialize batch 22: final high-confidence Tree Borrows and validity cases."""

from __future__ import annotations

from generate_batch2_cases import DEFAULT, mutation, write_case
from generate_batch6_cases import main_case
from generate_batch21_cases import EVIDENCE, TREE, WILD, wildcard_case


P = mutation("fn main(){", 'fn main(){panic!("main");', "Rejects the valid repaired entry.")


def s(case_id, path, contract, reference, muts, symbols=None, profiles=None, tests=None, evidence=EVIDENCE):
    if tests is None:
        tests = (
            "#[test]fn repaired_entry_completes(){main();}"
            "#[test]fn repeats(){for _ in 0..7{main();}}"
            "#[test]fn independent_valid_domain(){main();}"
        )
    return main_case(
        case_id, path, contract, symbols or [], profiles or TREE,
        evidence, reference, tests, muts + [P],
    )


SPECS = [
    s(
        "tree_borrows__reservedim_spurious_write",
        "tree_borrows/reservedim_spurious_write.rs",
        "Under a sequential schedule, the explicit writes 42, 64, and 13 occur in order and leave data=13.",
        "fn inner(x:&mut u8){*x=42;assert_eq!(*x,42);*x=64;assert_eq!(*x,64)}fn main(){let mut data=0u8;inner(&mut data);data=13;assert_eq!(data,13);}",
        [mutation("*x=42", "*x=41", "Changes the first write."), mutation("*x=64", "*x=63", "Changes the spurious write."), mutation("data=13", "data=12", "Changes the final write.")],
        symbols=["inner"],
        profiles=[("tree-deterministic", ["-Zmiri-tree-borrows", "-Zmiri-deterministic-concurrency"])],
    ),
    s(
        "tree_borrows__spurious_read",
        "tree_borrows/spurious_read.rs",
        "retagx_retagy_retx_writey_rety performs the explicit write 2 through one live owner and completes.",
        "fn retagx_retagy_retx_writey_rety(){let mut data=0u8;let y=&mut data;*y=2;assert_eq!(data,2);}fn main(){retagx_retagy_retx_writey_rety();}",
        [mutation("*y=2", "*y=3", "Changes the write."), mutation("data,2", "data,3", "Claims the wrong result."), mutation("let mut data=0u8", 'panic!("data");let mut data=0u8', "Rejects the valid allocation.")],
        symbols=["retagx_retagy_retx_writey_rety"],
        profiles=[("tree-deterministic", ["-Zmiri-tree-borrows", "-Zmiri-deterministic-concurrency"])],
    ),
    s(
        "tree_borrows__wildcard__dealloc",
        "tree_borrows/wildcard/dealloc.rs",
        "A zeroed u32 allocation is written to 14 and deallocated once through the original live allocation pointer.",
        "use std::alloc::{Layout,alloc_zeroed,dealloc};fn main(){unsafe{let l=Layout::new::<u32>();let p=alloc_zeroed(l)as*mut u32;assert!(!p.is_null());p.write(14);assert_eq!(p.read(),14);dealloc(p.cast(),l);}}",
        [mutation("write(14)", "write(13)", "Changes the write."), mutation("read(),14", "read(),13", "Claims the wrong value."), mutation("dealloc(p.cast(),l)", "dealloc(p.add(1).cast(),l)", "Deallocates through the wrong pointer.")],
        profiles=WILD,
    ),
    s(
        "tree_borrows__wildcard__gc",
        "tree_borrows/wildcard/gc.rs",
        "The live u32 changes from 4 to 5 and is read as 5 through a current pointer.",
        "fn main(){let mut x=4u32;assert_eq!(x,4);let p=&mut x as*mut u32;unsafe{p.write(5)};assert_eq!(unsafe{p.read()},5);assert_eq!(x,5);}",
        [mutation("x=4u32", "x=3u32", "Changes the input."), mutation("write(5)", "write(6)", "Changes the write."), mutation("x,5", "x,6", "Claims the wrong result.")],
        profiles=WILD,
    ),
    wildcard_case("tree_borrows__wildcard__multi_exposed_siblings_unique_writer", "tree_borrows/wildcard/multi_exposed_siblings_unique_writer.rs", [13], 13),
    wildcard_case("tree_borrows__wildcard__protected_wildcard", "tree_borrows/wildcard/protected_wildcard.rs", [13], 13),
    wildcard_case("tree_borrows__wildcard__protector_conflicted", "tree_borrows/wildcard/protector_conflicted.rs", [4], 4),
    s(
        "tree_borrows__wildcard__protector_release",
        "tree_borrows/wildcard/protector_release.rs",
        "A live UnsafeCell<[u32;2]> updates element 0 from 32 to 41 while element 1 remains 33.",
        "use std::cell::UnsafeCell;fn main(){let x=UnsafeCell::new([32u32,33]);unsafe{(*x.get())[0]=41;assert_eq!(*x.get(),[41,33]);}}",
        [mutation("[32u32,33]", "[32u32,34]", "Changes the untouched element."), mutation("[0]=41", "[0]=40", "Changes the write."), mutation("[41,33]", "[40,33]", "Claims the wrong result.")],
        profiles=WILD,
    ),
    s(
        "tree_borrows__wildcard__protector_release2",
        "tree_borrows/wildcard/protector_release2.rs",
        "A live UnsafeCell<[u32;2]> updates element 0 from 32 to 41 while element 1 remains 33.",
        "use std::cell::UnsafeCell;fn main(){let x=UnsafeCell::new([32u32,33]);unsafe{(*x.get())[0]=41;assert_eq!(*x.get(),[41,33]);}}",
        [mutation("[32u32,33]", "[32u32,34]", "Changes the untouched element."), mutation("[0]=41", "[0]=40", "Changes the write."), mutation("[41,33]", "[40,33]", "Claims the wrong result.")],
        profiles=WILD,
    ),
    wildcard_case("tree_borrows__wildcard__single_exposed_disable", "tree_borrows/wildcard/single_exposed_disable.rs", [13], 13),
    wildcard_case("tree_borrows__wildcard__single_exposed_foreign", "tree_borrows/wildcard/single_exposed_foreign.rs", [13], 13),
    wildcard_case("tree_borrows__wildcard__single_exposed_local", "tree_borrows/wildcard/single_exposed_local.rs", [41, 0], 0),
    wildcard_case("tree_borrows__wildcard__single_exposed_only_ro", "tree_borrows/wildcard/single_exposed_only_ro.rs", [0], 0),
    wildcard_case("tree_borrows__wildcard__subtree_internal_relatedness", "tree_borrows/wildcard/subtree_internal_relatedness.rs", [13], 13),
    wildcard_case("tree_borrows__wildcard__subtree_internal_relatedness_wildcard", "tree_borrows/wildcard/subtree_internal_relatedness_wildcard.rs", [13], 13),
    s(
        "validity__cast_fn_ptr_invalid_callee_ret",
        "validity/cast_fn_ptr_invalid_callee_ret.rs",
        "The original f returns a valid NonZero<u32> equal to 1 through a matching function pointer.",
        "use std::num::NonZeroU32;fn f()->NonZeroU32{NonZeroU32::new(1).unwrap()}fn main(){let g:fn()->NonZeroU32=f;assert_eq!(g().get(),1);}",
        [mutation("new(1)", "new(2)", "Changes the return value."), mutation("get(),1", "get(),2", "Claims the wrong result."), mutation("=f", '=||panic!("call")', "Rejects the matching call.")],
        symbols=["f"],
        profiles=DEFAULT,
    ),
    s(
        "validity__cast_fn_ptr_invalid_caller_arg",
        "validity/cast_fn_ptr_invalid_caller_arg.rs",
        "call invokes a genuine fn(NonZero<u32>) with value 1; the wrapper forwards 1 to original f(u32).",
        "use std::{num::NonZeroU32,sync::atomic::{AtomicU32,Ordering}};static SEEN:AtomicU32=AtomicU32::new(0);fn f(c:u32){SEEN.store(c,Ordering::SeqCst)}fn wrapper(c:NonZeroU32){f(c.get())}fn call(g:fn(NonZeroU32)){g(NonZeroU32::new(1).unwrap())}fn main(){SEEN.store(0,Ordering::SeqCst);call(wrapper);assert_eq!(SEEN.load(Ordering::SeqCst),1);}",
        [mutation("new(1)", "new(2)", "Changes the valid argument."), mutation("SeqCst),1", "SeqCst),2", "Claims the wrong forwarded value."), mutation("fn call(g:fn(NonZeroU32))", "fn call(g:fn(NonZeroU32)){panic!(\"call\")}fn unused(g:fn(NonZeroU32))", "Rejects call.")],
        symbols=["f", "call"],
        profiles=DEFAULT,
    ),
    s(
        "validity__cast_fn_ptr_invalid_caller_ret",
        "validity/cast_fn_ptr_invalid_caller_ret.rs",
        "A matching fn()->*const i32 returns a non-null pointer to live static X=42 before a shared reference is formed.",
        "static X:i32=42;fn f()->*const i32{&X}fn main(){let g:fn()->*const i32=f;let p=g();assert!(!p.is_null());assert_eq!(unsafe{*p},42);}",
        [mutation("X:i32=42", "X:i32=41", "Changes the pointee."), mutation("*p},42", "*p},41", "Claims the wrong pointee."), mutation("fn f()->*const i32{&X}", "fn f()->*const i32{std::ptr::null()}", "Returns null.")],
        symbols=["f"],
        profiles=[("official-permissive", ["-Zmiri-permissive-provenance"]), ("default-strict", [])],
    ),
]


def main() -> None:
    for item in SPECS:
        write_case(item)
    print(f"wrote {len(SPECS)} batch-22 cases")


if __name__ == "__main__":
    main()
