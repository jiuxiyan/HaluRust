#!/usr/bin/env python3
"""Audit the final private oracle suite against its frozen metadata."""

from __future__ import annotations

import hashlib
import json
from collections import Counter
from pathlib import Path

try:
    import tomllib
except ModuleNotFoundError:
    import tomli as tomllib


PRIVATE = Path(__file__).resolve().parents[1]
ROOT = PRIVATE.parent
CASES = PRIVATE / "cases"
MANIFEST = PRIVATE / "manifests" / "miri_dataset_manifest_v1.json"
CENSUS = PRIVATE / "manifests" / "oracle_census_v1.json"
VALIDATION = PRIVATE / "manifests" / "oracle_validation_summary_v1.json"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    census = json.loads(CENSUS.read_text(encoding="utf-8"))
    validation = json.loads(VALIDATION.read_text(encoding="utf-8"))
    manifest_by_id = {item["case_id"]: item for item in manifest["cases"]}
    census_by_id = {item["case_id"]: item for item in census["cases"]}
    p_ids = {case_id for case_id, item in census_by_id.items() if item["oracle_level"] == "P"}
    n_ids = set(census_by_id) - p_ids
    case_ids = {path.name for path in CASES.iterdir() if path.is_dir()}

    errors: list[str] = []
    if len(manifest_by_id) != 423 or len(census_by_id) != 423:
        errors.append("manifest and census must each contain 423 unique cases")
    dataset = manifest["dataset"]
    excluded_ids = set(dataset.get("excluded_case_ids", []))
    if dataset.get("canonical_candidate_count") != 438:
        errors.append("canonical candidate pool must contain 438 cases")
    if dataset.get("runnable_case_count") != 423:
        errors.append("frozen oracle-backed dataset must contain 423 cases")
    if len(excluded_ids) != 15 or excluded_ids & set(manifest_by_id):
        errors.append(
            "exactly 15 excluded candidates must be disjoint from the dataset"
        )
    if len(manifest_by_id) + len(excluded_ids) != 438:
        errors.append("dataset and exclusions must reconstruct 438 candidates")
    if census.get("manifest_id") != manifest.get("manifest_id"):
        errors.append("census manifest_id differs from the frozen manifest")
    if validation.get("manifest_id") != manifest.get("manifest_id"):
        errors.append("validation manifest_id differs from the frozen manifest")
    if case_ids != p_ids:
        errors.append(
            f"case directories differ from P census: missing={sorted(p_ids-case_ids)} "
            f"extra={sorted(case_ids-p_ids)}"
        )

    tests_total = 0
    mutants_total = 0
    batch_counts: Counter[str] = Counter()
    for case_id in sorted(case_ids):
        case_dir = CASES / case_id
        required = {"case.toml", "reference_fix.rs", "semantic_tests.rs", "oracle.md"}
        missing = [name for name in sorted(required) if not (case_dir / name).is_file()]
        if missing:
            errors.append(f"{case_id}: missing {missing}")
            continue
        config = tomllib.loads((case_dir / "case.toml").read_text(encoding="utf-8"))
        tests = (case_dir / "semantic_tests.rs").read_text(encoding="utf-8")
        manifest_case = manifest_by_id[case_id]
        census_case = census_by_id[case_id]
        actual_tests = tests.count("#[test]")
        mutants = config.get("oracle_validation", {}).get("mutants", [])
        if config.get("case_id") != case_id or config.get("oracle_level") != "P":
            errors.append(f"{case_id}: invalid identity/oracle level in case.toml")
        if config.get("source_relpath") != manifest_case["rel_path"]:
            errors.append(f"{case_id}: source path differs from frozen manifest")
        if config.get("source_sha256") != manifest_case["sha256"]:
            errors.append(f"{case_id}: source hash differs from frozen manifest")
        if config.get("test_count") != actual_tests:
            errors.append(f"{case_id}: test_count metadata {config.get('test_count')} != {actual_tests}")
        if len(mutants) != 4 or any(item.get("expected") != "fail" for item in mutants):
            errors.append(f"{case_id}: expected exactly four expected-fail mutants")
        if not config.get("profiles"):
            errors.append(f"{case_id}: no Miri profiles declared")
        if sha256(case_dir / "semantic_tests.rs") == sha256(case_dir / "reference_fix.rs"):
            errors.append(f"{case_id}: tests and reference unexpectedly identical")
        tests_total += actual_tests
        mutants_total += len(mutants)
        batch_counts[census_case["selection_batch"]] += 1

    totals = validation["totals"]
    expected = {
        "oracle_cases": len(p_ids),
        "references_passed": len(p_ids),
        "mutants_total": mutants_total,
        "mutants_killed": mutants_total,
        "heldout_tests": tests_total,
    }
    if totals != expected:
        errors.append(f"validation totals {totals} != suite totals {expected}")
    recorded_batches = {name: item["cases"] for name, item in validation["batches"].items()}
    if recorded_batches != dict(sorted(batch_counts.items())):
        errors.append(
            f"validation batch counts {recorded_batches} != census {dict(sorted(batch_counts.items()))}"
        )
    if n_ids:
        errors.append(
            f"the frozen oracle-backed dataset must not contain N cases: "
            f"{sorted(n_ids)}"
        )

    if errors:
        for error in errors:
            print(f"error: {error}")
        return 1
    print(
        f"suite audit OK: dataset=423 P={len(p_ids)} N={len(n_ids)} "
        f"tests={tests_total} mutants={mutants_total} batches={len(batch_counts)}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
