#!/usr/bin/env python3
"""Materialize batch 14: synchronized versions of data-race effects."""

from __future__ import annotations

from generate_batch2_cases import mutation, write_case
from generate_batch6_cases import main_case


PROFILES = [
    ("official-deterministic", ["-Zmiri-deterministic-concurrency", "-Zmiri-disable-stacked-borrows"]),
    ("default-strict", []),
]
LOCAL_PROFILES = [
    ("official-deterministic", ["-Zmiri-deterministic-concurrency"]),
    ("default-strict", []),
]
EVIL = "#[derive(Copy,Clone)]struct EvilSend<T>(pub T);unsafe impl<T>Send for EvilSend<T>{}unsafe impl<T>Sync for EvilSend<T>{}"


def s(case_id, contract, reference, tests, muts, profiles=PROFILES, symbols=None):
    return main_case(
        case_id, case_id.replace("data_race__", "data_race/") + ".rs",
        contract, symbols or [], profiles,
        "The source explicitly identifies the intended read/write/allocation effect and the missing happens-before edge; the oracle preserves the effect while ordering it with join, atomics, or a scoped lifetime.",
        reference, tests, muts,
    )


def basic_tests(extra: str) -> str:
    return (
        "#[test]fn repaired_entry_completes(){main();}"
        "#[test]fn repaired_entry_repeats(){for _ in 0..5{main();}}"
        f"#[test]fn independent_ordered_effect(){{{extra}}}"
    )


P = mutation("fn main(){", "fn main(){panic!(\"main\");", "Panics after synchronization.")


SPECS = [
    s("data_race__alloc_read_race","An allocated MaybeUninit<usize> is initialized to 42 before it is read and deallocated.",
      EVIL+"fn main(){let p=Box::into_raw(Box::new(std::mem::MaybeUninit::new(42usize)));let v=unsafe{(*p).assume_init()};assert_eq!(v,42);unsafe{drop(Box::from_raw(p))}}",
      basic_tests("let b=Box::new(7usize);assert_eq!(*b,7);"),
      [mutation("new(42usize)","new(41usize)","Changes initialized value."),mutation("v,42","v,41","Wrong read."),mutation("drop(Box::from_raw(p))","panic!(\"leak\")","Does not deallocate."),P],symbols=["EvilSend"]),
    s("data_race__alloc_write_race","An allocated MaybeUninit<usize> is written with 2 before it is read and deallocated.",
      EVIL+"fn main(){let p=Box::into_raw(Box::<usize>::new_uninit());unsafe{p.write(std::mem::MaybeUninit::new(2));assert_eq!((*p).assume_init(),2);drop(Box::from_raw(p));}}",
      basic_tests("let mut b=Box::new(0usize);*b=2;assert_eq!(*b,2);"),
      [mutation("new(2)","new(3)","Changes write."),mutation("assume_init(),2","assume_init(),3","Wrong read."),mutation("drop(Box::from_raw(p));","","Leaks allocation."),P],symbols=["EvilSend"]),
    s("data_race__atomic_read_na_write_race1","An AtomicUsize store of 32 happens before a SeqCst load that observes 32.",
      EVIL+"use std::sync::atomic::{AtomicUsize,Ordering};fn main(){let a=AtomicUsize::new(0);a.store(32,Ordering::SeqCst);assert_eq!(a.load(Ordering::SeqCst),32);}",
      basic_tests("let a=std::sync::atomic::AtomicUsize::new(0);a.store(7,std::sync::atomic::Ordering::SeqCst);assert_eq!(a.load(std::sync::atomic::Ordering::SeqCst),7);"),
      [mutation("store(32","store(31","Changes store."),mutation("),32",") ,31","Wrong load."),mutation("a.store(32,Ordering::SeqCst);","","Drops store."),P],symbols=["EvilSend"]),
    s("data_race__atomic_read_na_write_race2","The initial atomic load observes 0, followed by an ordered store of 32.",
      EVIL+"use std::sync::atomic::{AtomicUsize,Ordering};fn main(){let a=AtomicUsize::new(0);assert_eq!(a.load(Ordering::SeqCst),0);a.store(32,Ordering::SeqCst);assert_eq!(a.load(Ordering::SeqCst),32);}",
      basic_tests("let a=std::sync::atomic::AtomicUsize::new(0);assert_eq!(a.load(std::sync::atomic::Ordering::SeqCst),0);"),
      [mutation("new(0)","new(1)","Changes initial value."),mutation("store(32","store(31","Changes store."),mutation("),32",") ,31","Wrong final load."),P],symbols=["EvilSend"]),
    s("data_race__atomic_write_na_read_race1","A SeqCst store of 32 precedes and is observed by a later atomic load.",
      EVIL+"use std::sync::atomic::{AtomicUsize,Ordering};fn main(){let a=AtomicUsize::new(0);a.store(32,Ordering::SeqCst);let v=a.load(Ordering::SeqCst);assert_eq!(v,32);}",
      basic_tests("let a=std::sync::atomic::AtomicUsize::new(1);assert_eq!(a.load(std::sync::atomic::Ordering::SeqCst),1);"),
      [mutation("store(32","store(31","Changes store."),mutation("v,32","v,31","Wrong observation."),mutation("let v=a.load","let v=0;let _=a.load","Drops observation."),P],symbols=["EvilSend"]),
    s("data_race__atomic_write_na_read_race2","An initial atomic load observes 0 before a SeqCst store updates the value to 32.",
      EVIL+"use std::sync::atomic::{AtomicUsize,Ordering};fn main(){let a=AtomicUsize::new(0);assert_eq!(a.load(Ordering::SeqCst),0);a.store(32,Ordering::SeqCst);assert_eq!(a.load(Ordering::SeqCst),32);}",
      basic_tests("let a=std::sync::atomic::AtomicUsize::new(0);a.store(9,std::sync::atomic::Ordering::SeqCst);assert_eq!(a.load(std::sync::atomic::Ordering::SeqCst),9);"),
      [mutation("new(0)","new(1)","Changes initial value."),mutation("store(32","store(31","Changes store."),mutation("),32",") ,31","Wrong final load."),P],symbols=["EvilSend"]),
    s("data_race__atomic_write_na_write_race1","Ordered atomic stores of 32 then 64 leave the value 64.",
      EVIL+"use std::sync::atomic::{AtomicUsize,Ordering};fn main(){let a=AtomicUsize::new(0);a.store(32,Ordering::SeqCst);a.store(64,Ordering::SeqCst);assert_eq!(a.load(Ordering::SeqCst),64);}",
      basic_tests("let a=std::sync::atomic::AtomicUsize::new(0);a.store(1,std::sync::atomic::Ordering::SeqCst);a.store(2,std::sync::atomic::Ordering::SeqCst);assert_eq!(a.load(std::sync::atomic::Ordering::SeqCst),2);"),
      [mutation("store(64","store(63","Changes final store."),mutation("),64",") ,63","Wrong result."),mutation("a.store(64,Ordering::SeqCst);","","Drops final store."),P],symbols=["EvilSend"]),
    s("data_race__atomic_write_na_write_race2","Ordered atomic stores of 64 then 32 leave the value 32.",
      EVIL+"use std::sync::atomic::{AtomicUsize,Ordering};fn main(){let a=AtomicUsize::new(0);a.store(64,Ordering::SeqCst);a.store(32,Ordering::SeqCst);assert_eq!(a.load(Ordering::SeqCst),32);}",
      basic_tests("let a=std::sync::atomic::AtomicUsize::new(0);a.store(2,std::sync::atomic::Ordering::SeqCst);a.store(1,std::sync::atomic::Ordering::SeqCst);assert_eq!(a.load(std::sync::atomic::Ordering::SeqCst),1);"),
      [mutation("store(32","store(31","Changes final store."),mutation("),32",") ,31","Wrong result."),mutation("a.store(32,Ordering::SeqCst);","","Drops final store."),P],symbols=["EvilSend"]),
]


def two_writes(case_id):
    return s(
        case_id, "Joining each writer establishes order: the first stores 32 and the second stores 64, leaving 64.",
        EVIL+"use std::sync::{Arc,atomic::{AtomicU32,Ordering}};fn main(){let a=Arc::new(AtomicU32::new(0));let b=a.clone();std::thread::spawn(move||b.store(32,Ordering::SeqCst)).join().unwrap();let b=a.clone();std::thread::spawn(move||b.store(64,Ordering::SeqCst)).join().unwrap();assert_eq!(a.load(Ordering::SeqCst),64);}",
        basic_tests("let a=std::sync::atomic::AtomicU32::new(0);a.store(32,std::sync::atomic::Ordering::SeqCst);a.store(64,std::sync::atomic::Ordering::SeqCst);assert_eq!(a.load(std::sync::atomic::Ordering::SeqCst),64);"),
        [mutation("store(64","store(63","Changes second write."),mutation("),64",") ,63","Wrong result."),mutation("std::thread::spawn(move||b.store(64,Ordering::SeqCst)).join().unwrap();","","Drops second write."),P],
        symbols=["EvilSend"],
    )


SPECS += [
    two_writes("data_race__dangling_thread_async_race"),
    two_writes("data_race__dangling_thread_race"),
    s("data_race__dealloc_read_race_stack","The stack value remains live through its read and is dropped only afterward.",
      EVIL+"fn main(){let stack_var=7usize;let v=stack_var;assert_eq!(v,7);drop(stack_var);}",
      basic_tests("let x=9usize;assert_eq!(x,9);"),
      [mutation("stack_var=7","stack_var=6","Changes value."),mutation("v,7","v,6","Wrong read."),mutation("let v=stack_var","let v=0","Drops read."),P],symbols=["EvilSend"]),
    s("data_race__dealloc_write_race_stack","The stack value is updated to 3 while live and dropped only after the write is observed.",
      EVIL+"fn main(){let mut stack_var=0usize;stack_var=3;assert_eq!(stack_var,3);drop(stack_var);}",
      basic_tests("let mut x=0usize;x=9;assert_eq!(x,9);"),
      [mutation("stack_var=3","stack_var=2","Changes write."),mutation("stack_var,3","stack_var,2","Wrong read."),mutation("stack_var=3;","","Drops write."),P],symbols=["EvilSend"]),
    s("data_race__enable_after_join_to_main","After four joined setup threads, two joined atomic writers deterministically leave 64.",
      EVIL+"use std::sync::{Arc,atomic::{AtomicU32,Ordering}};fn main(){let ts:Vec<_>=(0..4).map(|_|std::thread::spawn(||())).collect();for t in ts{t.join().unwrap()}let a=Arc::new(AtomicU32::new(0));let b=a.clone();std::thread::spawn(move||b.store(32,Ordering::SeqCst)).join().unwrap();let b=a.clone();std::thread::spawn(move||b.store(64,Ordering::SeqCst)).join().unwrap();assert_eq!(a.load(Ordering::SeqCst),64);}",
      basic_tests("for _ in 0..4{std::thread::spawn(||()).join().unwrap();}"),
      [mutation("store(64","store(63","Changes final write."),mutation("),64",") ,63","Wrong result."),mutation("for t in ts{t.join().unwrap()}","panic!(\"setup\")","Rejects joined setup."),P],symbols=["EvilSend"]),
    s("data_race__fence_after_load","Joining the producer orders its store of 1; the main thread then stores and observes 2.",
      "use std::sync::{Arc,atomic::{AtomicU32,Ordering,fence}};fn main(){let v=Arc::new(AtomicU32::new(0));let w=v.clone();std::thread::spawn(move||w.store(1,Ordering::SeqCst)).join().unwrap();fence(Ordering::SeqCst);assert_eq!(v.load(Ordering::Relaxed),1);v.store(2,Ordering::SeqCst);assert_eq!(v.load(Ordering::SeqCst),2);}",
      basic_tests("let a=std::sync::atomic::AtomicU32::new(0);a.store(1,std::sync::atomic::Ordering::Release);assert_eq!(a.load(std::sync::atomic::Ordering::Acquire),1);"),
      [mutation("store(1","store(3","Changes producer."),mutation("store(2","store(3","Changes final write."),mutation("),2",") ,3","Wrong result."),P]),
    s("data_race__local_variable_read_race","A joined atomic writer stores 127 before the main thread reads it.", 
      "use std::sync::{Arc,atomic::{AtomicU8,Ordering}};fn main(){let v=Arc::new(AtomicU8::new(0));let w=v.clone();std::thread::spawn(move||w.store(127,Ordering::Release)).join().unwrap();assert_eq!(v.load(Ordering::Acquire),127);}",
      basic_tests("let a=std::sync::atomic::AtomicU8::new(0);a.store(127,std::sync::atomic::Ordering::Release);assert_eq!(a.load(std::sync::atomic::Ordering::Acquire),127);"),
      [mutation("store(127","store(126","Changes write."),mutation("),127",") ,126","Wrong read."),mutation("std::thread::spawn(move||w.store(127,Ordering::Release)).join().unwrap();","","Drops writer."),P],LOCAL_PROFILES),
    s("data_race__local_variable_write_race","A joined atomic writer updates the initialized value from 0 to 127.", 
      "use std::sync::{Arc,atomic::{AtomicU8,Ordering}};fn main(){let v=Arc::new(AtomicU8::new(0));let w=v.clone();std::thread::spawn(move||w.store(127,Ordering::Release)).join().unwrap();assert_eq!(v.load(Ordering::Acquire),127);}",
      basic_tests("let a=std::sync::atomic::AtomicU8::new(0);a.store(127,std::sync::atomic::Ordering::Release);assert_eq!(a.load(std::sync::atomic::Ordering::Acquire),127);"),
      [mutation("store(127","store(126","Changes write."),mutation("),127",") ,126","Wrong read."),mutation("std::thread::spawn(move||w.store(127,Ordering::Release)).join().unwrap();","","Drops writer."),P],LOCAL_PROFILES),
    s("data_race__mixed_size_read_write_read","A full-width AtomicI32 compare_exchange updates 0 to 1 and a later full-width load observes 1.",
      "use std::sync::atomic::{AtomicI32,Ordering};fn main(){let d=AtomicI32::new(0);assert_eq!(d.compare_exchange(0,1,Ordering::Relaxed,Ordering::Relaxed),Ok(0));assert_eq!(d.load(Ordering::Relaxed),1);}",
      basic_tests("let a=std::sync::atomic::AtomicI32::new(0);a.store(1,std::sync::atomic::Ordering::Relaxed);assert_eq!(a.load(std::sync::atomic::Ordering::Relaxed),1);"),
      [mutation("compare_exchange(0,1","compare_exchange(0,2","Changes write."),mutation("),1",") ,2","Wrong result."),mutation("Ok(0)","Err(0)","Wrong exchange outcome."),P],LOCAL_PROFILES),
    s("data_race__read_write_race","An ordered atomic read observes 0 before an ordered store leaves 64.",
      EVIL+"use std::sync::atomic::{AtomicU32,Ordering};fn main(){let a=AtomicU32::new(0);assert_eq!(a.load(Ordering::SeqCst),0);a.store(64,Ordering::SeqCst);assert_eq!(a.load(Ordering::SeqCst),64);}",
      basic_tests("let a=std::sync::atomic::AtomicU32::new(0);a.store(7,std::sync::atomic::Ordering::SeqCst);assert_eq!(a.load(std::sync::atomic::Ordering::SeqCst),7);"),
      [mutation("store(64","store(63","Changes write."),mutation("),64",") ,63","Wrong result."),mutation("new(0)","new(1)","Changes initial read."),P],symbols=["EvilSend"]),
    s("data_race__read_write_race_stack","A live stack-backed value is written to 3 before the ordered read observes 3.",
      EVIL+"fn main(){let mut stack_var=0usize;stack_var=3;let v=stack_var;assert_eq!(v,3);}",
      basic_tests("let mut x=0usize;x=3;assert_eq!(x,3);"),
      [mutation("stack_var=3","stack_var=2","Changes write."),mutation("v,3","v,2","Wrong read."),mutation("let v=stack_var","let v=0","Drops read."),P],symbols=["EvilSend"]),
    s("data_race__relax_acquire_race","A Release store followed by an Acquire load after join publishes data value 1.",
      EVIL+"use std::sync::{Arc,atomic::{AtomicU32,Ordering}};fn main(){let data=Arc::new(AtomicU32::new(0));let sync=Arc::new(AtomicU32::new(0));let(d,s)=(data.clone(),sync.clone());std::thread::spawn(move||{d.store(1,Ordering::Relaxed);s.store(1,Ordering::Release)}).join().unwrap();assert_eq!(sync.load(Ordering::Acquire),1);assert_eq!(data.load(Ordering::Relaxed),1);}",
      basic_tests("let a=std::sync::atomic::AtomicU32::new(0);a.store(1,std::sync::atomic::Ordering::Release);assert_eq!(a.load(std::sync::atomic::Ordering::Acquire),1);"),
      [mutation("d.store(1","d.store(2","Changes data."),mutation("data.load(Ordering::Relaxed),1","data.load(Ordering::Relaxed),2","Wrong data."),mutation("s.store(1","s.store(2","Changes signal."),P],symbols=["EvilSend"]),
]


def main() -> None:
    for item in SPECS:
        write_case(item)
    print(f"wrote {len(SPECS)} batch-14 cases")


if __name__ == "__main__":
    main()
