#!/usr/bin/env python3
"""Materialize the reviewed second batch of 20 partial semantic oracles."""

from __future__ import annotations

import hashlib
import json
import textwrap
from pathlib import Path


PRIVATE_ROOT = Path(__file__).resolve().parents[1]
ROOT = PRIVATE_ROOT.parent
CASES = PRIVATE_ROOT / "cases"
DATASET = ROOT / "miri_official_tests" / "fail"


def d(text: str) -> str:
    return textwrap.dedent(text).strip() + "\n"


def q(value: str) -> str:
    return json.dumps(value, ensure_ascii=False)


def mutation(find: str, replace: str, reason: str) -> dict:
    return {"find": find, "replace": replace, "reason": reason}


def write_case(spec: dict) -> None:
    case_dir = CASES / spec["id"]
    case_dir.mkdir(parents=True, exist_ok=True)
    source = (DATASET / spec["path"]).read_bytes()
    source_hash = hashlib.sha256(source).hexdigest()
    tests = d(spec["tests"])
    reference = d(spec["reference"])
    test_count = tests.count("#[test]")
    check_count = tests.count("assert")

    lines = [
        "version = 1",
        f"case_id = {q(spec['id'])}",
        f"source_relpath = {q(spec['path'])}",
        f"source_sha256 = {q(source_hash)}",
        'oracle_level = "P"',
        f"contract_summary = {q(spec['contract'])}",
        "protected_symbols = [" + ", ".join(q(x) for x in spec["symbols"]) + "]",
        f"test_count = {test_count}",
        f"check_count = {check_count}",
        'toolchain = "nightly"',
        f"timeout_seconds = {spec.get('timeout', 180)}",
        "",
    ]
    for name, flags in spec["profiles"]:
        lines.extend(
            [
                "[[profiles]]",
                f"name = {q(name)}",
                "flags = [" + ", ".join(q(flag) for flag in flags) + "]",
                "",
            ]
        )
    lines.extend(["[oracle_validation]", 'reference_fix = "reference_fix.rs"', ""])
    for index, item in enumerate(spec["mutations"], 1):
        lines.extend(
            [
                "[[oracle_validation.mutants]]",
                f'name = "m{index}"',
                'expected = "fail"',
                f"reason = {q(item['reason'])}",
                f"find = {q(item['find'])}",
                f"replace = {q(item['replace'])}",
                "",
            ]
        )
    (case_dir / "case.toml").write_text("\n".join(lines), encoding="utf-8")
    (case_dir / "semantic_tests.rs").write_text(tests, encoding="utf-8")
    (case_dir / "reference_fix.rs").write_text(reference, encoding="utf-8")
    partial_reason = spec.get(
        "partial_reason",
        (
            "The original `main` deliberately enters undefined behavior to exercise\n"
            "Miri. The held-out suite tests only the named helper/method on\n"
            "well-defined inputs and requires the repaired entry point to complete.\n"
            "The private callable signature is treated as a benchmark-level contract;\n"
            "this is not a complete whole-program equivalence claim."
        ),
    )
    oracle = d(
        f"""
        # Oracle: `{spec['id']}`

        ## Evidence and protected contract

        {spec['evidence']}

        Protected contract: {spec['contract']}

        ## Why this is Partial

        {partial_reason}
        """
    )
    (case_dir / "oracle.md").write_text(oracle, encoding="utf-8")


STACK_TREE = [("stacked-borrows", []), ("tree-borrows", ["-Zmiri-tree-borrows"])]
DEFAULT = [("default-strict", [])]
TREE = [("tree-borrows", ["-Zmiri-tree-borrows"])]
ALL_ALIAS = STACK_TREE + [("no-alias-model", ["-Zmiri-disable-stacked-borrows"])]
WEAK_STRICT = [
    ("official-weakened", ["-Zmiri-disable-validation", "-Zmiri-disable-stacked-borrows"]),
    ("default-strict", []),
]


SPECS = [
    {
        "id": "both_borrows__shr_frozen_violation1",
        "path": "both_borrows/shr_frozen_violation1.rs",
        "contract": "foo writes 5 through its mutable argument and returns 5.",
        "symbols": ["foo"],
        "profiles": STACK_TREE,
        "evidence": "The source assigns `*x = 5` and annotates the return with `must return 5`.",
        "tests": """
            #[test] fn repaired_entry_completes() { main(); }
            #[test] fn writes_and_returns_five() {
                for initial in [i32::MIN, -1, 0, 9, i32::MAX] {
                    let mut value = initial;
                    assert_eq!(foo(&mut value), 5);
                    assert_eq!(value, 5);
                }
            }
            #[test] fn repeated_calls_are_stable() {
                let mut value = 99;
                for _ in 0..6 { assert_eq!(foo(&mut value), 5); assert_eq!(value, 5); }
            }
        """,
        "reference": """
            fn foo(x: &mut i32) -> i32 { *x = 5; unknown_code(x); *x }
            fn unknown_code(_x: &i32) {}
            fn main() { let mut x = 0; assert_eq!(foo(&mut x), 5); }
        """,
        "mutations": [
            mutation("*x = 5", "*x = 4", "Wrong stored value."),
            mutation("unknown_code(x); *x", "unknown_code(x); 0", "Constant return."),
            mutation("*x = 5; unknown_code", "unknown_code", "Drops the required write."),
            mutation("unknown_code(x); *x", "unknown_code(x); *x + 1", "Off-by-one return."),
        ],
    },
    {
        "id": "both_borrows__mut_exclusive_violation1",
        "path": "both_borrows/mut_exclusive_violation1.rs",
        "contract": "demo_mut_advanced_unique stores 5 in the caller's integer and returns 5.",
        "symbols": ["demo_mut_advanced_unique"],
        "profiles": STACK_TREE,
        "evidence": "The source reasserts uniqueness with `*our = 5` and states `We know this will return 5`.",
        "tests": """
            #[test] fn repaired_entry_completes() { main(); }
            #[test] fn stores_and_returns_five() {
                for initial in [i32::MIN, -10, 0, 42, i32::MAX] {
                    let mut value = initial;
                    assert_eq!(demo_mut_advanced_unique(&mut value), 5);
                    assert_eq!(value, 5);
                }
            }
            #[test] fn repeated_calls_do_not_use_a_stale_leak() {
                let mut value = 1;
                for _ in 0..6 { assert_eq!(demo_mut_advanced_unique(&mut value), 5); assert_eq!(value, 5); }
            }
        """,
        "reference": """
            use std::ptr;
            static mut LEAK: *mut i32 = ptr::null_mut();
            fn demo_mut_advanced_unique(our: &mut i32) -> i32 {
                unknown_code_1(our); *our = 5; unknown_code_2(); *our
            }
            fn unknown_code_1(x: &i32) { unsafe { LEAK = x as *const _ as *mut _; } }
            fn unknown_code_2() {}
            fn main() { let mut x = 0; assert_eq!(demo_mut_advanced_unique(&mut x), 5); }
        """,
        "mutations": [
            mutation("*our = 5", "*our = 4", "Wrong stored value."),
            mutation("unknown_code_2(); *our", "unknown_code_2(); 7", "Wrong return."),
            mutation("unknown_code_1(our); *our = 5;", "unknown_code_1(our);", "Drops the write."),
            mutation("unknown_code_2(); *our", "unknown_code_2(); *our + 1", "Off-by-one return."),
        ],
    },
    {
        "id": "both_borrows__aliasing_mut2",
        "path": "both_borrows/aliasing_mut2.rs",
        "contract": "On distinct legal references safe preserves x and writes 2 to y.",
        "symbols": ["safe"],
        "profiles": STACK_TREE,
        "evidence": "The helper reads `x` and explicitly assigns `*y = 2`.",
        "tests": """
            fn run(x: i32, y: i32) -> (i32, i32) { let x=x; let mut y=y; safe(&x,&mut y); (x,y) }
            #[test] fn repaired_entry_completes() { main(); }
            #[test] fn preserves_x_and_sets_y() {
                for pair in [(0,0),(-7,99),(i32::MIN,i32::MAX)] {
                    assert_eq!(run(pair.0,pair.1), (pair.0,2));
                }
            }
            #[test] fn repeated_calls_are_independent() {
                for i in -4..5 { assert_eq!(run(i, i*10), (i,2)); }
            }
        """,
        "reference": """
            fn safe(x: &i32, y: &mut i32) { let _v = *x; *y = 2; }
            fn main() { let x=0; let mut y=0; safe(&x,&mut y); assert_eq!(y,2); }
        """,
        "mutations": [
            mutation("*y = 2", "*y = 3", "Wrong target value."),
            mutation("let _v = *x; *y = 2;", "let _v = *x;", "Drops the write."),
            mutation("*y = 2", "*y = *x", "Copies x instead of writing 2."),
            mutation("*y = 2", "*y = 0", "Trivializes output to zero."),
        ],
    },
    {
        "id": "both_borrows__aliasing_mut3",
        "path": "both_borrows/aliasing_mut3.rs",
        "contract": "On distinct legal references safe writes 1 to x and preserves y.",
        "symbols": ["safe"],
        "profiles": STACK_TREE,
        "evidence": "The helper explicitly assigns `*x = 1` and only reads `y`.",
        "tests": """
            fn run(x: i32, y: i32) -> (i32, i32) { let mut x=x; let y=y; safe(&mut x,&y); (x,y) }
            #[test] fn repaired_entry_completes() { main(); }
            #[test] fn sets_x_and_preserves_y() {
                for pair in [(0,0),(-7,99),(i32::MIN,i32::MAX)] {
                    assert_eq!(run(pair.0,pair.1), (1,pair.1));
                }
            }
            #[test] fn repeated_calls_are_independent() {
                for i in -4..5 { assert_eq!(run(i, i*10), (1,i*10)); }
            }
        """,
        "reference": """
            fn safe(x: &mut i32, y: &i32) { *x = 1; let _v = *y; }
            fn main() { let mut x=0; let y=0; safe(&mut x,&y); assert_eq!(x,1); }
        """,
        "mutations": [
            mutation("*x = 1", "*x = 2", "Wrong target value."),
            mutation("*x = 1; let _v = *y;", "let _v = *y;", "Drops the write."),
            mutation("*x = 1", "*x = *y", "Copies y instead of writing 1."),
            mutation("*x = 1", "*x = 0", "Trivializes output to zero."),
        ],
    },
    {
        "id": "stacked_borrows__return_invalid_mut",
        "path": "stacked_borrows/return_invalid_mut.rs",
        "contract": "foo returns a mutable reference to the second tuple field without changing either field.",
        "symbols": ["foo"],
        "profiles": STACK_TREE,
        "evidence": "The source implementation returns `&mut x.1`; the fault is caused later by an invalid aliasing access.",
        "tests": """
            #[test] fn repaired_entry_completes() { main(); }
            #[test] fn selects_only_the_second_field() {
                for pair in [(0,0),(-7,9),(i32::MIN,i32::MAX)] {
                    let mut value=pair; assert_eq!(*foo(&mut value), pair.1);
                    *foo(&mut value)=17; assert_eq!(value,(pair.0,17));
                }
            }
            #[test] fn repeated_borrows_remain_local() {
                let mut value=(4,5); for n in 0..8 { *foo(&mut value)=n; assert_eq!(value,(4,n)); }
            }
        """,
        "reference": """
            fn foo(x: &mut (i32, i32)) -> &mut i32 { &mut x.1 }
            fn main() { let mut x=(1,2); *foo(&mut x)=3; assert_eq!(x,(1,3)); }
        """,
        "mutations": [
            mutation("&mut x.1", "&mut x.0", "Selects the wrong tuple field."),
            mutation("{ &mut x.1 }", "{ x.1=0; &mut x.1 }", "Adds an observable mutation before returning."),
            mutation("{ &mut x.1 }", "{ x.0=0; &mut x.1 }", "Corrupts the unselected field."),
            mutation("{ &mut x.1 }", "{ x.1=x.1.wrapping_add(1); &mut x.1 }", "Changes the selected value."),
        ],
    },
    {
        "id": "stacked_borrows__return_invalid_mut_tuple",
        "path": "stacked_borrows/return_invalid_mut_tuple.rs",
        "contract": "foo returns a one-tuple containing a mutable reference to the second field, without other mutation.",
        "symbols": ["foo"],
        "profiles": STACK_TREE,
        "evidence": "The source return expression is `(&mut x.1,)`; the later caller action is the UB trigger.",
        "tests": """
            #[test] fn repaired_entry_completes() { main(); }
            #[test] fn tuple_wraps_the_second_field() {
                for pair in [(0,0),(-7,9),(i32::MIN,i32::MAX)] {
                    let mut value=pair; let (r,)=foo(&mut value); assert_eq!(*r,pair.1); *r=23;
                    assert_eq!(value,(pair.0,23));
                }
            }
            #[test] fn repeated_calls_preserve_first() {
                let mut value=(8,1); for n in -3..4 { let (r,)=foo(&mut value); *r=n; assert_eq!(value,(8,n)); }
            }
        """,
        "reference": """
            fn foo(x: &mut (i32, i32)) -> (&mut i32,) { (&mut x.1,) }
            fn main() { let mut x=(1,2); let (r,)=foo(&mut x); *r=3; assert_eq!(x,(1,3)); }
        """,
        "mutations": [
            mutation("(&mut x.1,)", "(&mut x.0,)", "Selects the wrong tuple field."),
            mutation("{ (&mut x.1,) }", "{ x.1=0; (&mut x.1,) }", "Adds an observable mutation."),
            mutation("{ (&mut x.1,) }", "{ x.0=0; (&mut x.1,) }", "Corrupts the unselected field."),
            mutation("{ (&mut x.1,) }", "{ x.1=x.1.wrapping_add(1); (&mut x.1,) }", "Changes the selected value."),
        ],
    },
    {
        "id": "tree_borrows__return_invalid_mut",
        "path": "tree_borrows/return_invalid_mut.rs",
        "contract": "foo returns a mutable reference to the second tuple field without changing the tuple.",
        "symbols": ["foo"],
        "profiles": TREE,
        "evidence": "The tree-borrows fixture directly returns `&mut x.1`; its original caller introduces the invalid access.",
        "tests": """
            #[test] fn repaired_entry_completes() { main(); }
            #[test] fn selects_second_field() {
                for pair in [(0,0),(-7,9),(i32::MIN,i32::MAX)] {
                    let mut value=pair; assert_eq!(*foo(&mut value),pair.1); *foo(&mut value)=-11;
                    assert_eq!(value,(pair.0,-11));
                }
            }
            #[test] fn writes_through_returned_reference() {
                let mut value=(99,0); for n in 0..7 { *foo(&mut value)=n; assert_eq!(value,(99,n)); }
            }
        """,
        "reference": """
            fn foo(x: &mut (i32, i32)) -> &mut i32 { &mut x.1 }
            fn main() { let mut x=(1,2); *foo(&mut x)=3; assert_eq!(x,(1,3)); }
        """,
        "mutations": [
            mutation("&mut x.1", "&mut x.0", "Selects the wrong tuple field."),
            mutation("{ &mut x.1 }", "{ x.1=0; &mut x.1 }", "Adds an observable mutation."),
            mutation("{ &mut x.1 }", "{ x.0=0; &mut x.1 }", "Corrupts the first field."),
            mutation("{ &mut x.1 }", "{ x.1=x.1.wrapping_sub(1); &mut x.1 }", "Changes the second field."),
        ],
    },
    {
        "id": "tree_borrows__write-during-2phase",
        "path": "tree_borrows/write-during-2phase.rs",
        "contract": "Foo::add returns self.0 + n for tested non-overflowing values and does not mutate self.",
        "symbols": ["Foo", "Foo::add"],
        "profiles": TREE,
        "evidence": "The method body is the pure expression `self.0 + n`; UB in the fixture comes from an external aliasing write.",
        "tests": """
            #[test] fn repaired_entry_completes() { main(); }
            #[test] fn adds_without_mutating_receiver() {
                for (a,b) in [(0,0),(1,2),(9,7),(u64::MAX-20,19)] {
                    let mut value=Foo(a); assert_eq!(value.add(b),a+b); assert_eq!(value.0,a);
                }
            }
            #[test] fn repeated_calls_are_pure() {
                let mut value=Foo(40); for n in 0..10 { assert_eq!(value.add(n),40+n); assert_eq!(value.0,40); }
            }
        """,
        "reference": """
            struct Foo(u64);
            impl Foo { fn add(&mut self, n: u64) -> u64 { self.0 + n } }
            fn main() { let mut value=Foo(2); assert_eq!(value.add(3),5); assert_eq!(value.0,2); }
        """,
        "mutations": [
            mutation("self.0 + n", "self.0", "Ignores the argument."),
            mutation("self.0 + n", "n", "Ignores the receiver."),
            mutation("self.0 + n", "self.0.saturating_sub(n)", "Uses subtraction."),
            mutation("self.0 + n", "self.0 + n + 1", "Adds an off-by-one error."),
        ],
    },
    {
        "id": "dangling_pointers__dangling_pointer_to_raw_pointer",
        "path": "dangling_pointers/dangling_pointer_to_raw_pointer.rs",
        "contract": "direct_raw and via_ref return a raw pointer to field 0 of a live tuple passed by pointer.",
        "symbols": ["direct_raw", "via_ref"],
        "profiles": STACK_TREE,
        "evidence": "Both source helpers project `.0`; the original failure dereferences their results only after the allocation dies.",
        "tests": """
            #[test] fn repaired_entry_completes() { main(); }
            #[test] fn both_paths_select_field_zero() {
                for pair in [(0,1),(-7,99),(i32::MIN,i32::MAX)] {
                    let value=pair; let base=&value as *const (i32,i32); let expected=std::ptr::addr_of!(value.0);
                    for got in [direct_raw(base),via_ref(base)] { assert_eq!(got,expected); unsafe { assert_eq!(*got,pair.0); } }
                    assert_eq!(value,pair);
                }
            }
            #[test] fn results_follow_each_allocation() {
                let a=(4,5); let b=(6,7); assert_ne!(direct_raw(&a),direct_raw(&b));
                unsafe { assert_eq!(*via_ref(&a),4); assert_eq!(*via_ref(&b),6); }
            }
        """,
        "reference": """
            fn direct_raw(x: *const (i32,i32)) -> *const i32 { unsafe { std::ptr::addr_of!((*x).0) } }
            fn via_ref(x: *const (i32,i32)) -> *const i32 { unsafe { &(*x).0 as *const i32 } }
            fn main() { let value=(1,2); unsafe { assert_eq!(*direct_raw(&value),1); assert_eq!(*via_ref(&value),1); } }
        """,
        "mutations": [
            mutation("addr_of!((*x).0)", "addr_of!((*x).1)", "direct_raw selects field 1."),
            mutation("&(*x).0 as *const i32", "&(*x).1 as *const i32", "via_ref selects field 1."),
            mutation("unsafe { &(*x).0 as *const i32 }", "{ std::ptr::null() }", "via_ref returns null."),
            mutation("unsafe { std::ptr::addr_of!((*x).0) }", "{ std::ptr::null() }", "direct_raw returns null."),
        ],
    },
    {
        "id": "unaligned_pointers__field_requires_parent_struct_alignment",
        "path": "unaligned_pointers/field_requires_parent_struct_alignment.rs",
        "contract": "foo reads and returns x from a properly aligned S pointer.",
        "symbols": ["S", "foo"],
        "profiles": DEFAULT,
        "evidence": "The helper expression is `(*x).x`; the original failure intentionally supplies a pointer misaligned for S.",
        "tests": """
            #[test] fn repaired_entry_completes() { main(); }
            #[test] fn reads_x_from_aligned_structs() {
                for x in [0u8,1,127,255] { let value=S{x,y:0x11223344}; assert_eq!(foo(&value),x); assert_eq!(value.y,0x11223344); }
            }
            #[test] fn ignores_neighboring_y() {
                for y in [0u32,1,u32::MAX] { let value=S{x:77,y}; assert_eq!(foo(&value),77); }
            }
        """,
        "reference": """
            struct S { x: u8, y: u32 }
            fn foo(x: *const S) -> u8 { unsafe { (*x).x } }
            fn main() { let value=S{x:7,y:9}; assert_eq!(foo(&value),7); }
        """,
        "mutations": [
            mutation("unsafe { (*x).x }", "{ 0 }", "Returns a constant."),
            mutation("unsafe { (*x).x }", "unsafe { (*x).y as u8 }", "Reads the neighboring field."),
            mutation("unsafe { (*x).x }", "unsafe { (*x).x.wrapping_add(1) }", "Off-by-one read."),
            mutation("unsafe { (*x).x }", "{ 255 }", "Returns a high constant."),
        ],
    },
    {
        "id": "unaligned_pointers__field_requires_parent_struct_alignment2",
        "path": "unaligned_pointers/field_requires_parent_struct_alignment2.rs",
        "contract": "foo reads nested packed.x from a properly aligned Aligned pointer.",
        "symbols": ["Aligned", "Packed", "foo"],
        "profiles": DEFAULT,
        "evidence": "The source projects `(*x).packed.x`; the failing entry point constructs a pointer with insufficient parent alignment.",
        "tests": """
            #[test] fn repaired_entry_completes() { main(); }
            #[test] fn reads_nested_x() {
                for x in [0u8,1,127,255] {
                    let value=Aligned{_pad:[3;11],packed:Packed{_pad:[4;5],x}}; assert_eq!(foo(&value),x);
                }
            }
            #[test] fn ignores_parent_padding() {
                for pad in [[0;11],[1;11],[255;11]] {
                    let value=Aligned{_pad:pad,packed:Packed{_pad:[7;5],x:61}}; assert_eq!(foo(&value),61);
                }
            }
        """,
        "reference": """
            #[repr(C,align(16))] #[derive(Default,Copy,Clone)] struct Aligned { _pad:[u8;11], packed:Packed }
            #[repr(C,packed)] #[derive(Default,Copy,Clone)] struct Packed { _pad:[u8;5], x:u8 }
            fn foo(x: *const Aligned) -> u8 { unsafe { (*x).packed.x } }
            fn main() { let value=Aligned::default(); assert_eq!(foo(&value),0); }
        """,
        "mutations": [
            mutation("unsafe { (*x).packed.x }", "{ 0 }", "Returns a constant."),
            mutation("unsafe { (*x).packed.x }", "unsafe { (*x)._pad[0] }", "Reads parent padding."),
            mutation("unsafe { (*x).packed.x }", "unsafe { (*x).packed.x.wrapping_add(1) }", "Off-by-one read."),
            mutation("unsafe { (*x).packed.x }", "{ 255 }", "Returns a high constant."),
        ],
    },
    {
        "id": "function_calls__return_pointer_aliasing_read",
        "path": "function_calls/return_pointer_aliasing_read.rs",
        "contract": "myfun may read a valid i32 pointer, returns 13, and leaves the pointee unchanged.",
        "symbols": ["myfun"],
        "profiles": ALL_ALIAS,
        "evidence": "The source callee performs `ptr.read()` and returns the literal 13; the fixture's UB depends on caller alias state.",
        "tests": """
            #[test] fn repaired_entry_completes() { main(); }
            #[test] fn returns_thirteen_without_writing() {
                for initial in [i32::MIN,-1,0,42,i32::MAX] { let mut value=initial; assert_eq!(myfun(&mut value),13); assert_eq!(value,initial); }
            }
            #[test] fn repeated_reads_are_stable() {
                let mut value=77; for _ in 0..8 { assert_eq!(myfun(&mut value),13); assert_eq!(value,77); }
            }
        """,
        "reference": """
            fn myfun(ptr: *mut i32) -> i32 { unsafe { ptr.read(); } 13 }
            fn main() { let mut value=5; assert_eq!(myfun(&mut value),13); assert_eq!(value,5); }
        """,
        "mutations": [
            mutation("unsafe { ptr.read(); } 13", "unsafe { ptr.write(0); } 13", "Writes instead of only reading."),
            mutation("unsafe { ptr.read(); } 13", "unsafe { ptr.read() }", "Returns the pointee instead of 13."),
            mutation("unsafe { ptr.read(); } 13", "unsafe { ptr.read(); } 12", "Returns the wrong constant."),
            mutation("unsafe { ptr.read(); } 13", "unsafe { ptr.read(); } 0", "Trivializes the return."),
        ],
    },
    {
        "id": "function_calls__return_pointer_aliasing_write",
        "path": "function_calls/return_pointer_aliasing_write.rs",
        "contract": "myfun writes 0 through a valid i32 pointer and returns 13.",
        "symbols": ["myfun"],
        "profiles": STACK_TREE,
        "evidence": "The source callee executes `ptr.write(0)` and then returns 13.",
        "tests": """
            #[test] fn repaired_entry_completes() { main(); }
            #[test] fn writes_zero_and_returns_thirteen() {
                for initial in [i32::MIN,-1,0,42,i32::MAX] { let mut value=initial; assert_eq!(myfun(&mut value),13); assert_eq!(value,0); }
            }
            #[test] fn repeated_calls_are_idempotent() {
                let mut value=77; for _ in 0..8 { assert_eq!(myfun(&mut value),13); assert_eq!(value,0); }
            }
        """,
        "reference": """
            fn myfun(ptr: *mut i32) -> i32 { unsafe { ptr.write(0); } 13 }
            fn main() { let mut value=5; assert_eq!(myfun(&mut value),13); assert_eq!(value,0); }
        """,
        "mutations": [
            mutation("unsafe { ptr.write(0); } 13", "13", "Drops the required write."),
            mutation("unsafe { ptr.write(0); } 13", "unsafe { ptr.write(1); } 13", "Writes the wrong value."),
            mutation("unsafe { ptr.write(0); } 13", "unsafe { ptr.write(0); } 12", "Returns the wrong value."),
            mutation("unsafe { ptr.write(0); } 13", "unsafe { ptr.write(13); } 13", "Confuses stored and returned values."),
        ],
    },
    {
        "id": "function_calls__return_pointer_aliasing_write_tail_call",
        "path": "function_calls/return_pointer_aliasing_write_tail_call.rs",
        "contract": "myfun delegates to myfun2; both write 0 through a valid pointer and return 13.",
        "symbols": ["myfun", "myfun2"],
        "profiles": STACK_TREE,
        "evidence": "The fixture separates the write/return behavior into a tail-position call to `myfun2`.",
        "tests": """
            #[test] fn repaired_entry_completes() { main(); }
            #[test] fn both_entry_points_write_zero_and_return_thirteen() {
                for initial in [-9,0,51] {
                    let mut a=initial; assert_eq!(myfun(&mut a),13); assert_eq!(a,0);
                    let mut b=initial; assert_eq!(myfun2(&mut b),13); assert_eq!(b,0);
                }
            }
            #[test] fn repeated_delegation_is_stable() {
                let mut value=88; for _ in 0..6 { value=88; assert_eq!(myfun(&mut value),13); assert_eq!(value,0); }
            }
        """,
        "reference": """
            fn myfun(ptr: *mut i32) -> i32 { myfun2(ptr) }
            fn myfun2(ptr: *mut i32) -> i32 { unsafe { ptr.write(0); } 13 }
            fn main() { let mut value=5; assert_eq!(myfun(&mut value),13); assert_eq!(value,0); }
        """,
        "mutations": [
            mutation("{ myfun2(ptr) }", "{ let _=ptr; 13 }", "Bypasses delegation and its write."),
            mutation("unsafe { ptr.write(0); } 13", "13", "Drops the write in myfun2."),
            mutation("unsafe { ptr.write(0); } 13", "unsafe { ptr.write(1); } 13", "Writes the wrong value."),
            mutation("unsafe { ptr.write(0); } 13", "unsafe { ptr.write(0); } 12", "Returns the wrong value."),
        ],
    },
    {
        "id": "function_calls__arg_inplace_mutate",
        "path": "function_calls/arg_inplace_mutate.rs",
        "contract": "callee accepts the by-value witness S(42), then stores S(0) through a distinct valid pointer.",
        "symbols": ["S", "callee"],
        "profiles": STACK_TREE,
        "evidence": "The source callee checks the by-value argument and assigns `S(0)` through the raw pointer.",
        "tests": """
            #[test] fn repaired_entry_completes() { main(); }
            #[test] fn overwrites_distinct_targets_with_zero() {
                for initial in [i32::MIN,-1,0,17,i32::MAX] { let mut target=S(initial); callee(S(42),&mut target); assert_eq!(target.0,0); }
            }
            #[test] fn independent_calls_do_not_share_state() {
                let mut a=S(8); let mut b=S(9); callee(S(42),&mut a); callee(S(42),&mut b); assert_eq!((a.0,b.0),(0,0));
            }
        """,
        "reference": """
            struct S(i32);
            fn callee(x: S, ptr: *mut S) { unsafe { ptr.write(S(0)); } assert_eq!(x.0,42); }
            fn main() { let mut target=S(7); callee(S(42),&mut target); assert_eq!(target.0,0); }
        """,
        "mutations": [
            mutation("unsafe { ptr.write(S(0)); }", "unsafe { ptr.write(S(1)); }", "Stores the wrong value."),
            mutation("unsafe { ptr.write(S(0)); }", "{}", "Drops the store."),
            mutation("unsafe { ptr.write(S(0)); }", "unsafe { ptr.write(S(x.0)); }", "Stores the witness instead."),
            mutation("unsafe { ptr.write(S(0)); }", "unsafe { ptr.write(S(-1)); }", "Stores a sentinel instead."),
        ],
    },
    {
        "id": "overlapping_assignment",
        "path": "overlapping_assignment.rs",
        "contract": "self_copy copies all four i32 elements between valid distinct mutable array pointers and preserves the source.",
        "symbols": ["self_copy"],
        "profiles": DEFAULT,
        "evidence": "The fixture's assignment is a whole-array copy; its original UB comes specifically from overlapping pointers.",
        "tests": """
            #[test] fn repaired_entry_completes() { main(); }
            #[test] fn copies_distinct_arrays_exactly() {
                for mut source in [[0,0,0,0],[1,2,3,4],[i32::MIN,-1,1,i32::MAX]] {
                    let before=source; let mut dest=[9,8,7,6]; self_copy(&mut dest,&mut source);
                    assert_eq!(dest,before); assert_eq!(source,before);
                }
            }
            #[test] fn repeated_copies_track_latest_source() {
                let mut dest=[0;4]; let mut a=[4,3,2,1]; let mut b=[-4,-3,-2,-1];
                self_copy(&mut dest,&mut a); assert_eq!(dest,a); self_copy(&mut dest,&mut b); assert_eq!(dest,b);
            }
        """,
        "reference": """
            fn self_copy(ptr1: *mut [i32;4], ptr2: *mut [i32;4]) { unsafe { *ptr1=*ptr2; } }
            fn main() { let mut source=[1,2,3,4]; let mut dest=[0;4]; self_copy(&mut dest,&mut source); assert_eq!(dest,source); }
        """,
        "mutations": [
            mutation("unsafe { *ptr1=*ptr2; }", "{}", "Drops the copy."),
            mutation("unsafe { *ptr1=*ptr2; }", "unsafe { *ptr1=[0;4]; }", "Writes a constant array."),
            mutation("unsafe { *ptr1=*ptr2; }", "unsafe { *(ptr2 as *mut [i32;4])=*ptr1; }", "Copies in the wrong direction."),
            mutation("unsafe { *ptr1=*ptr2; }", "unsafe { (*ptr1)[0]=(*ptr2)[0]; }", "Copies only the first element."),
        ],
    },
    {
        "id": "coroutine-pinned-moved",
        "path": "coroutine-pinned-moved.rs",
        "contract": "A pinned CoroutineIteratorAdapter(firstn()) returns Some(0) and then None without being moved.",
        "symbols": ["firstn", "CoroutineIteratorAdapter", "Iterator::next"],
        "profiles": WEAK_STRICT,
        "evidence": "The source coroutine starts at zero and yields it once; the original failure moves the already-pinned coroutine before resuming it.",
        "tests": """
            #[test] fn repaired_entry_completes() { main(); }
            #[test] fn one_item_sequence_is_exact() {
                let mut it=Box::new(CoroutineIteratorAdapter(firstn()));
                assert_eq!(it.next(),Some(0)); assert_eq!(it.next(),None);
            }
            #[test] fn independent_adapters_start_at_zero() {
                for _ in 0..4 { let mut it=Box::new(CoroutineIteratorAdapter(firstn())); assert_eq!(it.next(),Some(0)); assert_eq!(it.next(),None); }
            }
        """,
        "reference": """
            #![feature(coroutines, coroutine_trait, stmt_expr_attributes)]
            use std::ops::{Coroutine,CoroutineState}; use std::pin::Pin;
            fn firstn() -> impl Coroutine<Yield=u64,Return=()> {
                #[coroutine] static move || { let mut num=0; let num=&mut num; *num+=0; yield *num; *num+=1; }
            }
            struct CoroutineIteratorAdapter<G>(G);
            impl<G: Coroutine<Return=()>> Iterator for CoroutineIteratorAdapter<G> {
                type Item=G::Yield;
                fn next(&mut self)->Option<Self::Item>{ let me=unsafe{Pin::new_unchecked(&mut self.0)}; match me.resume(()) { CoroutineState::Yielded(x)=>Some(x), CoroutineState::Complete(())=>None } }
            }
            fn main(){ let mut it=Box::new(CoroutineIteratorAdapter(firstn())); assert_eq!(it.next(),Some(0)); assert_eq!(it.next(),None); }
        """,
        "mutations": [
            mutation("let mut num=0", "let mut num=1", "Starts at the wrong value."),
            mutation("yield *num", "yield *num+1", "Yields an off-by-one value."),
            mutation("CoroutineState::Yielded(x)=>Some(x)", "CoroutineState::Yielded(x)=>Some(x+1)", "Adapter changes yielded values."),
            mutation("CoroutineState::Complete(())=>None", "CoroutineState::Complete(())=>Some(99)", "Exhausted iterator produces an item."),
        ],
    },
    {
        "id": "dyn-upcast-trait-mismatch",
        "path": "dyn-upcast-trait-mismatch.rs",
        "contract": "Valid i32 Baz/Bar/Foo trait objects dispatch a=100, b=200, c=300 and the default z=11, y=12, w=21.",
        "symbols": ["Foo", "Bar", "Baz"],
        "profiles": WEAK_STRICT,
        "evidence": "Each source impl returns a distinct constant, making the intended dynamic-dispatch mapping explicit.",
        "tests": """
            #[test] fn repaired_entry_completes() { main(); }
            #[test] fn dynamic_dispatch_preserves_each_slot() {
                let x=0i32; let baz:&dyn Baz=&x;
                assert_eq!((baz.a(),baz.z(),baz.y(),baz.b(),baz.w(),baz.c()),(100,11,12,200,21,300));
            }
            #[test] fn direct_dispatch_matches_trait_objects() {
                let x=7i32; assert_eq!((Foo::a(&x),Foo::z(&x),Foo::y(&x)),(100,11,12));
                assert_eq!((Bar::b(&x),Bar::w(&x),Baz::c(&x)),(200,21,300));
            }
        """,
        "reference": """
            trait Foo:PartialEq<i32>+std::fmt::Debug+Send+Sync{fn a(&self)->i32{10} fn z(&self)->i32{11} fn y(&self)->i32{12}}
            trait Bar:Foo{fn b(&self)->i32{20} fn w(&self)->i32{21}}
            trait Baz:Bar{fn c(&self)->i32{30}}
            impl Foo for i32{fn a(&self)->i32{100}} impl Bar for i32{fn b(&self)->i32{200}} impl Baz for i32{fn c(&self)->i32{300}}
            fn main(){let x=0; let baz:&dyn Baz=&x; assert_eq!((baz.a(),baz.z(),baz.y(),baz.b(),baz.w(),baz.c()),(100,11,12,200,21,300));}
        """,
        "mutations": [
            mutation("fn a(&self)->i32{100}", "fn a(&self)->i32{101}", "Changes A's dispatch result."),
            mutation("fn b(&self)->i32{200}", "fn b(&self)->i32{201}", "Changes B's dispatch result."),
            mutation("fn z(&self)->i32{11}", "fn z(&self)->i32{12}", "Aliases default z with y."),
            mutation("fn w(&self)->i32{21}", "fn w(&self)->i32{20}", "Changes default w."),
        ],
    },
    {
        "id": "intrinsics__ptr_metadata_uninit_slice_len",
        "path": "intrinsics/ptr_metadata_uninit_slice_len.rs",
        "contract": "deref_meta returns the length metadata loaded from a valid pointer to an initialized i32 slice pointer.",
        "symbols": ["deref_meta"],
        "profiles": WEAK_STRICT,
        "evidence": "The fixture observes slice metadata length; its failure comes from uninitialized metadata, excluded by the private valid-input domain.",
        "tests": """
            #[test] fn repaired_entry_completes() { main(); }
            #[test] fn reports_valid_slice_lengths() {
                let data=[10i32,20,30,40,50]; for len in 0..=data.len() {
                    let slice_ptr:*const [i32]=&data[..len]; assert_eq!(unsafe{deref_meta(&slice_ptr)},len);
                }
            }
            #[test] fn length_is_independent_of_contents() {
                let a=[0i32;3]; let b=[255i32;3]; let pa:*const [i32]=&a; let pb:*const [i32]=&b;
                assert_eq!(unsafe{deref_meta(&pa)},3); assert_eq!(unsafe{deref_meta(&pb)},3);
            }
        """,
        "reference": """
            #![feature(ptr_metadata)]
            unsafe fn deref_meta(p: *const *const [i32]) -> usize { unsafe { std::ptr::metadata(*p) } }
            fn main(){ let data=[1i32,2,3]; let p:*const [i32]=&data; assert_eq!(unsafe{deref_meta(&p)},3); }
        """,
        "mutations": [
            mutation("unsafe { std::ptr::metadata(*p) }", "{ 0 }", "Returns a constant zero."),
            mutation("unsafe { std::ptr::metadata(*p) }", "{ 1 }", "Returns a constant one."),
            mutation("unsafe { std::ptr::metadata(*p) }", "unsafe { std::ptr::metadata(*p)+1 }", "Reports an off-by-one length."),
            mutation("unsafe { std::ptr::metadata(*p) }", "unsafe { std::ptr::metadata(*p).saturating_sub(1) }", "Under-reports nonempty slices."),
        ],
    },
    {
        "id": "validity__wrong-dyn-trait-assoc-type",
        "path": "validity/wrong-dyn-trait-assoc-type.rs",
        "contract": "For Copy values, Trait::foo returns a copy of self with Assoc equal to the implementing type.",
        "symbols": ["Trait", "Trait::foo"],
        "profiles": WEAK_STRICT,
        "evidence": "The blanket implementation sets `type Output = T` and returns `*self`; the original failure forges incompatible trait-object metadata.",
        "tests": """
            #[test] fn repaired_entry_completes() { main(); }
            #[test] fn blanket_impl_preserves_values() {
                assert_eq!(Trait::foo(&0u8),0); assert_eq!(Trait::foo(&255u8),255);
                assert_eq!(Trait::foo(&-17i32),-17); assert_eq!(Trait::foo(&'λ'),'λ'); assert_eq!(Trait::foo(&true),true);
                #[derive(Copy,Clone,Debug,PartialEq)] struct NoDefault(u8);
                assert_eq!(Trait::foo(&NoDefault(9)),NoDefault(9));
            }
            #[test] fn valid_trait_objects_dispatch_with_matching_output() {
                let x=41i32; let obj:&dyn Trait<Assoc=i32>=&x; assert_eq!(obj.foo(),41);
                let c='x'; let obj:&dyn Trait<Assoc=char>=&c; assert_eq!(obj.foo(),'x');
            }
        """,
        "reference": """
            trait Trait { type Assoc; fn foo(&self)->Self::Assoc; }
            impl<T: Copy> Trait for T { type Assoc=T; fn foo(&self)->T { *self } }
            fn main(){ let x=42i32; let obj:&dyn Trait<Assoc=i32>=&x; assert_eq!(obj.foo(),42); }
        """,
        "mutations": [
            mutation("fn foo(&self)->T { *self }", "fn foo(&self)->T { unsafe { std::mem::zeroed() } }", "Returns a zeroed value."),
            mutation("impl<T: Copy> Trait for T", "impl<T: Copy + Default> Trait for T", "Incorrectly narrows the blanket domain."),
            mutation("type Assoc=T", "type Assoc=()", "Breaks the associated output mapping."),
            mutation("fn foo(&self)->T { *self }", "fn foo(&self)->T { let _=self; panic!() }", "Panics instead of copying."),
        ],
    },
]


def main() -> None:
    for spec in SPECS:
        write_case(spec)
    print(f"wrote {len(SPECS)} batch-2 cases")


if __name__ == "__main__":
    main()
