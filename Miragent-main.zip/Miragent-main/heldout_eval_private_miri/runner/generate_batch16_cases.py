#!/usr/bin/env python3
"""Materialize batch 16: matched allocator protocols and aligned accesses."""

from __future__ import annotations

from generate_batch2_cases import DEFAULT, mutation, write_case
from generate_batch6_cases import main_case


NO_ALIAS = [
    ("official-no-validation-no-stacked", ["-Zmiri-disable-validation", "-Zmiri-disable-stacked-borrows"]),
    ("default-strict", []),
]
NO_STACK = [
    ("official-no-stacked", ["-Zmiri-disable-stacked-borrows"]),
    ("default-strict", []),
]
SYMBOLIC = [
    ("official-symbolic", ["-Zmiri-symbolic-alignment-check"]),
    ("default-strict", []),
]
PERMISSIVE_SYMBOLIC = [
    ("official-symbolic-permissive", ["-Zmiri-symbolic-alignment-check", "-Zmiri-permissive-provenance"]),
    ("default-strict", []),
]


def c(case_id, path, contract, symbols, profiles, evidence, reference, tests, muts):
    return main_case(case_id, path, contract, symbols, profiles, evidence, reference, tests, muts)


def entry_tests(extra: str) -> str:
    return (
        "#[test]fn repaired_entry_completes(){main();}"
        "#[test]fn repeated_entries(){for _ in 0..5{main();}}"
        f"#[test]fn independent_valid_domain(){{{extra}}}"
    )


P = mutation("fn main(){", 'fn main(){panic!("main");', "Rejects the valid repaired entry.")
ALLOC_EVIDENCE = (
    "The source makes the allocation layout and operation order explicit. "
    "The oracle keeps that operation in its well-defined domain by matching layouts, "
    "using only the live pointer, and releasing it exactly once."
)
ALIGN_EVIDENCE = (
    "The source identifies alignment, pointee type, and the intended access. "
    "The oracle exercises the same local operation on storage that satisfies the required alignment."
)


SPECS = [
    c(
        "alloc__deallocate-bad-alignment",
        "alloc/deallocate-bad-alignment.rs",
        "A one-byte allocation made with alignment 1 is deallocated once with the identical layout.",
        [],
        DEFAULT,
        ALLOC_EVIDENCE,
        "use std::alloc::{Layout,alloc,dealloc};fn main(){unsafe{let l=Layout::from_size_align(1,1).unwrap();let x=alloc(l);assert!(!x.is_null());x.write(42);assert_eq!(x.read(),42);dealloc(x,l);}}",
        entry_tests("let l=std::alloc::Layout::from_size_align(1,1).unwrap();assert_eq!((l.size(),l.align()),(1,1));"),
        [
            mutation("x.write(42)", "x.write(41)", "Changes the stored byte."),
            mutation("x.read(),42", "x.read(),41", "Claims the wrong byte."),
            mutation("dealloc(x,l)", "dealloc(x,Layout::from_size_align(1,2).unwrap())", "Uses a mismatched alignment."),
            P,
        ],
    ),
    c(
        "alloc__deallocate-bad-size",
        "alloc/deallocate-bad-size.rs",
        "A one-byte allocation is read and deallocated once with the same size-one layout.",
        [],
        DEFAULT,
        ALLOC_EVIDENCE,
        "use std::alloc::{Layout,alloc,dealloc};fn main(){unsafe{let l=Layout::from_size_align(1,1).unwrap();let x=alloc(l);assert!(!x.is_null());x.write(7);assert_eq!(x.read(),7);dealloc(x,l);}}",
        entry_tests("let l=std::alloc::Layout::from_size_align(1,1).unwrap();assert_eq!(l.size(),1);"),
        [
            mutation("x.write(7)", "x.write(8)", "Changes the stored byte."),
            mutation("x.read(),7", "x.read(),8", "Claims the wrong byte."),
            mutation("dealloc(x,l)", "dealloc(x,Layout::from_size_align(2,1).unwrap())", "Uses a mismatched size."),
            P,
        ],
    ),
    c(
        "alloc__deallocate-twice",
        "alloc/deallocate-twice.rs",
        "A live one-byte allocation containing 9 is deallocated exactly once.",
        [],
        DEFAULT,
        ALLOC_EVIDENCE,
        "use std::alloc::{Layout,alloc,dealloc};fn main(){unsafe{let l=Layout::from_size_align(1,1).unwrap();let x=alloc(l);assert!(!x.is_null());x.write(9);assert_eq!(x.read(),9);dealloc(x,l);}}",
        entry_tests("let l=std::alloc::Layout::from_size_align(1,1).unwrap();assert_eq!((l.size(),l.align()),(1,1));"),
        [
            mutation("x.write(9)", "x.write(10)", "Changes the stored byte."),
            mutation("x.read(),9", "x.read(),10", "Claims the wrong byte."),
            mutation("dealloc(x,l);", "dealloc(x,l);dealloc(x,l);", "Frees the allocation twice."),
            P,
        ],
    ),
    c(
        "alloc__global_system_mixup",
        "alloc/global_system_mixup.rs",
        "Global allocates and Global deallocates the same one-byte block with the same layout.",
        [],
        DEFAULT,
        "The fixture explicitly distinguishes Global from System ownership. The valid protocol keeps allocation and deallocation on Global.",
        "#![feature(allocator_api,slice_ptr_get)]use std::alloc::{Allocator,Global,Layout,System};fn main(){let l=Layout::from_size_align(1,1).unwrap();let p=Global.allocate(l).unwrap().as_non_null_ptr();unsafe{p.as_ptr().write(11)};assert_eq!(unsafe{p.as_ptr().read()},11);unsafe{Global.deallocate(p,l)};}",
        entry_tests("let l=std::alloc::Layout::from_size_align(1,1).unwrap();assert_eq!((l.size(),l.align()),(1,1));"),
        [
            mutation("write(11)", "write(12)", "Changes the stored byte."),
            mutation("read()},11", "read()},12", "Claims the wrong byte."),
            mutation("Global.deallocate(p,l)", "System.deallocate(p,l)", "Mixes allocator ownership."),
            P,
        ],
    ),
    c(
        "alloc__reallocate-bad-size",
        "alloc/reallocate-bad-size.rs",
        "realloc receives the original size-one layout, grows to two bytes, and preserves the first byte.",
        [],
        DEFAULT,
        ALLOC_EVIDENCE,
        "use std::alloc::{Layout,alloc,dealloc,realloc};fn main(){unsafe{let l=Layout::from_size_align(1,1).unwrap();let x=alloc(l);assert!(!x.is_null());x.write(13);let y=realloc(x,l,2);assert!(!y.is_null());assert_eq!(y.read(),13);y.add(1).write(14);assert_eq!(y.add(1).read(),14);dealloc(y,Layout::from_size_align(2,1).unwrap());}}",
        entry_tests("let a=std::alloc::Layout::from_size_align(1,1).unwrap();let b=std::alloc::Layout::from_size_align(2,1).unwrap();assert_eq!((a.size(),b.size()),(1,2));"),
        [
            mutation("x.write(13)", "x.write(12)", "Changes the preserved byte."),
            mutation("y.read(),13", "y.read(),12", "Claims the wrong preserved byte."),
            mutation("realloc(x,l,2)", "realloc(x,Layout::from_size_align(2,1).unwrap(),2)", "Supplies the wrong old size."),
            P,
        ],
    ),
    c(
        "alloc__reallocate-change-alloc",
        "alloc/reallocate-change-alloc.rs",
        "After realloc, all accesses and final deallocation use the returned pointer, whose first byte remains 15.",
        [],
        DEFAULT,
        ALLOC_EVIDENCE,
        "use std::alloc::{Layout,alloc,dealloc,realloc};fn main(){unsafe{let l=Layout::from_size_align(1,1).unwrap();let x=alloc(l);assert!(!x.is_null());x.write(15);let y=realloc(x,l,2);assert!(!y.is_null());assert_eq!(y.read(),15);y.add(1).write(16);assert_eq!(y.add(1).read(),16);dealloc(y,Layout::from_size_align(2,1).unwrap());}}",
        entry_tests("let l=std::alloc::Layout::from_size_align(2,1).unwrap();assert_eq!((l.size(),l.align()),(2,1));"),
        [
            mutation("x.write(15)", "x.write(14)", "Changes the preserved byte."),
            mutation("y.read(),15", "y.read(),14", "Claims the wrong preserved byte."),
            mutation("assert_eq!(y.read()", "assert_eq!(x.read()", "Reads the invalidated old pointer."),
            P,
        ],
    ),
    c(
        "alloc__reallocate-dangling",
        "alloc/reallocate-dangling.rs",
        "A live allocation is reallocated before being freed; the returned two-byte block preserves byte 17.",
        [],
        DEFAULT,
        ALLOC_EVIDENCE,
        "use std::alloc::{Layout,alloc,dealloc,realloc};fn main(){unsafe{let l=Layout::from_size_align(1,1).unwrap();let x=alloc(l);assert!(!x.is_null());x.write(17);let y=realloc(x,l,2);assert!(!y.is_null());assert_eq!(y.read(),17);y.add(1).write(18);assert_eq!(y.add(1).read(),18);dealloc(y,Layout::from_size_align(2,1).unwrap());}}",
        entry_tests("let l=std::alloc::Layout::from_size_align(1,1).unwrap();assert_eq!(l.size(),1);"),
        [
            mutation("x.write(17)", "x.write(16)", "Changes the preserved byte."),
            mutation("y.read(),17", "y.read(),16", "Claims the wrong preserved byte."),
            mutation("let y=realloc(x,l,2)", "dealloc(x,l);let y=realloc(x,l,2)", "Reallocates a freed pointer."),
            P,
        ],
    ),
    c(
        "alloc__stack_free",
        "alloc/stack_free.rs",
        "The stack integer remains an ordinary value 42; separately owned Box storage is dropped normally.",
        [],
        NO_ALIAS,
        "The source explicitly initializes the stack value to 42. Its only invalid step is fabricating Box ownership of that stack address.",
        "fn main(){let x=42i32;assert_eq!(x,42);let owned=Box::new(x);assert_eq!(*owned,42);drop(owned);assert_eq!(x,42);}",
        entry_tests("let x=42i32;let b=Box::new(x);assert_eq!((*b,x),(42,42));"),
        [
            mutation("x=42i32", "x=41i32", "Changes the explicit stack value."),
            mutation("*owned,42", "*owned,41", "Claims the wrong owned value."),
            mutation("assert_eq!(x,42);}", "assert_eq!(x,41);}", "Claims the wrong surviving stack value."),
            P,
        ],
    ),
    c(
        "unaligned_pointers__alignment",
        "unaligned_pointers/alignment.rs",
        "Two aligned u32 stores write 42 into the first two elements of the backing array.",
        [],
        DEFAULT,
        ALIGN_EVIDENCE,
        "fn main(){let mut x=[0u32;5];let p=x.as_mut_ptr();unsafe{*p=42;*p.add(1)=42;}assert_eq!(&x[..2],&[42,42]);}",
        entry_tests("let x=[42u32,42];assert_eq!(x,[42,42]);"),
        [
            mutation("*p=42", "*p=41", "Changes the first store."),
            mutation("*p.add(1)=42", "*p.add(1)=41", "Changes the second store."),
            mutation("p.add(1)", "p.add(2)", "Writes the wrong aligned element."),
            P,
        ],
    ),
    c(
        "unaligned_pointers__atomic_unaligned",
        "unaligned_pointers/atomic_unaligned.rs",
        "A naturally aligned AtomicU64 initialized to zero returns zero from a SeqCst load.",
        [],
        SYMBOLIC,
        ALIGN_EVIDENCE,
        "use std::sync::atomic::{AtomicU64,Ordering};fn main(){let z=AtomicU64::new(0);assert_eq!((&z as*const AtomicU64).align_offset(std::mem::align_of::<AtomicU64>()),0);assert_eq!(z.load(Ordering::SeqCst),0);}",
        entry_tests("let z=std::sync::atomic::AtomicU64::new(7);assert_eq!(z.load(std::sync::atomic::Ordering::SeqCst),7);"),
        [
            mutation("new(0)", "new(1)", "Changes the atomic value."),
            mutation("SeqCst),0", "SeqCst),1", "Claims the wrong loaded value."),
            mutation("align_of::<AtomicU64>()),0", "align_of::<AtomicU64>()),1", "Claims the aligned pointer is offset."),
            P,
        ],
    ),
    c(
        "unaligned_pointers__drop_in_place",
        "unaligned_pointers/drop_in_place.rs",
        "PartialDrop has alignment 2 and an aligned live instance can be dropped in place exactly once.",
        ["HasDrop", "PartialDrop"],
        DEFAULT,
        ALIGN_EVIDENCE,
        "use std::mem::ManuallyDrop;#[repr(transparent)]struct HasDrop(u8);impl Drop for HasDrop{fn drop(&mut self){}}#[repr(C,align(2))]struct PartialDrop{a:HasDrop,b:u8}fn main(){assert_eq!(std::mem::align_of::<PartialDrop>(),2);let mut x=ManuallyDrop::new(PartialDrop{a:HasDrop(7),b:9});assert_eq!((x.a.0,x.b),(7,9));unsafe{core::ptr::drop_in_place(&mut*x);}}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn declared_layout(){assert_eq!(std::mem::align_of::<PartialDrop>(),2);assert!(std::mem::size_of::<PartialDrop>()>=2);}#[test]fn repeated_aligned_drops(){for _ in 0..5{main();}}",
        [
            mutation("repr(C,align(2))", "repr(C,align(4))", "Changes the declared alignment."),
            mutation("HasDrop(7)", "HasDrop(6)", "Changes the field value."),
            mutation("x.b),(7,9)", "x.b),(7,8)", "Claims the wrong fields."),
            P,
        ],
    ),
    c(
        "unaligned_pointers__dyn_alignment",
        "unaligned_pointers/dyn_alignment.rs",
        "MuchAlign has alignment 256 and a trait object borrowing a live MuchAlign retains that dynamic alignment.",
        ["MuchAlign"],
        NO_STACK,
        "The repr(align(256)) declaration and Debug trait object are explicit; the valid domain keeps the trait object's data pointer on the live MuchAlign.",
        "#[repr(align(256))]#[derive(Debug)]struct MuchAlign;fn main(){let x=MuchAlign;let p=&x as&dyn std::fmt::Debug;assert_eq!((p as*const dyn std::fmt::Debug as*const u8).align_offset(256),0);assert_eq!(format!(\"{:?}\",p),\"MuchAlign\");}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn dynamic_alignment(){assert_eq!(std::mem::align_of::<MuchAlign>(),256);let x=MuchAlign;let p=&x as&dyn std::fmt::Debug;assert_eq!((p as*const _ as*const u8).align_offset(256),0);}#[test]fn repeated_trait_objects(){for _ in 0..5{main();}}",
        [
            mutation("repr(align(256))", "repr(align(128))", "Changes the declared alignment."),
            mutation('"MuchAlign");}', '"Other");}', "Claims the wrong Debug output."),
            mutation("align_offset(256),0", "align_offset(256),1", "Claims a misaligned data address."),
            P,
        ],
    ),
    c(
        "unaligned_pointers__intptrcast_alignment_check",
        "unaligned_pointers/intptrcast_alignment_check.rs",
        "A naturally aligned live u16 pointer stores 2 and the owner observes 2.",
        [],
        PERMISSIVE_SYMBOLIC,
        ALIGN_EVIDENCE,
        "fn main(){let mut x=0u16;let p=&mut x as*mut u16;assert_eq!(p.align_offset(std::mem::align_of::<u16>()),0);unsafe{*p=2};assert_eq!(x,2);}",
        entry_tests("let mut x=7u16;let p=&mut x as*mut u16;unsafe{*p=8};assert_eq!(x,8);"),
        [
            mutation("*p=2", "*p=3", "Changes the aligned write."),
            mutation("x,2", "x,3", "Claims the wrong result."),
            mutation("align_of::<u16>()),0", "align_of::<u16>()),1", "Claims a nonzero alignment offset."),
            P,
        ],
    ),
    c(
        "unaligned_pointers__promise_alignment_zero",
        "unaligned_pointers/promise_alignment_zero.rs",
        "The minimum valid promised alignment is one, a nonzero power of two; the u32 buffer also has alignment four.",
        [],
        DEFAULT,
        "The fixture's diagnostic states that zero is invalid because an alignment must be a power of two. The oracle checks the nearest valid boundary and actual buffer layout.",
        "fn main(){let align=1usize;assert!(align.is_power_of_two());let buffer=[0u32;128];assert_eq!(std::mem::align_of_val(&buffer),4);assert_eq!((buffer.as_ptr()as usize)%align,0);}",
        entry_tests("for a in [1usize,2,4,8,16]{assert!(a.is_power_of_two());}assert!(!0usize.is_power_of_two());"),
        [
            mutation("align=1usize", "align=0usize", "Uses the invalid zero boundary."),
            mutation("assert!(align.is_power_of_two())", "assert!(!align.is_power_of_two())", "Rejects the valid minimum alignment."),
            mutation("align_of_val(&buffer),4", "align_of_val(&buffer),8", "Claims the wrong buffer alignment."),
            P,
        ],
    ),
    c(
        "unaligned_pointers__unaligned_ptr1",
        "unaligned_pointers/unaligned_ptr1.rs",
        "Loading the first element through an aligned u32 pointer returns 2.",
        [],
        NO_ALIAS,
        ALIGN_EVIDENCE,
        "fn main(){let x=[2u32,3,4];let p=x.as_ptr();assert_eq!(p.align_offset(std::mem::align_of::<u32>()),0);assert_eq!(unsafe{*p},2);}",
        entry_tests("let x=[7u32,8];assert_eq!(unsafe{*x.as_ptr()},7);"),
        [
            mutation("[2u32,3,4]", "[1u32,3,4]", "Changes the first element."),
            mutation("*p},2", "*p},1", "Claims the wrong loaded element."),
            mutation("align_of::<u32>()),0", "align_of::<u32>()),1", "Claims a nonzero alignment offset."),
            P,
        ],
    ),
    c(
        "unaligned_pointers__unaligned_ptr2",
        "unaligned_pointers/unaligned_ptr2.rs",
        "An in-bounds aligned pointer to the first u32 element loads 2.",
        [],
        NO_ALIAS,
        ALIGN_EVIDENCE,
        "fn main(){let x=[2u32,3];let p=x.as_ptr();assert_eq!(p.align_offset(std::mem::align_of::<u32>()),0);assert_eq!(unsafe{*p},2);}",
        entry_tests("let x=[9u32,10];assert_eq!(unsafe{*x.as_ptr()},9);"),
        [
            mutation("[2u32,3]", "[1u32,3]", "Changes the first element."),
            mutation("*p},2", "*p},1", "Claims the wrong loaded element."),
            mutation("let p=x.as_ptr()", "let p=x.as_ptr().wrapping_add(1)", "Loads the other aligned element."),
            P,
        ],
    ),
    c(
        "unaligned_pointers__unaligned_ptr3",
        "unaligned_pointers/unaligned_ptr3.rs",
        "An aligned pointer-sized load retrieves the first stored pointer and it dereferences to byte 2.",
        [],
        NO_ALIAS,
        "The fixture specifically targets pointer-sized loads. The valid domain stores real pointers in a naturally aligned pointer array before loading one.",
        "fn main(){let a=2u8;let b=3u8;let x=[&a as*const u8,&b as*const u8];let p=x.as_ptr();assert_eq!(p.align_offset(std::mem::align_of::<*const u8>()),0);let q=unsafe{*p};assert_eq!(unsafe{*q},2);}",
        entry_tests("let x=7u8;let a=[&x as*const u8];let q=unsafe{*a.as_ptr()};assert_eq!(unsafe{*q},7);"),
        [
            mutation("let a=2u8", "let a=1u8", "Changes the first pointee."),
            mutation("*q},2", "*q},1", "Claims the wrong pointee value."),
            mutation("let q=unsafe{*p}", "let q=unsafe{*p.add(1)}", "Loads the other stored pointer."),
            P,
        ],
    ),
    c(
        "unaligned_pointers__unaligned_ptr4",
        "unaligned_pointers/unaligned_ptr4.rs",
        "An aligned u16 load from the start of a u16 array returns zero.",
        [],
        NO_ALIAS,
        ALIGN_EVIDENCE,
        "fn main(){let x=[0u16,1u16];let p=x.as_ptr();assert_eq!(p.align_offset(std::mem::align_of::<u16>()),0);assert_eq!(unsafe{*p},0);}",
        entry_tests("let x=[5u16,6];assert_eq!(unsafe{*x.as_ptr()},5);"),
        [
            mutation("[0u16,1u16]", "[1u16,1u16]", "Changes the loaded element."),
            mutation("*p},0", "*p},1", "Claims the wrong loaded value."),
            mutation("let p=x.as_ptr()", "let p=x.as_ptr().wrapping_add(1)", "Loads the other element."),
            P,
        ],
    ),
    c(
        "unaligned_pointers__unaligned_ptr_zst",
        "unaligned_pointers/unaligned_ptr_zst.rs",
        "A live [u32; 0] value is zero-sized, four-aligned, and may be loaded through its aligned pointer.",
        [],
        NO_ALIAS,
        "The source explicitly tests a zero-sized [u32; 0] load; the oracle supplies storage with the type's required alignment.",
        "fn main(){let x=[0u32;0];let p=&x as*const[u32;0];assert_eq!(p.align_offset(std::mem::align_of::<[u32;0]>()),0);let y=unsafe{*p};assert_eq!(y.len(),0);assert_eq!(std::mem::align_of_val(&y),4);}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn zst_layout(){assert_eq!(std::mem::size_of::<[u32;0]>(),0);assert_eq!(std::mem::align_of::<[u32;0]>(),4);}#[test]fn repeated_aligned_loads(){for _ in 0..8{main();}}",
        [
            mutation("[0u32;0]", "[0u32;1]", "Changes the source from a ZST."),
            mutation("y.len(),0", "y.len(),1", "Claims the wrong length."),
            mutation("align_of_val(&y),4", "align_of_val(&y),8", "Claims the wrong alignment."),
            P,
        ],
    ),
    c(
        "unaligned_pointers__unaligned_ref_addr_of",
        "unaligned_pointers/unaligned_ref_addr_of.rs",
        "A shared reference formed from an aligned live u32 pointer observes the first value 2.",
        [],
        NO_STACK,
        ALIGN_EVIDENCE,
        "fn main(){let x=[2u32,3,4];let p=x.as_ptr();assert_eq!(p.align_offset(std::mem::align_of::<u32>()),0);let r=unsafe{&*p};assert_eq!(*r,2);}",
        entry_tests("let x=[7u32,8];let r=unsafe{&*x.as_ptr()};assert_eq!(*r,7);"),
        [
            mutation("[2u32,3,4]", "[1u32,3,4]", "Changes the referenced value."),
            mutation("*r,2", "*r,1", "Claims the wrong referenced value."),
            mutation("let p=x.as_ptr()", "let p=x.as_ptr().wrapping_add(1)", "References the other aligned element."),
            P,
        ],
    ),
]


def main() -> None:
    for item in SPECS:
        write_case(item)
    print(f"wrote {len(SPECS)} batch-16 cases")


if __name__ == "__main__":
    main()
