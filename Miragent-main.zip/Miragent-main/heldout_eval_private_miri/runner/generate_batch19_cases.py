#!/usr/bin/env python3
"""Materialize batch 19: sequential, live-domain Stacked Borrows invariants."""

from __future__ import annotations

from generate_batch2_cases import DEFAULT, mutation, write_case
from generate_batch6_cases import main_case


NO_VALID = [("official-no-validation", ["-Zmiri-disable-validation"]), ("default-strict", [])]
PERMISSIVE = [("official-permissive", ["-Zmiri-permissive-provenance"]), ("default-strict", [])]
DETERMINISTIC = [("official-deterministic", ["-Zmiri-deterministic-concurrency"]), ("default-strict", [])]
WEAK = [
    ("official-checks-disabled", ["-Zmiri-disable-alignment-check", "-Zmiri-disable-stacked-borrows", "-Zmiri-disable-validation"]),
    ("default-strict", []),
]
P = mutation("fn main(){", 'fn main(){panic!("main");', "Rejects the valid repaired entry.")
EVIDENCE = (
    "The fixture's values and local access operation are explicit. The oracle removes only the stale/aliased access, "
    "then observes the same operation through one live pointer or reference under a sequential schedule."
)


def s(case_id, path, contract, reference, muts, symbols=None, profiles=None, extra="main();"):
    tests = (
        "#[test]fn repaired_entry_completes(){main();}"
        "#[test]fn repeated_live_domain(){for _ in 0..7{main();}}"
        f"#[test]fn independent_live_domain(){{{extra}}}"
    )
    return main_case(
        case_id,
        path,
        contract,
        symbols or [],
        profiles or DEFAULT,
        EVIDENCE,
        reference,
        tests,
        muts + [P],
    )


SPECS = [
    s(
        "stacked_borrows__disable_mut_does_not_merge_srw",
        "stacked_borrows/disable_mut_does_not_merge_srw.rs",
        "One live raw pointer derived from base writes 1 and the owner observes 1.",
        "fn main(){let mut mem=0i32;let base=&mut mem as*mut i32;let raw=base;unsafe{*raw=1};assert_eq!(mem,1);}",
        [mutation("*raw=1", "*raw=2", "Changes the write."), mutation("mem,1", "mem,2", "Claims the wrong value."), mutation("let raw=base", "let raw=std::ptr::null_mut()", "Drops the live pointer.")],
    ),
    s(
        "stacked_borrows__drop_in_place_retag",
        "stacked_borrows/drop_in_place_retag.rs",
        "drop_in_place receives an aligned writable pointer to a live u8 value 0 and completes.",
        "fn main(){let mut x=std::mem::ManuallyDrop::new(0u8);let p=&mut*x as*mut u8;unsafe{core::ptr::drop_in_place(p)};assert_eq!(*x,0);}",
        [mutation("new(0u8)", "new(1u8)", "Changes the value."), mutation("*x,0", "*x,1", "Claims the wrong value."), mutation("drop_in_place(p)", "drop_in_place(std::ptr::null_mut())", "Drops through an invalid pointer.")],
    ),
    s(
        "stacked_borrows__exposed_only_ro",
        "stacked_borrows/exposed_only_ro.rs",
        "A live writable raw pointer stores 1 into x and x observes 1.",
        "fn main(){let mut x=0i32;let p=&mut x as*mut i32;unsafe{*p=1};assert_eq!(x,1);}",
        [mutation("*p=1", "*p=2", "Changes the write."), mutation("x,1", "x,2", "Claims the wrong value."), mutation("let p=&mut x", "let p=std::ptr::null_mut();let _=&mut x", "Drops provenance.")],
        profiles=PERMISSIVE,
    ),
    s(
        "stacked_borrows__illegal_dealloc1",
        "stacked_borrows/illegal_dealloc1.rs",
        "A one-byte allocation is written through its live pointer and deallocated once with its matching layout.",
        "use std::alloc::{Layout,alloc,dealloc};fn main(){unsafe{let l=Layout::from_size_align(1,1).unwrap();let p=alloc(l);assert!(!p.is_null());p.write(0);assert_eq!(p.read(),0);dealloc(p,l);}}",
        [mutation("p.write(0)", "p.write(1)", "Changes the byte."), mutation("p.read(),0", "p.read(),1", "Claims the wrong byte."), mutation("dealloc(p,l)", "dealloc(p.add(1),l)", "Deallocates through the wrong pointer.")],
    ),
    s(
        "stacked_borrows__illegal_read4",
        "stacked_borrows/illegal_read4.rs",
        "The current mutable reborrow reads the live value 2.",
        "fn main(){let mut x=2i32;let r=&mut x;assert_eq!(*r,2);*r=3;assert_eq!(x,3);}",
        [mutation("x=2i32", "x=1i32", "Changes the input."), mutation("*r,2", "*r,1", "Claims the wrong read."), mutation("*r=3", "*r=4", "Changes the write.")],
    ),
    s(
        "stacked_borrows__illegal_read5",
        "stacked_borrows/illegal_read5.rs",
        "RefCell mutable and shared borrows occur in disjoint scopes and both observe 0.",
        "use std::cell::RefCell;fn main(){let rc=RefCell::new(0i32);{let r=rc.borrow_mut();assert_eq!(*r,0);}{let r=rc.borrow();assert_eq!(*r,0);}}",
        [mutation("new(0i32)", "new(1i32)", "Changes the cell."), mutation("assert_eq!(*r,0);}{", "assert_eq!(*r,1);}{", "Claims the wrong first read."), mutation("let r=rc.borrow();", 'panic!("borrow");let r=rc.borrow();', "Rejects the shared borrow.")],
    ),
    s(
        "stacked_borrows__illegal_read6",
        "stacked_borrows/illegal_read6.rs",
        "A current mutable reborrow and its shared child both observe the live value 0.",
        "fn main(){let mut v=0i32;let x=&mut v;let y=&*x;assert_eq!(*y,0);assert_eq!(*x,0);}",
        [mutation("v=0i32", "v=1i32", "Changes the value."), mutation("*y,0", "*y,1", "Claims the wrong shared read."), mutation("*x,0", "*x,1", "Claims the wrong mutable read.")],
    ),
    s(
        "stacked_borrows__illegal_read7",
        "stacked_borrows/illegal_read7.rs",
        "A live shared Cell reference stores 1 and then observes 1.",
        "use std::cell::Cell;fn main(){let x=Cell::new(0i32);let r=&x;r.set(1);assert_eq!(r.get(),1);}",
        [mutation("set(1)", "set(2)", "Changes the cell write."), mutation("get(),1", "get(),2", "Claims the wrong value."), mutation("let x=Cell::new", 'panic!("cell");let x=Cell::new', "Rejects the valid cell.")],
    ),
    s(
        "stacked_borrows__illegal_read8",
        "stacked_borrows/illegal_read8.rs",
        "A single live raw pointer increments x from 0 to 1 before x is observed.",
        "fn main(){let mut x=0i32;let p=&mut x as*mut i32;unsafe{*p+=1};assert_eq!(x,1);}",
        [mutation("*p+=1", "*p+=2", "Changes the increment."), mutation("x,1", "x,2", "Claims the wrong value."), mutation("x=0i32", "x=1i32", "Changes the initial value.")],
    ),
    s(
        "stacked_borrows__illegal_write2",
        "stacked_borrows/illegal_write2.rs",
        "The sole live mutable reference changes its target from 42 to 13.",
        "fn main(){let mut v=42i32;let target=&mut v;*target=13;assert_eq!(v,13);}",
        [mutation("let mut v=42i32", 'panic!("target");let mut v=42i32', "Rejects the valid target."), mutation("*target=13", "*target=12", "Changes the write."), mutation("v,13", "v,12", "Claims the wrong result.")],
    ),
    s(
        "stacked_borrows__illegal_write3",
        "stacked_borrows/illegal_write3.rs",
        "A shared reference to immutable target reads the explicit value 42 without mutation.",
        "fn main(){let target=42i32;let r=&target;assert_eq!(*r,42);}",
        [mutation("target=42i32", "target=41i32", "Changes the target."), mutation("*r,42", "*r,41", "Claims the wrong value."), mutation("let r=&target", 'panic!("reference");let r=&target', "Rejects the valid reference.")],
    ),
    s(
        "stacked_borrows__illegal_write4",
        "stacked_borrows/illegal_write4.rs",
        "One live mutable reference reads 42, writes 43, and the owner observes 43.",
        "fn main(){let mut target=42i32;let r=&mut target;assert_eq!(*r,42);*r=43;assert_eq!(target,43);}",
        [mutation("target=42i32", "target=41i32", "Changes the input."), mutation("*r=43", "*r=44", "Changes the write."), mutation("target,43", "target,44", "Claims the wrong result.")],
    ),
    s(
        "stacked_borrows__interior_mut1",
        "stacked_borrows/interior_mut1.rs",
        "One live UnsafeCell path writes an inner value from 0 to 1 and observes 1.",
        "use std::cell::UnsafeCell;fn main(){let c=UnsafeCell::new(UnsafeCell::new(0i32));unsafe{*(*c.get()).get()=1;assert_eq!(*(*c.get()).get(),1);}}",
        [mutation("=1;assert_eq!", "=2;assert_eq!", "Changes the write."), mutation("get(),1", "get(),2", "Claims the wrong value."), mutation("let c=UnsafeCell::new", 'panic!("cell");let c=UnsafeCell::new', "Rejects the valid cell.")],
    ),
    s(
        "stacked_borrows__load_invalid_mut",
        "stacked_borrows/load_invalid_mut.rs",
        "A boxed current mutable reference updates its live target from 42 to 43.",
        "fn main(){let mut v=42i32;let r=&mut v;let mut b=Box::new(r);**b=43;assert_eq!(v,43);}",
        [mutation("let mut v=42i32", 'panic!("boxed-ref");let mut v=42i32', "Rejects the valid target."), mutation("**b=43", "**b=44", "Changes the write."), mutation("v,43", "v,44", "Claims the wrong value.")],
        profiles=NO_VALID,
    ),
    s(
        "stacked_borrows__raw_tracking",
        "stacked_borrows/raw_tracking.rs",
        "One live raw pointer writes 13 and the owner observes 13.",
        "fn main(){let mut l=0i32;let p=&mut l as*mut i32;unsafe{*p=13};assert_eq!(l,13);}",
        [mutation("*p=13", "*p=12", "Changes the write."), mutation("l,13", "l,12", "Claims the wrong value."), mutation("let mut l=0i32", 'panic!("raw");let mut l=0i32', "Rejects the valid raw pointer path.")],
    ),
    s(
        "stacked_borrows__retag_data_race_protected_read",
        "stacked_borrows/retag_data_race_protected_read.rs",
        "A joined scoped mutable reborrow completes before the raw pointer is read as 0.",
        "fn main(){let mut mem=0i32;std::thread::scope(|s|{let r=&mut mem;s.spawn(move||{let _=&mut*r;}).join().unwrap();});assert_eq!(mem,0);}",
        [mutation("mem=0i32", "mem=1i32", "Changes the value."), mutation("mem,0", "mem,1", "Claims the wrong value."), mutation("s.spawn(move||", 's.spawn(move||panic!("retag"));s.spawn(move||', "Rejects the reborrow.")],
        profiles=DETERMINISTIC,
    ),
    s(
        "stacked_borrows__shared_rw_borrows_are_weak1",
        "stacked_borrows/shared_rw_borrows_are_weak1.rs",
        "A Cell shared write stores 1; after that borrow ends, a fresh mutable borrow observes 1.",
        "use std::cell::Cell;fn main(){let mut x=Cell::new(0i32);{let r=&x;r.set(1);}assert_eq!(*x.get_mut(),1);}",
        [mutation("set(1)", "set(2)", "Changes the write."), mutation("get_mut(),1", "get_mut(),2", "Claims the wrong value."), mutation("let mut x=Cell::new", 'panic!("cell");let mut x=Cell::new', "Rejects the valid Cell path.")],
    ),
    s(
        "stacked_borrows__shared_rw_borrows_are_weak2",
        "stacked_borrows/shared_rw_borrows_are_weak2.rs",
        "RefCell::replace stores 1 and a later non-overlapping borrow observes 1.",
        "use std::cell::RefCell;fn main(){let x=RefCell::new(0i32);assert_eq!(x.replace(1),0);assert_eq!(*x.borrow(),1);}",
        [mutation("replace(1)", "replace(2)", "Changes the write."), mutation("replace(1),0", "replace(1),1", "Claims the wrong old value."), mutation("borrow(),1", "borrow(),2", "Claims the wrong new value.")],
    ),
    s(
        "stacked_borrows__static_memory_modification",
        "stacked_borrows/static_memory_modification.rs",
        "The immutable static X is read-only and retains its declared value 5.",
        "static X:usize=5;fn main(){assert_eq!(X,5);assert_eq!(&X as*const usize,&X as*const usize);}",
        [mutation("X:usize=5", "X:usize=6", "Changes the static."), mutation("X,5", "X,6", "Claims the wrong value."), mutation("assert_eq!(&X", "assert_ne!(&X", "Negates address identity.")],
    ),
    s(
        "stacked_borrows__transmute-is-no-escape",
        "stacked_borrows/transmute-is-no-escape.rs",
        "A raw pointer directly derived from x[0] writes 13 while x[1] remains 43.",
        "fn main(){let mut x=[42i32,43];let p=&mut x[0]as*mut i32;unsafe{*p=13};assert_eq!(x,[13,43]);}",
        [mutation("*p=13", "*p=12", "Changes the write."), mutation("[13,43]", "[12,43]", "Claims the wrong result."), mutation("[42i32,43]", "[42i32,44]", "Changes the untouched element.")],
    ),
]


def main() -> None:
    for item in SPECS:
        write_case(item)
    print(f"wrote {len(SPECS)} batch-19 cases")


if __name__ == "__main__":
    main()
