#!/usr/bin/env python3
"""Materialize the ninth batch: intrinsics on their well-defined input domains."""

from __future__ import annotations

from generate_batch2_cases import DEFAULT, mutation, write_case
from generate_batch6_cases import main_case


def spec(case_id, contract, reference, independent_test, mutants):
    return main_case(
        case_id,
        case_id.replace("intrinsics__", "intrinsics/") + ".rs",
        contract,
        [],
        DEFAULT,
        "The source identifies the precise precondition violation; the oracle exercises the same operation only where that precondition holds.",
        reference,
        "#[test]fn repaired_entry_completes(){main();}"
        "#[test]fn repaired_entry_repeats(){for _ in 0..8{main();}}"
        f"#[test]fn independent_valid_domain(){{{independent_test}}}",
        mutants,
    )


PANIC = mutation("fn main(){", "fn main(){panic!(\"main\");", "Panics on valid input.")


SPECS = [
    spec("intrinsics__div-by-zero","unchecked_div returns the mathematical quotient for a nonzero divisor.",
         "#![feature(core_intrinsics)]fn main(){let n=unsafe{std::intrinsics::unchecked_div(12i64,3)};assert_eq!(n,4);}",
         "assert_eq!(unsafe{std::intrinsics::unchecked_div(-21i64,3)},-7);",
         [mutation("12i64,3","12i64,4","Changes divisor."),mutation("n,4","n,3","Wrong quotient."),mutation("unchecked_div","unchecked_rem","Uses remainder."),PANIC]),
    spec("intrinsics__rem-by-zero","unchecked_rem returns the mathematical remainder for a nonzero divisor.",
         "#![feature(core_intrinsics)]fn main(){let n=unsafe{std::intrinsics::unchecked_rem(11u32,3)};assert_eq!(n,2);}",
         "assert_eq!(unsafe{std::intrinsics::unchecked_rem(20u32,6)},2);",
         [mutation("11u32,3","10u32,3","Changes dividend."),mutation("n,2","n,1","Wrong remainder."),mutation("unchecked_rem","unchecked_div","Uses quotient."),PANIC]),
    spec("intrinsics__exact_div1","exact_div returns an exact quotient when the divisor is nonzero and the remainder is zero.",
         "#![feature(core_intrinsics)]fn main(){let n=unsafe{std::intrinsics::exact_div(12i32,3)};assert_eq!(n,4);}",
         "assert_eq!(unsafe{std::intrinsics::exact_div(-20i32,5)},-4);",
         [mutation("12i32,3","15i32,3","Changes dividend."),mutation("n,4","n,5","Wrong quotient."),mutation("12i32,3","12i32,4","Changes divisor."),PANIC]),
    spec("intrinsics__exact_div2","u16 exact_div preserves exact unsigned quotients.",
         "#![feature(core_intrinsics)]fn main(){let n=unsafe{std::intrinsics::exact_div(12u16,3)};assert_eq!(n,4);}",
         "assert_eq!(unsafe{std::intrinsics::exact_div(100u16,10)},10);",
         [mutation("12u16,3","15u16,3","Changes dividend."),mutation("n,4","n,5","Wrong quotient."),mutation("12u16,3","12u16,4","Changes divisor."),PANIC]),
    spec("intrinsics__exact_div3","i8 exact_div preserves exact signed quotients, including negative dividends.",
         "#![feature(core_intrinsics)]fn main(){let n=unsafe{std::intrinsics::exact_div(-18i8,2)};assert_eq!(n,-9);}",
         "assert_eq!(unsafe{std::intrinsics::exact_div(18i8,-2)},-9);",
         [mutation("-18i8,2","-16i8,2","Changes dividend."),mutation("n,-9","n,-8","Wrong quotient."),mutation("-18i8,2","-18i8,3","Changes divisor."),PANIC]),
    spec("intrinsics__exact_div4","i64 exact_div handles representable MIN quotients without the MIN/-1 overflow pair.",
         "#![feature(core_intrinsics)]fn main(){let n=unsafe{std::intrinsics::exact_div(i64::MIN,2)};assert_eq!(n,i64::MIN/2);}",
         "assert_eq!(unsafe{std::intrinsics::exact_div(i64::MIN,1)},i64::MIN);",
         [mutation("i64::MIN,2","i64::MIN,4","Changes divisor."),mutation("i64::MIN/2","i64::MIN/4","Wrong quotient."),mutation("exact_div","unchecked_rem","Uses remainder."),PANIC]),
    spec("intrinsics__unchecked_add1","u16 unchecked_add agrees with ordinary addition when the sum is representable.",
         "fn main(){let n=unsafe{30000u16.unchecked_add(30000)};assert_eq!(n,60000);}",
         "assert_eq!(unsafe{1u16.unchecked_add(2)},3);",
         [mutation("unchecked_add(30000)","unchecked_add(20000)","Changes addend."),mutation("n,60000","n,50000","Wrong sum."),mutation("unchecked_add","unchecked_sub","Uses subtraction."),PANIC]),
    spec("intrinsics__unchecked_add2","i16 unchecked_add agrees with ordinary addition for a representable negative sum.",
         "fn main(){let n=unsafe{(-30000i16).unchecked_add(8000)};assert_eq!(n,-22000);}",
         "assert_eq!(unsafe{(-10i16).unchecked_add(3)},-7);",
         [mutation("unchecked_add(8000)","unchecked_add(7000)","Changes addend."),mutation("n,-22000","n,-23000","Wrong sum."),mutation("unchecked_add","unchecked_sub","Uses subtraction."),PANIC]),
    spec("intrinsics__unchecked_sub1","u32 unchecked_sub agrees with ordinary subtraction when lhs is at least rhs.",
         "fn main(){let n=unsafe{22u32.unchecked_sub(14)};assert_eq!(n,8);}",
         "assert_eq!(unsafe{100u32.unchecked_sub(40)},60);",
         [mutation("unchecked_sub(14)","unchecked_sub(13)","Changes subtrahend."),mutation("n,8","n,9","Wrong difference."),mutation("unchecked_sub","unchecked_add","Uses addition."),PANIC]),
    spec("intrinsics__unchecked_sub2","i16 unchecked_sub agrees with ordinary subtraction when the result is representable.",
         "fn main(){let n=unsafe{30000i16.unchecked_sub(7000)};assert_eq!(n,23000);}",
         "assert_eq!(unsafe{(-10i16).unchecked_sub(3)},-13);",
         [mutation("unchecked_sub(7000)","unchecked_sub(6000)","Changes subtrahend."),mutation("n,23000","n,24000","Wrong difference."),mutation("unchecked_sub","unchecked_add","Uses addition."),PANIC]),
    spec("intrinsics__unchecked_mul1","u16 unchecked_mul agrees with ordinary multiplication when the product is representable.",
         "fn main(){let n=unsafe{200u16.unchecked_mul(250)};assert_eq!(n,50000);}",
         "assert_eq!(unsafe{12u16.unchecked_mul(3)},36);",
         [mutation("200u16","100u16","Changes factor."),mutation("n,50000","n,25000","Wrong product."),mutation("unchecked_mul(250)","unchecked_mul(249)","Changes factor."),PANIC]),
    spec("intrinsics__unchecked_mul2","i32 unchecked_mul preserves a representable negative product.",
         "fn main(){let n=unsafe{1_000_000_000i32.unchecked_mul(-2)};assert_eq!(n,-2_000_000_000);}",
         "assert_eq!(unsafe{(-12i32).unchecked_mul(-3)},36);",
         [mutation("unchecked_mul(-2)","unchecked_mul(-1)","Changes factor."),mutation("n,-2_000_000_000","n,-1_000_000_000","Wrong product."),mutation("1_000_000_000i32","900_000_000i32","Changes lhs."),PANIC]),
    spec("intrinsics__unchecked_div1","signed unchecked_div returns representable quotients and excludes MIN/-1.",
         "#![feature(core_intrinsics)]fn main(){let n=unsafe{std::intrinsics::unchecked_div(i16::MIN,2)};assert_eq!(n,i16::MIN/2);}",
         "assert_eq!(unsafe{std::intrinsics::unchecked_div(-30000i16,-2)},15000);",
         [mutation("i16::MIN,2","i16::MIN,4","Changes divisor."),mutation("i16::MIN/2","i16::MIN/4","Wrong quotient."),mutation("unchecked_div","unchecked_rem","Uses remainder."),PANIC]),
    spec("intrinsics__unchecked_shl","i8 unchecked_shl matches left shift for counts below eight.",
         "fn main(){let n=unsafe{1i8.unchecked_shl(7)};assert_eq!(n,i8::MIN);}",
         "assert_eq!(unsafe{3i8.unchecked_shl(2)},12);",
         [mutation("unchecked_shl(7)","unchecked_shl(6)","Changes count."),mutation("n,i8::MIN","n,64","Wrong result."),mutation("1i8","2i8","Changes value."),PANIC]),
    spec("intrinsics__unchecked_shl2","the intrinsic unchecked_shl accepts an in-range signed shift count and returns the shifted i8.",
         "#![feature(core_intrinsics)]fn main(){let n=unsafe{std::intrinsics::unchecked_shl(1i8,7i8)};assert_eq!(n,i8::MIN);}",
         "assert_eq!(unsafe{std::intrinsics::unchecked_shl(3i8,2i8)},12);",
         [mutation("7i8","6i8","Changes count."),mutation("n,i8::MIN","n,64","Wrong result."),mutation("1i8,7i8","2i8,7i8","Changes value."),PANIC]),
    spec("intrinsics__unchecked_shr","i64 unchecked_shr matches right shift for counts below 64.",
         "fn main(){let n=unsafe{8i64.unchecked_shr(3)};assert_eq!(n,1);}",
         "assert_eq!(unsafe{64i64.unchecked_shr(4)},4);",
         [mutation("unchecked_shr(3)","unchecked_shr(2)","Changes count."),mutation("n,1","n,2","Wrong result."),mutation("8i64","16i64","Changes value."),PANIC]),
    spec("intrinsics__ctlz_nonzero","ctlz_nonzero returns the leading-zero count for nonzero u8 values.",
         "#![feature(core_intrinsics)]fn main(){unsafe{assert_eq!(std::intrinsics::ctlz_nonzero(1u8),7);assert_eq!(std::intrinsics::ctlz_nonzero(0x80u8),0);}}",
         "assert_eq!(unsafe{std::intrinsics::ctlz_nonzero(0x10u8)},3);",
         [mutation("ctlz_nonzero(1u8),7","ctlz_nonzero(1u8),6","Wrong first count."),mutation("0x80u8),0","0x80u8),1","Wrong high-bit count."),mutation("ctlz_nonzero(1u8)","ctlz_nonzero(2u8)","Changes input."),PANIC]),
    spec("intrinsics__cttz_nonzero","cttz_nonzero returns the trailing-zero count for nonzero u8 values.",
         "#![feature(core_intrinsics)]fn main(){unsafe{assert_eq!(std::intrinsics::cttz_nonzero(1u8),0);assert_eq!(std::intrinsics::cttz_nonzero(0x80u8),7);}}",
         "assert_eq!(unsafe{std::intrinsics::cttz_nonzero(0x10u8)},4);",
         [mutation("cttz_nonzero(1u8),0","cttz_nonzero(1u8),1","Wrong first count."),mutation("0x80u8),7","0x80u8),6","Wrong high-bit count."),mutation("cttz_nonzero(1u8)","cttz_nonzero(2u8)","Changes input."),PANIC]),
    spec("intrinsics__disjoint_bitor","disjoint_bitor equals bitwise OR when the two operands have no common set bit.",
         "#![feature(core_intrinsics)]fn main(){let n=unsafe{std::intrinsics::disjoint_bitor(0b0101u8,0b1010u8)};assert_eq!(n,0b1111);}",
         "assert_eq!(unsafe{std::intrinsics::disjoint_bitor(0b0011u8,0b1100u8)},0b1111);",
         [mutation("0b0101u8","0b0001u8","Changes lhs."),mutation("n,0b1111","n,0b1011","Wrong OR."),mutation("0b1010u8","0b1000u8","Changes rhs."),PANIC]),
    spec("intrinsics__assume","assume accepts true predicates and leaves surrounding computation unchanged.",
         "#![feature(core_intrinsics)]fn main(){let x=5;unsafe{std::intrinsics::assume(x<10);std::intrinsics::assume(x>1);}assert_eq!(x,5);}",
         "let x=7;unsafe{std::intrinsics::assume(x==7)};assert_eq!(x,7);",
         [mutation("x<10","x>10","False assumption."),mutation("x>1","x<1","False assumption."),mutation("x,5","x,6","Wrong value."),PANIC]),
]


def main() -> None:
    for item in SPECS:
        write_case(item)
    print(f"wrote {len(SPECS)} batch-9 cases")


if __name__ == "__main__":
    main()
