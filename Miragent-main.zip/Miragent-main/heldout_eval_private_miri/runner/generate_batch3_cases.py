#!/usr/bin/env python3
"""Materialize the reviewed third batch of 20 partial semantic oracles."""

from __future__ import annotations

from generate_batch2_cases import (
    ALL_ALIAS,
    DEFAULT,
    STACK_TREE,
    TREE,
    WEAK_STRICT,
    mutation,
    write_case,
)


WEAK_STACK_TREE = [
    ("stacked-weakened", ["-Zmiri-disable-validation"]),
    ("tree-weakened", ["-Zmiri-disable-validation", "-Zmiri-tree-borrows"]),
]
TREE_NO_GC = [("tree-no-provenance-gc", ["-Zmiri-tree-borrows", "-Zmiri-provenance-gc=0"])]


SPECS = [
    {
        "id": "both_borrows__buggy_split_at_mut",
        "path": "both_borrows/buggy_split_at_mut.rs",
        "contract": "safe::split_at_mut partitions a mutable slice at mid into disjoint prefix and suffix slices, panicking only when mid exceeds len.",
        "symbols": ["safe::split_at_mut"],
        "profiles": STACK_TREE,
        "evidence": "The fixture labels the first result length `len - mid` as a bug and explicitly states it should be `mid`.",
        "tests": """
            #[test] fn repaired_entry_completes() { main(); }
            #[test] fn lengths_and_contents_match_every_boundary() {
                for mid in 0..=5 {
                    let mut data=[10,20,30,40,50]; let before=data;
                    let (left,right)=safe::split_at_mut(&mut data,mid);
                    assert_eq!(left,&before[..mid]); assert_eq!(right,&before[mid..]);
                    assert_eq!((left.len(),right.len()),(mid,5-mid));
                }
            }
            #[test] fn writes_are_disjoint_and_cover_the_source() {
                let mut data=[0,1,2,3,4,5]; let (left,right)=safe::split_at_mut(&mut data,2);
                left.copy_from_slice(&[8,9]); right.copy_from_slice(&[10,11,12,13]);
                assert_eq!(data,[8,9,10,11,12,13]);
            }
            #[test] fn out_of_range_mid_panics() {
                let mut data=[1,2,3]; let result=std::panic::catch_unwind(std::panic::AssertUnwindSafe(||{let _=safe::split_at_mut(&mut data,4);}));
                assert!(result.is_err());
            }
        """,
        "reference": """
            mod safe {
                use std::slice::from_raw_parts_mut;
                pub fn split_at_mut<T>(self_:&mut [T],mid:usize)->(&mut [T],&mut [T]){
                    let len=self_.len(); let ptr=self_.as_mut_ptr(); assert!(mid<=len);
                    unsafe{(from_raw_parts_mut(ptr,mid),from_raw_parts_mut(ptr.add(mid),len-mid))}
                }
            }
            fn main(){let mut data=[1,2,3,4];let(a,b)=safe::split_at_mut(&mut data,2);assert_eq!(a,&[1,2]);assert_eq!(b,&[3,4]);}
        """,
        "mutations": [
            mutation("from_raw_parts_mut(ptr,mid)", "from_raw_parts_mut(ptr,len-mid)", "Restores the fixture's overlapping-length bug."),
            mutation("from_raw_parts_mut(ptr.add(mid),len-mid)", "from_raw_parts_mut(ptr,len-mid)", "Starts both results at the same address."),
            mutation("from_raw_parts_mut(ptr.add(mid),len-mid)", "from_raw_parts_mut(ptr.add(mid),mid)", "Uses mid as the suffix length."),
            mutation("assert!(mid<=len)", "assert!(mid<len)", "Incorrectly rejects the len boundary."),
        ],
    },
    {
        "id": "both_borrows__aliasing_mut4",
        "path": "both_borrows/aliasing_mut4.rs",
        "contract": "On distinct legal inputs safe preserves x and stores 1 in the Cell referenced by y.",
        "symbols": ["safe"],
        "profiles": STACK_TREE,
        "evidence": "The source helper calls `y.set(1)` and only reads through x.",
        "tests": """
            fn run(x:i32,y:i32)->(i32,i32){let x=x;let mut y=std::cell::Cell::new(y);safe(&x,&mut y);(x,y.get())}
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn sets_cell_and_preserves_x(){for pair in [(0,0),(-7,9),(i32::MIN,i32::MAX)]{assert_eq!(run(pair.0,pair.1),(pair.0,1));}}
            #[test] fn repeated_calls_are_independent(){for n in -4..5{assert_eq!(run(n,n*10),(n,1));}}
        """,
        "reference": """
            use std::cell::Cell;
            fn safe(x:&i32,y:&mut Cell<i32>){y.set(1);let _load=*x;}
            fn main(){let x=4;let mut y=Cell::new(9);safe(&x,&mut y);assert_eq!((x,y.get()),(4,1));}
        """,
        "mutations": [
            mutation("y.set(1)", "y.set(2)", "Stores the wrong constant."),
            mutation("y.set(1);let _load=*x", "let _load=*x", "Drops the Cell write."),
            mutation("y.set(1)", "y.set(*x)", "Copies x into the Cell."),
            mutation("y.set(1)", "y.set(0)", "Trivializes the Cell value."),
        ],
    },
    {
        "id": "both_borrows__alias_through_mutation",
        "path": "both_borrows/alias_through_mutation.rs",
        "contract": "retarget changes the reference stored in x to point at target without changing target.",
        "symbols": ["retarget"],
        "profiles": STACK_TREE,
        "evidence": "The source assignment explicitly stores a reference derived from target into `*x`.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn points_to_target_and_preserves_it(){
                for value in [0u32,1,42,u32::MAX]{let dummy=9;let mut r=&dummy;let mut target=value;retarget(&mut r,&mut target);
                    assert_eq!(*r,value);assert_eq!(r as *const u32,&target as *const u32);assert_eq!(target,value);}
            }
            #[test] fn each_call_tracks_its_own_target(){let d=0;let(mut a,mut b)=(3,7);let mut r=&d;retarget(&mut r,&mut a);assert_eq!(*r,3);retarget(&mut r,&mut b);assert_eq!(*r,7);}
        """,
        "reference": """
            fn retarget(x:&mut &u32,target:&mut u32){unsafe{*x=&mut *(target as *mut _);}}
            fn main(){let dummy=0;let mut target=42;let mut r=&dummy;retarget(&mut r,&mut target);assert_eq!(*r,42);}
        """,
        "mutations": [
            mutation("unsafe{*x=&mut *(target as *mut _);}", "{}", "Leaves x pointing at its old target."),
            mutation("*x=&mut *(target as *mut _)", "*x=&0", "Retargets to an unrelated constant."),
            mutation("unsafe{*x=&mut *(target as *mut _);}", "unsafe{*target=0;*x=&mut *(target as *mut _);}", "Corrupts target while retargeting."),
            mutation("target as *mut _", "(target as *mut u32).wrapping_add(1)", "Creates an out-of-range target pointer."),
        ],
    },
    {
        "id": "both_borrows__illegal_write5",
        "path": "both_borrows/illegal_write5.rs",
        "contract": "callee stores 15 through a valid mutable i32 pointer.",
        "symbols": ["callee"],
        "profiles": STACK_TREE,
        "evidence": "The helper's only operation is the explicit raw-pointer store `*xraw = 15`.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn stores_fifteen(){for initial in [i32::MIN,-1,0,15,i32::MAX]{let mut x=initial;callee(&mut x);assert_eq!(x,15);}}
            #[test] fn repeated_calls_are_idempotent(){let mut x=7;for _ in 0..8{callee(&mut x);assert_eq!(x,15);}}
        """,
        "reference": """
            fn callee(xraw:*mut i32){unsafe{*xraw=15};}
            fn main(){let mut x=0;callee(&mut x);assert_eq!(x,15);}
        """,
        "mutations": [
            mutation("*xraw=15", "*xraw=14", "Stores the wrong value."),
            mutation("unsafe{*xraw=15};", "", "Drops the write."),
            mutation("*xraw=15", "*xraw=0", "Stores zero."),
            mutation("*xraw=15", "*xraw=(*xraw).wrapping_add(15)", "Adds instead of assigning."),
        ],
    },
    {
        "id": "both_borrows__illegal_write6",
        "path": "both_borrows/illegal_write6.rs",
        "contract": "On distinct valid inputs foo stores 1 in a, stores 2 through y, and returns 1.",
        "symbols": ["foo"],
        "profiles": STACK_TREE,
        "evidence": "The helper explicitly performs both stores and returns the value read from a.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn writes_both_distinct_targets_and_returns_one(){for pair in [(0,0),(9,8),(u32::MAX,u32::MAX-1)]{let(mut a,mut y)=pair;assert_eq!(foo(&mut a,&mut y),1);assert_eq!((a,y),(1,2));}}
            #[test] fn repeated_calls_are_stable(){let(mut a,mut y)=(7,9);for _ in 0..6{assert_eq!(foo(&mut a,&mut y),1);assert_eq!((a,y),(1,2));}}
        """,
        "reference": """
            fn foo(a:&mut u32,y:*mut u32)->u32{*a=1;let _b=&*a;unsafe{*y=2};*a}
            fn main(){let(mut a,mut y)=(0,0);assert_eq!(foo(&mut a,&mut y),1);assert_eq!((a,y),(1,2));}
        """,
        "mutations": [
            mutation("*a=1", "*a=3", "Stores the wrong value in a."),
            mutation("unsafe{*y=2}", "unsafe{*y=3}", "Stores the wrong value through y."),
            mutation(";*a}", ";0}", "Returns the wrong value."),
            mutation("unsafe{*y=2}", "{}", "Drops the y write."),
        ],
    },
    {
        "id": "both_borrows__invalidate_against_protector2",
        "path": "both_borrows/invalidate_against_protector2.rs",
        "contract": "On distinct valid inputs inner stores 0 through x and leaves the shared y value unchanged.",
        "symbols": ["inner"],
        "profiles": STACK_TREE,
        "evidence": "The helper writes zero through x and does not access y except through its protected argument.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn zeroes_x_and_preserves_distinct_y(){for pair in [(1,2),(-7,99),(i32::MAX,i32::MIN)]{let(mut x,y)=pair;inner(&mut x,&y);assert_eq!((x,y),(0,pair.1));}}
            #[test] fn repeated_calls_do_not_touch_y(){let(mut x,y)=(8,44);for _ in 0..6{x=8;inner(&mut x,&y);assert_eq!((x,y),(0,44));}}
        """,
        "reference": """
            fn inner(x:*mut i32,_y:&i32){unsafe{*x=0};}
            fn main(){let(mut x,y)=(5,7);inner(&mut x,&y);assert_eq!((x,y),(0,7));}
        """,
        "mutations": [
            mutation("*x=0", "*x=1", "Stores the wrong value."),
            mutation("unsafe{*x=0};", "", "Drops the store."),
            mutation("*x=0", "*x=*_y", "Copies y into x."),
            mutation("unsafe{*x=0};", "unsafe{*x=0;*x=(*x).wrapping_add(1)};", "Adds an extra mutation."),
        ],
    },
    {
        "id": "both_borrows__newtype_retagging",
        "path": "both_borrows/newtype_retagging.rs",
        "contract": "dealloc_while_running invokes its FnOnce callback exactly once while accepting Newtype by value.",
        "symbols": ["Newtype", "dealloc_while_running"],
        "profiles": STACK_TREE,
        "evidence": "The source body consists of the single callback invocation `dealloc()`.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn invokes_callback_once_and_preserves_referent(){for initial in [-1,0,42]{let mut value=initial;let count=std::cell::Cell::new(0);dealloc_while_running(Newtype(&mut value),||count.set(count.get()+1));assert_eq!(count.get(),1);assert_eq!(value,initial);}}
            #[test] fn independent_callbacks_each_run(){let(mut a,mut b)=(1,2);let count=std::cell::Cell::new(0);dealloc_while_running(Newtype(&mut a),||count.set(count.get()+1));dealloc_while_running(Newtype(&mut b),||count.set(count.get()+1));assert_eq!(count.get(),2);}
        """,
        "reference": """
            struct Newtype<'a>(#[allow(dead_code)] &'a mut i32);
            fn dealloc_while_running(_n:Newtype<'_>,dealloc:impl FnOnce()){dealloc();}
            fn main(){let mut x=0;let count=std::cell::Cell::new(0);dealloc_while_running(Newtype(&mut x),||count.set(1));assert_eq!(count.get(),1);}
        """,
        "mutations": [
            mutation("{dealloc();}", "{drop(dealloc);}", "Drops the callback without invoking it."),
            mutation("{dealloc();}", "{std::mem::forget(dealloc);}", "Forgets the callback."),
            mutation("{dealloc();}", "{panic!(\"skipped\")}", "Panics instead of invoking it."),
            mutation("{dealloc();}", "{dealloc();panic!(\"late\")}", "Panics after the callback."),
        ],
    },
    {
        "id": "both_borrows__newtype_pair_retagging",
        "path": "both_borrows/newtype_pair_retagging.rs",
        "contract": "dealloc_while_running invokes its FnOnce callback exactly once while accepting the scalar-pair Newtype by value and preserving its referenced i32.",
        "symbols": ["Newtype", "dealloc_while_running"],
        "profiles": STACK_TREE,
        "evidence": "The scalar-pair fixture's helper directly invokes `dealloc()` and otherwise ignores its Newtype value.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn invokes_once_and_preserves_pair(){for pair in [(-1,7),(0,0),(42,i32::MAX)]{let mut first=pair.0;let count=std::cell::Cell::new(0);dealloc_while_running(Newtype(&mut first,pair.1),||count.set(count.get()+1));assert_eq!(count.get(),1);assert_eq!(first,pair.0);}}
            #[test] fn callbacks_do_not_share_state(){let mut x=9;let count=std::cell::Cell::new(0);dealloc_while_running(Newtype(&mut x,3),||count.set(10));assert_eq!(count.get(),10);assert_eq!(x,9);}
        """,
        "reference": """
            struct Newtype<'a>(#[allow(dead_code)] &'a mut i32,#[allow(dead_code)] i32);
            fn dealloc_while_running(_n:Newtype<'_>,dealloc:impl FnOnce()){dealloc();}
            fn main(){let mut x=0;let count=std::cell::Cell::new(0);dealloc_while_running(Newtype(&mut x,4),||count.set(1));assert_eq!(count.get(),1);}
        """,
        "mutations": [
            mutation("{dealloc();}", "{drop(dealloc);}", "Drops the callback."),
            mutation("{dealloc();}", "{std::mem::forget(dealloc);}", "Forgets the callback."),
            mutation("{dealloc();}", "{panic!(\"skipped\")}", "Panics instead of invoking it."),
            mutation("{dealloc();}", "{dealloc();panic!(\"late\")}", "Panics after invoking it."),
        ],
    },
    {
        "id": "both_borrows__return_invalid_shr",
        "path": "both_borrows/return_invalid_shr.rs",
        "contract": "foo returns a shared reference to tuple field 1 without changing either field.",
        "symbols": ["foo"],
        "profiles": STACK_TREE,
        "evidence": "The intended returned reference is constructed from `.1`; the later whole-tuple overwrite is the invalidating action.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn selects_second_and_preserves_tuple(){for pair in [(0,1),(-7,9),(i32::MIN,i32::MAX)]{let mut value=pair;assert_eq!(*foo(&mut value),pair.1);assert_eq!(value,pair);}}
            #[test] fn repeated_borrows_are_stable(){let mut value=(4,5);for _ in 0..8{assert_eq!(*foo(&mut value),5);assert_eq!(value,(4,5));}}
        """,
        "reference": """
            fn foo(x:&mut(i32,i32))->&i32{&x.1}
            fn main(){let mut x=(1,2);assert_eq!(*foo(&mut x),2);assert_eq!(x,(1,2));}
        """,
        "mutations": [
            mutation("&x.1", "&x.0", "Selects field 0."),
            mutation("{&x.1}", "{x.1=0;&x.1}", "Changes field 1."),
            mutation("{&x.1}", "{x.0=0;&x.1}", "Changes field 0."),
            mutation("{&x.1}", "{x.1=x.1.wrapping_add(1);&x.1}", "Adds an observable mutation."),
        ],
    },
    {
        "id": "both_borrows__return_invalid_shr_option",
        "path": "both_borrows/return_invalid_shr_option.rs",
        "contract": "foo returns Some(shared reference to tuple field 1) without changing the tuple.",
        "symbols": ["foo"],
        "profiles": STACK_TREE,
        "evidence": "The source wraps a reference to `.1` in Some before the invalidating overwrite.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn returns_some_second_field(){for pair in [(0,1),(-7,9),(i32::MIN,i32::MAX)]{let mut value=pair;assert_eq!(foo(&mut value).copied(),Some(pair.1));assert_eq!(value,pair);}}
            #[test] fn never_returns_none_on_valid_input(){let mut value=(4,5);for _ in 0..8{assert_eq!(foo(&mut value),Some(&5));}}
        """,
        "reference": """
            fn foo(x:&mut(i32,i32))->Option<&i32>{Some(&x.1)}
            fn main(){let mut x=(1,2);assert_eq!(foo(&mut x),Some(&2));assert_eq!(x,(1,2));}
        """,
        "mutations": [
            mutation("Some(&x.1)", "Some(&x.0)", "Selects field 0."),
            mutation("Some(&x.1)", "None", "Drops the reference."),
            mutation("{Some(&x.1)}", "{x.1=0;Some(&x.1)}", "Changes field 1."),
            mutation("{Some(&x.1)}", "{x.0=0;Some(&x.1)}", "Changes field 0."),
        ],
    },
    {
        "id": "both_borrows__return_invalid_shr_tuple",
        "path": "both_borrows/return_invalid_shr_tuple.rs",
        "contract": "foo returns a one-tuple containing a shared reference to field 1 without changing the input tuple.",
        "symbols": ["foo"],
        "profiles": STACK_TREE,
        "evidence": "The fixture constructs `(reference to .1,)`; the later whole-tuple overwrite invalidates it.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn tuple_contains_second_field(){for pair in [(0,1),(-7,9),(i32::MIN,i32::MAX)]{let mut value=pair;let(r,)=foo(&mut value);assert_eq!(*r,pair.1);assert_eq!(value,pair);}}
            #[test] fn repeated_borrows_are_stable(){let mut value=(4,5);for _ in 0..8{let(r,)=foo(&mut value);assert_eq!(*r,5);}}
        """,
        "reference": """
            fn foo(x:&mut(i32,i32))->(&i32,){(&x.1,)}
            fn main(){let mut x=(1,2);assert_eq!(*foo(&mut x).0,2);assert_eq!(x,(1,2));}
        """,
        "mutations": [
            mutation("(&x.1,)", "(&x.0,)", "Selects field 0."),
            mutation("{(&x.1,)}", "{x.1=0;(&x.1,)}", "Changes field 1."),
            mutation("{(&x.1,)}", "{x.0=0;(&x.1,)}", "Changes field 0."),
            mutation("{(&x.1,)}", "{x.1=x.1.wrapping_sub(1);(&x.1,)}", "Adds an observable mutation."),
        ],
    },
    {
        "id": "tree_borrows__pass_invalid_mut",
        "path": "tree_borrows/pass_invalid_mut.rs",
        "contract": "foo stores 31 through a valid mutable i32 reference.",
        "symbols": ["foo"],
        "profiles": TREE,
        "evidence": "The helper body explicitly performs `*nope = 31`; the fixture invalidates the reference before the call.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn stores_thirty_one(){for initial in [i32::MIN,-1,0,31,i32::MAX]{let mut x=initial;foo(&mut x);assert_eq!(x,31);}}
            #[test] fn repeated_calls_are_idempotent(){let mut x=7;for _ in 0..8{foo(&mut x);assert_eq!(x,31);}}
        """,
        "reference": """
            fn foo(nope:&mut i32){*nope=31;}
            fn main(){let mut x=42;foo(&mut x);assert_eq!(x,31);}
        """,
        "mutations": [
            mutation("*nope=31", "*nope=30", "Stores the wrong value."),
            mutation("{*nope=31;}", "{}", "Drops the store."),
            mutation("*nope=31", "*nope=0", "Stores zero."),
            mutation("*nope=31", "*nope=nope.wrapping_add(31)", "Adds instead of assigning."),
        ],
    },
    {
        "id": "function_calls__arg_inplace_observe_during",
        "path": "function_calls/arg_inplace_observe_during.rs",
        "contract": "On distinct inputs change_arg may mutate its by-value local but only reads, and therefore preserves, the S pointee at ptr.",
        "symbols": ["S", "change_arg"],
        "profiles": ALL_ALIAS,
        "evidence": "The helper assigns only to local x and performs `ptr.read()` without a raw-pointer write.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn preserves_distinct_pointee(){for pair in [(0,1),(-7,9),(i32::MIN,i32::MAX)]{let mut observed=S(pair.1);change_arg(S(pair.0),&mut observed);assert_eq!(observed.0,pair.1);}}
            #[test] fn repeated_reads_leave_value(){let mut observed=S(77);for n in -4..5{change_arg(S(n),&mut observed);assert_eq!(observed.0,77);}}
        """,
        "reference": """
            pub struct S(i32);
            #[expect(unused_variables,unused_assignments)]
            fn change_arg(mut x:S,ptr:*mut S){x.0=0;unsafe{ptr.read()};}
            fn main(){let mut observed=S(7);change_arg(S(42),&mut observed);assert_eq!(observed.0,7);}
        """,
        "mutations": [
            mutation("unsafe{ptr.read()};", "unsafe{ptr.write(S(0))};", "Writes zero through ptr."),
            mutation("unsafe{ptr.read()};", "unsafe{ptr.write(S(1))};", "Writes one through ptr."),
            mutation("unsafe{ptr.read()};", "panic!(\"no read\");", "Panics instead of reading."),
            mutation("unsafe{ptr.read()};", "unsafe{ptr.read();ptr.write(S(2))};", "Adds a trailing pointer write."),
        ],
    },
    {
        "id": "function_calls__arg_inplace_locals_alias_ret",
        "path": "function_calls/arg_inplace_locals_alias_ret.rs",
        "contract": "callee is the identity function for S, returning the same wrapped i32 value passed by ownership.",
        "symbols": ["S", "callee"],
        "profiles": WEAK_STACK_TREE,
        "evidence": "The source helper body is exactly `x`, directly returning its argument.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn returns_every_input_unchanged(){for value in [i32::MIN,-1,0,42,i32::MAX]{assert_eq!(callee(S(value)).0,value);}}
            #[test] fn calls_are_independent(){assert_eq!((callee(S(7)).0,callee(S(9)).0),(7,9));}
        """,
        "reference": """
            #[allow(unused)] pub struct S(i32);
            fn callee(x:S)->S{x}
            fn main(){assert_eq!(callee(S(42)).0,42);}
        """,
        "mutations": [
            mutation("{x}", "{let _=x;S(0)}", "Returns zero."),
            mutation("{x}", "{S(x.0.wrapping_add(1))}", "Returns an off-by-one value."),
            mutation("{x}", "{S(-x.0)}", "Negates the value."),
            mutation("{x}", "{panic!(\"no return\")}", "Panics instead of returning."),
        ],
    },
    {
        "id": "tree_borrows__outside-range",
        "path": "tree_borrows/outside-range.rs",
        "contract": "With x backed by at least four bytes and y in a distinct four-byte allocation, stuff preserves x and writes 42 to y[1] and y[3] only.",
        "symbols": ["stuff"],
        "profiles": TREE,
        "evidence": "The helper writes exactly y offsets 1 and 3 while only reading x offsets 2 and 3.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn writes_documented_offsets_on_distinct_allocations(){for seed in [0u8,7,200]{let mut x=[seed,1,2,3];let before=x;let mut y=[9,8,7,6];unsafe{stuff(&mut x[0],y.as_mut_ptr())};assert_eq!(x,before);assert_eq!(y,[9,42,7,42]);}}
            #[test] fn repeated_calls_are_stable(){let mut x=[4,5,6,7];let mut y=[0;4];for _ in 0..5{unsafe{stuff(&mut x[0],y.as_mut_ptr())};assert_eq!(y,[0,42,0,42]);}}
        """,
        "reference": """
            unsafe fn stuff(x:&mut u8,y:*mut u8){let xraw=x as *mut u8;*y.add(1)=42;let _val=*xraw.add(2);let _val=*xraw.add(3);*y.add(3)=42;}
            fn main(){let mut x=[0u8,1,2,3];let mut y=[4u8,5,6,7];unsafe{stuff(&mut x[0],y.as_mut_ptr())};assert_eq!(y,[4,42,6,42]);}
        """,
        "mutations": [
            mutation("*y.add(1)=42", "*y.add(0)=42", "Writes the wrong first offset."),
            mutation("*y.add(1)=42", "*y.add(1)=41", "Writes the wrong first value."),
            mutation("*y.add(3)=42", "*y.add(2)=42", "Writes the wrong second offset."),
            mutation("*y.add(3)=42;", "", "Drops the second write."),
        ],
    },
    {
        "id": "tree_borrows__subtree_traversal_skipping_diagnostics",
        "path": "tree_borrows/subtree_traversal_skipping_diagnostics.rs",
        "contract": "On distinct valid pointers write_to_mut reads other_ptr, stores 42 through m, and does not modify the other pointee.",
        "symbols": ["write_to_mut"],
        "profiles": TREE_NO_GC,
        "evidence": "The source black-boxes a read through other_ptr and then explicitly assigns 42 through m.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn writes_m_and_preserves_other(){for pair in [(0u8,1u8),(7,9),(255,128)]{let(mut m,other)=pair;write_to_mut(&mut m,&other);assert_eq!((m,other),(42,pair.1));}}
            #[test] fn repeated_calls_are_stable(){let(mut m,other)=(0u8,77u8);for _ in 0..7{write_to_mut(&mut m,&other);assert_eq!((m,other),(42,77));}}
        """,
        "reference": """
            fn write_to_mut(m:&mut u8,other_ptr:*const u8){unsafe{std::hint::black_box(*other_ptr);};*m=42;}
            fn main(){let(mut m,other)=(0u8,7u8);write_to_mut(&mut m,&other);assert_eq!((m,other),(42,7));}
        """,
        "mutations": [
            mutation("*m=42", "*m=41", "Stores the wrong value."),
            mutation("*m=42;", "", "Drops the store."),
            mutation("*m=42", "*m=*other_ptr", "Copies the other value."),
            mutation("std::hint::black_box(*other_ptr)", "std::hint::black_box(*(other_ptr.wrapping_add(1)))", "Reads outside the valid other pointee."),
        ],
    },
    {
        "id": "tree_borrows__strongly-protected",
        "path": "tree_borrows/strongly-protected.rs",
        "contract": "inner invokes its function-pointer callback exactly once with a raw pointer to x, allowing a non-deallocating callback to mutate x.",
        "symbols": ["inner"],
        "profiles": TREE,
        "evidence": "The helper body calls `f(x)` once; the source comment permits mutation while forbidding deallocation.",
        "tests": """
            fn set_17(raw:*mut i32){unsafe{*raw=17;}} fn add_3(raw:*mut i32){unsafe{*raw+=3;}}
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn forwards_pointer_to_callback(){for initial in [-1,0,42]{let mut x=initial;inner(&mut x,set_17);assert_eq!(x,17);}}
            #[test] fn invokes_callback_once(){let mut x=10;inner(&mut x,add_3);assert_eq!(x,13);}
        """,
        "reference": """
            fn inner(x:&mut i32,f:fn(*mut i32)){f(x)}
            fn set_17(raw:*mut i32){unsafe{*raw=17;}}
            fn main(){let mut x=0;inner(&mut x,set_17);assert_eq!(x,17);}
        """,
        "mutations": [
            mutation("{f(x)}", "{}", "Drops the callback."),
            mutation("{f(x)}", "{f(std::ptr::null_mut())}", "Passes null instead of x."),
            mutation("{f(x)}", "{f(x);f(x)}", "Invokes the callback twice."),
            mutation("{f(x)}", "{*x=0;f(x)}", "Adds a mutation before the callback."),
        ],
    },
    {
        "id": "tree_borrows__protector-write-lazy",
        "path": "tree_borrows/protector-write-lazy.rs",
        "contract": "On distinct valid inputs the_other_function stores 42 in ref_to_fst_elem and returns ptr_to_vec unchanged.",
        "symbols": ["the_other_function"],
        "profiles": TREE,
        "evidence": "The source's final protected write is 42 and its pointer arithmetic advances once then subtracts once, returning the original address.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn writes_reference_and_returns_original_pointer(){for initial in [-1,0,9]{let mut protected=initial;let mut data=[10,20];let base=data.as_mut_ptr();let got=the_other_function(&mut protected,base);assert_eq!(protected,42);assert_eq!(got,base);unsafe{assert_eq!(*got,10);}}}
            #[test] fn repeated_calls_track_each_allocation(){let(mut a,mut b)=(1,2);let mut x=[3,4];let mut y=[5,6];assert_eq!(the_other_function(&mut a,x.as_mut_ptr()),x.as_mut_ptr());assert_eq!(the_other_function(&mut b,y.as_mut_ptr()),y.as_mut_ptr());assert_eq!((a,b),(42,42));}
        """,
        "reference": """
            fn the_other_function(ref_to_fst_elem:&mut i32,ptr_to_vec:*mut i32)->*mut i32{
                *ref_to_fst_elem=0;*ref_to_fst_elem=42;
                unsafe{(&mut *ptr_to_vec.wrapping_add(1))as *mut i32}.wrapping_sub(1)
            }
            fn main(){let mut protected=0;let mut data=[1,2];let base=data.as_mut_ptr();assert_eq!(the_other_function(&mut protected,base),base);assert_eq!(protected,42);}
        """,
        "mutations": [
            mutation("*ref_to_fst_elem=42", "*ref_to_fst_elem=41", "Stores the wrong final value."),
            mutation(".wrapping_sub(1)", "", "Returns the second-element pointer."),
            mutation("ptr_to_vec.wrapping_add(1)", "ptr_to_vec.wrapping_add(2)", "Forms an out-of-range intermediate pointer."),
            mutation("*ref_to_fst_elem=0;*ref_to_fst_elem=42", "*ref_to_fst_elem=0", "Drops the final protected write."),
        ],
    },
    {
        "id": "intrinsics__ptr_metadata_uninit_slice_data",
        "path": "intrinsics/ptr_metadata_uninit_slice_data.rs",
        "contract": "deref_meta returns the length metadata loaded from a valid pointer to an initialized i32 slice pointer.",
        "symbols": ["deref_meta"],
        "profiles": WEAK_STRICT,
        "evidence": "The custom MIR operation is `PtrMetadata(*p)`; the fixture failure leaves the data-pointer component uninitialized.",
        "tests": """
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn reports_every_valid_length(){let data=[10i32,20,30,40,50];for len in 0..=data.len(){let slice:*const[i32]=&data[..len];assert_eq!(unsafe{deref_meta(&slice)},len);}}
            #[test] fn ignores_slice_contents(){let a=[0i32;3];let b=[99i32;3];let pa:*const[i32]=&a;let pb:*const[i32]=&b;assert_eq!(unsafe{deref_meta(&pa)},3);assert_eq!(unsafe{deref_meta(&pb)},3);}
        """,
        "reference": """
            #![feature(ptr_metadata)]
            pub unsafe fn deref_meta(p:*const *const[i32])->usize{unsafe{std::ptr::metadata(*p)}}
            fn main(){let data=[1i32,2,3];let p:*const[i32]=&data;assert_eq!(unsafe{deref_meta(&p)},3);}
        """,
        "mutations": [
            mutation("unsafe{std::ptr::metadata(*p)}", "{0}", "Returns zero."),
            mutation("unsafe{std::ptr::metadata(*p)}", "{1}", "Returns one."),
            mutation("unsafe{std::ptr::metadata(*p)}", "unsafe{std::ptr::metadata(*p)+1}", "Over-reports length."),
            mutation("unsafe{std::ptr::metadata(*p)}", "unsafe{std::ptr::metadata(*p).saturating_sub(1)}", "Under-reports length."),
        ],
    },
    {
        "id": "layout_cycle",
        "path": "layout_cycle.rs",
        "contract": "For Tr implementations with a finite associated type layout, foo returns size_of::<S<T>>().",
        "symbols": ["S", "Tr", "foo"],
        "profiles": DEFAULT,
        "evidence": "The generic helper's source body is exactly `mem::size_of::<S<T>>()`; only the original recursive type choice causes a layout cycle.",
        "partial_reason": "The original entry point selects a recursively expanding associated type and fails layout computation. The held-out suite covers only finite `Tr` implementations, so it is a partial generic-domain contract rather than whole-program equivalence.",
        "tests": """
            impl Tr for u64{type I=u64;} struct Marker; impl Tr for Marker{type I=u64;}
            #[test] fn repaired_entry_completes(){main();}
            #[test] fn reports_finite_associated_layout_sizes(){assert_eq!(foo::<()>(),0);assert_eq!(foo::<u64>(),std::mem::size_of::<u64>());assert_eq!(foo::<Marker>(),std::mem::size_of::<u64>());}
            #[test] fn uses_associated_field_not_marker_size(){assert_eq!(std::mem::size_of::<Marker>(),0);assert_eq!(foo::<Marker>(),8);}
        """,
        "reference": """
            use std::mem;
            pub struct S<T:Tr>{pub f:<T as Tr>::I} pub trait Tr{type I:Tr;}
            impl<T:Tr> Tr for S<T>{type I=S<S<T>>;} impl Tr for (){type I=();}
            fn foo<T:Tr>()->usize{mem::size_of::<S<T>>()}
            fn main(){assert_eq!(foo::<()>(),0);}
        """,
        "mutations": [
            mutation("mem::size_of::<S<T>>()", "0", "Returns a constant zero."),
            mutation("mem::size_of::<S<T>>()", "mem::size_of::<T>()", "Measures T instead of S<T>."),
            mutation("mem::size_of::<S<T>>()", "mem::align_of::<S<T>>()", "Returns alignment instead of size."),
            mutation("mem::size_of::<S<T>>()", "mem::size_of::<S<T>>()+1", "Adds an off-by-one error."),
        ],
    },
]


def main() -> None:
    for spec in SPECS:
        write_case(spec)
    print(f"wrote {len(SPECS)} batch-3 cases")


if __name__ == "__main__":
    main()
