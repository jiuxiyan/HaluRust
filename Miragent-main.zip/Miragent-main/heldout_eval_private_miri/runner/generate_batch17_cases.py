#!/usr/bin/env python3
"""Materialize batch 17: valid scalar, reference, DST, and trait-object domains."""

from __future__ import annotations

from generate_batch2_cases import DEFAULT, mutation, write_case
from generate_batch6_cases import main_case


NO_STACK = [
    ("official-no-stacked", ["-Zmiri-disable-stacked-borrows"]),
    ("default-strict", []),
]
WEAK = [
    (
        "official-checks-disabled",
        ["-Zmiri-disable-alignment-check", "-Zmiri-disable-stacked-borrows", "-Zmiri-disable-validation"],
    ),
    ("default-strict", []),
]


def c(case_id, path, contract, symbols, profiles, evidence, reference, tests, muts):
    return main_case(case_id, path, contract, symbols, profiles, evidence, reference, tests, muts)


def entry_tests(extra: str) -> str:
    return (
        "#[test]fn repaired_entry_completes(){main();}"
        "#[test]fn repeats(){for _ in 0..6{main();}}"
        f"#[test]fn independent_valid_domain(){{{extra}}}"
    )


P = mutation("fn main(){", 'fn main(){panic!("main");', "Rejects the valid repaired entry.")
VALID_EVIDENCE = (
    "The source identifies the invalid representation or metadata boundary. "
    "The oracle keeps the same value category and operation while supplying a live, initialized, valid representation."
)


SPECS = [
    c(
        "validity__dangling_ref1",
        "validity/dangling_ref1.rs",
        "A shared i32 reference points to live storage and reads the stored value 16.",
        [],
        NO_STACK,
        VALID_EVIDENCE,
        "fn main(){let x=16i32;let r:&i32=&x;assert_eq!(*r,16);assert_eq!(r as*const i32,&x as*const i32);}",
        entry_tests("for x in [-1i32,0,42]{let r=&x;assert_eq!(*r,x);}"),
        [
            mutation("x=16i32", "x=15i32", "Changes the referenced value."),
            mutation("*r,16", "*r,15", "Claims the wrong value."),
            mutation("&x as*const i32", "std::ptr::null()", "Claims a null owner address."),
            P,
        ],
    ),
    c(
        "validity__dangling_ref2",
        "validity/dangling_ref2.rs",
        "An in-bounds offset-one pointer into [14,15] forms a live reference that reads 15.",
        [],
        NO_STACK,
        VALID_EVIDENCE,
        "fn main(){let x=[14i32,15];let p=x.as_ptr().wrapping_offset(1);let r=unsafe{&*p};assert_eq!(*r,15);assert_eq!(p,unsafe{x.as_ptr().add(1)});}",
        entry_tests("let x=[7i32,8,9];for i in 0..x.len(){let r=unsafe{&*x.as_ptr().add(i)};assert_eq!(*r,x[i]);}"),
        [
            mutation("[14i32,15]", "[14i32,16]", "Changes the offset element."),
            mutation("*r,15", "*r,16", "Claims the wrong value."),
            mutation("wrapping_offset(1)", "wrapping_offset(2)", "Moves beyond the allocation."),
            P,
        ],
    ),
    c(
        "validity__invalid_bool_op",
        "validity/invalid_bool_op.rs",
        "Boolean equality handles both valid encodings: false is not true and true is true.",
        [],
        WEAK,
        VALID_EVIDENCE,
        "fn main(){assert!(!std::hint::black_box(false).eq(&true));assert!(std::hint::black_box(true).eq(&true));}",
        entry_tests("for b in [false,true]{assert_eq!(b==std::hint::black_box(true),b);}"),
        [
            mutation("black_box(false)", "black_box(true)", "Changes the false input."),
            mutation("black_box(true).eq(&true)", "black_box(false).eq(&true)", "Changes the true input."),
            mutation("assert!(!std::hint", "assert!(std::hint", "Negates the false result."),
            P,
        ],
    ),
    c(
        "validity__invalid_bool_uninit",
        "validity/invalid_bool_uninit.rs",
        "MyUninit may expose a fully initialized one-element bool array containing true.",
        ["MyUninit"],
        DEFAULT,
        VALID_EVIDENCE,
        "#[allow(dead_code)]union MyUninit{init:(),uninit:[bool;1]}fn main(){let u=MyUninit{uninit:[true]};let b=unsafe{u.uninit};assert_eq!(b,[true]);}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn both_bool_values(){for b in [false,true]{let u=MyUninit{uninit:[b]};assert_eq!(unsafe{u.uninit},[b]);}}#[test]fn layout(){assert_eq!(std::mem::size_of::<MyUninit>(),1);}",
        [
            mutation("[true]};", "[false]};", "Changes the initialized boolean."),
            mutation("b,[true]", "b,[false]", "Claims the wrong boolean."),
            mutation("MyUninit{uninit:[true]}", "MyUninit{init:()}", "Reads an inactive uninitialized payload."),
            P,
        ],
    ),
    c(
        "validity__invalid_char_uninit",
        "validity/invalid_char_uninit.rs",
        "MyUninit may expose a fully initialized one-element char array containing 'A'.",
        ["MyUninit"],
        DEFAULT,
        VALID_EVIDENCE,
        "#[allow(dead_code)]union MyUninit{init:(),uninit:[char;1]}fn main(){let u=MyUninit{uninit:['A']};let b=unsafe{u.uninit};assert_eq!(b,['A']);}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn scalar_boundaries(){for c in ['\\0','A',char::MAX]{let u=MyUninit{uninit:[c]};assert_eq!(unsafe{u.uninit},[c]);}}#[test]fn layout(){assert_eq!(std::mem::size_of::<MyUninit>(),4);}",
        [
            mutation("['A']};", "['B']};", "Changes the initialized character."),
            mutation("b,['A']", "b,['B']", "Claims the wrong character."),
            mutation("MyUninit{uninit:['A']}", "MyUninit{init:()}", "Reads an inactive uninitialized payload."),
            P,
        ],
    ),
    c(
        "validity__invalid_enum_op",
        "validity/invalid_enum_op.rs",
        "Foo's valid variants A, B, C, and D remain distinct under discriminant inspection.",
        ["Foo"],
        WEAK,
        "The enum declaration provides exactly four valid variants; only the fabricated tag 42 is invalid.",
        "use std::mem;#[repr(C)]#[derive(Copy,Clone,Debug,PartialEq)]pub enum Foo{A,B,C,D}fn main(){let xs=[Foo::A,Foo::B,Foo::C,Foo::D];for i in 0..xs.len(){for j in 0..xs.len(){assert_eq!(mem::discriminant(&xs[i])==mem::discriminant(&xs[j]),i==j);}}}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn valid_variants_are_distinct(){assert_ne!(std::mem::discriminant(&Foo::A),std::mem::discriminant(&Foo::D));}#[test]fn layout(){assert_eq!(std::mem::size_of::<Foo>(),4);}",
        [
            mutation("Foo::A,Foo::B,Foo::C,Foo::D", "Foo::A,Foo::B,Foo::C,Foo::C", "Duplicates a variant."),
            mutation("i==j", "i!=j", "Negates the discriminant relation."),
            mutation("repr(C)", "repr(u8)", "Changes the declared representation."),
            P,
        ],
    ),
    c(
        "validity__invalid_fnptr_null",
        "validity/invalid_fnptr_null.rs",
        "A genuine fn(i32)->i32 pointer invokes target and maps 41 to 42.",
        ["target"],
        DEFAULT,
        VALID_EVIDENCE,
        "fn target(x:i32)->i32{x+1}fn main(){let f:fn(i32)->i32=target;assert_eq!(f(41),42);}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn valid_function_pointer(){let f:fn(i32)->i32=target;for x in [-1,0,41]{assert_eq!(f(x),x+1);}}#[test]fn pointer_is_non_null(){assert_ne!(target as usize,0);}",
        [
            mutation("x+1", "x+2", "Changes target behavior."),
            mutation("f(41),42", "f(41),43", "Claims the wrong result."),
            mutation("=target", "=|_|panic!(\"call\")", "Rejects invocation."),
            P,
        ],
    ),
    c(
        "validity__invalid_fnptr_uninit",
        "validity/invalid_fnptr_uninit.rs",
        "MyUninit exposes an initialized fn() pointer whose call stores the observable state 1.",
        ["MyUninit", "target"],
        DEFAULT,
        VALID_EVIDENCE,
        "use std::sync::atomic::{AtomicUsize,Ordering};static SEEN:AtomicUsize=AtomicUsize::new(0);#[allow(dead_code)]union MyUninit{init:(),uninit:[fn();1]}fn target(){SEEN.store(1,Ordering::SeqCst)}fn main(){SEEN.store(0,Ordering::SeqCst);let u=MyUninit{uninit:[target]};let f=unsafe{u.uninit}[0];f();assert_eq!(SEEN.load(Ordering::SeqCst),1);}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn initialized_pointer_calls(){main();}#[test]fn union_layout(){assert_eq!(std::mem::size_of::<MyUninit>(),std::mem::size_of::<fn()>());}",
        [
            mutation("store(1", "store(2", "Changes target state."),
            mutation("SeqCst),1", "SeqCst),2", "Claims the wrong state."),
            mutation("MyUninit{uninit:[target]}", "MyUninit{init:()}", "Reads an uninitialized function pointer."),
            P,
        ],
    ),
    c(
        "validity__invalid_int_op",
        "validity/invalid_int_op.rs",
        "An initialized one-element i32 array containing 41 supports addition by one and yields 42.",
        [],
        WEAK,
        VALID_EVIDENCE,
        "fn main(){let m=std::mem::MaybeUninit::new([41i32;1]);let i=unsafe{m.assume_init()};assert_eq!(i[0]+1,42);}",
        entry_tests("for x in [-1i32,0,41]{let m=std::mem::MaybeUninit::new([x]);let a=unsafe{m.assume_init()};assert_eq!(a[0]+1,x+1);}"),
        [
            mutation("[41i32;1]", "[40i32;1]", "Changes the initialized integer."),
            mutation("i[0]+1,42", "i[0]+1,41", "Claims the wrong result."),
            mutation("MaybeUninit::new([41i32;1])", "MaybeUninit::<[i32;1]>::uninit()", "Uses uninitialized integer storage."),
            P,
        ],
    ),
    c(
        "validity__match_binder_checks_validity1",
        "validity/match_binder_checks_validity1.rs",
        "The local uninhabited Void type is zero-sized; no Void value is materialized or matched.",
        [],
        DEFAULT,
        "The source declares the empty enum Void. Its independent well-defined property is its zero-sized layout.",
        "fn main(){enum Void{}assert_eq!(std::mem::size_of::<Void>(),0);}",
        entry_tests("enum Void{}assert_eq!(std::mem::size_of::<Void>(),0);"),
        [
            mutation("size_of::<Void>(),0", "size_of::<Void>(),1", "Claims the wrong size."),
            mutation("assert_eq!", "assert_ne!", "Negates the layout invariant."),
            mutation("enum Void{}", "enum Void{Value(u8)}", "Makes the type inhabited with nonzero layout."),
            P,
        ],
    ),
    c(
        "validity__ref_to_uninhabited1",
        "validity/ref_to_uninhabited1.rs",
        "The never type is zero-sized; no Box or reference to an uninhabited value is created.",
        [],
        DEFAULT,
        "The source explicitly names `!`; its layout is the only well-defined local type invariant before the invalid Box fabrication.",
        "#![feature(never_type)]fn main(){assert_eq!(std::mem::size_of::<!>(),0);}",
        entry_tests("assert_eq!(std::mem::size_of::<!>(),0);"),
        [
            mutation("size_of::<!>(),0", "size_of::<!>(),1", "Claims the wrong size."),
            mutation("assert_eq!", "assert_ne!", "Negates the layout invariant."),
            mutation("fn main(){assert_eq!", 'fn main(){panic!("never");assert_eq!', "Rejects the layout query."),
            P,
        ],
    ),
    c(
        "validity__ref_to_uninhabited2",
        "validity/ref_to_uninhabited2.rs",
        "The empty enum Void is zero-sized and uninhabited; no reference to (i32, Void) is constructed.",
        ["Void"],
        DEFAULT,
        "The source declares an empty enum Void; its type layout is independent of the invalid reference fabrication.",
        "enum Void{}fn main(){assert_eq!(std::mem::size_of::<Void>(),0);}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn void_layout(){assert_eq!(std::mem::size_of::<Void>(),0);}#[test]fn repeats(){for _ in 0..8{main();}}",
        [
            mutation("size_of::<Void>(),0", "size_of::<Void>(),1", "Claims the wrong size."),
            mutation("enum Void{}", "enum Void{Value(u8)}", "Makes Void inhabited with nonzero layout."),
            mutation("assert_eq!", "assert_ne!", "Negates the invariant."),
            P,
        ],
    ),
    c(
        "validity__too-big-slice",
        "validity/too-big-slice.rs",
        "A live three-byte allocation forms an in-bounds slice of length three with values 1, 2, and 3.",
        [],
        DEFAULT,
        "The fixture rejects usize::MAX metadata; the backing allocation and slice operation have a clear valid boundary at the allocation length.",
        "fn main(){let b=Box::new([1u8,2,3]);let s:&[u8]=&b[..];assert_eq!(s.len(),3);assert_eq!(s,[1,2,3]);}",
        entry_tests("let a=[0u8,1,2,3];for n in 0..=a.len(){let s=&a[..n];assert_eq!(s.len(),n);}"),
        [
            mutation("[1u8,2,3]", "[1u8,2,4]", "Changes the final byte."),
            mutation("s.len(),3", "s.len(),2", "Claims the wrong length."),
            mutation("s,[1,2,3]", "s,[1,2,4]", "Claims the wrong contents."),
            P,
        ],
    ),
    c(
        "validity__too-big-unsized",
        "validity/too-big-unsized.rs",
        "A live MySlice DST backed by two aligned words has prefix 7 and tail metadata length 3.",
        ["MySlice"],
        DEFAULT,
        "The source type and invalid oversized metadata are explicit. The oracle uses small metadata whose computed object fits entirely in aligned live storage.",
        "#[allow(dead_code)]struct MySlice{prefix:u64,tail:[u8]}fn main(){let storage=[7u64,0];let p:*const MySlice=unsafe{std::mem::transmute((storage.as_ptr()as*const u8,3usize))};let r=unsafe{&*p};assert_eq!(r.prefix,7);assert_eq!(r.tail.len(),3);assert!(std::mem::size_of_val(r)<=std::mem::size_of_val(&storage));}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn small_metadata_fits(){let storage=[9u64,0];let p:*const MySlice=unsafe{std::mem::transmute((storage.as_ptr()as*const u8,2usize))};let r=unsafe{&*p};assert_eq!(r.prefix,9);assert_eq!(r.tail.len(),2);assert!(std::mem::size_of_val(r)<=16);}#[test]fn repeats(){for _ in 0..5{main();}}",
        [
            mutation("3usize", "4usize", "Changes the tail metadata."),
            mutation("r.prefix,7", "r.prefix,8", "Claims the wrong prefix."),
            mutation("r.tail.len(),3", "r.tail.len(),4", "Claims the wrong tail length."),
            P,
        ],
    ),
    c(
        "validity__uninhabited_variant",
        "validity/uninhabited_variant.rs",
        "The valid inhabited E::V1 variant has discriminant zero and the repr(C) enum occupies four bytes.",
        ["E"],
        DEFAULT,
        "The source labels V1 discriminant 0 and V2(!) discriminant 1; the oracle constructs only V1.",
        "#![feature(never_type)]#[repr(C)]#[allow(dead_code)]enum E{V1,V2(!)}fn main(){let e=E::V1;assert!(matches!(e,E::V1));assert_eq!(std::mem::size_of::<E>(),4);}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn valid_variant(){let e=E::V1;assert!(matches!(e,E::V1));}#[test]fn layout(){assert_eq!(std::mem::size_of::<E>(),4);}",
        [
            mutation("matches!(e,E::V1)", "matches!(e,E::V2(_))", "Rejects the valid variant."),
            mutation("size_of::<E>(),4", "size_of::<E>(),1", "Claims the wrong size."),
            mutation("repr(C)", "repr(u8)", "Changes the representation."),
            P,
        ],
    ),
    c(
        "validity__uninit_float",
        "validity/uninit_float.rs",
        "An initialized one-element f32 array preserves 1.5 and its IEEE-754 bit pattern.",
        [],
        DEFAULT,
        VALID_EVIDENCE,
        "fn main(){let m=std::mem::MaybeUninit::new([1.5f32]);let v=unsafe{m.assume_init()};assert_eq!(v[0],1.5);assert_eq!(v[0].to_bits(),1.5f32.to_bits());}",
        entry_tests("for x in [0.0f32,-1.0,f32::INFINITY]{let a=std::mem::MaybeUninit::new([x]);let v=unsafe{a.assume_init()};assert_eq!(v[0].to_bits(),x.to_bits());}"),
        [
            mutation("[1.5f32]", "[2.5f32]", "Changes the initialized float."),
            mutation("v[0],1.5", "v[0],2.5", "Claims the wrong float."),
            mutation("MaybeUninit::new([1.5f32])", "MaybeUninit::<[f32;1]>::uninit()", "Uses uninitialized float storage."),
            P,
        ],
    ),
    c(
        "validity__uninit_integer",
        "validity/uninit_integer.rs",
        "An initialized one-element usize array preserves the value 7.",
        [],
        DEFAULT,
        VALID_EVIDENCE,
        "fn main(){let m=std::mem::MaybeUninit::new([7usize]);let v=unsafe{m.assume_init()};assert_eq!(v,[7]);}",
        entry_tests("for x in [0usize,1,usize::MAX]{let a=std::mem::MaybeUninit::new([x]);assert_eq!(unsafe{a.assume_init()},[x]);}"),
        [
            mutation("[7usize]", "[8usize]", "Changes the initialized integer."),
            mutation("v,[7]", "v,[8]", "Claims the wrong integer."),
            mutation("MaybeUninit::new([7usize])", "MaybeUninit::<[usize;1]>::uninit()", "Uses uninitialized integer storage."),
            P,
        ],
    ),
    c(
        "validity__uninit_raw_ptr",
        "validity/uninit_raw_ptr.rs",
        "An initialized one-element raw-pointer array points to a live byte 9 and dereferences to 9.",
        [],
        DEFAULT,
        VALID_EVIDENCE,
        "fn main(){let x=9u8;let m=std::mem::MaybeUninit::new([&x as*const u8]);let v=unsafe{m.assume_init()};assert_eq!(v[0],&x as*const u8);assert_eq!(unsafe{*v[0]},9);}",
        entry_tests("let x=7u8;let a=std::mem::MaybeUninit::new([&x as*const u8]);let p=unsafe{a.assume_init()}[0];assert_eq!(unsafe{*p},7);"),
        [
            mutation("x=9u8", "x=8u8", "Changes the pointee."),
            mutation("*v[0]},9", "*v[0]},8", "Claims the wrong pointee."),
            mutation("MaybeUninit::new([&x as*const u8])", "MaybeUninit::<[*const u8;1]>::uninit()", "Uses uninitialized pointer storage."),
            P,
        ],
    ),
    c(
        "validity__wrong-dyn-trait-generic",
        "validity/wrong-dyn-trait-generic.rs",
        "A live i32 viewed as dyn Trait<i32> retains its data address, size four, and alignment four.",
        ["Trait"],
        DEFAULT,
        "The source creates the valid `&dyn Trait<i32>` before transmuting it to a different generic instantiation. The oracle retains the matching instantiation.",
        "trait Trait<T>{}impl<T>Trait<T> for T{}fn main(){let x=7i32;let y:&dyn Trait<i32>=&x;assert_eq!(y as*const dyn Trait<i32>as*const u8,&x as*const i32 as*const u8);assert_eq!(std::mem::size_of_val(y),4);assert_eq!(std::mem::align_of_val(y),4);}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn matching_generic_object(){let x=9u32;let y:&dyn Trait<u32>=&x;assert_eq!(std::mem::size_of_val(y),4);assert_eq!(y as*const _ as*const u8,&x as*const _ as*const u8);}#[test]fn repeats(){for _ in 0..5{main();}}",
        [
            mutation("x=7i32", "x=7i64", "Changes the concrete layout."),
            mutation("size_of_val(y),4", "size_of_val(y),8", "Claims the wrong dynamic size."),
            mutation("align_of_val(y),4", "align_of_val(y),8", "Claims the wrong dynamic alignment."),
            P,
        ],
    ),
    c(
        "validity__wrong-dyn-trait",
        "validity/wrong-dyn-trait.rs",
        "A live i32 viewed through its matching dyn Debug vtable formats as 7 and retains size and alignment four.",
        [],
        DEFAULT,
        "The source mismatches dyn Send metadata with dyn Debug. The oracle constructs dyn Debug directly from the same concrete i32.",
        "use std::fmt;fn main(){let x=7i32;let y:&dyn fmt::Debug=&x;assert_eq!(format!(\"{:?}\",y),\"7\");assert_eq!(std::mem::size_of_val(y),4);assert_eq!(std::mem::align_of_val(y),4);}",
        entry_tests("let x=42i32;let y:&dyn std::fmt::Debug=&x;assert_eq!(format!(\"{:?}\",y),\"42\");"),
        [
            mutation("x=7i32", "x=8i32", "Changes the formatted value."),
            mutation('),"7"', '),"8"', "Claims the wrong Debug output."),
            mutation("size_of_val(y),4", "size_of_val(y),8", "Claims the wrong dynamic size."),
            P,
        ],
    ),
]


def main() -> None:
    for item in SPECS:
        write_case(item)
    print(f"wrote {len(SPECS)} batch-17 cases")


if __name__ == "__main__":
    main()
