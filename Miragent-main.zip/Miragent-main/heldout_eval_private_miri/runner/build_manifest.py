#!/usr/bin/env python3
"""Build the frozen 423-case Miri held-out dataset manifest.

The discovery rules intentionally mirror
``rustbrain_baseline.run_miri_fail_batch``.  They are copied here so the
private evaluator does not import or execute any repair-pipeline module.  The
canonical filter yields 438 candidates; the frozen dataset retains the 423
cases with implemented, high-confidence semantic oracles.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
import sys
from collections import Counter
from pathlib import Path


PRIVATE_ROOT = Path(__file__).resolve().parents[1]
PROJECT_ROOT = PRIVATE_ROOT.parent
DATASET_ROOT = PROJECT_ROOT / "miri_official_tests" / "fail"
MANIFEST_PATH = (
    PRIVATE_ROOT
    / "manifests"
    / "miri_dataset_manifest_v1.json"
)
EXPECTED_CANONICAL_CANDIDATES = 438
EXPECTED_DATASET_CASES = 423

SKIP_NAMES = {
    "no_main.rs",
    "miri_start_wrong_sig.rs",
    "rustc-error.rs",
    "rustc-error2.rs",
    "type-too-large.rs",
    "deny_lint.rs",
    "unsupported_foreign_function.rs",
    "extern-type-field-offset.rs",
    "extern_static.rs",
    "extern_static_in_const.rs",
    "extern_static_wrong_size.rs",
    "intrinsic_fallback_is_spec.rs",
}

SKIP_DIR_NAMES = {
    "fail-dep",
    "shims",
    "native-lib",
    "tls",
    "panic",
}

NON_STANDALONE_PATTERNS = [
    re.compile(r"#!\s*\[\s*no_main\s*\]"),
    re.compile(r"#!\s*\[\s*no_std\s*\]"),
    re.compile(r'^\s*extern\s+"[A-Za-z0-9-]+"\s*\{', re.MULTILINE),
    re.compile(r"#\[lang\s*=", re.MULTILINE),
    re.compile(r"#\[panic_handler\]"),
    re.compile(r"build_helper", re.MULTILINE),
]

ORACLE_CASES = {
    "box-cell-alias": ("P", "pilot_1"),
    "both_borrows__aliasing_mut1": ("P", "pilot_1"),
    "both_borrows__box_exclusive_violation1": ("P", "pilot_1"),
    "stacked_borrows__return_invalid_mut_option": ("P", "pilot_1"),
    "validity__invalid_char_cast": ("P", "pilot_1"),
    "both_borrows__shr_frozen_violation1": ("P", "batch_2"),
    "both_borrows__mut_exclusive_violation1": ("P", "batch_2"),
    "both_borrows__aliasing_mut2": ("P", "batch_2"),
    "both_borrows__aliasing_mut3": ("P", "batch_2"),
    "stacked_borrows__return_invalid_mut": ("P", "batch_2"),
    "stacked_borrows__return_invalid_mut_tuple": ("P", "batch_2"),
    "tree_borrows__return_invalid_mut": ("P", "batch_2"),
    "tree_borrows__write-during-2phase": ("P", "batch_2"),
    "dangling_pointers__dangling_pointer_to_raw_pointer": ("P", "batch_2"),
    "unaligned_pointers__field_requires_parent_struct_alignment": ("P", "batch_2"),
    "unaligned_pointers__field_requires_parent_struct_alignment2": ("P", "batch_2"),
    "function_calls__return_pointer_aliasing_read": ("P", "batch_2"),
    "function_calls__return_pointer_aliasing_write": ("P", "batch_2"),
    "function_calls__return_pointer_aliasing_write_tail_call": ("P", "batch_2"),
    "function_calls__arg_inplace_mutate": ("P", "batch_2"),
    "overlapping_assignment": ("P", "batch_2"),
    "coroutine-pinned-moved": ("P", "batch_2"),
    "dyn-upcast-trait-mismatch": ("P", "batch_2"),
    "intrinsics__ptr_metadata_uninit_slice_len": ("P", "batch_2"),
    "validity__wrong-dyn-trait-assoc-type": ("P", "batch_2"),
    "both_borrows__buggy_split_at_mut": ("P", "batch_3"),
    "both_borrows__aliasing_mut4": ("P", "batch_3"),
    "both_borrows__alias_through_mutation": ("P", "batch_3"),
    "both_borrows__illegal_write5": ("P", "batch_3"),
    "both_borrows__illegal_write6": ("P", "batch_3"),
    "both_borrows__invalidate_against_protector2": ("P", "batch_3"),
    "both_borrows__newtype_retagging": ("P", "batch_3"),
    "both_borrows__newtype_pair_retagging": ("P", "batch_3"),
    "both_borrows__return_invalid_shr": ("P", "batch_3"),
    "both_borrows__return_invalid_shr_option": ("P", "batch_3"),
    "both_borrows__return_invalid_shr_tuple": ("P", "batch_3"),
    "tree_borrows__pass_invalid_mut": ("P", "batch_3"),
    "function_calls__arg_inplace_observe_during": ("P", "batch_3"),
    "function_calls__arg_inplace_locals_alias_ret": ("P", "batch_3"),
    "tree_borrows__outside-range": ("P", "batch_3"),
    "tree_borrows__subtree_traversal_skipping_diagnostics": ("P", "batch_3"),
    "tree_borrows__strongly-protected": ("P", "batch_3"),
    "tree_borrows__protector-write-lazy": ("P", "batch_3"),
    "intrinsics__ptr_metadata_uninit_slice_data": ("P", "batch_3"),
    "layout_cycle": ("P", "batch_3"),
    "issue-miri-1112": ("P", "batch_4"),
    "unaligned_pointers__reference_to_packed": ("P", "batch_4"),
    "dangling_pointers__stack_temporary": ("P", "batch_4"),
    "stacked_borrows__interior_mut2": ("P", "batch_4"),
    "uninit__uninit_alloc_diagnostic_with_provenance": ("P", "batch_4"),
    "stacked_borrows__deallocate_against_protector1": ("P", "batch_4"),
    "tree_borrows__wildcard__strongly_protected_wildcard": ("P", "batch_4"),
    "enum-set-discriminant-niche-variant-wrong": ("P", "batch_4"),
    "data_race__local_variable_alloc_race": ("P", "batch_4"),
    "both_borrows__retag_data_race_write": ("P", "batch_4"),
    "function_calls__return_pointer_on_unwind": ("P", "batch_4"),
    "both_borrows__box_noalias_violation": ("P", "batch_4"),
    "data_race__mixed_size_read_write": ("P", "batch_4"),
    "validity__invalid_enum_cast": ("P", "batch_4"),
    "validity__invalid_char_match": ("P", "batch_4"),
    "stacked_borrows__illegal_read1": ("P", "batch_4"),
    "stacked_borrows__illegal_read2": ("P", "batch_4"),
    "stacked_borrows__invalidate_against_protector1": ("P", "batch_4"),
    "both_borrows__pass_invalid_shr_tuple": ("P", "batch_4"),
    "both_borrows__pass_invalid_shr_option": ("P", "batch_4"),
    "both_borrows__pass_invalid_shr": ("P", "batch_5"),
    "stacked_borrows__pass_invalid_mut": ("P", "batch_5"),
    "stacked_borrows__track_caller": ("P", "batch_5"),
    "stacked_borrows__illegal_read3": ("P", "batch_5"),
    "stacked_borrows__fnentry_invalidation2": ("P", "batch_5"),
    "stacked_borrows__pointer_smuggling": ("P", "batch_5"),
    "dangling_pointers__storage_dead_dangling": ("P", "batch_5"),
    "provenance__provenance_transmute": ("P", "batch_5"),
    "tree_borrows__repeated_foreign_read_lazy_conflicted": ("P", "batch_5"),
    "tail_calls__dangling-local-var": ("P", "batch_5"),
    "terminate-terminator": ("P", "batch_5"),
    "function_calls__arg_inplace_observe_after": ("P", "batch_5"),
    "function_calls__arg_inplace_locals_alias": ("P", "batch_5"),
    "dyn-call-trait-mismatch": ("P", "batch_5"),
    "validity__dyn-transmute-inner-binder": ("P", "batch_5"),
    "both_borrows__invalidate_against_protector3": ("P", "batch_5"),
    "function_pointers__deref_fn_ptr": ("P", "batch_5"),
    "function_pointers__fn_ptr_offset": ("P", "batch_5"),
    "stacked_borrows__fnentry_invalidation": ("P", "batch_5"),
    "tree_borrows__fnentry_invalidation": ("P", "batch_5"),
    "stacked_borrows__retag_data_race_read": ("P", "batch_6"),
    "data_race__mixed_size_read_read_write": ("P", "batch_6"),
    "data_race__mixed_size_write_write": ("P", "batch_6"),
    "enum-untagged-variant-invalid-encoding": ("P", "batch_6"),
    "uninit__padding-enum": ("P", "batch_6"),
    "uninit__padding-wide-ptr": ("P", "batch_6"),
    "uninit__padding-pair": ("P", "batch_6"),
    "uninit__transmute-pair-uninit": ("P", "batch_6"),
    "both_borrows__outdated_local": ("P", "batch_6"),
    "rc_as_ptr": ("P", "batch_6"),
    "stacked_borrows__zst_slice": ("P", "batch_6"),
    "unaligned_pointers__promise_alignment": ("P", "batch_6"),
    "tree_borrows__parent_read_freezes_raw_mut": ("P", "batch_6"),
    "modifying_constants": ("P", "batch_6"),
    "provenance__ptr_int_unexposed": ("P", "batch_6"),
    "match__only_inhabited_variant": ("P", "batch_6"),
    "match__closures__uninhabited-variant1": ("P", "batch_6"),
    "match__closures__uninhabited-variant2": ("P", "batch_6"),
    "provenance__int_copy_looses_provenance3": ("P", "batch_6"),
    "validity__invalid_char": ("P", "batch_6"),
    "validity__invalid_bool": ("P", "batch_7"),
    "validity__invalid_char_op": ("P", "batch_7"),
    "validity__invalid_enum_tag": ("P", "batch_7"),
    "validity__nonzero": ("P", "batch_7"),
    "validity__recursive-validity-box-bool": ("P", "batch_7"),
    "validity__recursive-validity-ref-bool": ("P", "batch_7"),
    "validity__match_binder_checks_validity2": ("P", "batch_7"),
    "validity__transmute_through_ptr": ("P", "batch_7"),
    "uninit__padding-struct-in-union": ("P", "batch_7"),
    "uninit__padding-struct": ("P", "batch_7"),
    "uninit__padding-union": ("P", "batch_7"),
    "function_pointers__abi_mismatch_array_vs_struct": ("P", "batch_7"),
    "function_pointers__abi_mismatch_int_vs_float": ("P", "batch_7"),
    "function_pointers__abi_mismatch_raw_pointer": ("P", "batch_7"),
    "function_pointers__abi_mismatch_repr_C": ("P", "batch_7"),
    "function_pointers__abi_mismatch_return_type": ("P", "batch_7"),
    "function_pointers__abi_mismatch_simple": ("P", "batch_7"),
    "function_pointers__abi_mismatch_too_few_args": ("P", "batch_7"),
    "function_pointers__abi_mismatch_too_many_args": ("P", "batch_7"),
    "function_pointers__abi_mismatch_vector": ("P", "batch_7"),
    "async-shared-mutable": ("P", "batch_8"),
    "branchless-select-i128-pointer": ("P", "batch_8"),
    "memleak_rc": ("P", "batch_8"),
    "static_memory_modification1": ("P", "batch_8"),
    "static_memory_modification2": ("P", "batch_8"),
    "static_memory_modification3": ("P", "batch_8"),
    "storage-live-dead-var": ("P", "batch_8"),
    "storage-live-resets-var": ("P", "batch_8"),
    "overlapping_assignment_aggregate": ("P", "batch_8"),
    "ptr_swap_nonoverlapping": ("P", "batch_8"),
    "read_from_trivial_switch": ("P", "batch_8"),
    "uninit__uninit-after-aggregate-assign": ("P", "batch_8"),
    "uninit__uninit_alloc_diagnostic": ("P", "batch_8"),
    "uninit__uninit_byte_read": ("P", "batch_8"),
    "match__closures__deref-in-pattern": ("P", "batch_8"),
    "match__closures__partial-pattern": ("P", "batch_8"),
    "match__single_variant": ("P", "batch_8"),
    "match__single_variant_uninit": ("P", "batch_8"),
    "zst_local_oob": ("P", "batch_8"),
    "validity__invalid_wide_raw": ("P", "batch_8"),
    "intrinsics__div-by-zero": ("P", "batch_9"),
    "intrinsics__rem-by-zero": ("P", "batch_9"),
    "intrinsics__exact_div1": ("P", "batch_9"),
    "intrinsics__exact_div2": ("P", "batch_9"),
    "intrinsics__exact_div3": ("P", "batch_9"),
    "intrinsics__exact_div4": ("P", "batch_9"),
    "intrinsics__unchecked_add1": ("P", "batch_9"),
    "intrinsics__unchecked_add2": ("P", "batch_9"),
    "intrinsics__unchecked_sub1": ("P", "batch_9"),
    "intrinsics__unchecked_sub2": ("P", "batch_9"),
    "intrinsics__unchecked_mul1": ("P", "batch_9"),
    "intrinsics__unchecked_mul2": ("P", "batch_9"),
    "intrinsics__unchecked_div1": ("P", "batch_9"),
    "intrinsics__unchecked_shl": ("P", "batch_9"),
    "intrinsics__unchecked_shl2": ("P", "batch_9"),
    "intrinsics__unchecked_shr": ("P", "batch_9"),
    "intrinsics__ctlz_nonzero": ("P", "batch_9"),
    "intrinsics__cttz_nonzero": ("P", "batch_9"),
    "intrinsics__disjoint_bitor": ("P", "batch_9"),
    "intrinsics__assume": ("P", "batch_9"),
    "intrinsics__float_to_int_32_inf1": ("P", "batch_10"),
    "intrinsics__float_to_int_32_infneg1": ("P", "batch_10"),
    "intrinsics__float_to_int_32_nan": ("P", "batch_10"),
    "intrinsics__float_to_int_32_nanneg": ("P", "batch_10"),
    "intrinsics__float_to_int_32_neg": ("P", "batch_10"),
    "intrinsics__float_to_int_32_too_big1": ("P", "batch_10"),
    "intrinsics__float_to_int_32_too_big2": ("P", "batch_10"),
    "intrinsics__float_to_int_32_too_small1": ("P", "batch_10"),
    "intrinsics__float_to_int_64_inf1": ("P", "batch_10"),
    "intrinsics__float_to_int_64_infneg1": ("P", "batch_10"),
    "intrinsics__float_to_int_64_infneg2": ("P", "batch_10"),
    "intrinsics__float_to_int_64_nan": ("P", "batch_10"),
    "intrinsics__float_to_int_64_neg": ("P", "batch_10"),
    "intrinsics__float_to_int_64_too_big1": ("P", "batch_10"),
    "intrinsics__float_to_int_64_too_big2": ("P", "batch_10"),
    "intrinsics__float_to_int_64_too_big3": ("P", "batch_10"),
    "intrinsics__float_to_int_64_too_big4": ("P", "batch_10"),
    "intrinsics__float_to_int_64_too_big5": ("P", "batch_10"),
    "intrinsics__float_to_int_64_too_big6": ("P", "batch_10"),
    "intrinsics__float_to_int_64_too_big7": ("P", "batch_10"),
    "intrinsics__float_to_int_64_too_small1": ("P", "batch_11"),
    "intrinsics__float_to_int_64_too_small2": ("P", "batch_11"),
    "intrinsics__float_to_int_64_too_small3": ("P", "batch_11"),
    "intrinsics__funnel_shl": ("P", "batch_11"),
    "intrinsics__funnel_shr": ("P", "batch_11"),
    "intrinsics__copy_overflow": ("P", "batch_11"),
    "intrinsics__copy_overlapping": ("P", "batch_11"),
    "intrinsics__copy_unaligned": ("P", "batch_11"),
    "intrinsics__ptr_offset_from_different_allocs": ("P", "batch_11"),
    "intrinsics__ptr_offset_from_different_ints": ("P", "batch_11"),
    "intrinsics__ptr_offset_from_oob": ("P", "batch_11"),
    "intrinsics__ptr_offset_from_unsigned_neg": ("P", "batch_11"),
    "intrinsics__ptr_offset_int_plus_int": ("P", "batch_11"),
    "intrinsics__ptr_offset_int_plus_ptr": ("P", "batch_11"),
    "intrinsics__ptr_offset_out_of_bounds": ("P", "batch_11"),
    "intrinsics__ptr_offset_out_of_bounds_neg": ("P", "batch_11"),
    "intrinsics__ptr_offset_out_of_bounds_neg2": ("P", "batch_11"),
    "intrinsics__ptr_offset_overflow": ("P", "batch_11"),
    "intrinsics__ptr_offset_unsigned_overflow": ("P", "batch_11"),
    "intrinsics__write_bytes_overflow": ("P", "batch_11"),
    "intrinsics__simd-div-by-zero": ("P", "batch_12"),
    "intrinsics__simd-div-overflow": ("P", "batch_12"),
    "intrinsics__simd-extract": ("P", "batch_12"),
    "intrinsics__simd-float-to-int": ("P", "batch_12"),
    "intrinsics__simd-funnel_shl-too-far": ("P", "batch_12"),
    "intrinsics__simd-funnel_shr-too-far": ("P", "batch_12"),
    "intrinsics__simd-gather": ("P", "batch_12"),
    "intrinsics__simd-reduce-invalid-bool": ("P", "batch_12"),
    "intrinsics__simd-rem-by-zero": ("P", "batch_12"),
    "intrinsics__simd-scatter": ("P", "batch_12"),
    "intrinsics__simd-select-invalid-bool": ("P", "batch_12"),
    "intrinsics__simd-shl-too-far": ("P", "batch_12"),
    "intrinsics__simd-shr-too-far": ("P", "batch_12"),
    "intrinsics__simd_masked_load_element_misaligned": ("P", "batch_12"),
    "intrinsics__simd_masked_load_vector_misaligned": ("P", "batch_12"),
    "intrinsics__simd_masked_store_element_misaligned": ("P", "batch_12"),
    "intrinsics__simd_masked_store_vector_misaligned": ("P", "batch_12"),
    "intrinsics__typed-swap-invalid-array": ("P", "batch_12"),
    "intrinsics__typed-swap-invalid-scalar": ("P", "batch_12"),
    "intrinsics__typed-swap-overlap": ("P", "batch_12"),
    "intrinsics__fast_math_both": ("P", "batch_13"),
    "intrinsics__fast_math_first": ("P", "batch_13"),
    "intrinsics__fast_math_result": ("P", "batch_13"),
    "intrinsics__fast_math_second": ("P", "batch_13"),
    "intrinsics__ptr_metadata_uninit_thin": ("P", "batch_13"),
    "intrinsics__zero_fn_ptr": ("P", "batch_13"),
    "dangling_pointers__dangling_pointer_deref": ("P", "batch_13"),
    "dangling_pointers__dangling_pointer_offset": ("P", "batch_13"),
    "dangling_pointers__dangling_pointer_project_underscore_let": ("P", "batch_13"),
    "dangling_pointers__dangling_pointer_project_underscore_let_type_annotation": ("P", "batch_13"),
    "dangling_pointers__dangling_pointer_project_underscore_match": ("P", "batch_13"),
    "dangling_pointers__dangling_primitive": ("P", "batch_13"),
    "dangling_pointers__deref-invalid-ptr": ("P", "batch_13"),
    "dangling_pointers__null_pointer_deref": ("P", "batch_13"),
    "dangling_pointers__null_pointer_write": ("P", "batch_13"),
    "dangling_pointers__out_of_bounds_project": ("P", "batch_13"),
    "dangling_pointers__out_of_bounds_read": ("P", "batch_13"),
    "dangling_pointers__out_of_bounds_read_neg_offset": ("P", "batch_13"),
    "dangling_pointers__out_of_bounds_write": ("P", "batch_13"),
    "dangling_pointers__wild_pointer_deref": ("P", "batch_13"),
    "data_race__alloc_read_race": ("P", "batch_14"),
    "data_race__alloc_write_race": ("P", "batch_14"),
    "data_race__atomic_read_na_write_race1": ("P", "batch_14"),
    "data_race__atomic_read_na_write_race2": ("P", "batch_14"),
    "data_race__atomic_write_na_read_race1": ("P", "batch_14"),
    "data_race__atomic_write_na_read_race2": ("P", "batch_14"),
    "data_race__atomic_write_na_write_race1": ("P", "batch_14"),
    "data_race__atomic_write_na_write_race2": ("P", "batch_14"),
    "data_race__dangling_thread_async_race": ("P", "batch_14"),
    "data_race__dangling_thread_race": ("P", "batch_14"),
    "data_race__dealloc_read_race_stack": ("P", "batch_14"),
    "data_race__dealloc_write_race_stack": ("P", "batch_14"),
    "data_race__enable_after_join_to_main": ("P", "batch_14"),
    "data_race__fence_after_load": ("P", "batch_14"),
    "data_race__local_variable_read_race": ("P", "batch_14"),
    "data_race__local_variable_write_race": ("P", "batch_14"),
    "data_race__mixed_size_read_write_read": ("P", "batch_14"),
    "data_race__read_write_race": ("P", "batch_14"),
    "data_race__read_write_race_stack": ("P", "batch_14"),
    "data_race__relax_acquire_race": ("P", "batch_14"),
    "data_race__release_seq_race": ("P", "batch_15"),
    "data_race__release_seq_race_same_thread": ("P", "batch_15"),
    "data_race__rmw_race": ("P", "batch_15"),
    "data_race__stack_pop_race": ("P", "batch_15"),
    "data_race__write_write_race": ("P", "batch_15"),
    "data_race__write_write_race_stack": ("P", "batch_15"),
    "concurrency__mutex-leak-move-deadlock": ("P", "batch_15"),
    "concurrency__read_only_atomic_cmpxchg": ("P", "batch_15"),
    "concurrency__read_only_atomic_load_acquire": ("P", "batch_15"),
    "concurrency__read_only_atomic_load_large": ("P", "batch_15"),
    "dangling_pointers__dangling_pointer_deref_match_never": ("P", "batch_15"),
    "dangling_pointers__deref_dangling_box": ("P", "batch_15"),
    "dangling_pointers__deref_dangling_ref": ("P", "batch_15"),
    "dangling_pointers__dyn_size": ("P", "batch_15"),
    "weak_memory__weak_uninit": ("P", "batch_15"),
    "intrinsics__uninit_uninhabited_type": ("P", "batch_15"),
    "match__all_variants_uninhabited": ("P", "batch_15"),
    "function_pointers__cast_box_int_to_fn_ptr": ("P", "batch_15"),
    "function_pointers__cast_int_to_fn_ptr": ("P", "batch_15"),
    "function_pointers__execute_memory": ("P", "batch_15"),
    "alloc__deallocate-bad-alignment": ("P", "batch_16"),
    "alloc__deallocate-bad-size": ("P", "batch_16"),
    "alloc__deallocate-twice": ("P", "batch_16"),
    "alloc__global_system_mixup": ("P", "batch_16"),
    "alloc__reallocate-bad-size": ("P", "batch_16"),
    "alloc__reallocate-change-alloc": ("P", "batch_16"),
    "alloc__reallocate-dangling": ("P", "batch_16"),
    "alloc__stack_free": ("P", "batch_16"),
    "unaligned_pointers__alignment": ("P", "batch_16"),
    "unaligned_pointers__atomic_unaligned": ("P", "batch_16"),
    "unaligned_pointers__drop_in_place": ("P", "batch_16"),
    "unaligned_pointers__dyn_alignment": ("P", "batch_16"),
    "unaligned_pointers__intptrcast_alignment_check": ("P", "batch_16"),
    "unaligned_pointers__promise_alignment_zero": ("P", "batch_16"),
    "unaligned_pointers__unaligned_ptr1": ("P", "batch_16"),
    "unaligned_pointers__unaligned_ptr2": ("P", "batch_16"),
    "unaligned_pointers__unaligned_ptr3": ("P", "batch_16"),
    "unaligned_pointers__unaligned_ptr4": ("P", "batch_16"),
    "unaligned_pointers__unaligned_ptr_zst": ("P", "batch_16"),
    "unaligned_pointers__unaligned_ref_addr_of": ("P", "batch_16"),
    "validity__dangling_ref1": ("P", "batch_17"),
    "validity__dangling_ref2": ("P", "batch_17"),
    "validity__invalid_bool_op": ("P", "batch_17"),
    "validity__invalid_bool_uninit": ("P", "batch_17"),
    "validity__invalid_char_uninit": ("P", "batch_17"),
    "validity__invalid_enum_op": ("P", "batch_17"),
    "validity__invalid_fnptr_null": ("P", "batch_17"),
    "validity__invalid_fnptr_uninit": ("P", "batch_17"),
    "validity__invalid_int_op": ("P", "batch_17"),
    "validity__match_binder_checks_validity1": ("P", "batch_17"),
    "validity__ref_to_uninhabited1": ("P", "batch_17"),
    "validity__ref_to_uninhabited2": ("P", "batch_17"),
    "validity__too-big-slice": ("P", "batch_17"),
    "validity__too-big-unsized": ("P", "batch_17"),
    "validity__uninhabited_variant": ("P", "batch_17"),
    "validity__uninit_float": ("P", "batch_17"),
    "validity__uninit_integer": ("P", "batch_17"),
    "validity__uninit_raw_ptr": ("P", "batch_17"),
    "validity__wrong-dyn-trait-generic": ("P", "batch_17"),
    "validity__wrong-dyn-trait": ("P", "batch_17"),
    "provenance__int_copy_looses_provenance0": ("P", "batch_18"),
    "provenance__int_copy_looses_provenance1": ("P", "batch_18"),
    "provenance__int_copy_looses_provenance2": ("P", "batch_18"),
    "provenance__mix-ptrs1": ("P", "batch_18"),
    "provenance__mix-ptrs2": ("P", "batch_18"),
    "provenance__pointer_partial_overwrite": ("P", "batch_18"),
    "provenance__ptr_copy_loses_partial_provenance0": ("P", "batch_18"),
    "provenance__ptr_copy_loses_partial_provenance1": ("P", "batch_18"),
    "provenance__ptr_invalid": ("P", "batch_18"),
    "provenance__ptr_invalid_offset": ("P", "batch_18"),
    "provenance__strict_provenance_cast": ("P", "batch_18"),
    "memleak": ("P", "batch_18"),
    "memleak_no_backtrace": ("P", "batch_18"),
    "never_match_never": ("P", "batch_18"),
    "never_say_never": ("P", "batch_18"),
    "never_transmute_humans": ("P", "batch_18"),
    "never_transmute_void": ("P", "batch_18"),
    "tls_macro_leak": ("P", "batch_18"),
    "tls_static_leak": ("P", "batch_18"),
    "dyn-upcast-nop-wrong-trait": ("P", "batch_18"),
    "stacked_borrows__disable_mut_does_not_merge_srw": ("P", "batch_19"),
    "stacked_borrows__drop_in_place_retag": ("P", "batch_19"),
    "stacked_borrows__exposed_only_ro": ("P", "batch_19"),
    "stacked_borrows__illegal_dealloc1": ("P", "batch_19"),
    "stacked_borrows__illegal_read4": ("P", "batch_19"),
    "stacked_borrows__illegal_read5": ("P", "batch_19"),
    "stacked_borrows__illegal_read6": ("P", "batch_19"),
    "stacked_borrows__illegal_read7": ("P", "batch_19"),
    "stacked_borrows__illegal_read8": ("P", "batch_19"),
    "stacked_borrows__illegal_write2": ("P", "batch_19"),
    "stacked_borrows__illegal_write3": ("P", "batch_19"),
    "stacked_borrows__illegal_write4": ("P", "batch_19"),
    "stacked_borrows__interior_mut1": ("P", "batch_19"),
    "stacked_borrows__load_invalid_mut": ("P", "batch_19"),
    "stacked_borrows__raw_tracking": ("P", "batch_19"),
    "stacked_borrows__retag_data_race_protected_read": ("P", "batch_19"),
    "stacked_borrows__shared_rw_borrows_are_weak1": ("P", "batch_19"),
    "stacked_borrows__shared_rw_borrows_are_weak2": ("P", "batch_19"),
    "stacked_borrows__static_memory_modification": ("P", "batch_19"),
    "stacked_borrows__transmute-is-no-escape": ("P", "batch_19"),
    "both_borrows__illegal_read_despite_exposed1": ("P", "batch_20"),
    "both_borrows__illegal_read_despite_exposed2": ("P", "batch_20"),
    "both_borrows__illegal_write1": ("P", "batch_20"),
    "both_borrows__illegal_write_despite_exposed1": ("P", "batch_20"),
    "both_borrows__issue-miri-1050-1": ("P", "batch_20"),
    "both_borrows__issue-miri-1050-2": ("P", "batch_20"),
    "both_borrows__load_invalid_shr": ("P", "batch_20"),
    "both_borrows__mut_exclusive_violation2": ("P", "batch_20"),
    "both_borrows__shr_frozen_violation2": ("P", "batch_20"),
    "stacked_borrows__drop_in_place_protector": ("P", "batch_20"),
    "stacked_borrows__unescaped_local": ("P", "batch_20"),
    "stacked_borrows__unescaped_static": ("P", "batch_20"),
    "const-ub-checks": ("P", "batch_20"),
    "erroneous_const2": ("P", "batch_20"),
    "reading_half_a_pointer": ("P", "batch_20"),
    "validity__box-custom-alloc-dangling-ptr": ("P", "batch_20"),
    "validity__box-custom-alloc-invalid-alloc": ("P", "batch_20"),
    "validity__cast_fn_ptr_invalid_callee_arg": ("P", "batch_20"),
    "tail_calls__cc-mismatch": ("P", "batch_20"),
    "tail_calls__signature-mismatch-arg": ("P", "batch_20"),
    "tree_borrows__alternate-read-write": ("P", "batch_21"),
    "tree_borrows__cell-inside-struct": ("P", "batch_21"),
    "tree_borrows__error-range": ("P", "batch_21"),
    "tree_borrows__frozen-lazy-write-to-surrounding": ("P", "batch_21"),
    "tree_borrows__reserved__cell-protected-write": ("P", "batch_21"),
    "tree_borrows__reserved__int-protected-write": ("P", "batch_21"),
    "tree_borrows__wildcard__cross_tree_from_main": ("P", "batch_21"),
    "tree_borrows__wildcard__cross_tree_update_main": ("P", "batch_21"),
    "tree_borrows__wildcard__cross_tree_update_main_invalid_exposed": ("P", "batch_21"),
    "tree_borrows__wildcard__cross_tree_update_main_invalid_exposed2": ("P", "batch_21"),
    "tree_borrows__wildcard__cross_tree_update_newer": ("P", "batch_21"),
    "tree_borrows__wildcard__cross_tree_update_newer_exposed": ("P", "batch_21"),
    "tree_borrows__wildcard__cross_tree_update_older": ("P", "batch_21"),
    "tree_borrows__wildcard__cross_tree_update_older_invalid_exposed": ("P", "batch_21"),
    "tree_borrows__wildcard__cross_tree_update_older_invalid_exposed2": ("P", "batch_21"),
    "tree_borrows__wildcard__multi_exposed_child": ("P", "batch_21"),
    "tree_borrows__wildcard__multi_exposed_child_unique_writer": ("P", "batch_21"),
    "tree_borrows__wildcard__multi_exposed_siblings_disable": ("P", "batch_21"),
    "tree_borrows__wildcard__multi_exposed_siblings_foreign": ("P", "batch_21"),
    "tree_borrows__wildcard__multi_exposed_siblings_local": ("P", "batch_21"),
    "tree_borrows__reservedim_spurious_write": ("P", "batch_22"),
    "tree_borrows__spurious_read": ("P", "batch_22"),
    "tree_borrows__wildcard__dealloc": ("P", "batch_22"),
    "tree_borrows__wildcard__gc": ("P", "batch_22"),
    "tree_borrows__wildcard__multi_exposed_siblings_unique_writer": ("P", "batch_22"),
    "tree_borrows__wildcard__protected_wildcard": ("P", "batch_22"),
    "tree_borrows__wildcard__protector_conflicted": ("P", "batch_22"),
    "tree_borrows__wildcard__protector_release": ("P", "batch_22"),
    "tree_borrows__wildcard__protector_release2": ("P", "batch_22"),
    "tree_borrows__wildcard__single_exposed_disable": ("P", "batch_22"),
    "tree_borrows__wildcard__single_exposed_foreign": ("P", "batch_22"),
    "tree_borrows__wildcard__single_exposed_local": ("P", "batch_22"),
    "tree_borrows__wildcard__single_exposed_only_ro": ("P", "batch_22"),
    "tree_borrows__wildcard__subtree_internal_relatedness": ("P", "batch_22"),
    "tree_borrows__wildcard__subtree_internal_relatedness_wildcard": ("P", "batch_22"),
    "validity__cast_fn_ptr_invalid_callee_ret": ("P", "batch_22"),
    "validity__cast_fn_ptr_invalid_caller_arg": ("P", "batch_22"),
    "validity__cast_fn_ptr_invalid_caller_ret": ("P", "batch_22"),
}


def _command_output(command: list[str]) -> str:
    try:
        result = subprocess.run(
            command,
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True,
            timeout=20,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return "unavailable"
    output = (result.stdout or result.stderr).strip().splitlines()
    return output[0] if output else "unavailable"


def _last_dataset_commit() -> str:
    try:
        result = subprocess.run(
            ["git", "log", "-1", "--format=%H", "--", str(DATASET_ROOT)],
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True,
            timeout=20,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return "unavailable"
    return result.stdout.strip() or "unavailable"


def _repository_head() -> str:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True,
            timeout=20,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return "unavailable"
    return result.stdout.strip() or "unavailable"


def _is_runnable(path: Path, source: str) -> bool:
    if path.name in SKIP_NAMES:
        return False
    if any(part in SKIP_DIR_NAMES for part in path.relative_to(DATASET_ROOT).parts):
        return False
    if re.search(r"\bfn\s+main\s*\(", source) is None:
        return False
    return not any(pattern.search(source) for pattern in NON_STANDALONE_PATTERNS)


def _directive_values(source: str, name: str) -> list[str]:
    pattern = re.compile(rf"^\s*//\s*@\s*{re.escape(name)}:\s*(.+)$")
    values: list[str] = []
    for line in source.splitlines():
        match = pattern.match(line)
        if match:
            values.extend(match.group(1).split())
    return values


def _parse_directives(source: str) -> dict:
    compile_flags: list[str] = []
    revision_compile_flags: dict[str, list[str]] = {}
    generic = re.compile(r"^\s*//\s*@\s*compile-flags:\s*(.+)$")
    revised = re.compile(
        r"^\s*//\s*@\[(?P<revision>[^\]]+)\]\s*compile-flags:\s*(?P<flags>.+)$"
    )
    for line in source.splitlines():
        match = generic.match(line)
        if match:
            compile_flags.extend(match.group(1).split())
            continue
        match = revised.match(line)
        if match:
            revision_compile_flags.setdefault(match.group("revision"), []).extend(
                match.group("flags").split()
            )
    return {
        "revisions": _directive_values(source, "revisions"),
        "compile_flags": compile_flags,
        "revision_compile_flags": dict(sorted(revision_compile_flags.items())),
        "only_targets": _directive_values(source, "only-target"),
        "ignore_targets": _directive_values(source, "ignore-target"),
    }


def build_manifest() -> dict:
    raw_paths = sorted(DATASET_ROOT.rglob("*.rs"))
    candidate_cases: list[dict] = []
    for path in raw_paths:
        source = path.read_text(encoding="utf-8")
        if not _is_runnable(path, source):
            continue
        relative = path.relative_to(DATASET_ROOT)
        case_id = "__".join(relative.with_suffix("").parts)
        category = relative.parts[0] if len(relative.parts) > 1 else "_root"
        oracle_level, selection_batch = ORACLE_CASES.get(
            case_id, ("N", None)
        )
        oracle_case_dir = PRIVATE_ROOT / "cases" / case_id
        oracle_status = (
            "implemented"
            if (oracle_case_dir / "case.toml").is_file()
            else ("selected" if selection_batch else "censused")
        )
        candidate_cases.append(
            {
                "case_id": case_id,
                "category": category,
                "rel_path": relative.as_posix(),
                "sha256": hashlib.sha256(source.encode("utf-8")).hexdigest(),
                "size_bytes": len(source.encode("utf-8")),
                "directives": _parse_directives(source),
                "oracle": {
                    "level": oracle_level,
                    "status": oracle_status,
                    "selection_batch": selection_batch,
                    "case_dir": (
                        f"cases/{case_id}" if selection_batch else None
                    ),
                },
            }
        )

    candidate_ids = {case["case_id"] for case in candidate_cases}
    missing_oracles = sorted(set(ORACLE_CASES) - candidate_ids)
    if missing_oracles:
        raise RuntimeError(
            "oracle cases are absent from the canonical candidate pool: "
            + ", ".join(missing_oracles)
        )
    cases = [
        case for case in candidate_cases if case["case_id"] in ORACLE_CASES
    ]
    excluded_case_ids = sorted(candidate_ids - set(ORACLE_CASES))
    category_counts = Counter(case["category"] for case in cases)
    return {
        "schema_version": 1,
        "manifest_id": "miri_dataset_manifest_v1",
        "generated_on": "2026-07-30",
        "dataset": {
            "name": "Miri official fail tests with held-out semantic oracles",
            "root": "miri_official_tests/fail",
            "raw_rs_count": len(raw_paths),
            "canonical_candidate_count": len(candidate_cases),
            "expected_canonical_candidate_count": EXPECTED_CANONICAL_CANDIDATES,
            "runnable_case_count": len(cases),
            "expected_runnable_case_count": EXPECTED_DATASET_CASES,
            "selection_rule": (
                "canonical benchmark filter plus an implemented "
                "high-confidence held-out semantic oracle"
            ),
            "excluded_without_high_confidence_oracle_count": len(
                excluded_case_ids
            ),
            "excluded_case_ids": excluded_case_ids,
            "last_dataset_commit": _last_dataset_commit(),
            "repository_head_at_freeze": _repository_head(),
            "canonical_filter_source": (
                "rustbrain_baseline/run_miri_fail_batch.py:44-96"
            ),
            "category_counts": dict(sorted(category_counts.items())),
        },
        "toolchain_observed_at_freeze": {
            "rustc": _command_output(["rustc", "--version"]),
            "cargo": _command_output(["cargo", "--version"]),
            "miri": _command_output(["cargo", "+nightly", "miri", "--version"]),
            "runner_toolchain": "nightly",
            "note": (
                "For final paper runs replace the moving nightly alias with an "
                "explicit rustup nightly date matching the recorded Miri build."
            ),
        },
        "isolation": {
            "visible_to_repair": False,
            "repair_feedback_allowed": False,
            "evaluation_phase": "post-hoc final patch only",
        },
        "cases": cases,
    }


def _serialized(manifest: dict) -> str:
    return json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=False) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--check",
        action="store_true",
        help="verify that the checked-in manifest is current",
    )
    parser.add_argument(
        "--stdout",
        action="store_true",
        help="print instead of writing the manifest",
    )
    args = parser.parse_args()

    manifest = build_manifest()
    count = manifest["dataset"]["runnable_case_count"]
    candidate_count = manifest["dataset"]["canonical_candidate_count"]
    if candidate_count != EXPECTED_CANONICAL_CANDIDATES:
        print(
            f"error: canonical filter produced {candidate_count} candidates, "
            f"expected {EXPECTED_CANONICAL_CANDIDATES}",
            file=sys.stderr,
        )
        return 2
    if count != EXPECTED_DATASET_CASES:
        print(
            f"error: frozen oracle-backed dataset contains {count} cases, "
            f"expected {EXPECTED_DATASET_CASES}",
            file=sys.stderr,
        )
        return 2

    content = _serialized(manifest)
    if args.check:
        if not MANIFEST_PATH.exists():
            print(f"error: missing {MANIFEST_PATH}", file=sys.stderr)
            return 1
        if MANIFEST_PATH.read_text(encoding="utf-8") != content:
            print("error: frozen manifest differs from regenerated data", file=sys.stderr)
            return 1
        print(f"manifest OK: {count} cases")
        return 0

    if args.stdout:
        sys.stdout.write(content)
        return 0

    MANIFEST_PATH.parent.mkdir(parents=True, exist_ok=True)
    MANIFEST_PATH.write_text(content, encoding="utf-8")
    print(f"wrote {MANIFEST_PATH} ({count} cases)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
