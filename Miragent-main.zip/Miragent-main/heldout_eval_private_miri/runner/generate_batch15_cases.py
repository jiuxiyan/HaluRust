#!/usr/bin/env python3
"""Materialize batch 15: remaining ordered concurrency and valid indirections."""

from __future__ import annotations

from generate_batch2_cases import DEFAULT, mutation, write_case
from generate_batch6_cases import main_case


DATA = [("official-deterministic",["-Zmiri-deterministic-concurrency","-Zmiri-disable-stacked-borrows"]),("default-strict",[])]
NO_STACK = [("official-no-stacked",["-Zmiri-disable-stacked-borrows"]),("default-strict",[])]
NO_VALID = [("official-no-validation",["-Zmiri-disable-validation"]),("default-strict",[])]
WEAK = [("official-fixed",["-Zmiri-ignore-leaks","-Zmiri-fixed-schedule"]),("default-strict",[])]
EVIL = "#[derive(Copy,Clone)]struct EvilSend<T>(pub T);unsafe impl<T>Send for EvilSend<T>{}unsafe impl<T>Sync for EvilSend<T>{}"


def c(case_id, path, contract, symbols, profiles, evidence, reference, tests, muts):
    return main_case(case_id,path,contract,symbols,profiles,evidence,reference,tests,muts)


def tests(extra):
    return "#[test]fn repaired_entry_completes(){main();}#[test]fn repeats(){for _ in 0..5{main();}}"+f"#[test]fn independent_valid_domain(){{{extra}}}"


P = mutation("fn main(){","fn main(){panic!(\"main\");","Panics on valid behavior.")
DATA_EVIDENCE = "The source lists the intended atomic/non-atomic effects and ordering; the oracle preserves those values while adding join or an explicit happens-before edge."


SPECS = [
    c("data_race__release_seq_race","data_race/release_seq_race.rs","A joined Release publication makes data=1 visible before later synchronization states 2 and 3.",["EvilSend"],DATA,DATA_EVIDENCE,
      EVIL+"use std::sync::{Arc,atomic::{AtomicU32,Ordering}};fn main(){let data=Arc::new(AtomicU32::new(0));let sync=Arc::new(AtomicU32::new(0));let(d,s)=(data.clone(),sync.clone());std::thread::spawn(move||{d.store(1,Ordering::Relaxed);s.store(1,Ordering::Release)}).join().unwrap();sync.store(2,Ordering::Relaxed);sync.store(3,Ordering::Release);assert_eq!(sync.load(Ordering::Acquire),3);assert_eq!(data.load(Ordering::Relaxed),1);}",
      tests("let a=std::sync::atomic::AtomicU32::new(0);a.store(1,std::sync::atomic::Ordering::Release);assert_eq!(a.load(std::sync::atomic::Ordering::Acquire),1);"),
      [mutation("d.store(1","d.store(2","Changes data."),mutation("),3",") ,2","Wrong sync."),mutation("data.load(Ordering::Relaxed),1","data.load(Ordering::Relaxed),2","Wrong data."),P]),
    c("data_race__release_seq_race_same_thread","data_race/release_seq_race_same_thread.rs","After joining the publisher, synchronization state 2 and data value 1 are both observed.",["EvilSend"],DATA,DATA_EVIDENCE,
      EVIL+"use std::sync::{Arc,atomic::{AtomicU32,Ordering}};fn main(){let data=Arc::new(AtomicU32::new(0));let sync=Arc::new(AtomicU32::new(0));let(d,s)=(data.clone(),sync.clone());std::thread::spawn(move||{d.store(1,Ordering::Relaxed);s.store(1,Ordering::Release);s.store(2,Ordering::Relaxed)}).join().unwrap();assert_eq!(sync.load(Ordering::Acquire),2);assert_eq!(data.load(Ordering::Relaxed),1);}",
      tests("let a=std::sync::atomic::AtomicU32::new(0);a.store(2,std::sync::atomic::Ordering::Release);assert_eq!(a.load(std::sync::atomic::Ordering::Acquire),2);"),
      [mutation("d.store(1","d.store(2","Changes data."),mutation("s.store(2","s.store(3","Changes sync."),mutation("data.load(Ordering::Relaxed),1","data.load(Ordering::Relaxed),2","Wrong data."),P]),
    c("data_race__rmw_race","data_race/rmw_race.rs","A joined publisher stores data=1; the subsequent RMW changes sync 1→2 and the final store leaves 3.",["EvilSend"],DATA,DATA_EVIDENCE,
      EVIL+"use std::sync::{Arc,atomic::{AtomicU32,Ordering}};fn main(){let data=Arc::new(AtomicU32::new(0));let sync=Arc::new(AtomicU32::new(0));let(d,s)=(data.clone(),sync.clone());std::thread::spawn(move||{d.store(1,Ordering::Relaxed);s.store(1,Ordering::Release)}).join().unwrap();assert_eq!(sync.swap(2,Ordering::AcqRel),1);assert_eq!(sync.load(Ordering::Acquire),2);sync.store(3,Ordering::Release);assert_eq!(sync.load(Ordering::Acquire),3);assert_eq!(data.load(Ordering::Relaxed),1);}",
      tests("let a=std::sync::atomic::AtomicU32::new(1);assert_eq!(a.swap(2,std::sync::atomic::Ordering::AcqRel),1);assert_eq!(a.load(std::sync::atomic::Ordering::Acquire),2);"),
      [mutation("swap(2","swap(4","Changes RMW."),mutation("),3",") ,2","Wrong sync."),mutation("d.store(1","d.store(2","Changes data."),P]),
    c("data_race__stack_pop_race","data_race/stack_pop_race.rs","race keeps its i32 argument alive until a scoped reader has joined and observed the same value.",["MakeSend","race"],DATA,DATA_EVIDENCE,
      "#[derive(Copy,Clone)]struct MakeSend(*const i32);unsafe impl Send for MakeSend{}fn race(local:i32){std::thread::scope(|s|{let p=&local;s.spawn(move||assert_eq!(*p,local));});}fn main(){race(0);race(42);}",
      "#[test]fn repaired_entry_completes(){main();}#[test]fn helper_values(){for x in [-1,0,42]{race(x);}}#[test]fn repeat_helper(){for _ in 0..8{race(7);}}",
      [mutation("race(42)","race(41);panic!(\"value\")","Rejects value."),mutation("assert_eq!(*p,local)","assert_ne!(*p,local)","Wrong read."),mutation("race(local:i32){","race(_local:i32){panic!(\"race\")}fn unused(local:i32){","Panics."),P]),
    c("data_race__write_write_race","data_race/write_write_race.rs","Two ordered atomic stores of 32 then 64 leave 64.",["EvilSend"],DATA,DATA_EVIDENCE,
      EVIL+"use std::sync::atomic::{AtomicU32,Ordering};fn main(){let a=AtomicU32::new(0);a.store(32,Ordering::SeqCst);a.store(64,Ordering::SeqCst);assert_eq!(a.load(Ordering::SeqCst),64);}",
      tests("let a=std::sync::atomic::AtomicU32::new(0);a.store(1,std::sync::atomic::Ordering::SeqCst);a.store(2,std::sync::atomic::Ordering::SeqCst);assert_eq!(a.load(std::sync::atomic::Ordering::SeqCst),2);"),
      [mutation("store(64","store(63","Changes final write."),mutation("),64",") ,63","Wrong result."),mutation("a.store(64,Ordering::SeqCst);","","Drops final write."),P]),
    c("data_race__write_write_race_stack","data_race/write_write_race_stack.rs","The live stack value is written to 3 and then 1 in order, leaving 1.",["EvilSend"],DATA,DATA_EVIDENCE,
      EVIL+"fn main(){let mut stack_var=0usize;stack_var=3;assert_eq!(stack_var,3);stack_var=1;assert_eq!(stack_var,1);}",
      tests("let mut x=0usize;x=3;x=1;assert_eq!(x,1);"),
      [mutation("stack_var=3","stack_var=2","Changes first write."),mutation("stack_var=1","stack_var=2","Changes final write."),mutation("stack_var,1","stack_var,2","Wrong final result."),P]),
    c("concurrency__mutex-leak-move-deadlock","concurrency/mutex-leak-move-deadlock.rs","The first Mutex guard is dropped before the Mutex is moved and locked again.",[],DEFAULT,"The only fault is leaking the first guard; ordinary guard scope and the value 0 are explicit.",
      "use std::sync::Mutex;fn main(){let m=Mutex::new(0);{let mut g=m.lock().unwrap();*g=1;}let m2=m;let g=m2.lock().unwrap();assert_eq!(*g,1);}",
      tests("let m=std::sync::Mutex::new(0);{let _g=m.lock().unwrap();}assert!(m.try_lock().is_ok());"),
      [mutation("*g=1","*g=2","Changes value."),mutation("*g,1","*g,2","Wrong result."),mutation("let g=m2.lock().unwrap()","panic!(\"lock\");let g=m2.lock().unwrap()","Rejects relock."),P]),
    c("concurrency__read_only_atomic_cmpxchg","concurrency/read_only_atomic_cmpxchg.rs","compare_exchange on writable AtomicI32(0) with expected 1 returns Err(0) and preserves 0.",[],NO_STACK,"The source explicitly expects unwrap_err=0; only placing the atomic in read-only storage is invalid.",
      "use std::sync::atomic::{AtomicI32,Ordering};fn main(){let x=AtomicI32::new(0);assert_eq!(x.compare_exchange(1,2,Ordering::Relaxed,Ordering::Relaxed),Err(0));assert_eq!(x.load(Ordering::Relaxed),0);}",
      tests("let x=std::sync::atomic::AtomicI32::new(0);assert_eq!(x.compare_exchange(1,2,std::sync::atomic::Ordering::Relaxed,std::sync::atomic::Ordering::Relaxed),Err(0));"),
      [mutation("compare_exchange(1,2","compare_exchange(0,2","Changes expected value."),mutation("Err(0)","Ok(0)","Wrong outcome."),mutation("new(0)","new(1)","Changes initial value."),P]),
    c("concurrency__read_only_atomic_load_acquire","concurrency/read_only_atomic_load_acquire.rs","Acquire load on writable AtomicI32(0) returns 0.",[],NO_STACK,"The source value and Acquire load are explicit; only read-only backing storage is invalid.",
      "use std::sync::atomic::{AtomicI32,Ordering};fn main(){let x=AtomicI32::new(0);assert_eq!(x.load(Ordering::Acquire),0);}",
      tests("let x=std::sync::atomic::AtomicI32::new(7);assert_eq!(x.load(std::sync::atomic::Ordering::Acquire),7);"),
      [mutation("new(0)","new(1)","Changes value."),mutation("),0",") ,1","Wrong result."),mutation("x.load(Ordering::Acquire)","panic!(\"load\")","Rejects load."),P]),
    c("concurrency__read_only_atomic_load_large","concurrency/read_only_atomic_load_large.rs","AlignedI64 has eight-byte alignment and a writable AtomicI64 relaxed load returns 0.",["AlignedI64"],NO_STACK,"The aligned type and zero value are explicit; only loading through read-only backing storage is invalid.",
      "use std::sync::atomic::{AtomicI64,Ordering};#[repr(align(8))]struct AlignedI64(#[allow(dead_code)]i64);fn main(){let x=AtomicI64::new(0);assert_eq!(x.load(Ordering::Relaxed),0);assert_eq!(std::mem::align_of::<AlignedI64>(),8);}",
      "#[test]fn repaired_entry_completes(){main();}#[test]fn aligned_layout(){assert_eq!(std::mem::align_of::<AlignedI64>(),8);}#[test]fn writable_atomic(){let x=std::sync::atomic::AtomicI64::new(7);assert_eq!(x.load(std::sync::atomic::Ordering::Relaxed),7);}",
      [mutation("new(0)","new(1)","Changes value."),mutation("),0",") ,1","Wrong result."),mutation("align(8)","align(16)","Changes alignment."),P]),
]


SPECS += [
    c("dangling_pointers__dangling_pointer_deref_match_never","dangling_pointers/dangling_pointer_deref_match_never.rs","The never type is zero-sized; no value is materialized or dereferenced.",[],NO_VALID,"The source uses `!`; its only well-defined property here is the type layout.",
      "#![feature(never_type)]fn main(){assert_eq!(std::mem::size_of::<!>(),0);}",
      tests("assert_eq!(std::mem::size_of::<!>(),0);"),
      [mutation("size_of::<!>(),0","size_of::<!>(),1","Wrong size."),mutation("assert_eq!","assert_ne!","Negates invariant."),mutation("fn main(){","fn main(){panic!(\"never\");","Panics."),mutation("fn main(){assert_eq!","fn main(){panic!(\"layout\");assert_eq!","Rejects layout query.")]),
    c("dangling_pointers__deref_dangling_box","dangling_pointers/deref_dangling_box.rs","A pointer-to-Box indirection remains valid while the Box owns 42.",[],NO_STACK,"The source specifically distinguishes invalid dangling Box from valid owning Box indirection.",
      "fn main(){let mut inner=Box::new(42i32);let outer=&mut inner as*mut Box<i32>;let p=unsafe{std::ptr::addr_of_mut!(**outer)};assert_eq!(unsafe{*p},42);}",
      tests("let mut b=Box::new(7);let p=&mut b as*mut Box<i32>;assert_eq!(unsafe{***&p},7);"),
      [mutation("42i32","41i32","Changes value."),mutation("*p},42","*p},41","Wrong result."),mutation("addr_of_mut!(**outer)","panic!(\"box\")","Rejects indirection."),P]),
    c("dangling_pointers__deref_dangling_ref","dangling_pointers/deref_dangling_ref.rs","A pointer-to-reference indirection remains valid while the referenced i32 is alive.",[],NO_STACK,"The source specifically distinguishes invalid dangling reference from a live reference indirection.",
      "fn main(){let mut value=42i32;let mut inner=&mut value;let outer=&mut inner as*mut&mut i32;let p=unsafe{std::ptr::addr_of_mut!(**outer)};unsafe{*p=43};assert_eq!(value,43);}",
      tests("let mut x=7;let mut r=&mut x;let p=&mut r as*mut&mut i32;unsafe{**p=8};assert_eq!(x,8);"),
      [mutation("*p=43","*p=44","Changes write."),mutation("value,43","value,44","Wrong result."),mutation("addr_of_mut!(**outer)","panic!(\"ref\")","Rejects indirection."),P]),
    c("dangling_pointers__dyn_size","dangling_pointers/dyn_size.rs","A live SliceWithHead DST with a three-byte tail has dynamic size four.",["SliceWithHead"],NO_STACK,"The source type is explicit; only crafting metadata beyond the backing allocation is invalid.",
      "struct SliceWithHead(#[allow(dead_code)]u8,#[allow(dead_code)][u8]);fn main(){let bytes=[1u8,2,3,4];let p: *const SliceWithHead=unsafe{std::mem::transmute((bytes.as_ptr(),3usize))};let r=unsafe{&*p};assert_eq!(std::mem::size_of_val(r),4);assert_eq!(r.0,1);}",
      "#[test]fn repaired_entry_completes(){main();}#[test]fn live_dst(){let bytes=[1u8,2,3];let p:*const SliceWithHead=unsafe{std::mem::transmute((bytes.as_ptr(),2usize))};let r=unsafe{&*p};assert_eq!(std::mem::size_of_val(r),3);assert_eq!(r.0,1);}#[test]fn repeat(){main();}",
      [mutation("3usize","2usize","Changes tail metadata."),mutation("size_of_val(r),4","size_of_val(r),3","Wrong size."),mutation("r.0,1","r.0,2","Wrong head."),P]),
    c("weak_memory__weak_uninit","weak_memory/weak_uninit.rs","static_uninit_atomic returns an initialized static AtomicUsize; relaxed joins its store before asserting value 1.",["EvilSend","static_uninit_atomic","relaxed"],WEAK,"The helpers and desired store/load behavior are explicit; only the original uninitialized atomic is outside the domain.",
      "use std::sync::atomic::{AtomicUsize,Ordering};#[derive(Copy,Clone)]struct EvilSend<T>(pub T);unsafe impl<T>Send for EvilSend<T>{}unsafe impl<T>Sync for EvilSend<T>{}fn static_uninit_atomic()->&'static AtomicUsize{static X:AtomicUsize=AtomicUsize::new(0);&X}fn relaxed(){let x=static_uninit_atomic();let j=std::thread::spawn(move||x.store(1,Ordering::Relaxed));j.join().unwrap();assert_eq!(x.load(Ordering::Relaxed),1);}fn main(){for _ in 0..8{relaxed();}}",
      "#[test]fn repaired_entry_completes(){main();}#[test]fn initialized_static(){static_uninit_atomic().store(0,std::sync::atomic::Ordering::Relaxed);assert_eq!(static_uninit_atomic().load(std::sync::atomic::Ordering::Relaxed),0);}#[test]fn helper_repeats(){for _ in 0..5{relaxed();}}",
      [mutation("store(1","store(2","Changes store."),mutation("),1",") ,2","Wrong load."),mutation("fn static_uninit_atomic()->&'static AtomicUsize{","fn static_uninit_atomic()->&'static AtomicUsize{panic!(\"atomic\");","Rejects initialized static."),P]),
    c("intrinsics__uninit_uninhabited_type","intrinsics/uninit_uninhabited_type.rs","The never type has size zero; no uninhabited value is constructed.",[],DEFAULT,"The source names `!`; construction has no well-defined input, leaving only its explicit type/layout invariant.",
      "#![feature(never_type)]fn main(){assert_eq!(std::mem::size_of::<!>(),0);}",
      tests("assert_eq!(std::mem::size_of::<!>(),0);"),
      [mutation("size_of::<!>(),0","size_of::<!>(),1","Wrong size."),mutation("assert_eq!","assert_ne!","Negates invariant."),mutation("fn main(){","fn main(){panic!(\"never\");","Panics."),mutation("fn main(){assert_eq!","fn main(){panic!(\"layout\");assert_eq!","Rejects layout query.")]),
    c("match__all_variants_uninhabited","match/all_variants_uninhabited.rs","The original callable helpers lol and wut both complete without requiring an uninhabited Result value.",["Never","lol","wut"],DEFAULT,"Both helper bodies are ordinary, explicit behavior independent of the invalid uninhabited match.",
      "enum Never{}fn lol(){println!(\"lol\");}fn wut(){println!(\"wut\");}fn main(){lol();wut();assert_eq!(std::mem::size_of::<Never>(),0);}",
      "#[test]fn repaired_entry_completes(){main();}#[test]fn helpers_complete(){lol();wut();}#[test]fn never_layout(){assert_eq!(std::mem::size_of::<Never>(),0);}",
      [mutation("lol();wut();","lol();panic!(\"wut\")","Rejects wut."),mutation("println!(\"lol\")","panic!(\"lol\")","Rejects lol."),mutation("size_of::<Never>(),0","size_of::<Never>(),1","Wrong size."),P]),
]


def fnptr(case_id,path):
    return c(case_id,path,"A genuine fn(i32)->i32 pointer invokes executable code and maps 42 to 43.",[],NO_VALID,"The failure is solely fabricating a function pointer from data/integer memory; a real function item supplies the well-defined domain.",
      "fn main(){fn target(x:i32)->i32{x+1}let g:fn(i32)->i32=target;assert_eq!(g(42),43);}",
      tests("fn f(x:i32)->i32{x*2}let p:fn(i32)->i32=f;assert_eq!(p(7),14);"),
      [mutation("x+1","x+2","Changes function."),mutation("g(42),43","g(42),44","Wrong result."),mutation("=target","=|_|panic!(\"call\")","Rejects call."),P])


SPECS += [
    fnptr("function_pointers__cast_box_int_to_fn_ptr","function_pointers/cast_box_int_to_fn_ptr.rs"),
    fnptr("function_pointers__cast_int_to_fn_ptr","function_pointers/cast_int_to_fn_ptr.rs"),
    c("function_pointers__execute_memory","function_pointers/execute_memory.rs","A genuine fn()->i32 pointer invokes executable code and returns 42.",[],NO_VALID,"The failure is executing heap data as code; a real function item supplies the well-defined domain.",
      "fn main(){fn target()->i32{42}let f:fn()->i32=target;assert_eq!(f(),42);}",
      tests("fn f()->i32{7}let p:fn()->i32=f;assert_eq!(p(),7);"),
      [mutation("->i32{42}","->i32{41}","Changes function."),mutation("f(),42","f(),41","Wrong result."),mutation("=target","=||panic!(\"call\")","Rejects call."),P]),
]


def main() -> None:
    for item in SPECS:
        write_case(item)
    print(f"wrote {len(SPECS)} batch-15 cases")


if __name__ == "__main__":
    main()
