#!/usr/bin/env python3
"""Materialize the reviewed fifth batch of 20 partial semantic oracles."""

from __future__ import annotations

from generate_batch2_cases import DEFAULT, STACK_TREE, TREE, mutation, write_case


WEAK_STACK_TREE = [
    ("stacked-weakened", ["-Zmiri-disable-validation"]),
    ("tree-weakened", ["-Zmiri-disable-validation", "-Zmiri-tree-borrows"]),
]
WEAK_ALIAS = [
    ("official-weakened", ["-Zmiri-disable-validation", "-Zmiri-disable-stacked-borrows"]),
    ("default-strict", []),
]


def narrow_read_case(case_id: str, source_path: str, symbol: str, reference: str, tests: str, profiles, evidence: str, mutants: list[dict]) -> dict:
    return {
        "id": case_id,
        "path": source_path,
        "contract": f"On the declared valid-input domain, {symbol} completes and preserves all caller-observable input state.",
        "symbols": [symbol],
        "profiles": profiles,
        "evidence": evidence,
        "tests": tests,
        "reference": reference,
        "mutations": mutants,
    }


SPECS = [
    narrow_read_case(
        "both_borrows__pass_invalid_shr",
        "both_borrows/pass_invalid_shr.rs",
        "foo",
        """
        #![allow(invalid_reference_casting)]
        fn foo(_: &i32){}
        fn main(){let x=42;foo(&x);assert_eq!(x,42);}
        """,
        """
        #[test]fn repaired_entry_completes(){main();}
        #[test]fn accepts_all_valid_values(){for x in [i32::MIN,-1,0,42,i32::MAX]{foo(&x);assert_eq!(x,x);}}
        #[test]fn repeated_calls_are_noops(){let x=7;for _ in 0..8{foo(&x);assert_eq!(x,7);}}
        """,
        STACK_TREE,
        "The helper body is empty; the fixture fails only because its shared reference was invalidated before the call.",
        [
            mutation("fn foo(_: &i32){}", "fn foo(x:&i32){unsafe{*(x as *const _ as *mut i32)=0;}}", "Mutates the referent."),
            mutation("fn foo(_: &i32){}", "fn foo(x:&i32){if *x==0{panic!(\"zero\")}}", "Rejects zero."),
            mutation("fn foo(_: &i32){}", "fn foo(x:&i32){if *x==42{panic!(\"42\")}}", "Rejects 42."),
            mutation("fn foo(_: &i32){}", "fn foo(_:&i32){panic!(\"all\")}", "Always panics."),
        ],
    ),
    narrow_read_case(
        "stacked_borrows__pass_invalid_mut",
        "stacked_borrows/pass_invalid_mut.rs",
        "foo",
        "fn foo(_: &mut i32){}\nfn main(){let mut x=42;foo(&mut x);assert_eq!(x,42);}",
        """
        #[test]fn repaired_entry_completes(){main();}
        #[test]fn preserves_valid_mut_refs(){for initial in [i32::MIN,-1,0,42,i32::MAX]{let mut x=initial;foo(&mut x);assert_eq!(x,initial);}}
        #[test]fn repeated_calls_are_noops(){let mut x=7;for _ in 0..8{foo(&mut x);assert_eq!(x,7);}}
        """,
        DEFAULT,
        "The helper body is empty; the fixture invalidates the mutable reference before passing it.",
        [
            mutation("fn foo(_: &mut i32){}", "fn foo(x:&mut i32){*x=0;}", "Writes zero."),
            mutation("fn foo(_: &mut i32){}", "fn foo(x:&mut i32){*x=1;}", "Writes one."),
            mutation("fn foo(_: &mut i32){}", "fn foo(x:&mut i32){*x=x.wrapping_add(1);}", "Increments."),
            mutation("fn foo(_: &mut i32){}", "fn foo(_:&mut i32){panic!(\"all\")}", "Panics."),
        ],
    ),
    narrow_read_case(
        "stacked_borrows__track_caller",
        "stacked_borrows/track_caller.rs",
        "callee",
        "#[track_caller]fn callee(xraw:*mut i32){let _val=unsafe{*xraw};}\nfn main(){let mut x=15;callee(&mut x);assert_eq!(x,15);}",
        """
        #[test]fn repaired_entry_completes(){main();}
        #[test]fn preserves_valid_pointers(){for initial in [-1,0,42]{let mut x=initial;callee(&mut x);assert_eq!(x,initial);}}
        #[test]fn repeated_reads_are_noops(){let mut x=7;for _ in 0..8{callee(&mut x);assert_eq!(x,7);}}
        """,
        DEFAULT,
        "The track_caller helper only reads through xraw; the later alias use triggers the fixture failure.",
        [
            mutation("{let _val=unsafe{*xraw};}", "{unsafe{*xraw=0;}}", "Writes zero."),
            mutation("{let _val=unsafe{*xraw};}", "{unsafe{*xraw=1;}}", "Writes one."),
            mutation("*xraw", "*xraw.add(1)", "Reads outside the object."),
            mutation("{let _val=unsafe{*xraw};}", "{panic!(\"read\")}", "Panics."),
        ],
    ),
    {
        "id": "stacked_borrows__illegal_read3",
        "path": "stacked_borrows/illegal_read3.rs",
        "contract": "callee reads a valid HiddenRef and leaves its i32 referent unchanged.",
        "symbols": ["HiddenRef", "callee"],
        "profiles": DEFAULT,
        "evidence": "The union helper performs a single read through `xref1.r` and no write.",
        "tests": """
        fn hidden(x:&i32)->HiddenRef{unsafe{std::mem::transmute_copy(&x)}}
        #[test]fn repaired_entry_completes(){main();}
        #[test]fn preserves_values(){for x in [-1,0,42]{callee(hidden(&x));assert_eq!(x,x);}}
        #[test]fn repeated_reads_are_noops(){let x=7;for _ in 0..8{callee(hidden(&x));assert_eq!(x,7);}}
        """,
        "reference": """
        use std::mem;union HiddenRef{r:&'static i32}
        fn callee(xref1:HiddenRef){let _val=unsafe{*xref1.r};}
        fn main(){let x=15;let h:HiddenRef=unsafe{mem::transmute_copy(&&x)};callee(h);assert_eq!(x,15);}
        """,
        "mutations": [
            mutation("{let _val=unsafe{*xref1.r};}", "{unsafe{*(xref1.r as *const _ as *mut i32)=0;}}", "Mutates the referent."),
            mutation("*xref1.r", "*xref1.r.add(1)", "Reads out of range."),
            mutation("{let _val=unsafe{*xref1.r};}", "{panic!(\"read\")}", "Panics."),
            mutation("*xref1.r", "*std::ptr::null::<i32>()", "Reads null."),
        ],
    },
    narrow_read_case(
        "stacked_borrows__fnentry_invalidation2",
        "stacked_borrows/fnentry_invalidation2.rs",
        "inner",
        "struct Thing<'a>{sli:&'a mut[i32]}\nfn inner(t:&mut Thing){let _=t.sli.as_mut_ptr();}\nfn main(){let mut data=[0,1,2];let mut t=Thing{sli:&mut data};inner(&mut t);assert_eq!(t.sli,&[0,1,2]);}",
        """
        #[test]fn repaired_entry_completes(){main();}
        #[test]fn preserves_slices(){for mut data in [[0,1,2],[-1,7,9]]{let before=data;let mut t=Thing{sli:&mut data};inner(&mut t);assert_eq!(t.sli,&before);}}
        #[test]fn repeated_calls_are_noops(){let mut data=[4,5,6];let mut t=Thing{sli:&mut data};for _ in 0..6{inner(&mut t);assert_eq!(t.sli,&[4,5,6]);}}
        """,
        DEFAULT,
        "inner only obtains the slice's raw mutable pointer; the caller's stale alias causes the original failure.",
        [
            mutation("{let _=t.sli.as_mut_ptr();}", "{t.sli[0]=0;}", "Writes element zero."),
            mutation("{let _=t.sli.as_mut_ptr();}", "{t.sli.reverse();}", "Reverses the slice."),
            mutation("{let _=t.sli.as_mut_ptr();}", "{panic!(\"inner\")}", "Panics."),
            mutation("as_mut_ptr()", "as_mut_ptr().add(99)", "Forms an invalid pointer."),
        ],
    ),
    {
        "id": "stacked_borrows__pointer_smuggling",
        "path": "stacked_borrows/pointer_smuggling.rs",
        "contract": "For a live unmodified pointee, fun1 stores its address in PTR and fun2 reads it without changing the pointee or PTR.",
        "symbols": ["PTR", "fun1", "fun2"],
        "profiles": DEFAULT,
        "evidence": "fun1 assigns PTR=x; fun2 only reads `*PTR`. The fixture fails after invalidating the stored raw pointer.",
        "tests": """
        #[test]fn repaired_entry_completes(){main();}
        #[test]fn live_protocol_preserves_value(){for initial in [0u8,1,255]{let mut x=initial;fun1(&mut x);assert_eq!(unsafe{PTR},std::ptr::addr_of_mut!(x));fun2();assert_eq!(x,initial);}}
        #[test]fn latest_registration_wins(){let(mut a,mut b)=(1u8,2u8);fun1(&mut a);fun1(&mut b);assert_eq!(unsafe{PTR},std::ptr::addr_of_mut!(b));fun2();assert_eq!((a,b),(1,2));}
        """,
        "reference": """
        static mut PTR:*mut u8=std::ptr::null_mut();
        fn fun1(x:&mut u8){unsafe{PTR=x;}}fn fun2(){let _x=unsafe{*PTR};}
        fn main(){let mut x=0;fun1(&mut x);fun2();assert_eq!(x,0);}
        """,
        "mutations": [
            mutation("unsafe{PTR=x;}", "{}", "Does not register x."),
            mutation("unsafe{PTR=x;}", "unsafe{PTR=std::ptr::null_mut();}", "Stores null."),
            mutation("{let _x=unsafe{*PTR};}", "{unsafe{*PTR=0;}}", "fun2 writes zero."),
            mutation("{let _x=unsafe{*PTR};}", "{panic!(\"fun2\")}", "fun2 panics."),
        ],
    },
    {
        "id": "dangling_pointers__storage_dead_dangling",
        "path": "dangling_pointers/storage_dead_dangling.rs",
        "contract": "While the registered i32 remains live, fill exposes its address in LEAK and evil forms a reference without changing the value or address.",
        "symbols": ["LEAK", "fill", "evil"],
        "profiles": [("official-weakened", ["-Zmiri-disable-validation", "-Zmiri-permissive-provenance"]), ("default-strict", [])],
        "evidence": "fill stores the exposed address; evil only creates a reference. The fixture ends storage before evil.",
        "tests": """
        #[test]fn repaired_entry_completes(){main();}
        #[test]fn live_registration_is_stable(){for initial in [-1,0,42]{let mut x=initial;fill(&mut x);assert_eq!(unsafe{LEAK},&mut x as *mut i32 as usize);evil();assert_eq!(x,initial);}}
        #[test]fn latest_live_value_wins(){let(mut a,mut b)=(1,2);fill(&mut a);fill(&mut b);assert_eq!(unsafe{LEAK},&mut b as *mut i32 as usize);evil();assert_eq!((a,b),(1,2));}
        """,
        "reference": """
        static mut LEAK:usize=0;fn fill(v:&mut i32){unsafe{LEAK=v as *mut _ as usize;}}fn evil(){let _ref=unsafe{&mut *(LEAK as *mut i32)};}
        fn main(){let mut x=0;fill(&mut x);evil();assert_eq!(x,0);}
        """,
        "mutations": [
            mutation("unsafe{LEAK=v as *mut _ as usize;}", "{}", "Does not register v."),
            mutation("v as *mut _ as usize", "0usize", "Registers null."),
            mutation("{let _ref=unsafe{&mut *(LEAK as *mut i32)};}", "{unsafe{*(LEAK as *mut i32)=0;}}", "evil writes zero."),
            mutation("{let _ref=unsafe{&mut *(LEAK as *mut i32)};}", "{panic!(\"evil\")}", "evil panics."),
        ],
    },
    narrow_read_case(
        "provenance__provenance_transmute",
        "provenance/provenance_transmute.rs",
        "deref",
        "#![allow(integer_to_ptr_transmutes)]\nuse std::mem;unsafe fn deref(left:*const u8,right:*const u8){let left_int:usize=mem::transmute(left);let right_int:usize=mem::transmute(right);if left_int==right_int{let left_ptr:*const u8=mem::transmute(left_int);let _val=*left_ptr;}}\nfn main(){let(a,b)=(7u8,9u8);unsafe{deref(&a,&b);}assert_eq!((a,b),(7,9));}",
        """
        #[test]fn repaired_entry_completes(){main();}
        #[test]fn distinct_live_pointers_are_preserved(){for pair in [(1u8,2u8),(7,9),(254,255)]{let(a,b)=pair;unsafe{deref(&a,&b);}assert_eq!((a,b),pair);}}
        #[test]fn repeated_distinct_calls_are_noops(){let(a,b)=(3u8,4u8);for _ in 0..8{unsafe{deref(&a,&b);}assert_eq!((a,b),(3,4));}}
        """,
        [("permissive", ["-Zmiri-permissive-provenance"])],
        "For distinct addresses the source branch is not entered; the fixture manufactures equal addresses with incompatible provenance.",
        [
            mutation("let left_int:usize", "*(left as *mut u8)=0;let left_int:usize", "Writes left before comparison."),
            mutation("let right_int:usize", "*(right as *mut u8)=0;let right_int:usize", "Writes right before comparison."),
            mutation("let left_int:usize", "panic!(\"deref\");let left_int:usize", "Panics on distinct input."),
            mutation("if left_int==right_int", "if left_int!=right_int{*(left as *mut u8)=0;}if false", "Takes an effectful wrong branch."),
        ],
    ),
    {
        "id": "tree_borrows__repeated_foreign_read_lazy_conflicted",
        "path": "tree_borrows/repeated_foreign_read_lazy_conflicted.rs",
        "contract": "With x backed by a two-byte allocation and orig_ptr in a distinct live allocation, access_after_sub_1 reads orig and stores 42 in the byte immediately before x.",
        "symbols": ["do_something", "access_after_sub_1"],
        "profiles": TREE,
        "evidence": "The helper reads orig_ptr and explicitly writes 42 to `(x as *mut u8).byte_sub(1)`.",
        "tests": """
        #[test]fn repaired_entry_completes(){main();}
        #[test]fn writes_previous_byte_on_distinct_orig(){for initial in [0u8,7,255]{let mut data=[initial,9];let mut orig=3u8;unsafe{access_after_sub_1(&mut data[1],&mut orig)};assert_eq!(data,[42,9]);assert_eq!(orig,3);}}
        #[test]fn repeated_calls_are_stable(){let mut data=[0u8,1];let mut orig=2;for _ in 0..6{unsafe{access_after_sub_1(&mut data[1],&mut orig)};assert_eq!(data,[42,1]);}}
        """,
        "reference": """
        fn do_something(_:u8){}unsafe fn access_after_sub_1(x:&mut u8,orig_ptr:*mut u8){do_something(*orig_ptr);*(x as *mut u8).byte_sub(1)=42;}
        fn main(){let mut data=[0u8,1];let mut orig=2;unsafe{access_after_sub_1(&mut data[1],&mut orig)};assert_eq!(data,[42,1]);}
        """,
        "mutations": [
            mutation("byte_sub(1)=42", "byte_sub(1)=41", "Stores 41."),
            mutation("byte_sub(1)=42", "byte_sub(0)=42", "Writes x instead."),
            mutation("do_something(*orig_ptr)", "do_something(*orig_ptr.add(1))", "Reads out of range."),
            mutation(";*(x as *mut u8).byte_sub(1)=42", "", "Drops the write."),
        ],
    },
    narrow_read_case(
        "tail_calls__dangling-local-var",
        "tail_calls/dangling-local-var.rs",
        "g",
        "#![feature(explicit_tail_calls)]\n#![allow(incomplete_features)]\nfn g(x:*const i32){let _val=unsafe{*x};}fn f(x:*const i32){become g(x)}\nfn main(){let x=7;g(&x);assert_eq!(x,7);}",
        """
        #[test]fn repaired_entry_completes(){main();}
        #[test]fn reads_live_pointers(){for x in [i32::MIN,-1,0,42,i32::MAX]{g(&x);assert_eq!(x,x);}}
        #[test]fn repeated_reads_are_noops(){let x=7;for _ in 0..8{g(&x);assert_eq!(x,7);}}
        """,
        DEFAULT,
        "g only reads its pointer; the original f tail-calls g after destroying the local allocation that pointer names.",
        [
            mutation("{let _val=unsafe{*x};}", "{unsafe{*(x as *mut i32)=0;}}", "Writes zero."),
            mutation("*x", "*x.add(1)", "Reads out of range."),
            mutation("{let _val=unsafe{*x};}", "{panic!(\"g\")}", "Panics."),
            mutation("*x", "*std::ptr::null::<i32>()", "Reads null."),
        ],
    ),
    {
        "id": "terminate-terminator",
        "path": "terminate-terminator.rs",
        "contract": "has_cleanup always panics after constructing its local Foo; callers may catch that Rust unwind.",
        "symbols": ["Foo", "has_cleanup"],
        "profiles": DEFAULT,
        "evidence": "The helper creates Foo and then explicitly calls panic.",
        "tests": """
        #[test]fn repaired_entry_completes(){main();}
        #[test]fn always_panics(){for _ in 0..6{assert!(std::panic::catch_unwind(has_cleanup).is_err());}}
        #[test]fn unwind_does_not_poison_next_call(){assert!(std::panic::catch_unwind(has_cleanup).is_err());assert!(std::panic::catch_unwind(has_cleanup).is_err());}
        """,
        "reference": """
        struct Foo;impl Drop for Foo{fn drop(&mut self){}}
        #[inline(always)]fn has_cleanup(){let _f=Foo;panic!();}
        fn main(){assert!(std::panic::catch_unwind(has_cleanup).is_err());}
        """,
        "mutations": [
            mutation("{let _f=Foo;panic!();}", "{}", "Returns normally."),
            mutation("panic!()", "return", "Suppresses panic."),
            mutation("{let _f=Foo;panic!();}", "{let _f=Foo;std::mem::forget(_f);}", "Leaks then returns."),
            mutation("{let _f=Foo;panic!();}", "{let _f=Foo;drop(_f);}", "Drops then returns."),
        ],
    },
    narrow_read_case(
        "function_calls__arg_inplace_observe_after",
        "function_calls/arg_inplace_observe_after.rs",
        "change_arg",
        "pub struct S(i32);#[expect(unused_variables,unused_assignments)]fn change_arg(mut x:S){x.0=0;}fn main(){change_arg(S(42));}",
        """
        #[test]fn repaired_entry_completes(){main();}
        #[test]fn accepts_owned_values(){for x in [i32::MIN,-1,0,42,i32::MAX]{change_arg(S(x));}}
        #[test]fn repeated_calls_complete(){for _ in 0..8{change_arg(S(7));}}
        """,
        DEFAULT,
        "change_arg mutates only its owned local; the fixture's failure comes from observing the moved-from caller local.",
        [
            mutation("{x.0=0;}", "{if x.0==0{panic!(\"zero\")}x.0=0;}", "Rejects zero."),
            mutation("{x.0=0;}", "{if x.0==42{panic!(\"42\")}x.0=0;}", "Rejects 42."),
            mutation("{x.0=0;}", "{let _=x;panic!(\"all\")}", "Always panics."),
            mutation("{x.0=0;}", "{if x.0<0{panic!(\"negative\")}x.0=0;}", "Rejects negatives."),
        ],
    ),
    narrow_read_case(
        "function_calls__arg_inplace_locals_alias",
        "function_calls/arg_inplace_locals_alias.rs",
        "callee",
        "pub struct S(i32);#[expect(unused_variables,unused_assignments)]fn callee(x:S,mut y:S){y.0=0;assert_eq!(x.0,42);}fn main(){callee(S(42),S(7));}",
        """
        #[test]fn repaired_entry_completes(){main();}
        #[test]fn accepts_witness_42_and_any_distinct_y(){for y in [i32::MIN,-1,0,42,i32::MAX]{callee(S(42),S(y));}}
        #[test]fn repeated_calls_complete(){for _ in 0..8{callee(S(42),S(7));}}
        """,
        WEAK_STACK_TREE,
        "The helper mutates only owned y and explicitly asserts that the independent x witness remains 42.",
        [
            mutation("assert_eq!(x.0,42)", "assert_eq!(x.0,41)", "Checks the wrong witness."),
            mutation("{y.0=0;assert_eq!(x.0,42);}", "{let _=(x,y);panic!(\"all\")}", "Always panics."),
            mutation("{y.0=0;assert_eq!(x.0,42);}", "{if y.0==0{panic!(\"zero y\")}y.0=0;assert_eq!(x.0,42);}", "Rejects valid y."),
            mutation("{y.0=0;assert_eq!(x.0,42);}", "{if y.0<0{panic!(\"negative y\")}y.0=0;assert_eq!(x.0,42);}", "Rejects negative y."),
        ],
    ),
    {
        "id": "dyn-call-trait-mismatch",
        "path": "dyn-call-trait-mismatch.rs",
        "contract": "The valid i32 implementation of T1::method1 accepts ownership through Box<dyn T1> and completes.",
        "symbols": ["T1", "T1::method1"],
        "profiles": WEAK_ALIAS,
        "evidence": "The i32 method1 implementation is empty; UB requires transmuting its vtable to unrelated T2.",
        "tests": """
        #[test]fn repaired_entry_completes(){main();}
        #[test]fn valid_trait_objects_complete(){for x in [i32::MIN,-1,0,42,i32::MAX]{let obj=Box::new(x)as Box<dyn T1>;obj.method1();}}
        #[test]fn repeated_dispatch_completes(){for _ in 0..8{(Box::new(7)as Box<dyn T1>).method1();}}
        """,
        "reference": """
        trait T1{fn method1(self:Box<Self>);}trait T2{fn method2(self:Box<Self>);}
        impl T1 for i32{fn method1(self:Box<Self>){}}
        fn main(){(Box::new(0)as Box<dyn T1>).method1();}
        """,
        "mutations": [
            mutation("{fn method1(self:Box<Self>){}", "{fn method1(self:Box<Self>){if *self==0{panic!(\"zero\")}", "Rejects zero."),
            mutation("{fn method1(self:Box<Self>){}", "{fn method1(self:Box<Self>){if *self==42{panic!(\"42\")}", "Rejects 42."),
            mutation("{fn method1(self:Box<Self>){}", "{fn method1(self:Box<Self>){let _=self;panic!(\"all\")", "Always panics."),
            mutation("{fn method1(self:Box<Self>){}", "{fn method1(self:Box<Self>){if *self<0{panic!(\"negative\")}", "Rejects negatives."),
        ],
    },
    {
        "id": "validity__dyn-transmute-inner-binder",
        "path": "validity/dyn-transmute-inner-binder.rs",
        "contract": "A correctly typed dyn Trait<for<'a> fn(&'a ())> object dispatches the default foo method and completes.",
        "symbols": ["Trait", "HigherRanked", "Trait::foo"],
        "profiles": DEFAULT,
        "evidence": "The default foo body is empty; the fixture only fails after replacing the trait object's incompatible vtable.",
        "tests": """
        #[test]fn repaired_entry_completes(){main();}
        #[test]fn valid_higher_ranked_objects_complete(){let x=();let y:&dyn Trait<for<'a>fn(&'a())>=&x;for _ in 0..8{y.foo();}}
        #[test]fn blanket_impl_supports_other_values(){let x=42i32;let y:&dyn Trait<for<'a>fn(&'a())>=&x;y.foo();}
        """,
        "reference": """
        trait Trait<U>{fn foo(&self)where U:HigherRanked{}}impl<T,U>Trait<U>for T{}
        trait HigherRanked{}impl HigherRanked for for<'a>fn(&'a()){}
        trait Unsatisfied{}impl<T:Unsatisfied>HigherRanked for T{}
        fn main(){let x=();let y:&dyn Trait<for<'a>fn(&'a())>=&x;y.foo();}
        """,
        "mutations": [
            mutation("where U:HigherRanked{}", "where U:HigherRanked{panic!(\"foo\")} ", "foo panics."),
            mutation("fn foo(&self)where U:HigherRanked{}", "fn foo(&self)where U:HigherRanked{let _=self;panic!(\"all\")}", "Always panics."),
            mutation("where U:HigherRanked{}", "where U:HigherRanked{assert!(false)}", "Asserts false."),
            mutation("where U:HigherRanked{}", "where U:HigherRanked{unreachable!()}", "Is unreachable."),
        ],
    },
    {
        "id": "both_borrows__invalidate_against_protector3",
        "path": "both_borrows/invalidate_against_protector3.rs",
        "contract": "On distinct valid inputs inner stores 0 through x and preserves the shared y pointee.",
        "symbols": ["inner"],
        "profiles": STACK_TREE,
        "evidence": "inner explicitly writes zero through x; the fixture's allocation makes x and protected y alias.",
        "tests": """
        #[test]fn repaired_entry_completes(){main();}
        #[test]fn zeroes_distinct_x(){for pair in [(-1,0),(0,42),(i32::MAX,i32::MIN)]{let(mut x,y)=pair;inner(&mut x,&y);assert_eq!((x,y),(0,pair.1));}}
        #[test]fn repeated_calls_preserve_y(){let(mut x,y)=(7,9);for _ in 0..8{x=7;inner(&mut x,&y);assert_eq!((x,y),(0,9));}}
        """,
        "reference": "fn inner(x:*mut i32,_y:&i32){unsafe{*x=0};}fn main(){let(mut x,y)=(1,2);inner(&mut x,&y);assert_eq!((x,y),(0,2));}",
        "mutations": [
            mutation("*x=0", "*x=1", "Writes one."),
            mutation("unsafe{*x=0};", "", "Drops the write."),
            mutation("*x=0", "*x=*_y", "Copies y."),
            mutation("unsafe{*x=0};", "panic!(\"inner\");", "Panics."),
        ],
    },
    narrow_read_case(
        "function_pointers__deref_fn_ptr",
        "function_pointers/deref_fn_ptr.rs",
        "f",
        "fn f(){}fn main(){f();}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn direct_calls_complete(){for _ in 0..8{f();}}#[test]fn function_pointer_calls_complete(){let p:fn()=f;for _ in 0..8{p();}}",
        DEFAULT,
        "The top-level f body is empty; the fixture fails only by treating its function address as data.",
        [mutation("fn f(){}", "fn f(){panic!(\"f\")}","Panics."),mutation("fn f(){}", "fn f(){assert!(false)}","Asserts."),mutation("fn f(){}", "fn f(){unreachable!()}","Unreachable."),mutation("fn f(){}", "fn f(){std::process::abort()}","Aborts.")],
    ),
    narrow_read_case(
        "function_pointers__fn_ptr_offset",
        "function_pointers/fn_ptr_offset.rs",
        "f",
        "fn f(){}fn main(){f();}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn direct_calls_complete(){for _ in 0..8{f();}}#[test]fn unmodified_pointer_calls_complete(){let p:fn()=f;for _ in 0..8{p();}}",
        [("official-weakened",["-Zmiri-disable-validation"]),("default-strict",[])],
        "f is empty; the fixture fails only after offsetting and reconstructing its function pointer.",
        [mutation("fn f(){}", "fn f(){panic!(\"f\")}","Panics."),mutation("fn f(){}", "fn f(){assert!(false)}","Asserts."),mutation("fn f(){}", "fn f(){unreachable!()}","Unreachable."),mutation("fn f(){}", "fn f(){std::process::abort()}","Aborts.")],
    ),
    {
        "id": "stacked_borrows__fnentry_invalidation",
        "path": "stacked_borrows/fnentry_invalidation.rs",
        "contract": "The default Bad::do_bad implementation for i32 completes and preserves the receiver.",
        "symbols": ["Bad", "Bad::do_bad"],
        "profiles": DEFAULT,
        "evidence": "The default method body is empty; the fixture failure comes from a stale raw alias used after method entry.",
        "tests": "#[test]fn repaired_entry_completes(){main();}#[test]fn preserves_values(){for initial in [-1,0,42]{let mut x=initial;x.do_bad();assert_eq!(x,initial);}}#[test]fn repeated_calls_are_noops(){let mut x=7;for _ in 0..8{x.do_bad();assert_eq!(x,7);}}",
        "reference": "trait Bad{fn do_bad(&mut self){}}impl Bad for i32{}fn main(){let mut x=0;x.do_bad();assert_eq!(x,0);}",
        "mutations": [mutation("{fn do_bad(&mut self){}}","{fn do_bad(&mut self){*self=0;}}","Writes zero."),mutation("{fn do_bad(&mut self){}}","{fn do_bad(&mut self){*self=1;}}","Writes one."),mutation("{fn do_bad(&mut self){}}","{fn do_bad(&mut self){*self+=1;}}","Increments."),mutation("{fn do_bad(&mut self){}}","{fn do_bad(&mut self){panic!(\"bad\")}}","Panics.")],
    },
    {
        "id": "tree_borrows__fnentry_invalidation",
        "path": "tree_borrows/fnentry_invalidation.rs",
        "contract": "Under Tree Borrows, the default Bad::do_bad implementation for i32 completes and preserves the receiver.",
        "symbols": ["Bad", "Bad::do_bad"],
        "profiles": TREE,
        "evidence": "The method body is empty; the fixture's raw-pointer write after method entry is the invalid operation.",
        "tests": "#[test]fn repaired_entry_completes(){main();}#[test]fn preserves_values(){for initial in [-1,0,42]{let mut x=initial;x.do_bad();assert_eq!(x,initial);}}#[test]fn repeated_calls_are_noops(){let mut x=7;for _ in 0..8{x.do_bad();assert_eq!(x,7);}}",
        "reference": "trait Bad{fn do_bad(&mut self){}}impl Bad for i32{}fn main(){let mut x=0;x.do_bad();assert_eq!(x,0);}",
        "mutations": [mutation("{fn do_bad(&mut self){}}","{fn do_bad(&mut self){*self=0;}}","Writes zero."),mutation("{fn do_bad(&mut self){}}","{fn do_bad(&mut self){*self=1;}}","Writes one."),mutation("{fn do_bad(&mut self){}}","{fn do_bad(&mut self){*self+=1;}}","Increments."),mutation("{fn do_bad(&mut self){}}","{fn do_bad(&mut self){panic!(\"bad\")}}","Panics.")],
    },
]


def main() -> None:
    for spec in SPECS:
        write_case(spec)
    print(f"wrote {len(SPECS)} batch-5 cases")


if __name__ == "__main__":
    main()
