#!/usr/bin/env python3
"""Materialize the sixth batch: helper contracts and explicit type/main invariants."""

from __future__ import annotations

from generate_batch2_cases import DEFAULT, STACK_TREE, TREE, mutation, write_case


DETERMINISTIC = [("deterministic", ["-Zmiri-deterministic-concurrency"])]
WEAK_STRICT = [("official-weakened", ["-Zmiri-disable-validation"]), ("default-strict", [])]


def main_case(case_id, source_path, contract, symbols, profiles, evidence, reference, tests, mutants):
    return {
        "id": case_id, "path": source_path, "contract": contract, "symbols": symbols,
        "profiles": profiles, "evidence": evidence, "reference": reference,
        "tests": tests, "mutations": mutants,
        "partial_reason": "Only the cited local/type invariant and repaired entry completion are tested. Other behavior of the diagnostic fixture remains unspecified, so this is P rather than E.",
    }


SPECS = [
    {
        "id": "stacked_borrows__retag_data_race_read",
        "path": "stacked_borrows/retag_data_race_read.rs",
        "contract": "Under a sequential non-racing schedule, thread_1 preserves the valid pointee and thread_2 stores 5.",
        "symbols": ["SendPtr", "thread_1", "thread_2"], "profiles": DETERMINISTIC,
        "evidence": "thread_1 only forms a shared reference; thread_2 explicitly writes 5.",
        "reference": "#[derive(Copy,Clone)]struct SendPtr(*mut u8);unsafe impl Send for SendPtr{}fn thread_1(p:SendPtr){let p=p.0;unsafe{let _r=&*p;}}fn thread_2(p:SendPtr){let p=p.0;unsafe{*p=5;}}fn main(){let mut x=0;let p=SendPtr(&mut x);thread_1(p);thread_2(p);assert_eq!(x,5);}",
        "tests": "#[test]fn repaired_entry_completes(){main();}#[test]fn sequential_effects(){for initial in [0u8,1,255]{let mut x=initial;let p=SendPtr(&mut x);thread_1(p);assert_eq!(x,initial);thread_2(p);assert_eq!(x,5);}}#[test]fn independent_values(){let(mut a,mut b)=(1u8,2u8);thread_2(SendPtr(&mut a));thread_2(SendPtr(&mut b));assert_eq!((a,b),(5,5));}",
        "mutations": [mutation("*p=5","*p=4","Writes 4."),mutation("unsafe{*p=5;}","{}","Drops write."),mutation("unsafe{let _r=&*p;}","unsafe{*p=1;}","thread_1 writes."),mutation("unsafe{let _r=&*p;}","panic!(\"read\")","Panics.")],
    },
    {
        "id": "data_race__mixed_size_read_read_write", "path": "data_race/mixed_size_read_read_write.rs",
        "contract": "convert returns a two-byte AtomicU8 view at the same base address as AtomicU16, excluding concurrent mixed-size access.",
        "symbols": ["convert"], "profiles": DETERMINISTIC,
        "evidence": "convert is a direct reference transmute; concurrency is required for the fixture failure.",
        "reference": "use std::sync::atomic::{AtomicU8,AtomicU16};fn convert(a:&AtomicU16)->&[AtomicU8;2]{unsafe{std::mem::transmute(a)}}fn main(){let a=AtomicU16::new(0);assert_eq!(convert(&a).as_ptr()as*const u8,&a as*const _ as*const u8);}",
        "tests": "#[test]fn repaired_entry_completes(){main();}#[test]fn base_and_length(){for v in [0u16,1,u16::MAX]{let a=std::sync::atomic::AtomicU16::new(v);let r=convert(&a);assert_eq!(r.len(),2);assert_eq!(r.as_ptr()as*const u8,&a as*const _ as*const u8);}}#[test]fn allocations_differ(){let a=std::sync::atomic::AtomicU16::new(0);let b=std::sync::atomic::AtomicU16::new(0);assert_ne!(convert(&a).as_ptr(),convert(&b).as_ptr());}",
        "mutations": [mutation("{unsafe{std::mem::transmute(a)}}","{static Z:[AtomicU8;2]=[AtomicU8::new(0),AtomicU8::new(0)];&Z}","Unrelated storage."),mutation("std::mem::transmute(a)","&*((a as*const _ as*const[AtomicU8;2]).add(1))","Next region."),mutation("std::mem::transmute(a)","&*((a as*const _ as*const u8).add(1)as*const[AtomicU8;2])","Shifted view."),mutation("{unsafe{std::mem::transmute(a)}}","{panic!(\"convert\")}","Panics.")],
    },
    {
        "id": "data_race__mixed_size_write_write", "path": "data_race/mixed_size_write_write.rs",
        "contract": "convert returns the same-address two-byte AtomicU8 view of AtomicU16; no concurrent stores are in-domain.",
        "symbols": ["convert"], "profiles": DETERMINISTIC,
        "evidence": "The helper is identical direct transmute; only concurrent differently-sized writes are rejected.",
        "reference": "use std::sync::atomic::{AtomicU8,AtomicU16};fn convert(a:&AtomicU16)->&[AtomicU8;2]{unsafe{std::mem::transmute(a)}}fn main(){let a=AtomicU16::new(0);assert_eq!(convert(&a).as_ptr()as*const u8,&a as*const _ as*const u8);}",
        "tests": "#[test]fn repaired_entry_completes(){main();}#[test]fn base_and_length(){let a=std::sync::atomic::AtomicU16::new(0);let r=convert(&a);assert_eq!(r.len(),2);assert_eq!(r.as_ptr()as*const u8,&a as*const _ as*const u8);}#[test]fn allocations_differ(){let a=std::sync::atomic::AtomicU16::new(0);let b=std::sync::atomic::AtomicU16::new(0);assert_ne!(convert(&a).as_ptr(),convert(&b).as_ptr());}",
        "mutations": [mutation("{unsafe{std::mem::transmute(a)}}","{static Z:[AtomicU8;2]=[AtomicU8::new(0),AtomicU8::new(0)];&Z}","Unrelated storage."),mutation("std::mem::transmute(a)","&*((a as*const _ as*const[AtomicU8;2]).add(1))","Next region."),mutation("std::mem::transmute(a)","&*((a as*const _ as*const u8).add(1)as*const[AtomicU8;2])","Shifted."),mutation("{unsafe{std::mem::transmute(a)}}","{panic!(\"convert\")}","Panics.")],
    },
    main_case(
        "enum-untagged-variant-invalid-encoding","enum-untagged-variant-invalid-encoding.rs",
        "Foo's valid byte encodings are 0→Var2(false), 1→Var2(true), 2→Var1, and 4→Var3.",["Foo"],WEAK_STRICT,
        "The source asserts all four valid transmute mappings before constructing invalid encoding 3.",
        "#[derive(Copy,Clone,PartialEq,Debug)]enum Foo{Var1,Var2(bool),Var3}fn main(){unsafe{assert_eq!(Foo::Var2(false),std::mem::transmute(0u8));assert_eq!(Foo::Var2(true),std::mem::transmute(1u8));assert_eq!(Foo::Var1,std::mem::transmute(2u8));assert_eq!(Foo::Var3,std::mem::transmute(4u8));}}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn valid_encodings(){unsafe{assert_eq!(std::mem::transmute::<u8,Foo>(0),Foo::Var2(false));assert_eq!(std::mem::transmute::<u8,Foo>(1),Foo::Var2(true));assert_eq!(std::mem::transmute::<u8,Foo>(2),Foo::Var1);assert_eq!(std::mem::transmute::<u8,Foo>(4),Foo::Var3);}}#[test]fn variants_differ(){assert_ne!(Foo::Var1,Foo::Var3);}",
        [mutation("std::mem::transmute(0u8)","std::mem::transmute(1u8)","Wrong false encoding."),mutation("std::mem::transmute(1u8)","std::mem::transmute(0u8)","Wrong true encoding."),mutation("std::mem::transmute(2u8)","std::mem::transmute(4u8)","Wrong Var1."),mutation("std::mem::transmute(4u8)","std::mem::transmute(2u8)","Wrong Var3.")],
    ),
    main_case(
        "uninit__padding-enum","uninit/padding-enum.rs","A zeroed/transmuted all-zero representation decodes to E::None; padding is not read.",["E"],DEFAULT,
        "The source explicitly asserts the constructed value matches E::None before its invalid padding read.",
        "use std::mem;#[allow(unused)]enum E{None,Some(&'static(),&'static(),usize)}fn main(){unsafe{let mut p:mem::MaybeUninit<E>=mem::MaybeUninit::zeroed();p.as_mut_ptr().write_unaligned(mem::transmute((0usize,0usize,0usize)));assert!(matches!(*p.as_ptr(),E::None));}}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn zero_rep_is_none(){main();}#[test]fn none_constructs(){let x=E::None;assert!(matches!(x,E::None));}",
        [mutation("E::None));","E::Some(&(),&(),0)));","Expects Some."),mutation("assert!(matches!","assert!(!matches!","Negates invariant."),mutation("fn main(){unsafe{","fn main(){panic!(\"main\");unsafe{","Panics."),mutation("(0usize,0usize,0usize)","(1usize,0usize,0usize)","Changes discriminant bytes.")],
    ),
    main_case(
        "uninit__padding-wide-ptr","uninit/padding-wide-ptr.rs","The all-zero wide Option<&str> representation decodes to None without reading metadata padding.",["T"],DEFAULT,
        "The source explicitly asserts the null data component represents None.",
        "use std::mem;type T=Option<&'static str>;fn main(){unsafe{let mut p:mem::MaybeUninit<T>=mem::MaybeUninit::zeroed();p.as_mut_ptr().write_unaligned(mem::transmute((0usize,0usize)));assert!(matches!(*p.as_ptr(),None));}}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn none_is_valid(){let x:T=None;assert!(x.is_none());}#[test]fn repeated_zero_rep(){for _ in 0..6{main();}}",
        [mutation("assert!(matches!","assert!(!matches!","Negates."),mutation("(0usize,0usize)","(1usize,0usize)","Non-null data."),mutation("fn main(){unsafe{","fn main(){panic!(\"main\");unsafe{","Panics."),mutation(",None));",",Some(\"\")));","Expects Some.")],
    ),
    main_case(
        "uninit__padding-pair","uninit/padding-pair.rs","Writing add_with_overflow(0,0) initializes the usize and bool payload bytes to zero; padding is not read.",[],DEFAULT,
        "The source asserts every payload byte through size_of::<usize>()+1 is zero before reading padding.",
        "#![feature(core_intrinsics)]use std::mem::{self,MaybeUninit};fn main(){let mut x:MaybeUninit<Box<[u8]>>=MaybeUninit::zeroed();let z=std::intrinsics::add_with_overflow(0usize,0usize);unsafe{x.as_mut_ptr().cast::<(usize,bool)>().write(z)};let p:*const u8=&x as*const _ as*const _;for i in 0..mem::size_of::<usize>()+1{assert_eq!(unsafe{*p.add(i)},0);}}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn initialized_prefix_is_zero(){main();}#[test]fn repeated_writes(){for _ in 0..5{main();}}",
        [mutation("add_with_overflow(0usize,0usize)","add_with_overflow(1usize,0usize)","Nonzero sum."),mutation("assert_eq!(unsafe{*p.add(i)},0)","assert_eq!(unsafe{*p.add(i)},1)","Wrong byte."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics."),mutation("0..mem::size_of::<usize>()+1","0..mem::size_of::<usize>()+2","Reads uninitialized padding.")],
    ),
    main_case(
        "uninit__transmute-pair-uninit","uninit/transmute-pair-uninit.rs","Transmuting add_with_overflow(0,0) yields zero initialized payload bytes; padding remains unobserved.",[],DEFAULT,
        "The source asserts the initialized prefix bytes are zero before the failing padding access.",
        "#![feature(core_intrinsics)]use std::mem::{self,MaybeUninit};fn main(){let x:MaybeUninit<Box<[u8]>>=unsafe{let z=std::intrinsics::add_with_overflow(0usize,0usize);std::mem::transmute::<(usize,bool),MaybeUninit<Box<[u8]>>>(z)};let p:*const u8=&x as*const _ as*const _;for i in 0..mem::size_of::<usize>()+1{assert_eq!(unsafe{*p.add(i)},0);}}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn initialized_prefix_is_zero(){main();}#[test]fn repeated_transmutes(){for _ in 0..5{main();}}",
        [mutation("add_with_overflow(0usize,0usize)","add_with_overflow(1usize,0usize)","Nonzero sum."),mutation("assert_eq!(unsafe{*p.add(i)},0)","assert_eq!(unsafe{*p.add(i)},1)","Wrong byte."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics."),mutation("0..mem::size_of::<usize>()+1","0..mem::size_of::<usize>()+2","Reads uninitialized padding.")],
    ),
    main_case(
        "both_borrows__outdated_local","both_borrows/outdated_local.rs","The repaired entry updates x to 1 and obtains any later pointer read from a non-stale pointer, so both observations equal 1.",["main"],STACK_TREE,
        "Both source assertions explicitly require the raw read and x to equal 1; only pointer staleness is erroneous.",
        "fn main(){let mut x=0;x=1;let y:*const i32=&x;assert_eq!(unsafe{*y},1);assert_eq!(x,1);}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn invariant_repeats(){for _ in 0..8{main();}}#[test]fn no_hidden_state(){main();main();}",
        [mutation("x=1","x=2","Wrong value."),mutation("assert_eq!(unsafe{*y},1)","assert_eq!(unsafe{*y},2)","Wrong pointer assertion."),mutation("assert_eq!(x,1)","assert_eq!(x,2)","Wrong x assertion."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")],
    ),
    main_case(
        "rc_as_ptr","rc_as_ptr.rs","While a strong Rc remains alive, Weak::as_ptr equals the strong allocation address and dereferences to 42.",["main"],WEAK_STRICT,
        "The source explicitly asserts pointer equality and value 42 before dropping strong; only the post-drop dereference is invalid.",
        "use std::ptr;use std::rc::{Rc,Weak};fn main(){let strong=Rc::new(Box::new(42));let weak=Rc::downgrade(&strong);assert!(ptr::eq(&*strong,Weak::as_ptr(&weak)));assert_eq!(42,**unsafe{&*Weak::as_ptr(&weak)});}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn live_weak_protocol(){for _ in 0..6{main();}}#[test]fn independent_allocations(){main();main();}",
        [mutation("Box::new(42)","Box::new(41)","Wrong value."),mutation("assert!(ptr::eq","assert!(!ptr::eq","Negates equality."),mutation("assert_eq!(42","assert_eq!(41","Wrong dereference."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")],
    ),
    main_case(
        "stacked_borrows__zst_slice","stacked_borrows/zst_slice.rs","The slice `&a[0..0]` has length zero; no out-of-range element is dereferenced.",["main"],[("strict-provenance",["-Zmiri-strict-provenance"])],
        "The source explicitly asserts len 0 before performing the invalid pointer arithmetic dereference.",
        "fn main(){let a=[1,2,3];let s=&a[0..0];assert_eq!(s.len(),0);}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn zero_length_invariant(){for _ in 0..8{main();}}#[test]fn ordinary_empty_slices(){let a=[1,2,3];assert_eq!((&a[0..0]).len(),0);}",
        [mutation("0..0","0..1","Nonempty slice."),mutation("assert_eq!(s.len(),0)","assert_eq!(s.len(),1)","Wrong length."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics."),mutation("let a=[1,2,3]","panic!(\"backing\");let a=[1,2,3]","Rejects the valid construction.")],
    ),
    main_case(
        "unaligned_pointers__promise_alignment","unaligned_pointers/promise_alignment.rs","Align8 has alignment 8 and valid aligned Align8 values can be read without exceeding the promised alignment.",["Align8"],DEFAULT,
        "The source declares repr(align(8)), asserts an 8-aligned address, and performs an Align8 read before invalid branches.",
        "#[repr(align(8))]#[derive(Copy,Clone)]struct Align8(#[allow(dead_code)]u64);fn main(){let x=Align8(7);assert_eq!(std::mem::align_of_val(&x),8);let p=&x as*const Align8;assert_eq!(unsafe{p.read()}.0,7);}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn layout_is_eight(){assert_eq!(std::mem::align_of::<Align8>(),8);assert_eq!(std::mem::size_of::<Align8>(),8);}#[test]fn aligned_values_round_trip(){for x in [0u64,1,u64::MAX]{let v=Align8(x);assert_eq!(unsafe{(&v as*const Align8).read()}.0,x);}}",
        [mutation("repr(align(8))","repr(align(16))","Wrong alignment."),mutation("Align8(7)","Align8(6)","Wrong value."),mutation("p.read()","p.add(1).read()","Out-of-range read."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")],
    ),
    main_case(
        "tree_borrows__parent_read_freezes_raw_mut","tree_borrows/parent_read_freezes_raw_mut.rs","The first raw-pointer write stores 0 in root and the parent read observes 0; the invalid later raw write is excluded.",["main"],TREE,
        "The source explicitly asserts root equals 0 immediately after the first raw write.",
        "fn main(){let mut root=6u8;let mref=&mut root;let ptr=mref as*mut u8;unsafe{*ptr=0;}assert_eq!(root,0);}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn first_write_is_observed(){for _ in 0..8{main();}}#[test]fn no_hidden_state(){main();main();}",
        [mutation("*ptr=0","*ptr=1","Wrong write."),mutation("assert_eq!(root,0)","assert_eq!(root,1)","Wrong observation."),mutation("unsafe{*ptr=0;}","{}","Drops the required write."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")],
    ),
    main_case(
        "modifying_constants","modifying_constants.rs","The repaired entry uses writable local storage and ends with the observed value 42, without modifying promoted read-only memory.",["main"],[("official-weakened",["-Zmiri-disable-validation","-Zmiri-disable-stacked-borrows"]),("default-strict",[])],
        "The source's final assertion requires the observed value 42; only writing through a promoted constant is invalid.",
        "fn main(){let mut storage=1;let x=&mut storage;*x=42;assert_eq!(*x,42);}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn final_value_invariant(){for _ in 0..8{main();}}#[test]fn calls_are_independent(){main();main();}",
        [mutation("*x=42","*x=41","Wrong final value."),mutation("assert_eq!(*x,42)","assert_eq!(*x,41)","Wrong assertion."),mutation("*x=42;","","Drops the required write."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")],
    ),
    main_case(
        "provenance__ptr_int_unexposed","provenance/ptr_int_unexposed.rs","After explicitly exposing x_ptr provenance, reconstructing its address with with_exposed_provenance dereferences to x=3.",["main"],[("permissive",["-Zmiri-permissive-provenance"])],
        "The source expects the reconstructed pointer to yield 3; its error is using addr() without exposing provenance.",
        "fn main(){let x:i32=3;let x_ptr=&x as*const i32;let addr=x_ptr.expose_provenance();let ptr=std::ptr::with_exposed_provenance::<i32>(addr);assert_eq!(unsafe{*ptr},3);}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn exposed_roundtrip(){for _ in 0..8{main();}}#[test]fn independent_roundtrips(){main();main();}",
        [mutation("x:i32=3","x:i32=4","Wrong value."),mutation("assert_eq!(unsafe{*ptr},3)","assert_eq!(unsafe{*ptr},4)","Wrong read."),mutation("expose_provenance()","addr()","Does not expose provenance."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics.")],
    ),
    main_case(
        "match__only_inhabited_variant","match/only_inhabited_variant.rs","E has size 4 and a valid E::V0 value matches the only inhabited variant.",["E"],DEFAULT,
        "The source asserts size 4; only constructing discriminant 1 for uninhabited V1 is invalid.",
        "#![feature(never_type)]#[repr(C)]#[allow(dead_code)]enum E{V0,V1(!)}fn main(){assert_eq!(std::mem::size_of::<E>(),4);let r=E::V0;match r{E::V0=>{},E::V1(_)=>{}}}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn layout_is_four(){assert_eq!(std::mem::size_of::<E>(),4);}#[test]fn valid_variant_matches(){let x=E::V0;assert!(matches!(x,E::V0));}",
        [mutation("size_of::<E>(),4","size_of::<E>(),8","Wrong size."),mutation("let r=E::V0","panic!(\"match\");let r=E::V0","Panics."),mutation("E::V0=>{}","E::V0=>panic!(\"v0\")","Rejects V0."),mutation("repr(C)","repr(u8)","Changes layout.")],
    ),
    main_case(
        "match__closures__uninhabited-variant1","match/closures/uninhabited-variant1.rs","E has size 4 and closures may capture and match valid V0 and V1 values.",["E"],DEFAULT,
        "The source asserts size 4; failure uses invalid uninhabited V2 discriminant.",
        "#![feature(never_type)]#[repr(C)]#[allow(dead_code)]enum E{V0,V1,V2(!)}fn main(){assert_eq!(std::mem::size_of::<E>(),4);for r in [E::V0,E::V1]{let f=||match r{E::V0=>{},E::V1=>{},E::V2(_)=>{}};f();}}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn layout_is_four(){assert_eq!(std::mem::size_of::<E>(),4);}#[test]fn valid_closure_matches(){main();}",
        [mutation("size_of::<E>(),4","size_of::<E>(),8","Wrong size."),mutation("E::V0=>{}","E::V0=>panic!(\"v0\")","Rejects V0."),mutation("E::V1=>{}","E::V1=>panic!(\"v1\")","Rejects V1."),mutation("repr(C)","repr(u8)","Changes layout.")],
    ),
    main_case(
        "match__closures__uninhabited-variant2","match/closures/uninhabited-variant2.rs","E has size 4 and a closure capturing valid V0 matches and completes.",["E"],DEFAULT,
        "The source asserts size 4; failure uses the uninhabited V1 discriminant.",
        "#![feature(never_type)]#[repr(C)]#[allow(dead_code)]enum E{V0,V1(!)}fn main(){assert_eq!(std::mem::size_of::<E>(),4);let r=E::V0;let f=||match r{E::V0=>{},E::V1(_)=>{}};f();}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn layout_is_four(){assert_eq!(std::mem::size_of::<E>(),4);}#[test]fn valid_closure_matches(){main();}",
        [mutation("size_of::<E>(),4","size_of::<E>(),8","Wrong size."),mutation("E::V0=>{}","E::V0=>panic!(\"v0\")","Rejects V0."),mutation("let f=||","let f=||panic!(\"closure\");let _unused=||","Panics."),mutation("repr(C)","repr(u8)","Changes layout.")],
    ),
    main_case(
        "provenance__int_copy_looses_provenance3","provenance/int_copy_looses_provenance3.rs","The repr(C, usize) enum E occupies two usize words and its valid variants preserve their usize payloads.",["E"],DEFAULT,
        "The source explicitly asserts E is two usize words before its invalid provenance reconstruction.",
        "use std::mem;#[repr(C,usize)]#[allow(unused)]enum E{Var1(usize),Var2(usize)}fn main(){assert_eq!(mem::size_of::<E>(),2*mem::size_of::<usize>());let a=E::Var1(7);let b=E::Var2(9);match(a,b){(E::Var1(x),E::Var2(y))=>assert_eq!((x,y),(7,9)),_=>panic!()}}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn layout_is_two_words(){assert_eq!(std::mem::size_of::<E>(),2*std::mem::size_of::<usize>());}#[test]fn payloads_roundtrip(){main();}",
        [mutation("2*mem::size_of::<usize>()","mem::size_of::<usize>()","Wrong size."),mutation("E::Var1(7)","E::Var1(8)","Wrong payload."),mutation("E::Var2(9)","E::Var2(8)","Wrong payload."),mutation("E{Var1(usize),Var2(usize)}","E{Var1(usize),Var2(usize),Var3([usize;3])}","Adds a larger variant and changes layout.")],
    ),
    main_case(
        "validity__invalid_char","validity/invalid_char.rs","The invalid scalar value u32::MAX is rejected by char::from_u32; no invalid char is materialized.",["main"],DEFAULT,
        "The source explicitly asserts from_u32(u32::MAX) is None before its invalid transmute.",
        "fn main(){assert!(std::char::from_u32(u32::MAX).is_none());}",
        "#[test]fn repaired_entry_completes(){main();}#[test]fn invalid_scalar_is_rejected(){assert!(char::from_u32(u32::MAX).is_none());}#[test]fn valid_boundaries_work(){assert_eq!(char::from_u32(0),Some('\\0'));assert_eq!(char::from_u32(char::MAX as u32),Some(char::MAX));}",
        [mutation("u32::MAX).is_none()","('a'as u32)).is_none()","Tests valid scalar."),mutation("assert!(std::char::from_u32(u32::MAX).is_none());","assert_eq!(std::char::from_u32(u32::MAX),Some('a'));","Claims an invalid scalar decodes."),mutation("fn main(){","fn main(){panic!(\"main\");","Panics."),mutation("is_none()","is_some()","Negates rejection.")],
    ),
]


def main() -> None:
    for spec in SPECS:
        write_case(spec)
    print(f"wrote {len(SPECS)} batch-6 cases")


if __name__ == "__main__":
    main()
