# Private held-out evaluation for the Miri dataset

This directory contains evaluation-only semantic oracles.  It is deliberately
separate from:

- `halurust/` and `Miragent-artifact-anonymous/miragent/`;
- the Miri repair inputs;
- Semantic RAG and the UB example library;
- the repair/reflection loop.

The repair process must finish and write a final `.rs` file before anything in
this directory is mounted or invoked.  Results from this evaluator are for
post-hoc measurement only and must never be fed back to a repair agent.

For a blind paper run, place this directory in a separate private repository or
protected CI artifact and mount it only in the evaluator job.  Keeping it in
this workspace is for local construction and validation.

## Frozen dataset

`manifests/miri_dataset_manifest_v1.json` contains the 423 standalone,
oracle-backed cases selected from `miri_official_tests/fail/`. The canonical
benchmark filter first produces 438 candidates; 15 candidates without an
implemented high-confidence semantic oracle are excluded before the dataset is
frozen. Every dataset entry includes a source hash and parsed Miri directives.

Regenerate and verify it with:

```bash
python3 heldout_eval_private_miri/runner/build_manifest.py --check
```

`--check` exits non-zero if the checked-in manifest differs from a freshly
computed manifest, if the canonical candidate count is no longer 438, or if
the frozen oracle-backed dataset count is no longer 423.

## E/P/N oracle census

`manifests/oracle_census_v1.json` records a conservative decision for every
frozen case:

- `E`: complete whole-case executable semantics;
- `P`: a high-confidence original callable, type/layout, or explicit local
  invariant on well-defined inputs;
- `N`: no independent high-confidence oracle selected in this census.

`N` is not a claim that an oracle can never be written. The frozen dataset
contains 423 `P` cases (5 in `pilot_1`, 20 each in `batch_2` through
`batch_21`, and 18 in `batch_22`), no `N` cases, and no `E` cases. These cases
contain 1,269 held-out tests. Raw Miri failure entry points deliberately
execute UB or otherwise exist specifically to fail, so none met the
whole-program `E` standard.

Regenerate or verify both artifacts with:

```bash
python3 heldout_eval_private_miri/runner/build_manifest.py --check
python3 heldout_eval_private_miri/runner/build_census.py --check
python3 heldout_eval_private_miri/runner/audit_suite.py
```

The reviewed expansion batches are reproducibly materialized by
`runner/generate_batch2_cases.py` through `runner/generate_batch22_cases.py`.
They must be run only while maintaining the private evaluator, never in a
Miragent repair job.

`manifests/oracle_validation_summary_v1.json` records the completed oracle
calibration: all 423 references passed their declared profiles and all 1,692
expected-fail semantic mutants were rejected.

The 15 non-oracle candidates were reviewed individually and are recorded in
the manifest's `excluded_case_ids`; they are not members of the 423-case
dataset or census. They fall into four exclusion gates:

- the original callable has no well-defined input or success domain;
- the only behavior is an intentional trap, abort, panic, or unreachable UB;
- preserving the original API would preserve an intrinsically unsound
  ownership/aliasing contract;
- the required C-variadic, target-feature, SIMD, or WASM execution is not
  supported portably by the current private Miri evaluator target.

## Evaluate a final patch

```bash
python3 heldout_eval_private_miri/runner/evaluate.py \
  --case box-cell-alias \
  --fixed miri_fail_results/halurust/fixed/box-cell-alias.rs \
  --output /tmp/box-cell-alias.semantic.json
```

The evaluator constructs an isolated temporary Cargo library from the final
patch and appends the private `semantic_tests.rs` as a child module.  It then
runs every Miri profile declared by the case.

## Validate an oracle

Each implemented case contains a reference fix and semantic mutants. Mutants
may be stored as files or declared as exact inline substitutions in
`case.toml`. Validate that the reference passes and every expected mutant is
rejected:

```bash
python3 heldout_eval_private_miri/runner/evaluate.py \
  --case box-cell-alias \
  --validate-oracle
```

An expected survivor is recorded explicitly when a partial oracle cannot
observe a behavior.  Such limitations are documented in the case's
`oracle.md`.

## Batch evaluation

The batch wrapper expects flat final-patch names matching the frozen case IDs:

```bash
python3 heldout_eval_private_miri/runner/batch_evaluate.py \
  --fixed-root miri_fail_results/halurust/fixed \
  --output-dir /tmp/halurust-heldout \
  --workers 2
```

It reports oracle coverage separately from semantic consistency.  Missing or
non-evaluable patches are never silently counted as semantic passes.
