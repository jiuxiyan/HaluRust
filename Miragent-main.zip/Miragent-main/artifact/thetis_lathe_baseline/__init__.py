"""Compatibility package for the artifact layout."""

from pathlib import Path

__path__ = [
    str(
        Path(__file__).resolve().parent.parent
        / "baselines"
        / "thetis-lathe"
        / "thetis_lathe_baseline"
    )
]
