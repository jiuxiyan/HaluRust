# Miragent Anonymous Artifact

This repository contains the anonymous artifact package for the submitted paper
on Miragent, a multi-agent framework for automated repair of Undefined Behavior
in Rust.

## Contents

```text
.
├── baselines/
│   ├── giantrepair/       # GiantRepair-style baseline pipeline, no results
│   ├── llm_only/          # Direct LLM repair baseline pipeline, no results
│   ├── rustbrain/         # RustBrain-style baseline pipeline, no results
│   └── thetis-lathe/      # Thetis-Lathe-style baseline pipeline, no results
├── cve_crates/            # CVE crate material used by the study
├── datasets_cve/          # Filtered 65-CVE dataset
├── datasets_miri/         # Miri official failing tests used as Miri dataset
├── docs/
│   └── environment.md     # Environment and rerun notes
├── miragent/              # Miragent pipeline implementation
├── results/
│   ├── result.txt
│   └── result_ablation_study.txt
├── scripts/
│   ├── run_smoke_test.sh
│   ├── run_miragent_miri.sh
│   ├── run_miragent_cve.sh
│   ├── run_*_miri.sh
│   ├── run_*_cve.sh
│   └── run_ablation_*.sh
├── ub_example_library/    # Empty placeholder; populated after acceptance
└── requirements.txt
```

## Artifact Scope

This package supports availability and transparency checks for the main paper
claims:

- The Miragent repair pipeline implementation is included under `miragent/`.
- The Miri dataset is included under `datasets_miri/`.
- The CVE dataset is included under `datasets_cve/`. It contains the 65 CVE
  entries selected according to the no-data-race CVE list used in the study.
- The four baseline pipelines are included under `baselines/`.
- The summarized main and ablation results are included under `results/`.

The package includes an empty `ub_example_library` placeholder. The default
Miragent scripts disable Semantic RAG so they do not depend on that library.
The populated `ub_example_library` will be updated and uploaded after the paper
is accepted.

## Quick Start

From the repository root:

```bash
bash scripts/run_smoke_test.sh
```

Expected behavior:

- The script reports 65 CVE entries under `datasets_cve/`.
- The script reports at least one Rust test under `datasets_miri/`.
- The script imports the `miragent` Python package.
- The script prints installed Rust/Cargo versions if they are available.

## Setup for Online Reruns

Install Python dependencies:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Install Rust nightly with Miri:

```bash
rustup toolchain install nightly
rustup +nightly component add miri clippy rustfmt
```

Configure an LLM endpoint:

```bash
export OPENAI_API_KEY="..."
export OPENAI_BASE_URL="..." 
```

See `docs/environment.md` for details.

## Running Experiments

All online reruns require an LLM API key. You may either export it in advance:

```bash
export API_KEY="..."
export BASE_URL="..."
export MODEL="gpt-4o"   # or another OpenAI-compatible model name
```

or run a script interactively and enter the key when prompted.

The scripts accept common options such as `--limit`, `--workers`, `--max-iter`,
`--num-candidates`, `--timeout`, `--cve`, and `--out-dir`. For example:

```bash
bash scripts/run_miragent_miri.sh --limit 3
bash scripts/run_llm_only_cve.sh --limit 2
```

### Miri Dataset Scripts

```bash
bash scripts/run_miragent_miri.sh
bash scripts/run_llm_only_miri.sh
bash scripts/run_rustbrain_miri.sh
bash scripts/run_thetis_lathe_miri.sh
bash scripts/run_giantrepair_miri.sh
```

`run_miragent_miri.sh` disables Semantic RAG by default because the submitted
artifact contains only an empty `ub_example_library`.

After the populated library is available, run:

```bash
bash scripts/run_miragent_miri_with_ub_library.sh
```

### CVE Dataset Scripts

```bash
bash scripts/run_miragent_cve.sh
bash scripts/run_llm_only_cve.sh
bash scripts/run_rustbrain_cve.sh
bash scripts/run_thetis_lathe_cve.sh
bash scripts/run_giantrepair_cve.sh
```

`run_miragent_cve.sh` disables Semantic RAG by default. After the populated
library is available, run:

```bash
bash scripts/run_miragent_cve_with_ub_library.sh
```

The Thetis-Lathe and GiantRepair CVE scripts operate on a pre-synthesized
`source.rs`/`test.rs` layout. If `--synth-root` is not provided, the launcher
creates a compatibility directory under `work/cve_synth_from_dataset/` from
the included `datasets_cve` files. For strict reproduction, replace it with the
pre-synthesized CVE inputs used in the paper and pass `--synth-root PATH`.

### Miragent Ablation Scripts

```bash
bash scripts/run_ablation_miri.sh
bash scripts/run_ablation_cve.sh
```

These scripts run the full Miragent setting plus four ablations:

- `no_rag`
- `no_hallucination`
- `no_reflection`
- `no_multidim`

All outputs are written under `results/runs/` unless `--out-dir` is supplied.

## Data

### Miri Dataset

`datasets_miri/` is copied from the failing official Miri tests. It contains
Rust programs that exercise Undefined Behavior categories such as dangling
pointers, uninitialized memory, provenance, alignment, validity, stacked
borrows, and tree borrows.

### CVE Dataset

`datasets_cve/` contains 65 CVE entries. The entries were selected by matching
the CVE names in the no-data-race CVE subset used in the study. Each CVE
directory may contain source snippets, Miri tests, metadata, and vulnerability
description material.

`cve_crates/` contains crate-level CVE material used by the study.

## Pipelines

### Miragent

The Miragent implementation is in `miragent/`. The package includes the repair
pipeline, Miri runner, AST parser, LLM client, prompts, candidate evaluation,
and supporting models.

### Baselines

The baseline pipeline code is included under `baselines/`:

- `baselines/llm_only/`
- `baselines/giantrepair/`
- `baselines/rustbrain/`
- `baselines/thetis-lathe/`


## Results

The summarized results are:

- `results/result.txt`: main result table used by the paper.
- `results/result_ablation_study.txt`: ablation study summary.