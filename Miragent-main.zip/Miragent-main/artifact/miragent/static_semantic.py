"""Adapter exposing the semantic-consistency D1-D3 static metrics to the
pipeline, so that the in-loop Critic and the post-hoc evaluator share a single
definition of "semantic preservation".

We deliberately reuse :mod:`semantic_consistency_eval.static_metrics` instead of
re-implementing the heuristics. If that package is not importable (e.g. when
``halurust`` is used standalone), we fall back to degraded-but-safe defaults so
the pipeline keeps running.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

try:
    from semantic_consistency_eval.static_metrics import (
        api_surface_score as _api_surface_score,
        structural_similarity_score as _structural_similarity_score,
        trivialization_score as _trivialization_score,
    )

    _SCE_AVAILABLE = True
except Exception as e:  # noqa: BLE001
    logger.warning("semantic_consistency_eval not importable (%s); using fallbacks", e)
    _SCE_AVAILABLE = False


# Weights mirror semantic_consistency_eval.evaluator.ScoreWeights (sum = 1.0).
W_API = 0.20
W_TRIV = 0.30
W_STRUCT = 0.15
W_JUDGE = 0.35


def static_dims(original: str, fixed: str) -> tuple[float, float, float]:
    """Return (D1 api, D2 trivialization, D3 structural) scores in [0, 1]."""
    if not _SCE_AVAILABLE:
        return 1.0, 1.0, 0.5
    try:
        d1 = _api_surface_score(original, fixed).score
    except Exception:
        d1 = 1.0
    try:
        d2 = _trivialization_score(original, fixed).score
    except Exception:
        d2 = 1.0
    try:
        d3 = _structural_similarity_score(original, fixed)
    except Exception:
        d3 = 0.5
    return d1, d2, d3


def trivialization_preservation(original: str, fixed: str) -> float:
    """D2 only: 1.0 = no public function was trivialised, 0.0 = all gutted."""
    if not _SCE_AVAILABLE:
        return 1.0
    try:
        return _trivialization_score(original, fixed).score
    except Exception:
        return 1.0


def composite_semantic(d1: float, d2: float, d3: float, d4: float) -> float:
    """Weighted D1-D4 composite (normalised), matching the post-hoc evaluator."""
    total = W_API + W_TRIV + W_STRUCT + W_JUDGE
    return (W_API * d1 + W_TRIV * d2 + W_STRUCT * d3 + W_JUDGE * d4) / total
