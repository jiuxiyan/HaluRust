"""Unified LLM client wrapper with retry logic."""

from __future__ import annotations

import logging
import time

from openai import OpenAI
import httpx

from .config import HaluRustConfig

logger = logging.getLogger(__name__)

MAX_RETRIES = 5
RETRY_BACKOFF = [5, 15, 30, 60, 120]


class LLMClient:
    def __init__(self, config: HaluRustConfig):
        kwargs = {
            "api_key": config.api_key,
            "timeout": httpx.Timeout(300.0, connect=30.0),
            "max_retries": 2,
        }
        if config.base_url:
            kwargs["base_url"] = config.base_url
        self._client = OpenAI(**kwargs)
        self._model = config.model
        self._temperature = config.temperature

    def _call_with_retry(self, **kwargs) -> str:
        for attempt in range(MAX_RETRIES):
            try:
                resp = self._client.chat.completions.create(**kwargs)
                return resp.choices[0].message.content or ""
            except Exception as e:
                err_str = str(e).lower()
                is_transient = any(
                    kw in err_str
                    for kw in ["connection", "timeout", "rate", "502", "503", "429"]
                )
                if is_transient and attempt < MAX_RETRIES - 1:
                    wait = RETRY_BACKOFF[attempt]
                    logger.warning(
                        "LLM call failed (attempt %d/%d): %s — retrying in %ds",
                        attempt + 1, MAX_RETRIES, e, wait,
                    )
                    time.sleep(wait)
                else:
                    raise

    def chat(self, system: str, user: str, temperature: float | None = None) -> str:
        return self._call_with_retry(
            model=self._model,
            temperature=temperature or self._temperature,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        )

    def chat_with_history(
        self, system: str, messages: list[dict], temperature: float | None = None
    ) -> str:
        full = [{"role": "system", "content": system}] + messages
        return self._call_with_retry(
            model=self._model,
            temperature=temperature or self._temperature,
            messages=full,
        )
