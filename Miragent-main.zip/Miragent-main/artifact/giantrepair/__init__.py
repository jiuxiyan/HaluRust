"""Compatibility package for the artifact layout."""

from pathlib import Path

__path__ = [
    str(Path(__file__).resolve().parent.parent / "baselines" / "giantrepair" / "giantrepair")
]
