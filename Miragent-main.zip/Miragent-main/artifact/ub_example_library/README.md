# UB Example Library Placeholder

The paper artifact currently ships with an empty UB example library so that the
default reproduction scripts can run with Semantic RAG disabled.

After paper acceptance, the populated `ub_example_library` will be uploaded.
At that point, use the `scripts/run_miragent_*_with_ub_library.sh` scripts, or
pass `--use-ub-library` to `scripts/run_experiment.py`.
