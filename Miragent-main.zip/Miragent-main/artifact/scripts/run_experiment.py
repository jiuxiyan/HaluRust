#!/usr/bin/env python3
"""Unified artifact experiment launcher.

This script provides stable entry points for Miragent and the four baselines on
the Miri and CVE datasets. It is intentionally thin: it normalizes paths,
checks API configuration, creates result directories, and dispatches to the
corresponding pipeline implementation.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import time
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from typing import Iterable

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

METHODS = ("miragent", "llm_only", "rustbrain", "thetis_lathe", "giantrepair")
DATASETS = ("miri", "cve")
ABLATIONS = ("none", "no_rag", "no_hallucination", "no_reflection", "no_multidim")


def _api_key() -> str:
    return os.environ.get("API_KEY") or os.environ.get("OPENAI_API_KEY") or ""


def _model() -> str:
    return os.environ.get("MODEL") or os.environ.get("OPENAI_MODEL") or "gpt-4o"


def _base_url() -> str | None:
    return os.environ.get("BASE_URL") or os.environ.get("OPENAI_BASE_URL") or None


def _env() -> dict[str, str]:
    env = os.environ.copy()
    env.setdefault("PYTHONPATH", str(ROOT))
    env["PYTHONPATH"] = f"{ROOT}{os.pathsep}{env['PYTHONPATH']}"
    key = _api_key()
    if key:
        env.setdefault("API_KEY", key)
        env.setdefault("OPENAI_API_KEY", key)
    if _base_url():
        env.setdefault("BASE_URL", _base_url() or "")
        env.setdefault("OPENAI_BASE_URL", _base_url() or "")
    env.setdefault("MODEL", _model())
    env.setdefault("OPENAI_MODEL", _model())
    return env


def _run(cmd: list[str]) -> int:
    print("+", " ".join(str(c) for c in cmd), flush=True)
    return subprocess.run(cmd, cwd=ROOT, env=_env()).returncode


def _out_dir(args: argparse.Namespace, suffix: str) -> Path:
    if args.out_dir:
        out = Path(args.out_dir).expanduser()
    else:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        out = ROOT / "results" / "runs" / f"{args.dataset}_{args.method}_{suffix}_{ts}"
    out.mkdir(parents=True, exist_ok=True)
    return out


def _extract_rust_code(raw: str) -> str:
    m = re.search(r"```rust\s*\n(.*?)```", raw, re.DOTALL)
    if m:
        return m.group(1).strip()
    m = re.search(r"```\s*\n(.*?)```", raw, re.DOTALL)
    if m:
        return m.group(1).strip()
    return raw.strip()


def _miri_cases(root: Path, limit: int | None) -> list[Path]:
    skip_names = {
        "no_main.rs",
        "miri_start_wrong_sig.rs",
        "rustc-error.rs",
        "rustc-error2.rs",
        "type-too-large.rs",
        "deny_lint.rs",
        "unsupported_foreign_function.rs",
    }
    non_standalone = [
        re.compile(r"#!\s*\[\s*no_main\s*\]"),
        re.compile(r"#!\s*\[\s*no_std\s*\]"),
        re.compile(r"^\s*extern\s+\"[A-Za-z0-9-]+\"\s*\{", re.MULTILINE),
        re.compile(r"#\[panic_handler\]"),
    ]
    cases: list[Path] = []
    for path in sorted(root.rglob("*.rs")):
        if path.name in skip_names:
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        if "fn main(" not in text:
            continue
        if any(p.search(text) for p in non_standalone):
            continue
        cases.append(path)
        if limit is not None and len(cases) >= limit:
            break
    return cases


def _cve_ids(root: Path, limit: int | None, selected: list[str] | None = None) -> list[str]:
    if selected:
        return selected[:limit] if limit is not None else selected
    ids = [p.name for p in sorted(root.iterdir()) if p.is_dir() and p.name.startswith("CVE-")]
    return ids[:limit] if limit is not None else ids


def _make_miragent_config(args: argparse.Namespace, out_dir: Path, ablation: str):
    from miragent.config import HaluRustConfig

    no_multidim = ablation == "no_multidim"
    use_rag = args.use_ub_library and ablation != "no_rag"
    return HaluRustConfig(
        model=_model(),
        api_key=_api_key(),
        base_url=_base_url(),
        max_iterations=args.max_iter,
        num_candidates=1 if no_multidim else args.num_candidates,
        score_threshold=0.0 if no_multidim else 0.4,
        enable_rag=use_rag,
        enable_reflection=(ablation != "no_reflection"),
        enable_hallucination=(use_rag and ablation != "no_hallucination"),
        enable_clippy=(not no_multidim),
        enable_semantic_check=(not no_multidim),
        enable_experience_accumulation=False,
        workspace_dir=out_dir / "_workspace",
    )


def _history_payload(path: Path, history, elapsed: float) -> dict:
    return {
        "case": str(path),
        "succeeded": history.succeeded,
        "initial_miri_passed": history.original_report.passed,
        "initial_error_type": history.original_report.error_type.value,
        "attempts": [
            {
                "iteration": a.iteration,
                "status": a.status.value,
                "miri_passed": a.miri_report.passed,
                "score": asdict(a.score),
                "num_candidates": a.num_candidates,
            }
            for a in history.attempts
        ],
        "elapsed_seconds": round(elapsed, 2),
    }


def run_miragent_miri(args: argparse.Namespace, ablation: str) -> int:
    from miragent.pipeline import HaluRustPipeline

    out = _out_dir(args, ablation)
    config = _make_miragent_config(args, out, ablation)
    pipeline = HaluRustPipeline(config, library_path=str(ROOT / "ub_example_library"))
    per_case = out / "per_case"
    fixed = out / "fixed"
    per_case.mkdir(parents=True, exist_ok=True)
    fixed.mkdir(parents=True, exist_ok=True)

    cases = _miri_cases(ROOT / "datasets_miri", args.limit)
    rows = []
    for idx, path in enumerate(cases, 1):
        print(f"[{idx}/{len(cases)}] Miragent Miri: {path.relative_to(ROOT)}")
        source = path.read_text(encoding="utf-8", errors="ignore")
        t0 = time.time()
        history = pipeline.run_single_file(
            source,
            filename=str(path.relative_to(ROOT)),
            skip_hallucination=(not config.enable_hallucination),
        )
        payload = _history_payload(path.relative_to(ROOT), history, time.time() - t0)
        rows.append(payload)
        stem = "__".join(path.relative_to(ROOT / "datasets_miri").with_suffix("").parts)
        (per_case / f"{stem}.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
        if history.final_code:
            (fixed / f"{stem}.rs").write_text(history.final_code, encoding="utf-8")

    summary = {
        "method": "miragent",
        "dataset": "miri",
        "ablation": ablation,
        "use_ub_library": args.use_ub_library,
        "total": len(rows),
        "succeeded": sum(1 for r in rows if r["succeeded"]),
        "results": rows,
    }
    (out / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(f"Results written to {out}")
    return 0


def run_llm_only_miri(args: argparse.Namespace) -> int:
    from miragent.config import HaluRustConfig
    from miragent.llm_client import LLMClient
    from miragent.miri_runner import parse_miri_flags, run_miri_single_file

    out = _out_dir(args, "direct")
    per_case = out / "per_case"
    fixed = out / "fixed"
    per_case.mkdir(parents=True, exist_ok=True)
    fixed.mkdir(parents=True, exist_ok=True)
    config = HaluRustConfig(
        model=_model(),
        api_key=_api_key(),
        base_url=_base_url(),
        max_iterations=args.max_iter,
        enable_rag=False,
        enable_hallucination=False,
        enable_experience_accumulation=False,
        workspace_dir=out / "_workspace",
    )
    llm = LLMClient(config)
    system = (
        "You are a Rust developer. Fix the Undefined Behavior in the given Rust "
        "program. Return only the complete fixed Rust code in a ```rust block."
    )
    cases = _miri_cases(ROOT / "datasets_miri", args.limit)
    rows = []
    for idx, path in enumerate(cases, 1):
        print(f"[{idx}/{len(cases)}] LLM-only Miri: {path.relative_to(ROOT)}")
        original = path.read_text(encoding="utf-8", errors="ignore")
        current = original
        flags = parse_miri_flags(original)
        initial = run_miri_single_file(current, config, extra_miri_flags=flags)
        t0 = time.time()
        final_report = initial
        for _ in range(args.max_iter):
            prompt = (
                "## Rust code\n```rust\n"
                + current
                + "\n```\n\n## Miri result\n```\n"
                + final_report.raw_stderr[-6000:]
                + "\n```\n"
            )
            current = _extract_rust_code(llm.chat(system, prompt, temperature=0.2))
            final_report = run_miri_single_file(current, config, extra_miri_flags=flags)
            if final_report.passed:
                break
        stem = "__".join(path.relative_to(ROOT / "datasets_miri").with_suffix("").parts)
        payload = {
            "case": str(path.relative_to(ROOT)),
            "initial_miri_passed": initial.passed,
            "final_miri_passed": final_report.passed,
            "initial_error_type": initial.error_type.value,
            "elapsed_seconds": round(time.time() - t0, 2),
        }
        rows.append(payload)
        (per_case / f"{stem}.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
        (fixed / f"{stem}.rs").write_text(current, encoding="utf-8")
    (out / "summary.json").write_text(json.dumps({"results": rows}, indent=2), encoding="utf-8")
    print(f"Results written to {out}")
    return 0


def _single_file_as_lib_test(source: str) -> tuple[str, str]:
    test = "#[cfg(test)]\nmod tests {\n    use super::*;\n    #[test]\n    fn trigger_miri_ub() {\n        main();\n    }\n}\n"
    return source, test


def _run_libtest_miri(args: argparse.Namespace, method: str) -> int:
    if method == "thetis_lathe":
        from thetis_lathe_baseline.config import ThetisLatheParams, tooling_config
        from thetis_lathe_baseline.orchestrator import ThetisLathe

        cfg = tooling_config()
        cfg.results_dir = ROOT / "results" / "runs"
        runner = ThetisLathe(config=cfg, params=ThetisLatheParams(max_repair_rounds=args.max_iter))
    elif method == "giantrepair":
        from giantrepair.config import GiantRepairParams, tooling_config
        from giantrepair.orchestrator import GiantRepair

        cfg = tooling_config()
        cfg.results_dir = ROOT / "results" / "runs"
        runner = GiantRepair(config=cfg, params=GiantRepairParams(n_llm_patches=args.num_candidates))
    else:
        raise ValueError(method)

    out = _out_dir(args, "libtest")
    per_case = out / "per_case"
    fixed = out / "fixed"
    per_case.mkdir(parents=True, exist_ok=True)
    fixed.mkdir(parents=True, exist_ok=True)
    cases = _miri_cases(ROOT / "datasets_miri", args.limit)
    rows = []
    for idx, path in enumerate(cases, 1):
        print(f"[{idx}/{len(cases)}] {method} Miri: {path.relative_to(ROOT)}")
        source, test = _single_file_as_lib_test(path.read_text(encoding="utf-8", errors="ignore"))
        t0 = time.time()
        result = runner.run_lib_test(source, test, salt=str(path.relative_to(ROOT)))
        stem = "__".join(path.relative_to(ROOT / "datasets_miri").with_suffix("").parts)
        payload = result.to_trace_dict()
        payload["case"] = str(path.relative_to(ROOT))
        payload["elapsed_seconds"] = round(time.time() - t0, 2)
        rows.append(payload)
        (per_case / f"{stem}.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
        (fixed / f"{stem}.rs").write_text(result.final_code, encoding="utf-8")
    (out / "summary.json").write_text(json.dumps({"results": rows}, indent=2), encoding="utf-8")
    print(f"Results written to {out}")
    return 0


def _prepare_cve_synth(root: Path, limit: int | None, selected: list[str] | None) -> Path:
    out = ROOT / "work" / "cve_synth_from_dataset"
    out.mkdir(parents=True, exist_ok=True)
    ids = _cve_ids(root, limit, selected)
    for cid in ids:
        src_dir = root / cid
        rs_candidates = [p for p in sorted(src_dir.glob("*.rs")) if p.name != "miri_test.rs"]
        if not rs_candidates or not (src_dir / "miri_test.rs").is_file():
            continue
        dst = out / cid
        dst.mkdir(parents=True, exist_ok=True)
        (dst / "source.rs").write_text(rs_candidates[0].read_text(encoding="utf-8"), encoding="utf-8")
        (dst / "test.rs").write_text((src_dir / "miri_test.rs").read_text(encoding="utf-8"), encoding="utf-8")
        meta = {"source": str(rs_candidates[0].relative_to(ROOT)), "test": str((src_dir / "miri_test.rs").relative_to(ROOT))}
        md = next(iter(sorted(src_dir.glob("*.md"))), None)
        if md:
            meta["description"] = str(md.relative_to(ROOT))
        (dst / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return out


def run_cve(args: argparse.Namespace, ablation: str) -> int:
    cves = _cve_ids(ROOT / "datasets_cve", args.limit, args.cve)
    out = _out_dir(args, ablation)
    if args.method == "miragent":
        cmd = [
            sys.executable,
            str(ROOT / "baselines" / "llm_only" / "run_cve_safe_func_batch.py"),
            "--out-dir",
            str(out),
            "--max-iter",
            str(args.max_iter),
            "--num-candidates",
            str(args.num_candidates),
            "--timeout",
            str(args.timeout),
            "--ablation",
            "none" if args.use_ub_library and ablation == "none" else ablation,
        ]
        if not args.use_ub_library and ablation == "none":
            cmd[-1] = "no_rag"
        if cves:
            cmd += ["--cve", *cves]
        return _run(cmd)
    if args.method == "llm_only":
        cmd = [
            sys.executable,
            str(ROOT / "baselines" / "llm_only" / "run_baseline_batch.py"),
            "--out-dir",
            str(out),
            "--max-iter",
            str(args.max_iter),
            "--timeout",
            str(args.timeout),
        ]
        if cves:
            cmd += ["--cve", *cves]
        return _run(cmd)
    if args.method == "rustbrain":
        cmd = [
            sys.executable,
            "-m",
            "rustbrain_baseline.run_cve_safe_func_batch",
            "--cve-root",
            str(ROOT / "datasets_cve"),
            "--out-dir",
            str(out),
            "--workers",
            str(args.workers),
            "--cve-timeout",
            str(args.timeout),
        ]
        if args.limit is not None:
            cmd += ["--limit", str(args.limit)]
        if args.cve:
            cmd += ["--cve", *args.cve]
        return _run(cmd)

    synth = args.synth_root or _prepare_cve_synth(ROOT / "datasets_cve", args.limit, args.cve)
    module = (
        "thetis_lathe_baseline.run_cve_synth_batch"
        if args.method == "thetis_lathe"
        else "giantrepair.run_cve_synth_batch"
    )
    cmd = [
        sys.executable,
        "-m",
        module,
        "--synth-root",
        str(synth),
        "--out-dir",
        str(out),
        "--workers",
        str(args.workers),
        "--cve-timeout",
        str(args.timeout),
    ]
    if args.limit is not None:
        cmd += ["--limit", str(args.limit)]
    if args.cve:
        cmd += ["--cve", *args.cve]
    return _run(cmd)


def run_miri(args: argparse.Namespace, ablation: str) -> int:
    if args.method == "miragent":
        return run_miragent_miri(args, ablation)
    if args.method == "llm_only":
        return run_llm_only_miri(args)
    if args.method == "rustbrain":
        out = _out_dir(args, "batch")
        cmd = [
            sys.executable,
            "-m",
            "rustbrain_baseline.run_miri_fail_batch",
            "--root",
            str(ROOT / "datasets_miri"),
            "--out-dir",
            str(out),
            "--workers",
            str(args.workers),
        ]
        if args.limit is not None:
            cmd += ["--limit", str(args.limit)]
        return _run(cmd)
    if args.method in ("thetis_lathe", "giantrepair"):
        return _run_libtest_miri(args, args.method)
    raise ValueError(args.method)


def run_ablation(args: argparse.Namespace) -> int:
    variants = ("none", "no_rag", "no_hallucination", "no_reflection", "no_multidim")
    for variant in variants:
        print(f"\n=== Miragent ablation: {variant} on {args.dataset} ===", flush=True)
        code = run_miri(args, variant) if args.dataset == "miri" else run_cve(args, variant)
        if code != 0:
            return code
    return 0


def main(argv: Iterable[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--method", choices=METHODS, default="miragent")
    parser.add_argument("--dataset", choices=DATASETS, required=True)
    parser.add_argument("--ablation", choices=ABLATIONS, default="none")
    parser.add_argument("--all-ablation", action="store_true")
    parser.add_argument("--use-ub-library", action="store_true")
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--cve", nargs="*", default=None)
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--max-iter", type=int, default=4)
    parser.add_argument("--num-candidates", type=int, default=2)
    parser.add_argument("--timeout", type=int, default=1500)
    parser.add_argument("--out-dir", type=Path, default=None)
    parser.add_argument("--synth-root", type=Path, default=None)
    args = parser.parse_args(list(argv) if argv is not None else None)

    if not _api_key():
        print("Missing API key. Set API_KEY or OPENAI_API_KEY.", file=sys.stderr)
        return 2

    if args.all_ablation:
        args.method = "miragent"
        return run_ablation(args)
    if args.dataset == "miri":
        return run_miri(args, args.ablation)
    return run_cve(args, args.ablation)


if __name__ == "__main__":
    raise SystemExit(main())
