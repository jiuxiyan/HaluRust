#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ARTIFACT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
REPO_ROOT="$(cd "$ARTIFACT_ROOT/.." && pwd)"
export PYTHONPATH="$ARTIFACT_ROOT:${PYTHONPATH:-}"

load_dotenv_file() {
  local env_file="$1"
  [[ -f "$env_file" ]] || return 0
  local line key value
  while IFS= read -r line || [[ -n "$line" ]]; do
    line="${line#"${line%%[![:space:]]*}"}"
    line="${line%"${line##*[![:space:]]}"}"
    [[ -z "$line" || "$line" == \#* || "$line" != *=* ]] && continue
    if [[ "$line" == export\ * ]]; then
      line="${line#export }"
    fi
    key="${line%%=*}"
    value="${line#*=}"
    key="${key#"${key%%[![:space:]]*}"}"
    key="${key%"${key##*[![:space:]]}"}"
    value="${value#"${value%%[![:space:]]*}"}"
    value="${value%"${value##*[![:space:]]}"}"
    value="${value%\"}"
    value="${value#\"}"
    value="${value%\'}"
    value="${value#\'}"
    [[ "$key" =~ ^[A-Za-z_][A-Za-z0-9_]*$ ]] || continue
    if [[ -z "${!key:-}" ]]; then
      export "$key=$value"
    fi
  done < "$env_file"
}

load_dotenv() {
  load_dotenv_file "$REPO_ROOT/.env"
  load_dotenv_file "$ARTIFACT_ROOT/.env"
  load_dotenv_file "$PWD/.env"
}

ensure_api_key() {
  for arg in "$@"; do
    if [[ "$arg" == "--help" || "$arg" == "-h" ]]; then
      return 0
    fi
  done

  load_dotenv

  if [[ -z "${API_KEY:-}" && -n "${OPENAI_API_KEY:-}" ]]; then
    export API_KEY="$OPENAI_API_KEY"
  fi
  if [[ -z "${OPENAI_API_KEY:-}" && -n "${API_KEY:-}" ]]; then
    export OPENAI_API_KEY="$API_KEY"
  fi

  if [[ -z "${API_KEY:-}" ]]; then
    if [[ -t 0 ]]; then
      printf "Enter LLM API key (input hidden): "
      stty -echo
      read -r API_KEY
      stty echo
      printf "\n"
      export API_KEY
      export OPENAI_API_KEY="$API_KEY"
    else
      echo "Missing API key. Set API_KEY or OPENAI_API_KEY before running this script." >&2
      exit 2
    fi
  fi

  export MODEL="${MODEL:-${OPENAI_MODEL:-gpt-4o}}"
  export OPENAI_MODEL="${OPENAI_MODEL:-$MODEL}"
  if [[ -n "${OPENAI_BASE_URL:-}" && -z "${BASE_URL:-}" ]]; then
    export BASE_URL="$OPENAI_BASE_URL"
  fi
  if [[ -n "${BASE_URL:-}" && -z "${OPENAI_BASE_URL:-}" ]]; then
    export OPENAI_BASE_URL="$BASE_URL"
  fi
}

run_experiment() {
  ensure_api_key "$@"
  cd "$ARTIFACT_ROOT"
  python3 scripts/run_experiment.py "$@"
}
