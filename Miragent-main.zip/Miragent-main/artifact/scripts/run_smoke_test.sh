#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

echo "[smoke] Artifact root: $ROOT"

required_paths=(
  "datasets_miri"
  "datasets_cve"
  "cve_crates"
  "miragent"
  "baselines/llm_only"
  "baselines/giantrepair"
  "baselines/rustbrain"
  "baselines/thetis-lathe"
  "results/result.txt"
  "results/result_ablation_study.txt"
  "docs/environment.md"
  "ub_example_library"
  "scripts/run_experiment.py"
  "scripts/run_miragent_miri.sh"
  "scripts/run_llm_only_miri.sh"
  "scripts/run_rustbrain_miri.sh"
  "scripts/run_thetis_lathe_miri.sh"
  "scripts/run_giantrepair_miri.sh"
  "scripts/run_ablation_miri.sh"
)

for path in "${required_paths[@]}"; do
  if [[ ! -e "$path" ]]; then
    echo "[smoke] Missing required path: $path" >&2
    exit 1
  fi
done

cve_count="$(find datasets_cve -maxdepth 1 -type d -name 'CVE-*' | wc -l | tr -d ' ')"
if [[ "$cve_count" != "65" ]]; then
  echo "[smoke] Expected 65 CVE dataset entries, found $cve_count" >&2
  exit 1
fi

miri_rs_count="$(find datasets_miri -type f -name '*.rs' | wc -l | tr -d ' ')"
if [[ "$miri_rs_count" -lt "1" ]]; then
  echo "[smoke] No Rust tests found under datasets_miri" >&2
  exit 1
fi

if [[ -n "$(find ub_example_library -mindepth 1 -type f ! -name 'README.md' ! -name '.gitkeep' -print -quit)" ]]; then
  echo "[smoke] ub_example_library should be an empty placeholder in this artifact" >&2
  exit 1
fi

python3 - <<'PY'
from pathlib import Path
import sys

root = Path.cwd()
sys.path.insert(0, str(root))

from miragent.config import HaluRustConfig
import rustbrain_baseline.config
import thetis_lathe_baseline.config
import giantrepair.config

cfg = HaluRustConfig(api_key="dummy", enable_rag=False, enable_semantic_check=False)
assert cfg.max_iterations >= 1
assert (root / "datasets_cve").exists()
assert (root / "datasets_miri").exists()
assert (root / "ub_example_library").exists()

print("[smoke] Python import check passed")
print(f"[smoke] Miragent default model: {cfg.model}")
PY

python3 scripts/run_experiment.py --help >/dev/null
echo "[smoke] Experiment launcher help check passed"

if command -v rustc >/dev/null 2>&1; then
  echo "[smoke] rustc: $(rustc --version)"
else
  echo "[smoke] rustc not found; install Rust nightly for online Miri reruns"
fi

if command -v cargo >/dev/null 2>&1; then
  echo "[smoke] cargo: $(cargo --version)"
else
  echo "[smoke] cargo not found; install Rust nightly for online Miri reruns"
fi

echo "[smoke] Dataset entries: $cve_count CVEs, $miri_rs_count Miri failing tests"
echo "[smoke] Smoke test passed"
