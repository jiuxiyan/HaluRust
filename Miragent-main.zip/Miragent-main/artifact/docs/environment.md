# Environment

This artifact supports two usage modes.

1. Offline inspection and table verification. This mode uses the included source code,
   datasets, and summarized result tables. It does not require LLM API access.
2. Online rerun. This mode reruns Miragent or the baselines on selected cases. It
   requires Rust nightly with Miri and user-provided LLM credentials.

## Tested Software Stack

- Python 3.11 or newer
- Rust nightly toolchain
- Miri component for Rust nightly
- Cargo and Clippy
- Python packages listed in `requirements.txt`

Recommended Rust setup:

```bash
rustup toolchain install nightly
rustup +nightly component add miri clippy rustfmt
```

Recommended Python setup:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## Optional LLM Configuration

Online reruns require API credentials. The exact endpoint is intentionally not
bundled in the anonymous artifact.

```bash
export OPENAI_API_KEY="..."
export OPENAI_BASE_URL="..."   
export OPENAI_MODEL="gpt-4o"   # optional
```

The shell scripts also accept `API_KEY`, `BASE_URL`, and `MODEL`. If no key is
set and the script is run interactively, it will prompt for one.

The reported paper results were produced with multiple LLM backends. Exact
online reruns may differ because hosted model versions, decoding behavior, and
API-side safety filters can change over time. The artifact therefore includes
summarized result tables for reviewer inspection.

## Quick Validation

Run:

```bash
bash scripts/run_smoke_test.sh
```

The smoke test checks that the expected artifact directories exist, verifies
that the filtered CVE dataset contains 65 entries, imports the Miragent Python
package, and reports whether Rust/Cargo are installed.

## Online Rerun Examples

Run a small Miragent sample on the Miri dataset with Semantic RAG disabled:

```bash
bash scripts/run_miragent_miri.sh --limit 3
```

Run the four baselines on a small CVE subset:

```bash
bash scripts/run_llm_only_cve.sh --limit 2
bash scripts/run_rustbrain_cve.sh --limit 2
bash scripts/run_thetis_lathe_cve.sh --limit 2
bash scripts/run_giantrepair_cve.sh --limit 2
```

Run Miragent ablations:

```bash
bash scripts/run_ablation_miri.sh --limit 3
bash scripts/run_ablation_cve.sh --limit 2
```
