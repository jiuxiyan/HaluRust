ICSE 2027 Paper  Reviews and Comments
===========================================================================
Paper Miragent: Repairing Undefined Behavior in Rust via a RAG-based
Hallucination-Augmented Workflow


Review #2319A
===========================================================================

Overall merit
-------------
4. Accept

Novelty
-------
3. Substantial - presents a clearly new idea, method, result, artifact,
   dataset, use case, workflow, or perspective

Rigor
-----
4. Excellent - methodologically rigorous, well-justified, and strongly
   supported

Relevance
---------
3. High - addresses an important SE problem and is likely to influence
   research or practice under clear assumptions

Verifiability and Transparency
------------------------------
4. Excellent - The work is highly transparent and well documented, strongly
   supporting verification or replication where appropriate

Presentation
------------
3. Good - clear, well organized, and easy to follow

Paper summary
-------------
This paper presents Miragent, a multi-agent framework for automatically repairing undefined behavior in Rust. Its four-stage workflow covers localization, context construction using retrieved repair examples and hallucinated bad fixes, repair generation through agentic process, and candidate evaluation with Miri, Clippy, semantic consistency, and minimal-change checks. Its key idea, described as fighting hallucination with hallucination, uses intentionally incorrect fixes as contrastive guidance.

Strengths
---------
Novel and well-illustrated hallucination as contrastive prior mechanism, with a concrete worked example that makes the intuition clear.

Evaluated across three backends and two datasets with an ablation isolating each component.

Weaknesses
----------
Localization is admitted to be approximate and is never measured.

The test generation agent's runtime, budget, and success rate at exposing UB are unreported, despite the approach being entirely Miri/test-grounded.

Detailed comments for authors
-----------------------------
Novelty

The core idea, deliberately eliciting hallucinated, unsound fixes and using them as contrastive negative priors rather than only suppressing hallucination, is a genuinely fresh framing for repair, and pairing it with Miri-grounded verification and a held-out semantic-consistency check is sensible. 

Rigor

Localization quality. Stage 1 localizes by aligning the Miri-reported location with the AST, but the discussion itself admits the Miri-reported location is not always the true root cause. How good is the localization part, actually? There is no measurement of localization accuracy, and since the entire repair context is built around the localized region, a weak localizer would silently cap the whole pipeline.

Test Generation Agent. How do you know that UB is present in the first place? The agent iterates generating Miri tests until Miri observes UB or the budget is exhausted. But if no test triggers UB, how is the presence of UB established? How long does the test generation agent run, and what is its success rate at actually exposing the UB? 

Hallucination validity. How do you know that the hallucinated agent's output is indeed hallucinated? Miragent keeps fixes that fail Miri or that pass Miri but significantly change program semantics as Hallucination Fixes. But the criterion for significantly change semantics is exactly the hard judgment. If that judgment is unreliable, genuine fixes could be mislabeled as hallucinations, which risks steering the repair away from correct directions.

Cost analysis. Without token and dollar cost of the entire process, the acceptable time overhead claim cannot be assessed.

Relevance

UB repair at Rust's unsafe boundaries is a real and growing problem and Miri-grounded, semantics-preserving repair is well-motivated. 

Verifiability

An anonymized artifact with implementation, scripts, benchmark metadata, and result files is provided, and the datasets, baselines, backends, and metrics are described.

Questions for authors’ response
-------------------------------
1. How good is the localization part, and how was its accuracy measured given Miri's reported site may not be the true root cause?

2. For the test generation agent: how do you know UB is present at all? How long does it run, and what is its success rate at generating a UB-triggering test?

3. How do you know that a hallucinated fix is indeed hallucinated?

4. What is the full cost analysis of this approach compared to existing approaches?



Review #2319B
===========================================================================

Overall merit
-------------
2. Weak reject

Novelty
-------
2. Incremental - modest extension, adaptation, combination, or improvement

Rigor
-----
2. Fair - some weaknesses, but the main claims are at least partially
   supported

Relevance
---------
2. Moderate - relevant and useful, but the expected impact is limited or
   narrowly scoped

Verifiability and Transparency
------------------------------
2. Fair - Some information is provided, but not enough to support
   independent scrutiny, verification, or replication where appropriate

Presentation
------------
2. Fair - understandable, but with noticeable clarity or organization
   issues

Paper summary
-------------
This paper presents Miragent, an LLM-based workflow for repairing Miri-detectable undefined behavior in Rust. The system combines Miri diagnostics and Tree-sitter ASTs with retrieval from a 101-example UB repair library, an agent deliberately prompted to generate incorrect or semantics-changing fixes, a Reflection-Plan-Fix agent pipeline, and an evaluation stage using Miri, Clippy, semantic-consistency assessment, and edit size. Miragent is evaluated on 438 tests collected from the official Miri repository and 65 selected Rust CVEs using Gemini-3-Flash, GPT-5 Mini, and DeepSeek-V4-Flash. The paper reports higher fix rates than four adapted baselines and attributes part of the gain to the hallucination agent.

Strengths
---------
- Repairing undefined behavior in Rust is an important problem.
- The evaluation includes both Miri test cases and real-world CVEs across three LLM backends.
- The reported results are promising.

Weaknesses
----------
- The Hallucination Agent is not compared with simpler negative examples or additional repair sampling under a comparable budget.
- The retrieval library and Miri evaluation set share a source, but their separation is not documented.
- The semantic evaluator and candidate-acceptance rules are insufficiently specified.
- The adapted baselines need clearer implementation details and labeling.
- The coverage of the held-out semantic tests and variability across runs are not reported.
- Important configuration details are missing from the manuscript.
- The aggregate results provide little evidence about how negative examples affect actual repairs.

Detailed comments for authors
-----------------------------
**Novelty**

- Miragent combines retrieval, agent-based planning, reflection, and validation. Its most distinctive feature is the use of deliberately generated bad fixes as repair context. The ablation shows a drop without the Hallucination Agent, but does not establish why these examples help. They could provide useful warnings, additional context, or simply more opportunities for analysis.
- I would compare the Hallucination Agent with fixed anti-patterns or a direct critique of the retrieved fix, using a comparable model-call or token budget. Additional ordinary repair sampling would also be a useful control. This would show whether generating bad fixes adds something beyond spending more computation on the repair.

**Motivation**

- Figure 2(d) does not demonstrate the claimed semantic change in the code as shown. The vector contains ten zero bytes, so the length guard is always true and adding one cannot overflow. Replacing ordinary addition with saturating addition therefore does not change the computed value relative to Figure 2(c). If the example represents a more general case, please show the inputs and behavior that distinguish the two versions. This matters because it is the paper's example of a Miri-passing but semantically incorrect negative fix.
- The Miri-reproducible scope is clearly stated in Section II-A and discussed in Section IV. What remains unclear is how often the Test Generation Agent is needed in the evaluation. Please report how many cases required generated tests, how often those tests exposed the UB, and whether unsuccessful test generation was counted in the results.

**Soundness**

- Section II-C collects library examples partly from the official Miri repository, which also supplies the 438 evaluation cases. This creates a possible overlap, but the manuscript does not describe how it is checked. Please report exact and near-duplicate matches and exclude examples derived from the evaluation test when retrieving for that test. Shared provenance alone does not prove leakage, but the current description does not rule it out.
- Section III-A gives CVE selection criteria and explains how the held-out semantic tests were constructed. Those are useful details, but the Miri revision, selected test and CVE identifiers, and test coverage are still needed. In particular, how were expected behaviors defined for the Miri failing tests, and how were the expert repairs checked? A failing UB example does not by itself specify the intended repaired behavior.
- The Semantic Consistency Evaluator in Section II-E is not described well enough to reproduce. Please specify whether it uses an LLM, rules, or executable checks, and provide the corresponding configuration. The held-out semantic tests are explicitly excluded from repair context, so their role should be distinguished from this in-loop evaluator. It is also unclear whether a semantic mismatch forces rejection or merely lowers the candidate's rank. The acceptance criteria and score combination need to be stated.
- The baseline adaptations are disclosed, but the reported names can obscure what is being compared. On the CVE dataset, Thetis-Lathe's detection output is passed to an LLM rather than repaired by its original rule-based stage. GiantRepair is adapted using Rust-compatible skeletons. These can be useful baselines, but they should be labeled as adaptations and documented in enough detail to assess their capabilities. The paper should also explain how the Thetis-Lathe row is implemented on the Miri dataset.
- The paper states that tests, time limits, iteration budgets, and LLM settings are shared whenever applicable. However, the actual limits and budget allocation in the ablations are not reported. Does removing the Hallucination Agent leave the saved calls unused, or make them available for repair generation? The number of independent runs is also unspecified. On 65 CVEs, one case changes the fix rate by about 1.54 percentage points, so repeated runs and per-case comparisons are important.
- Fix Rate requires both Miri and held-out semantic tests, which is stronger than Miri alone. It still measures success against those tests rather than establishing semantic correctness in general. Report how many patches pass Miri but fail the semantic tests, and inspect a sample of accepted patches independently. The 6.7%-14.4% headline is a relative gain over the average baseline. The strongest-baseline comparisons in Section III-C are more informative and should be equally visible.

**Presentation**

- The issue is missing experimental detail rather than manuscript length. A compact configuration table should give the Miri and Rust versions, model settings, candidate counts, iteration limits, and acceptance thresholds. Section IV discusses practical limitations, but does not address retrieval overlap, evaluator reliability, or run variability.
- Table I reports fix rates and time, but not where repairs improve or fail. A breakdown by UB category and by Miri-versus-semantic-test outcome would make the results easier to interpret. The hallucination ablation on CVEs differs from the full system by only two or three repaired cases per backend; those cases would be worth examining.
- Figure 2 illustrates context construction, but does not trace a complete benchmark repair through the workflow. Show one case where a generated negative example changed the plan and helped produce a valid patch, together with the relevant validation results.
- Replace broad claims that accepted patches are UB-free and semantically consistent with statements about the checks they pass. The phrase "fighting hallucination with hallucination" is less informative than explaining how bad fixes are identified and how downstream agents use them.

Artifact assessment
-------------------
2. Partially Satisfactory, i.e., the artifacts partially contain what is
   declared in the submission form or the paper.

Comments on artifact assessment
-------------------------------
The anonymous repository is accessible and includes implementation files, baseline code, dataset materials, experiment scripts, and summarized results. However, the 101-example UB repair library described in the paper is missing. The ub_example_library directory contains only a placeholder, and its README states that the examples will be released after acceptance. The default Miragent scripts consequently disable Semantic RAG. Thus, substantial materials are available, but the package does not yet include a core component of the evaluated system. I checked availability and inspected files without running the artifact.

Questions for authors’ response
-------------------------------
- How much exact or near-duplicate overlap exists between the 101 library examples and the 438 Miri tests, and what happens when examples from the target test are excluded?
- How is the in-loop Semantic Consistency Evaluator implemented, and can it reject a Miri-passing candidate independently of the held-out tests?
- Does the Hallucination Agent outperform fixed anti-patterns, direct critique, or additional repair sampling under a comparable inference budget?
- What parts of Thetis-Lathe and GiantRepair are retained in the Rust adaptations, and which parts are replaced by author-implemented components?
- How many independent runs were performed, and are the gains consistent across runs and across the same CVE cases?
- Can the authors provide per-case patches and semantic tests, with an independent assessment of whether accepted patches preserve the intended behavior?



Review #2319C
===========================================================================

Overall merit
-------------
2. Weak reject

Novelty
-------
3. Substantial - presents a clearly new idea, method, result, artifact,
   dataset, use case, workflow, or perspective

Rigor
-----
2. Fair - some weaknesses, but the main claims are at least partially
   supported

Relevance
---------
3. High - addresses an important SE problem and is likely to influence
   research or practice under clear assumptions

Verifiability and Transparency
------------------------------
3. Good - Sufficient information is provided to understand the work and
   support verification of the main claims

Presentation
------------
3. Good - clear, well organized, and easy to follow

Paper summary
-------------
This paper proposes Miragent, a multi-agent framework for repairing undefined behavior (UB) in Rust. The key idea is to deliberately generate hallucinated fixes and use them as contrastive priors, together with repair examples retrieved through Semantic RAG. Miragent combines Miri-based UB detection, a Reflection–Plan–Fix workflow, and multi-dimensional patch evaluation. The evaluation on 438 Miri cases and 65 real-world Rust CVEs shows that Miragent consistently improves the fix rate over four baselines across three LLM backends.

Strengths
---------
Interesting idea of hallucination positively.
Evaluation includes real-world vulnerabilities.

Weaknesses
----------
Baseline fairness is a concern.
The real-world dataset is relatively small.

Detailed comments for authors
-----------------------------
Novelty. The idea of deliberately generating hallucinated fixes as contrastive priors is interesting and novel. However, it is unclear how Miragent reliably determines that these generated fixes are truly negative. In particular, a Miri-passing fix may be a valid alternative repair rather than a semantically incorrect one. The authors should clarify the oracle and validation process for identifying negative fixes.

Rigor. The evaluation covers two datasets, four baselines, three LLMs, and ablation studies. However, baseline fairness is a concern because Thetis-Lathe and GiantRepair are substantially adapted for the evaluation. The real-world dataset contains only 65 CVEs, and no repeated runs or statistical analysis are reported. More details are also needed on the construction and validation of the manually created semantic tests.

Relevance. Rust UB repair is an important SE problem, and evaluation on real-world CVEs strengthens the practical relevance.

Verifiability and Transparency. The provided artifact is a strength. However, more details on prompts, baseline adaptations, semantic tests, and the UB knowledge base would improve reproducibility.

Presentation. The paper is generally clear and well organized. However, key components, particularly the Hallucination Agent and semantic consistency evaluation, need more precise explanations.

Questions for authors’ response
-------------------------------
1. How do you verify that the generated hallucinated fixes are truly negative examples?
2. How do you ensure fair baseline comparisons, given that Thetis-Lathe and GiantRepair are substantially adapted?
3. How were the manually constructed semantic consistency tests validated?