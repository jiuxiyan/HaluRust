# UB Example Fix Review

This report reviews every one of the 89 UB examples. No example was deleted.

## Correctness contract

Each case is checked against three requirements:

1. The stored original has an established Miri Undefined Behavior diagnostic.
2. `fixed.rs` compiles and completes without Miri UB under the applicable
   default, Stacked Borrows, Tree Borrows, revision, and per-test flags.
3. The code change addresses the diagnosed root cause. When the UB program has
   no defined functional result, any necessary policy choice is stated rather
   than presented as proof of application-level semantic equivalence.

`S` means a direct root-cause repair. `P` means safety is verified but the fix
contains an explicit application-policy choice (for example wrapping versus
saturating arithmetic). `I` means a sound illustrative replacement for a Miri
negative test whose intended application behavior is not specified.

Current execution evidence is in `fix_validation_report.json`. All 89 fixed
programs pass Miri. Current Miri reproduces 87 original UB diagnostics; one
mixed-width atomic original triggers a Miri ICE and one C-variadic original is
rejected as unsupported before interpretation. Their stored legacy Miri UB
diagnostics remain the original-side evidence.

## Aliasing — 21 cases

| Case | Repair review | Result |
|---|---|---|
| `miri__both_borrows__alias_through_mutation` | Replaces forged aliased references with `Cell`, making shared mutation explicit. | S |
| `miri__both_borrows__aliasing_mut2` | Avoids simultaneously materializing incompatible Rust references and performs the intended accesses through raw pointers. | S |
| `miri__both_borrows__outdated_local` | Performs the assignment before deriving the pointer, so the pointer is not invalidated by the later local write. | S |
| `miri__both_borrows__pass_invalid_shr_option` | Completes raw mutation before creating and passing the shared reference. | S |
| `miri__both_borrows__return_invalid_shr_option` | Mutates the tuple before deriving the returned shared reference. | S |
| `miri__stacked_borrows__illegal_read2` | Passes a raw pointer reborrowed from the live `&mut`, preserving its borrow-stack permission. | S |
| `miri__stacked_borrows__illegal_read4` | Uses the derived reference before the parent raw access that invalidates it. | S |
| `miri__stacked_borrows__illegal_read6` | Removes the reborrow that killed the previously derived raw pointer. | S |
| `miri__stacked_borrows__raw_tracking` | Uses `addr_of_mut!` to derive raw pointers without creating competing mutable references. | S |
| `miri__stacked_borrows__return_invalid_mut` | Completes the whole-value read before creating and returning the field `&mut`. | S |
| `miri__stacked_borrows__shared_rw_borrows_are_weak2` | Keeps the `RefCell` guard alive and removes lifetime laundering through `transmute`. | S |
| `miri__stacked_borrows__unescaped_static` | Derives the offset pointer from the complete static allocation rather than a one-element reference. | S |
| `miri__tree_borrows__cross_tree_update_older` | Retains raw pointers until the final access instead of creating conflicting child references. | S |
| `miri__tree_borrows__frozen_lazy_write_to_surrounding` | Derives the write pointer from the actual mutable field rather than casting a pointer to a neighboring ZST field. | S |
| `miri__tree_borrows__multi_exposed_siblings_disable` | Avoids competing `&mut` siblings and performs exposed-pointer operations through raw pointers. | S |
| `miri__tree_borrows__parent_read_freezes_raw_mut` | Reads through the same raw pointer before writing, avoiding a parent reference that freezes the child. | S |
| `miri__tree_borrows__pass_invalid_mut` | Uses the still-valid mutable reference instead of invalidating it via its parent raw pointer. | S |
| `miri__tree_borrows__return_invalid_mut` | Completes parent access before deriving the field reference returned to the caller. | S |
| `miri__tree_borrows__single_exposed_foreign` | Keeps sibling handles raw rather than creating mutually conflicting mutable references. | S |
| `miri__tree_borrows__single_exposed_only_ro` | Exposes provenance from a mutable pointer before reconstructing a pointer used for writing. | S |
| `miri__tree_borrows__strongly_protected` | Keeps the `Box` owned across the protected call and restricts the callback to mutation rather than deallocation. | S |

## Bounds and pointer arithmetic — 2 cases

| Case | Repair review | Result |
|---|---|---|
| `miri__both_borrows__issue_miri_1050_1` | Reconstructs the `Box<u16>` with its original pointee type and allocation layout. | S |
| `miri__root__zst_local_oob` | Uses a live one-byte allocation before performing a one-byte load; a ZST allocation cannot support that access. | I |

## Compiler intrinsics — 17 cases

| Case | Repair review | Result |
|---|---|---|
| `miri__intrinsics__assume` | Checks all promised conditions and returns before executing `assume` when the contract is false. | P |
| `miri__intrinsics__cttz_nonzero` | Uses `trailing_zeros`, whose contract is defined for zero. | S |
| `miri__intrinsics__disjoint_bitor` | Uses ordinary bitwise OR, which has no disjoint-bits precondition and produces the intended OR value. | S |
| `miri__intrinsics__exact_div1` | Uses `checked_div` and handles zero/overflow explicitly. | P |
| `miri__intrinsics__fast_math_first` | Uses the ordinary remainder operator, which defines the non-finite-input behavior. | P |
| `miri__intrinsics__float_to_int_32_inf1` | Uses Rust's defined saturating float-to-integer cast for infinity. | P |
| `miri__intrinsics__float_to_int_32_nan` | Uses Rust's defined saturating float-to-integer cast for NaN. | P |
| `miri__intrinsics__ptr_offset_from_different_allocs` | Derives both pointers from one array before calling `offset_from`. | S |
| `miri__intrinsics__simd_div_overflow` | Detects `MIN / -1`, substitutes a safe divisor, and explicitly chooses wrapping-style result restoration. | P |
| `miri__intrinsics__simd_shr_too_far` | Masks shift counts into the lane width before `simd_shr`. | P |
| `miri__intrinsics__unchecked_add1` | Replaces overflowing unsigned `unchecked_add` with `wrapping_add`. | P |
| `miri__intrinsics__unchecked_add2` | Replaces overflowing signed `unchecked_add` with `wrapping_add`. | P |
| `miri__intrinsics__unchecked_mul1` | Widens the computation so the mathematical product is representable. | P |
| `miri__intrinsics__unchecked_mul2` | Replaces overflowing signed multiplication with `wrapping_mul`. | P |
| `miri__intrinsics__unchecked_sub1` | Replaces unsigned underflow with an explicit saturating subtraction policy. | P |
| `miri__intrinsics__unchecked_sub2` | Replaces overflowing signed subtraction with `wrapping_sub`. | P |
| `miri__root__unreachable` | Handles the reachable path explicitly instead of asserting it is impossible to the optimizer. | I |

## Concurrency — 6 cases

| Case | Repair review | Result |
|---|---|---|
| `miri__data_race__alloc_read_race` | Publishes the allocation with Release and consumes it with Acquire before access/deallocation. | S |
| `miri__data_race__dealloc_write_race_stack` | Replaces an escaped stack pointer with scoped threads and an atomic value. | S |
| `miri__data_race__fence_after_load` | Makes the shared value atomic and establishes Release/Acquire synchronization before access. | S |
| `miri__data_race__local_variable_alloc_race` | Uses Release/Acquire publication for the pointer and its initialized pointee. | S |
| `miri__data_race__mixed_size_read_write_read` | Uses one `AtomicI32` width and updates its low byte through a full-width atomic operation. | S |
| `miri__data_race__stack_pop_race` | Uses scoped threads so the borrowed stack local outlives the spawned access. | S |

## Function boundaries — 10 cases

| Case | Repair review | Result |
|---|---|---|
| `miri__function_calls__check_arg_abi` | Declares `malloc` with its actual C ABI and frees a non-null result. | S |
| `miri__function_calls__check_arg_count_too_few_args` | Supplies the correct `malloc` argument and matching declaration. | S |
| `miri__function_calls__exported_symbol_abi_mismatch` | Makes the definition, declarations, and function-pointer call uniformly `extern "C"` in all three revisions. | S |
| `miri__function_calls__exported_symbol_wrong_type` | Defines the exported symbol as the function the caller expects. | S |
| `miri__function_pointers__abi_mismatch_array_vs_struct` | Uses an explicit adapter closure to convert the array into the struct argument. | S |
| `miri__function_pointers__abi_mismatch_int_vs_float` | Uses an adapter closure with an explicit numeric conversion rather than transmuting the function type. | P |
| `miri__function_pointers__abi_mismatch_raw_pointer` | Constructs the required wide slice pointer and calls the correctly typed function directly. | S |
| `miri__root__c_variadic_mismatch` | Makes caller and callee consistently non-variadic for the demonstrated two-argument contract. | P |
| `miri__shims__shim_arg_size` | Uses the platform `c_int` parameter type and a valid buffer pointer for `memchr`. | S |
| `miri__tail_calls__cc_mismatch` | Removes the function-pointer transmute and makes the function use the expected Rust ABI. | S |

## Immutable memory — 3 cases

| Case | Repair review | Result |
|---|---|---|
| `miri__concurrency__read_only_atomic_cmpxchg` | Declares the static as `AtomicI32` instead of casting immutable scalar storage. | S |
| `miri__root__modifying_constants` | Uses a mutable local rather than mutating promoted read-only memory through a cast. | S |
| `miri__stacked_borrows__static_memory_modification` | Represents mutable static state with `AtomicUsize` instead of forging `&mut` to an immutable static. | P |

## Invalid memory access — 14 cases

| Case | Repair review | Result |
|---|---|---|
| `miri__both_borrows__issue_miri_1050_2` | Reconstructs and deallocates a `Box` from the same live allocation rather than `NonNull::dangling()`. | S |
| `miri__dangling_pointers__deref_invalid_ptr` | Derives the pointer from a live `u32` allocation instead of treating integer 16 as an address. | I |
| `miri__dangling_pointers__wild_pointer_deref` | Derives the raw pointer from a live stack value, restoring provenance and liveness. | I |
| `miri__root__reading_half_a_pointer` | Addresses the packed pointer field directly and loads it with `read_unaligned`. | S |
| `miri__root__storage_live_dead_var` | Moves `StorageLive` before the MIR access and `StorageDead` after it. | S |
| `miri__intrinsics__simd_masked_load_vector_misaligned` | Selects element alignment because the supplied pointer does not meet vector alignment. | S |
| `miri__unaligned_pointers__intptrcast_alignment_check` | Uses `write_unaligned` for a deliberately unaligned destination. | S |
| `miri__unaligned_pointers__unaligned_ptr2` | Uses `read_unaligned` for a deliberately unaligned source. | S |
| `miri__dangling_pointers__null_pointer_deref` | Converts the nullable raw pointer to `Option<&i32>` before reading and applies an explicit fallback. | P |
| `miri__dangling_pointers__null_pointer_write` | Points to live writable storage before performing the raw-pointer write. | I |
| `miri__provenance__mix_ptrs1` | Uses the pointer carrying the target allocation's provenance when changing its address. | S |
| `miri__provenance__ptr_int_unexposed` | Calls `expose_provenance` before reconstructing the pointer from its integer address. | S |
| `miri__data_race__dealloc_write_race2` | Replaces unsynchronized manual deallocation with shared `Arc` ownership and atomic mutation. | S |
| `miri__tls__tls_static_dealloc` | Copies the TLS value inside its owning thread instead of exporting a pointer past TLS destruction. | S |

## Unsafe API contracts — 2 cases

| Case | Repair review | Result |
|---|---|---|
| `miri__alloc__deallocate_bad_size` | Reuses the exact checked `Layout` for allocation and deallocation and handles allocation failure. | S |
| `miri__alloc__global_system_mixup` | Deallocates through the same allocator instance/family that allocated the block. | S |

## Value validity — 14 cases

| Case | Repair review | Result |
|---|---|---|
| `miri__intrinsics__zero_fn_ptr` | Represents the absence of a callback with `Option<fn()>`. | S |
| `miri__match__deref_in_pattern` | Stores the value outside the inner scope so every nested reference remains live. | S |
| `miri__validity__box_custom_alloc_dangling_ptr` | Implements allocation/deallocation and constructs the `Box` from storage returned by that allocator. | S |
| `miri__validity__cast_fn_ptr_invalid_caller_arg` | Supplies a non-zero value satisfying the callee's scalar valid range. | S |
| `miri__validity__dangling_ref3` | Returns a pointer to static storage instead of a dead local and only then creates the reference. | S |
| `miri__validity__invalid_bool` | Replaces invalid `u8`-to-`bool` transmutation with an explicit non-zero policy. | P |
| `miri__validity__invalid_bool_op` | Converts the byte before boolean comparison, avoiding deferred use of an invalid `bool`. | P |
| `miri__validity__invalid_fnptr_null` | Models the nullable callback directly as `Option<fn()>`; no integer-to-function-pointer transmute remains. | S |
| `miri__validity__nonzero` | Makes the invariant-bearing field private, checks construction, and uses a valid value. | S |
| `miri__validity__wrong_dyn_trait` | Uses a compound trait object whose vtable supports the requested `Debug` operation. | S |
| `miri__uninit__transmute_pair_uninit` | Reads only initialized payload bytes and deliberately skips tuple padding. | S |
| `miri__uninit__uninit_byte_read` | Initializes the vector length and bytes before indexed access. | P |
| `miri__validity__uninit_raw_ptr` | Initializes every raw-pointer slot to the valid null raw-pointer representation before `assume_init`. | P |
| `miri__weak_memory__weak_uninit` | Allocates an initialized `AtomicUsize` before sharing it between threads. | S |

## Totals

- Direct root-cause repairs (`S`): 63
- Explicit policy choices (`P`): 21
- Sound illustrative replacements (`I`): 5
- Current fixed Miri passes: 89/89
- Deleted examples: 0

No `P` or `I` case can establish equivalence to an unspecified external
application. They are correct UB-removal examples under the policy documented
in the fixed code; downstream use must choose the policy appropriate to the
real program.
